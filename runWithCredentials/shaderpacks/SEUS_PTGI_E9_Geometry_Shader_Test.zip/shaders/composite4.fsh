#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"


const bool colortex6MipmapEnabled = false;


in vec4 texcoord;

in vec3 lightVector;
in vec3 worldLightVector;
in vec3 worldSunVector;

in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSkyUp;
in vec3 colorTorchlight;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;

#include "lib/GBufferData.inc"


// vec4 GetViewPosition(in vec2 coord, in float depth) 
// {	
// 	vec4 tcoord = vec4(coord.xy, 0.0, 0.0);

// 	vec4 fragposition = gbufferProjectionInverse * vec4(tcoord.s * 2.0f - 1.0f, tcoord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
// 		 fragposition /= fragposition.w;

	
// 	return fragposition;
// }





#include "lib/Materials.inc"


 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int y=v.x*v.y;
   return t(f(floor(pow(float(y),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int y=v.x*v.y;
   return d(f(floor(pow(float(y),.333333))));
 }
 vec3 e(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,y=d();
   ivec2 f=ivec2(v.x*m.x,v.y*m.y);
   float z=float(f.y/y),i=float(int(f.x+mod(m.x*z,y))/y);
   i+=floor(m.x*z/y);
   vec3 r=vec3(0.,0.,i);
   r.x=mod(f.x+mod(m.x*z,y),y);
   r.y=mod(f.y,y);
   r.xyz=floor(r.xyz);
   r/=y;
   r.xyz=r.xzy;
   return r;
 }
 vec2 x(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 r;
   r.x=mod(i.x+y*x,f.x);
   float s=i.x+y*x;
   r.y=i.y+floor(s/f.x)*x;
   r+=.5;
   r/=f;
   return r;
 }
 vec3 s(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 r=ivec2(i.x*m.x,i.y*m.y);
   float z=float(r.y/y),s=float(int(r.x+mod(m.x*z,y))/y);
   s+=floor(m.x*z/y);
   vec3 n=vec3(0.,0.,s);
   n.x=mod(r.x+mod(m.x*z,y),y);
   n.y=mod(r.y,y);
   n.xyz=floor(n.xyz);
   n/=y;
   n.xyz=n.xzy;
   return n;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,m.x);
   float f=i.x+x*y;
   r.y=i.y+floor(f/m.x)*y;
   r+=.5;
   r/=m;
   r.xy*=.5;
   return r;
 }
 vec3 e(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 n(vec3 v)
 {
   int y=d();
   v*=1./y;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 r(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 e()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,y=floor(v-.0001),x=floor(f-.0001);
   return y-x;
 }
 vec3 m(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/y;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 i,vec2 f,vec2 r,vec4 m,vec4 n,inout float y,out vec2 x)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(n.x==8||n.x==9||n.x==79||n.x<1.||!z||n.x==20.||n.x==171.||min(abs(i.x),abs(i.z))>.2)
     y=1.;
   if(n.x==50.||n.x==76.)
     {
       y=0.;
       if(i.y<.5)
         y=1.;
     }
   if(n.x==51)
     y=0.;
   if(n.x>255)
     y=0.;
   vec3 s,c;
   if(i.x>.5)
     s=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(i.x<-.5)
       s=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(i.y>.5)
         s=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(i.y<-.5)
           s=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(i.z>.5)
             s=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(i.z<-.5)
               s=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   x=clamp((f.xy-r.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,t=.15;
   if(n.x==10.||n.x==11.)
     {
       if(abs(i.y)<.01&&z||i.y>.99)
         h=.1,t=.1,y=0.;
       else
          y=1.;
     }
   if(n.x==51)
     h=.5,t=.1;
   if(n.x==76)
     h=.2,t=.2;
   if(n.x-255.+39.>=102.&&n.x-255.+39.<=112.)
     t=.025,h=.025;
   s=normalize(m.xyz);
   c=normalize(cross(s,i.xyz)*sign(m.w));
   vec3 d=v.xyz+mix(s*h,-s*h,vec3(x.x));
   d.xyz+=mix(c*h,-c*h,vec3(x.y));
   d.xyz-=i.xyz*t;
   return d;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA p(Ray v)
 {
   DDA i;
   i.mapPos=floor(v.origin);
   i.mapPosOrigin=i.mapPos;
   i.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.rayStep=sign(v.direction);
   i.sideDist=(sign(v.direction)*(i.mapPos-v.origin)+sign(v.direction)*.5+.5)*i.deltaDist;
   i.mask=vec3(0.);
   return i;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 i[2],out float f,out float y)
 {
   float z,x,r,s;
   f=(i[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(i[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   z=(i[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   x=(i[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(i[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   s=(i[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   f=max(max(f,z),r);
   y=min(min(y,x),s);
 }
 vec3 d(const vec3 v,const vec3 i,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(i+v)*.5,n=(i-v)*.5,f=y-z,r=vec3(0.);
   r+=vec3(sign(f.x),0.,0.)*step(abs(abs(f.x)-n.x),x);
   r+=vec3(0.,sign(f.y),0.)*step(abs(abs(f.y)-n.y),x);
   r+=vec3(0.,0.,sign(f.z))*step(abs(abs(f.z)-n.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 i,Ray m,out vec2 r)
 {
   vec3 y=m.inv_direction*(v-m.origin),f=m.inv_direction*(i-m.origin),n=min(f,y),s=max(f,y);
   vec2 x=max(n.xx,n.yz);
   float z=max(x.x,x.y);
   x=min(s.xx,s.yz);
   float t=min(x.x,x.y);
   r.x=z;
   r.y=t;
   return t>max(z,0.);
 }
 bool d(const vec3 v,const vec3 i,Ray m,inout float y,inout vec3 x)
 {
   vec3 f=m.inv_direction*(v-m.origin),s=m.inv_direction*(i-m.origin),n=min(s,f),r=max(s,f);
   vec2 c=max(n.xx,n.yz);
   float z=max(c.x,c.y);
   c=min(r.xx,r.yz);
   float t=min(c.x,c.y);
   bool e=t>max(z,0.)&&max(z,0.)<y;
   if(e)
     x=d(v,i,m.origin+m.direction*z),y=z;
   return e;
 }
 vec3 e(vec3 v,vec3 i,vec3 y,vec3 z,int x)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 f=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(f.xy,f.z-.0006*s),0).x;
   r*=saturate(dot(i,y));
   {
     vec4 n=texture2DLod(shadowcolor1,f.xy-vec2(0.,.5),4);
     float t=abs(n.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,i,t),c=shadow2DLod(shadowtex0,vec3(f.xy-vec2(0.,.5),f.z+1e-06),4).x;
     r=mix(r,r*h,1.-c);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 y,vec3 i,vec3 x,vec3 z,int f)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(y),n=m(s+x*.99);
   float t=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*t),3).x;
   r*=saturate(dot(i,x));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 i,vec3 y,vec3 z,int x)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 f=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(f.xy,f.z-.0006*s),2).x;
   r*=saturate(dot(i,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct VcxfcrgVbw{float bgoSMWoOlk;float UchydvPYLr;float bRfUKhvDSW;float DqzEnDHRia;vec3 YNIRJTVYcH;};
 vec4 h(VcxfcrgVbw v)
 {
   vec4 i;
   v.YNIRJTVYcH=max(vec3(0.),v.YNIRJTVYcH);
   i.x=v.bgoSMWoOlk;
   v.YNIRJTVYcH=pow(v.YNIRJTVYcH,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.YNIRJTVYcH.x,v.bRfUKhvDSW);
   i.z=PackTwo16BitTo32Bit(v.YNIRJTVYcH.y,v.DqzEnDHRia);
   i.w=PackTwo16BitTo32Bit(v.YNIRJTVYcH.z,v.UchydvPYLr);
   return i;
 }
 VcxfcrgVbw i(vec4 v)
 {
   VcxfcrgVbw i;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),f=UnpackTwo16BitFrom32Bit(v.z),n=UnpackTwo16BitFrom32Bit(v.w);
   i.bgoSMWoOlk=v.x;
   i.bRfUKhvDSW=m.y;
   i.DqzEnDHRia=f.y;
   i.UchydvPYLr=n.y;
   i.YNIRJTVYcH=pow(vec3(m.x,f.x,n.x),vec3(8.));
   return i;
 }
 VcxfcrgVbw D(vec2 v)
 {
   vec2 y=1./vec2(viewWidth,viewHeight),x=vec2(viewWidth,viewHeight);
   v=(floor(v*x)+.5)*y;
   return i(texture2DLod(colortex5,v,0));
 }
 float D(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void D(inout float v,inout float i,float m,float y,vec3 f,float x)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,y);
   #else
   v*=mix(3.4,3.4,y);
   #endif
   float r=dot(f,vec3(1.));
   i*=1.-pow(y,.4);
   i/=m*.1+2e-06;
   i*=4.;
   i*=.6;
   float z=m/(r+1e-07)*.2+4e-08;
   z=min(z,1.);
   z=mix(z,1.,pow(y,.25));
   if(x<.12)
     i=0.;
 }
 float D(vec3 v,vec3 y,float m)
 {
   float i=dot(abs(v-y),vec3(.3333));
   i*=m;
   i*=.18;
   return i;
 }
 void e(inout vec3 v,vec2 y,vec3 x)
 {}
 float h(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool d(vec3 v,float y,Ray i,bool z,inout float f,inout vec3 x)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(z)
     return false;
   if(y>=66.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),i,f,x);
   r=m;
   #else
   if(y<40.)
     return m=d(v,v+vec3(1.,1.,1.),i,f,x),m;
   if(y==40.||y>=42.&&y<=53.)
     m=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),i,f,x),r=r||m;
   if(y==41.||y>=54.&&y<=65.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,f,x),r=r||m;
   if(y==42.||y==45.||y==46.||y==51.||y==52.||y==53.||y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
     {
       float s=.5;
       if(y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
         s=0.;
       m=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),i,f,x);
       r=r||m;
     }
   if(y==42.||y==44.||y==47.||y==50.||y==52.||y==53.||y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
     {
       float s=.5;
       if(y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
         s=0.;
       m=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),i,f,x);
       r=r||m;
     }
   if(y==43.||y==44.||y==48.||y==50.||y==51.||y==53.||y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
     {
       float s=.5;
       if(y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
         s=0.;
       m=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),i,f,x);
       r=r||m;
     }
   if(y==43.||y==45.||y==49.||y==50.||y==51.||y==52.||y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
     {
       float s=.5;
       if(y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
         s=0.;
       m=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),i,f,x);
       r=r||m;
     }
   if(y>=66.&&y<=81.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,f,x),r=r||m;
   if(y==67.||y==68.||y==69.||y==71.||y==72.||y==73.||y==75.||y==76.||y==77.||y==79.||y==80.||y==81.)
     {
       float s=8.,c=8.;
       if(y==67.||y==69.||y==71.||y==73.||y==75.||y==77.||y==79.||y==81.)
         s=0.;
       if(y==68.||y==69.||y==72.||y==73.||y==76.||y==77.||y==80.||y==81.)
         c=16.;
       m=d(v+vec3(s,6.,7.)/16.,v+vec3(c,9.,9.)/16.,i,f,x);
       r=r||m;
       m=d(v+vec3(s,12.,7.)/16.,v+vec3(c,15.,9.)/16.,i,f,x);
       r=r||m;
     }
   if(y>=70.&&y<=81.)
     {
       float s=8.,t=8.;
       if(y>=70.&&y<=73.||y>=78.&&y<=81.)
         t=16.;
       if(y>=74.&&y<=81.)
         s=0.;
       m=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,t)/16.,i,f,x);
       r=r||m;
       m=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,t)/16.,i,f,x);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=82.&&y<=85.)
     {
       vec3 s=vec3(0),c=vec3(0);
       if(y==82.)
         s=vec3(0,0,0),c=vec3(16,16,3);
       if(y==83.)
         s=vec3(0,0,13),c=vec3(16,16,16);
       if(y==85.)
         s=vec3(0,0,0),c=vec3(3,16,16);
       if(y==84.)
         s=vec3(13,0,0),c=vec3(16,16,16);
       m=d(v+s/16.,v+c/16.,i,f,x);
       r=r||m;
     }
   if(y>=86.&&y<=101.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(y>=86.&&y<=93.)
         {
           float t=0.;
           if(y>=90.&&y<=93.)
             t=13.;
           s=vec3(0.,t,0.)/16.;
           c=vec3(16.,t+3.,16.)/16.;
         }
       if(y>=94.&&y<=97.)
         {
           float t=13.;
           if(y==96.||y==97.)
             t=0.;
           s=vec3(0.,0.,t)/16.;
           c=vec3(16.,16.,t+3.)/16.;
         }
       if(y>=98.&&y<=101.)
         {
           float t=13.;
           if(y==98.||y==99.)
             t=0.;
           s=vec3(t,0.,0.)/16.;
           c=vec3(t+3.,16.,16.)/16.;
         }
       m=d(v+s,v+c,i,f,x);
       r=r||m;
     }
   if(y>=102.&&y<=112.)
     {
       vec3 s=vec3(0.),n=vec3(1.);
       if(y>=102.&&y<=109.)
         {
           float t=float(y)-float(102.)+1.;
           n.y=t*2./16.;
         }
       if(y==110.)
         n.y=.0625;
       if(y==111.)
         s=vec3(1.,0.,1.)/16.,n=vec3(15.,1.,15.)/16.;
       if(y==112.)
         s=vec3(1.,0.,1.)/16.,n=vec3(15.,.5,15.)/16.;
       m=d(v+s,v+n,i,f,x);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 float i(float v,float y)
 {
   return 1./(v*(1.-y)+y);
 }
 void D(inout vec3 v,in vec3 y,in vec3 i,vec3 z,float x)
 {
   float r=length(y);
   r*=pow(eyeBrightnessSmooth.y/240.f,6.f);
   r*=rainStrength;
   float s=pow(exp(-r*3e-06),4.);
   vec3 f=vec3(dot(colorSkyUp,vec3(1.)));
   v=mix(f,v,vec3(s));
 }
 vec4 G(vec2 v)
 {
   vec2 y=vec2(v.x,(v.y-floor(mod(FRAME_TIME*60.f,60.f)))/60.f);
   return texture2DLod(colortex4,y.xy,0);
 }
 float G(vec3 v,float y)
 {
   vec3 i=v.xyz+cameraPosition.xyz,m=refract(worldLightVector,vec3(0.,1.,0.),.750188);
   i+=m*((v.y+cameraPosition.y)/m.y);
   vec4 f=G(mod(i.xz/4.,vec2(1.)))*13.;
   float s=pow(y/2.,.5),r=pow(f.x,saturate(s*.5+.5));
   r=mix(r,f.y,saturate(s-1.));
   r=mix(r,f.z,saturate(s-2.));
   r=mix(r,f.w,saturate(s-3.));
   return r;
 }
 float m(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 float n(vec3 v,vec3 y)
 {
   return dot(abs(v-y),vec3(.3333));
 }
 vec3 c(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 i[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   y=(floor(y*64.)+.5)/64.;
   vec3 r=texture2D(noisetex,y).xyz,f=vec3(sqrt(.2),sqrt(2.),1.61803);
   r=mod(r+vec3(f)*mod(frameCounter,64.f),vec3(1.));
   return r;
 }
 vec3 D(float v,float m,float i,vec3 y)
 {
   vec3 r;
   r.x=i*cos(v);
   r.y=i*sin(v);
   r.z=m;
   vec3 s=abs(y.y)<.999?vec3(0,0,1):vec3(1,0,0),f=normalize(cross(y,vec3(0.,1.,1.))),x=cross(f,y);
   return f*r.x+x*r.y+y*r.z;
 }
 vec3 G(vec2 v,float y,vec3 x)
 {
   float i=2*3.14159*v.x,s=sqrt((1-v.y)/(1+(y*y-1)*v.y)),f=sqrt(1-s*s);
   return D(i,s,f,x);
 }
 float a(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 a(in vec2 v,in float y,in vec3 x)
 {
   float i=a(y),f=2*3.14159*v.x,s=pow(v.y,1.f/(i+1.f)),z=sqrt(1-s*s);
   return D(f,s,z,x);
 }
 float R(vec2 v)
 {
   return texture2DLod(colortex3,v,0).w;
 }
 vec4 D(sampler2D v,float i,bool y,float f,float s,float x,float z)
 {
   GBufferData m=GetGBufferData();
   GBufferDataTransparent r=GetGBufferDataTransparent();
   bool t=r.depth<m.depth;
   if(t)
     m.normal=r.normal,m.smoothness=r.smoothness,m.metalness=0.,m.mcLightmap=r.mcLightmap,m.depth=r.depth;
   vec4 d=GetViewPosition(texcoord.xy,m.depth),p=gbufferModelViewInverse*vec4(d.xyz,1.),a=gbufferModelViewInverse*vec4(d.xyz,0.);
   vec3 e=normalize(d.xyz),o=normalize(a.xyz),w=normalize((gbufferModelViewInverse*vec4(m.normal,0.)).xyz);
   float G=GetDepthLinear(texcoord.xy),l=1.-m.smoothness,k=l*l,g=D(m.smoothness,m.metalness);
   int b=0;
   vec4 H=texture2DLod(colortex6,texcoord.xy,b);
   float Y=Luminance(H.xyz);
   if(g<.001)
     return H;
   float U=i*.9;
   U*=min(k*15.,1.1);
   U*=mix(H.w,1.,z);
   vec2 W=vec2(0.);
   if(y)
     {
       vec2 T=c(texcoord.xy).xy*.99+.005;
       W=T-.5;
     }
   float T=0.,S=1.1,u=h(f,m.totalTexGrad)/(k+.0001),L=h(s,m.totalTexGrad);
   vec4 V=vec4(0.),M=vec4(0.);
   float P=0.;
   vec4 F=vec4(vec3(x),1.);
   F.xyz=vec3(.5);
   F.xyz*=H.w*.95+.05;
   float I=m.smoothness;
   int B=0;
   for(int A=-1;A<=1;A++)
     {
       for(int E=-1;E<=1;E++)
         {
           vec2 N=(vec2(A,E)+W)/vec2(viewWidth,viewHeight)*U,C=texcoord.xy+N.xy;
           float O=length(N*vec2(viewWidth,viewHeight));
           C=clamp(C,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
           vec4 J=texture2DLod(colortex6,C,b);
           vec3 q=GetNormals(C);
           float Q=GetDepthLinear(C),K=pow(saturate(dot(m.normal,q)),u),j=exp(-(abs(Q-G)*S)),Z=exp(-(n(J.xyz,H.xyz)*T)),X=exp(-abs(I-R(C))*L),ab=K*j*Z*X;
           V+=vec4(pow(length(J.xyz),F.x)*normalize(J.xyz+1e-05),J.w)*ab;
           P+=ab;
           M+=J;
           B++;
         }
     }
   V/=P+.0001;
   V.xyz=pow(length(V.xyz),1./F.x)*normalize(V.xyz+1e-06);
   vec4 J=V;
   if(P<.001)
     J=H;
   return J;
 }
 void main()
 {
   GBufferData v=GetGBufferData();
   GBufferDataTransparent y=GetGBufferDataTransparent();
   MaterialMask s=CalculateMasks(v.materialID),f=CalculateMasks(y.materialID);
   bool x=y.depth<v.depth;
   if(x)
     v.normal=y.normal,v.smoothness=y.smoothness,v.metalness=0.,v.mcLightmap=y.mcLightmap,v.depth=y.depth,f.sky=0.;
   vec4 r=GetViewPosition(texcoord.xy,v.depth),c=gbufferModelViewInverse*vec4(r.xyz,1.),m=gbufferModelViewInverse*vec4(r.xyz,0.);
   vec3 n=normalize(r.xyz),z=normalize(m.xyz),t=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz);
   float e=ExpToLinearDepth(v.depth),h=1.-v.smoothness,p=h*h,a=D(v.smoothness,v.metalness);
   int d=0;
   vec4 G=texture2DLod(colortex6,texcoord.xy,d),H=G;
   float k=1.-v.smoothness,w=k*k;
   vec3 l=t,C=-z,b=normalize(reflect(-C,l)+l*w),o=normalize(C+b);
   float J=saturate(dot(l,b)),g=saturate(dot(l,C)),Y=saturate(dot(l,o)),R=saturate(dot(b,o)),T=v.metalness*.98+.02,S=pow(1.-R,5.),U=T+(1.-T)*S,W=w/2.,X=i(J,W)*i(g+.8,W),V=J*U*X;
   H.xyz*=mix(vec3(1.),v.albedo.xyz,vec3(v.metalness));
   V=mix(V,1.,v.metalness);
   if(v.depth>.99999)
     V=0.;
   if(f.water>.5&&isEyeInWater>0)
     {
       if(length(refract(C,l,1.3333))<.5)
         V=1.;
       else
          V=0.;
     }
   V*=D(v.smoothness,v.metalness);
   vec4 F=texture2DLod(colortex3,texcoord.xy,0);
   vec3 P=pow(F.xyz,vec3(2.2)),A=P;
   A*=120.;
   UnderwaterFog(A,length(m.xyz),z,colorSkyUp,colorSunlight);
   A=mix(A,H.xyz,vec3(V));
   A+=P*v.metalness*120.;
   if(f.sky<.5&&!x&&isEyeInWater<1)
     LandAtmosphericScattering(A,r.xyz,n.xyz,z.xyz,worldSunVector.xyz,1.);
   D(A,r.xyz,n.xyz,z.xyz,1.);
   {
     if(isEyeInWater>0)
       {
         float E=BlueNoiseTemporal(texcoord.xy).x,j=20.;
         vec3 B=vec3(0.),u=(gbufferModelViewInverse*vec4(0.,0.,0.,1.)).xyz;
         for(int M=0;M<10;M++)
           {
             float L=float(M+E)/float(10);
             vec3 I=z.xyz*j*L+u;
             if(length(m.xyz)<length(I-u))
               {
                 break;
               }
             float q,K;
             vec3 N=WorldPosToShadowProjPos(I.xyz,q,K);
             float Q=shadow2DLod(shadowtex0,vec3(N.xy,N.z+1e-06),3).x,Z=abs(texture2DLod(shadowcolor1,N.xy-vec2(0.,.5),4).x*256.-(I.y+cameraPosition.y)),O=GetCausticsComposite(I,worldLightVector,Z),ac=shadow2DLod(shadowtex0,vec3(N.xy-vec2(0.,.5),N.z+1e-06),4).x;
             Q=mix(Q,Q*O,1.-ac);
             B+=Q*exp(-GetWaterAbsorption()*(j*L))*exp(-GetWaterAbsorption()*Z);
           }
         float Q=dot(refract(worldLightVector,vec3(0.,-1.,0.),.750019),z.xyz),Z=Q*Q,L=PhaseMie(.8,Q,Z);
         A+=TintUnderwaterDepth(B*colorSunlight*GetWaterFogColor()*.075*L);
       }
   }
   A/=120.;
   A*=exp(-e*blindness);
   A=pow(A.xyz,vec3(.454545));
   gl_FragData[0]=vec4(A,F.w);
 };





/* DRAWBUFFERS:3 */
