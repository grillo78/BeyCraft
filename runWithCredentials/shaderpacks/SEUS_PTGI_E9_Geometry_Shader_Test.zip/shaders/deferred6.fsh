#version 330 compatibility

/*
 _______ _________ _______  _______  _
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////











const int 		shadowMapResolution 	= 4096;
const float 	shadowDistance 			= 120.0; // Shadow distance. Set lower if you prefer nicer close shadows. Set higher if you prefer nicer distant shadows. [80.0 120.0 180.0 240.0]
const float 	shadowIntervalSize 		= 1.0f;
const bool 		shadowHardwareFiltering0 = true;

const bool 		shadowtexMipmap = true;
const bool 		shadowtex1Mipmap = false;
const bool 		shadowtex1Nearest = false;
const bool 		shadowcolor0Mipmap = false;
const bool 		shadowcolor0Nearest = false;
const bool 		shadowcolor1Mipmap = false;
const bool 		shadowcolor1Nearest = false;

const float shadowDistanceRenderMul = 1.0f;

const int 		RGB8 					= 0;
const int 		RGBA8 					= 0;
const int 		RGBA16 					= 0;
const int 		RGBA16F 				= 0;
const int 		RGBA32F 				= 0;
const int 		RG16 					= 0;
const int 		RGB16 					= 0;
const int 		R11F_G11F_B10F 			= 0;
const int 		colortex0Format 			= RGB8;
const int 		colortex1Format 			= RGBA16;
const int 		colortex2Format 			= RGBA16;
const int 		colortex3Format 			= RGBA16;
const int 		colortex4Format 			= RGBA16F;
const int 		colortex5Format 			= RGBA32F;
const int 		colortex6Format 			= RGBA16F;
const int 		colortex7Format 			= RGBA16;


const int 		superSamplingLevel 		= 0;

const float		sunPathRotation 		= -40.0f;

const int 		noiseTextureResolution  = 64;

const float 	ambientOcclusionLevel 	= 0.06f;


const bool colortex7Clear = false;

const float wetnessHalflife = 100.0;
const float drynessHalflife = 100.0;




in vec4 texcoord;

in vec3 lightVector;
in vec3 worldLightVector;
in vec3 worldSunVector;

in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSkyUp;
in vec3 colorTorchlight;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;









#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/Materials.inc"



/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// vec4 GetViewPosition(in vec2 coord, in float depth) 
// {	
// 	vec2 tcoord = coord;
// 	TemporalJitterProjPosInv01(tcoord);

// 	vec4 fragposition = gbufferProjectionInverse * vec4(tcoord.s * 2.0f - 1.0f, tcoord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
// 		 fragposition /= fragposition.w;

	
// 	return fragposition;
// }




/////////////////////////STRUCTS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////STRUCTS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#include "lib/GBufferData.inc"




struct Plane {
	vec3 normal;
	vec3 origin;
};

struct Intersection {
	vec3 pos;
	float distance;
	float angle;
};

/////////////////////////STRUCT FUNCTIONS//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////STRUCT FUNCTIONS//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





Intersection 	RayPlaneIntersectionWorld(in Ray ray, in Plane plane)
{
	float rayPlaneAngle = dot(ray.direction, plane.normal);

	float planeRayDist = 100000000.0f;
	vec3 intersectionPos = ray.direction * planeRayDist;

	if (rayPlaneAngle > 0.0001f || rayPlaneAngle < -0.0001f)
	{
		planeRayDist = dot((plane.origin), plane.normal) / rayPlaneAngle;
		intersectionPos = ray.direction * planeRayDist;
		intersectionPos = -intersectionPos;

		intersectionPos += cameraPosition.xyz;
	}

	Intersection i;

	i.pos = intersectionPos;
	i.distance = planeRayDist;
	i.angle = rayPlaneAngle;

	return i;
}

Intersection 	RayPlaneIntersection(in Ray ray, in Plane plane)
{
	float rayPlaneAngle = dot(ray.direction, plane.normal);

	float planeRayDist = 100000000.0f;
	vec3 intersectionPos = ray.direction * planeRayDist;

	if (rayPlaneAngle > 0.0001f || rayPlaneAngle < -0.0001f)
	{
		planeRayDist = dot((plane.origin - ray.origin), plane.normal) / rayPlaneAngle;
		intersectionPos = ray.origin + ray.direction * planeRayDist;
		// intersectionPos = -intersectionPos;

		// intersectionPos += cameraPosition.xyz;
	}

	Intersection i;

	i.pos = intersectionPos;
	i.distance = planeRayDist;
	i.angle = rayPlaneAngle;

	return i;
}








vec3 CalculateSunlightVisibility(vec4 screenSpacePosition, MaterialMask mask) {				//Calculates shadows
	if (rainStrength >= 0.99f)
		return vec3(1.0f);



	//if (shadingStruct.directionect > 0.0f) {
		float distance = sqrt(  screenSpacePosition.x * screenSpacePosition.x 	//Get surface distance in meters
							  + screenSpacePosition.y * screenSpacePosition.y
							  + screenSpacePosition.z * screenSpacePosition.z);

		vec4 ssp = screenSpacePosition;

		// if (isEyeInWater > 0.5)
		// {
		// 	ssp.xy *= 0.82;
		// }

		vec3 worldPos = (gbufferModelViewInverse * ssp).xyz;


		float dist;
		float distortFactor;
		vec3 shadowProjPos = WorldPosToShadowProjPos(worldPos.xyz, dist, distortFactor);

		// float fademult = 0.15f;
			// shadowMult = clamp((shadowDistance * 1.4f * fademult) - (distance * fademult), 0.0f, 1.0f);	//Calculate shadowMult to fade shadows out

		float shadowMult = 1.0;

		float shading = 0.0;
		vec3 result = vec3(0.0);

		if (shadowMult > 0.0) 
		{

			float diffthresh = dist * 1.0f + 0.10f;
				  diffthresh *= 2.0f / (shadowMapResolution / 2048.0f);
				  //diffthresh /= shadingStruct.directionect + 0.1f;






			float vpsSpread = 0.105 / distortFactor;

			float avgDepth = 0.0;
			float minDepth = 11.0;
			int c;

			for (int i = -1; i <= 1; i++)
			{
				for (int j = -1; j <= 1; j++)
				{
					vec2 lookupCoord = shadowProjPos.xy + (vec2(i, j) / shadowMapResolution) * 8.0 * vpsSpread;
					//avgDepth += pow(texture2DLod(shadowtex1, lookupCoord, 2).x, 4.1);
					float depthSample = texture2DLod(shadowtex1, lookupCoord, 2).x;
					minDepth = min(minDepth, depthSample);
					avgDepth += pow(min(max(0.0, shadowProjPos.z - depthSample) * 1.0, 0.025), 2.0);
					c++;
				}
			}

			avgDepth /= c;
			avgDepth = pow(avgDepth, 1.0 / 2.0);

			// float penumbraSize = min(abs(shadowProjPos.z - minDepth), 0.15);
			float penumbraSize = avgDepth;

			//if (mask.leaves > 0.5)
			//{
				//penumbraSize = 0.02;
			//}

			int count = 0;
			float spread = penumbraSize * 0.055 * vpsSpread + 0.55 / shadowMapResolution;


			vec3 noise = BlueNoiseTemporal(texcoord.st);

			diffthresh *= 0.5 + avgDepth * 50.0;





















			const int latSamples = 5;
			const int lonSamples = 5;

			for (int i = 0; i < 25; i++)
			{
				float fi = float(i + noise.x) / 10.0;
				float r = float(i + noise.x) * 3.14159265 * 2.0 * 1.61;

				vec2 radialPos = vec2(cos(r), sin(r));
				vec2 coordOffset = radialPos * spread * sqrt(fi) * 2.0;

				shading += shadow2DLod(shadowtex0, vec3(shadowProjPos.st + coordOffset, shadowProjPos.z - 0.0012f * diffthresh - (noise.z * 0.0001)), 0).x;
				count += 1;
			}
			shading /= count;



			result = vec3(shading);


			// stained glass shadow
			{
				float stainedGlassShadow = shadow2DLod(shadowtex0, vec3(shadowProjPos.st - vec2(0.5, 0.0), shadowProjPos.z - 0.0012 * diffthresh), 2).x;
				vec3 stainedGlassColor = texture2DLod(shadowcolor, vec2(shadowProjPos.st - vec2(0.5, 0.0)), 2).rgb;
				stainedGlassColor *= stainedGlassColor;
				result = mix(result, result * stainedGlassColor, vec3(1.0 - stainedGlassShadow));

				// result = mix(result, vec3(0.0), vec3(1.0 - stainedGlassShadow));
			}

			// CAUSTICS
			// water shadow (caustics)
			{
				float waterDepth = abs(texture2DLod(shadowcolor1, shadowProjPos.st - vec2(0.0, 0.5), 4).x * 256.0 - (worldPos.y + cameraPosition.y));

				// float caustics = GetCausticsDeferred(worldPos, waterDepth);
				vec3 caustics = vec3(0.0);
				caustics.r = GetCausticsDeferred(worldPos, 										worldLightVector, waterDepth);
				// caustics.g = GetCausticsDeferred(worldPos + vec3(0.003 * waterDepth, 0.0, 0.0), worldLightVector, waterDepth);
				// caustics.b = GetCausticsDeferred(worldPos + vec3(0.006 * waterDepth, 0.0, 0.0), worldLightVector, waterDepth);
				caustics.g = caustics.r;
				caustics.b = caustics.r;

				float waterShadow = shadow2DLod(shadowtex0, vec3(shadowProjPos.st - vec2(0.0, 0.5), shadowProjPos.z - 0.0012 * diffthresh), 4).x;
				result = mix(result, 
					// result * caustics * exp(-GetWaterAbsorption() * waterDepth), 
					result * caustics, 
					vec3(1.0 - waterShadow));
			}
		}



		result = mix(vec3(1.0), result, shadowMult);





		return result;
	//} else {
	//	return vec3(0.0f);
	//}
}


vec3 SubsurfaceScatteringSunlight(vec3 worldNormal, vec3 worldPos, vec3 albedo)
{
	vec4 shadowProjPos = shadowModelView * vec4(worldPos.xyz, 1.0);	//Transform from world space to shadow space
	shadowProjPos = shadowProjection * shadowProjPos;
	shadowProjPos /= shadowProjPos.w;

	float dist = sqrt(shadowProjPos.x * shadowProjPos.x + shadowProjPos.y * shadowProjPos.y);
	float distortFactor = (1.0f - SHADOW_MAP_BIAS) + dist * SHADOW_MAP_BIAS;
	shadowProjPos.xy *= 0.95f / distortFactor;
	shadowProjPos.z = mix(shadowProjPos.z, 0.5, 0.8);
	shadowProjPos = shadowProjPos * 0.5f + 0.5f;		//Transform from shadow space to shadow map coordinates

	//move to quadrant
	shadowProjPos.xy *= 0.5;
	shadowProjPos.xy += 0.5;

	float subsurfaceDepth = 0.0;
	float depthThresh = 0.0005;
	float weights = 0.0;

	vec2 dither = BlueNoiseTemporal(texcoord.st).xy - 0.5;

	for (int i = -1; i <= 1; i++)
	{
		for (int j = -1; j <= 1; j++)
		{
			vec2 coordOffset = vec2(i + dither.x, j + dither.y) * 0.001;
			subsurfaceDepth += max(0.0, (shadowProjPos.z - texture2DLod(shadowtex1, shadowProjPos.xy + coordOffset, 0).x) / depthThresh);
			weights += 1.0;
		}
	}

	subsurfaceDepth /= weights;

	// subsurfaceDepth = exp(-subsurfaceDepth * 10.0);

	vec3 subsurfaceColor = 1.0 - (normalize(albedo.rgb + 0.000001) * 0.3);
	// vec3 subsurfaceColor = 1.0 - (albedo.rgb * 0.5);
	// vec3 subsurfaceColor = 1.0 - (albedo.rgb * 0.8);
	// vec3 subsurfaceColor = 1.0 - vec3(0.7, 0.5, 0.1);
	vec3 sss = exp(-subsurfaceDepth * subsurfaceColor * 6.0) * (1.0 - subsurfaceColor);

	return sss * 24.0 * colorSunlight;
}


float ScreenSpaceShadow(vec3 origin, vec3 normal, MaterialMask mask)
{
	if (mask.sky > 0.5 || rainStrength >= 0.999)
	{
		return 1.0;
	}

	if (isEyeInWater > 0.5)
	{
		origin.xy /= 0.82;
	}

	vec3 viewDir = normalize(origin.xyz);


	float nearCutoff = 0.50;
	float traceBias = 0.015;


	//Prevent self-intersection issues
	float viewDirDiff = dot(fwidth(viewDir), vec3(0.333333));


	vec3 rayPos = origin;
	vec3 rayDir = lightVector * 0.01;
	rayDir *= viewDirDiff * 2000.001;
	rayDir *= -origin.z * 0.28 + nearCutoff;


	rayPos += rayDir * -origin.z * 0.000017 * traceBias;



	float randomness = rand(texcoord.st + sin(frameTimeCounter)).x;

	rayPos += rayDir * randomness;



	float zThickness = 0.025 * -origin.z;

	float shadow = 1.0;

	float numSamplesf = 64.0;
	//numSamplesf /= -origin.z * 0.125 + nearCutoff;

	int numSamples = int(numSamplesf);


	float shadowStrength = 0.9;

	if (mask.grass > 0.5)
	{
		shadowStrength = 0.6;
	}
	if (mask.leaves > 0.5)
	{
		shadowStrength = 0.4;
	}

	// shadowStrength = pow(shadowStrength, exp2(-length(origin) * 0.05));

	// vec3 prevRayProjPos = ProjectBack(rayPos);

	for (int i = 0; i < 6; i++)
	{
		float fi = float(i) / float(12);

		rayPos += rayDir;

		vec2 rayProjPos = ProjectBack(rayPos).xy;


		TemporalJitterProjPos01(rayProjPos);




		// vec2 pixelPos = floor(rayProjPos.xy * vec2(viewWidth, viewHeight));
		// vec2 pixelPosPrev = floor(prevRayProjPos.xy * vec2(viewWidth, viewHeight));
		// if (pixelPos.x == pixelPosPrev.x || pixelPos.y == pixelPosPrev.y)
		// {
		// 	continue;
		// }

		// prevRayProjPos = rayProjPos;

		/*
		float sampleDepth = GetDepthLinear(rayProjPos.xy);

		float depthDiff = -rayPos.z - sampleDepth;
		*/

		vec3 samplePos = GetViewPositionNoJitter(rayProjPos.xy, GetDepth(rayProjPos.xy)).xyz;

		float depthDiff = samplePos.z - rayPos.z - 0.02 * -origin.z * traceBias;

		if (depthDiff > 0.0 && depthDiff < zThickness)
		{
			shadow *= 1.0 - shadowStrength;
		}
	}

	return shadow;
}


float OrenNayar(vec3 normal, vec3 eyeDir, vec3 lightDir)
{
	const float PI = 3.14159;
	const float roughness = 0.55;

	// interpolating normals will change the length of the normal, so renormalize the normal.



	// normal = normalize(normal + surface.lightVector * pow(clamp(dot(eyeDir, surface.lightVector), 0.0, 1.0), 5.0) * 0.5);

	// normal = normalize(normal + eyeDir * clamp(dot(normal, eyeDir), 0.0f, 1.0f));

	// calculate intermediary values
	float NdotL = dot(normal, lightDir);
	float NdotV = dot(normal, eyeDir);

	float angleVN = acos(NdotV);
	float angleLN = acos(NdotL);

	float alpha = max(angleVN, angleLN);
	float beta = min(angleVN, angleLN);
	float gamma = dot(eyeDir - normal * dot(eyeDir, normal), lightDir - normal * dot(lightDir, normal));

	float roughnessSquared = roughness * roughness;

	// calculate A and B
	float A = 1.0 - 0.5 * (roughnessSquared / (roughnessSquared + 0.57));

	float B = 0.45 * (roughnessSquared / (roughnessSquared + 0.09));

	float C = sin(alpha) * tan(beta);

	// put it all together
	float L1 = max(0.0, NdotL) * (A + B * max(0.0, gamma) * C);

	//return max(0.0f, surface.NdotL * 0.99f + 0.01f);
	return clamp(L1, 0.0f, 1.0f);
}





float GetCoverage(in float coverage, in float density, in float clouds)
{
	clouds = clamp(clouds - (1.0f - coverage), 0.0f, 1.0f -density) / (1.0f - density);
		clouds = max(0.0f, clouds * 1.1f - 0.1f);
	 clouds = clouds = clouds * clouds * (3.0f - 2.0f * clouds);
	 // clouds = pow(clouds, 1.0f);
	return clouds;
}

float   CalculateSunglow(vec3 npos, vec3 lightVector) {

	float curve = 4.0f;

	vec3 halfVector2 = normalize(-lightVector + npos);
	float factor = 1.0f - dot(halfVector2, npos);

	return factor * factor * factor * factor;
}

vec4 CloudColor(in vec4 worldPosition, in float sunglow, in vec3 worldLightVector, in float altitude, in float thickness, const bool isShadowPass)
{

	float cloudHeight = altitude;
	float cloudDepth  = thickness;
	float cloudUpperHeight = cloudHeight + (cloudDepth / 2.0f);
	float cloudLowerHeight = cloudHeight - (cloudDepth / 2.0f);

	//worldPosition.xz /= 1.0f + max(0.0f, length(worldPosition.xz - cameraPosition.xz) / 5000.0f);

	vec3 p = worldPosition.xyz / 150.0f;



	float t = frameTimeCounter * 1.0f;
		  t *= 0.5;


	 p += (Get3DNoise(p * 2.0f + vec3(0.0f, t * 0.00f, 0.0f)) * 2.0f - 1.0f) * 0.10f;
	 p.z -= (Get3DNoise(p * 0.25f + vec3(0.0f, t * 0.00f, 0.0f)) * 2.0f - 1.0f) * 0.45f;
	 p.x -= (Get3DNoise(p * 0.125f + vec3(0.0f, t * 0.00f, 0.0f)) * 2.0f - 1.0f) * 2.2f;
	p.xz -= (Get3DNoise(p * 0.0525f + vec3(0.0f, t * 0.00f, 0.0f)) * 2.0f - 1.0f) * 2.7f;


	p.x *= 0.5f;
	p.x -= t * 0.01f;

	vec3 p1 = p * vec3(1.0f, 0.5f, 1.0f)  + vec3(0.0f, t * 0.01f, 0.0f);
	float noise  = 	Get3DNoise(p * vec3(1.0f, 0.5f, 1.0f) + vec3(0.0f, t * 0.01f, 0.0f));	p *= 2.0f;	p.x -= t * 0.057f;	vec3 p2 = p;
		  noise += (2.0f - abs(Get3DNoise(p) * 2.0f - 0.0f)) * (0.15f);						p *= 3.0f;	p.xz -= t * 0.035f;	p.x *= 2.0f;	vec3 p3 = p;
		  noise += (3.0f - abs(Get3DNoise(p) * 3.0f - 0.0f)) * (0.050f);						p *= 3.0f;	p.xz -= t * 0.035f;	vec3 p4 = p;
		  noise += (3.0f - abs(Get3DNoise(p) * 3.0f - 0.0f)) * (0.015f);						p *= 3.0f;	p.xz -= t * 0.035f;
		  if (!isShadowPass)
		  {
		 		noise += ((Get3DNoise(p))) * (0.022f);												p *= 3.0f;
		  		noise += ((Get3DNoise(p))) * (0.009f);
		  }
		  noise /= 1.475f;

	//cloud edge
	float coverage = 0.701f;
		  coverage = mix(coverage, 0.97f, rainStrength);

		  float dist = length(worldPosition.xz - cameraPosition.xz * 0.5);
		  coverage *= max(0.0f, 1.0f - dist / 14000.0f);
	float density = 0.1f + rainStrength * 0.3;

	if (isShadowPass)
	{
		return vec4(GetCoverage(0.4f, 0.4f, noise));
	}

	noise = GetCoverage(coverage, density, noise);

	const float lightOffset = 0.4f;



	float sundiff = Get3DNoise(p1 + worldLightVector.xyz * lightOffset);
		  sundiff += (2.0f - abs(Get3DNoise(p2 + worldLightVector.xyz * lightOffset / 2.0f) * 2.0f - 0.0f)) * (0.55f);
		  				float largeSundiff = sundiff;
		  				      largeSundiff = -GetCoverage(coverage, 0.0f, largeSundiff * 1.3f);
		  sundiff += (3.0f - abs(Get3DNoise(p3 + worldLightVector.xyz * lightOffset / 5.0f) * 3.0f - 0.0f)) * (0.045f);
		  sundiff += (3.0f - abs(Get3DNoise(p4 + worldLightVector.xyz * lightOffset / 8.0f) * 3.0f - 0.0f)) * (0.015f);
		  sundiff /= 1.5f;

		  sundiff *= max(0.0f, 1.0f - dist / 14000.0f);

		  sundiff = -GetCoverage(coverage * 1.0f, 0.0f, sundiff);
	float secondOrder 	= pow(clamp(sundiff * 1.1f + 1.45f, 0.0f, 1.0f), 4.0f);
	float firstOrder 	= pow(clamp(largeSundiff * 1.1f + 1.66f, 0.0f, 1.0f), 3.0f);



	float directLightFalloff = firstOrder * secondOrder;
	float anisoBackFactor = mix(clamp(pow(noise, 1.6f) * 2.5f, 0.0f, 1.0f), 1.0f, pow(sunglow, 1.0f));

		  directLightFalloff *= anisoBackFactor;
	 	  directLightFalloff *= mix(11.5f, 1.0f, pow(sunglow, 0.5f));

	//noise *= saturate(1.0 - directLightFalloff);

	vec3 colorDirect = colorSunlight * 51.215f;
		 colorDirect = mix(colorDirect, colorDirect * vec3(0.2f, 0.2f, 0.2f), timeMidnight);
		 colorDirect *= 1.0f + pow(sunglow, 2.0f) * 120.0f * pow(directLightFalloff, 1.1f) * (1.0 - rainStrength * 0.8);
		 colorDirect *= 1.0f;


	vec3 colorAmbient = mix(colorSkylight, colorSunlight * 2.0f, vec3(0.15f)) * 0.93f;
		 colorAmbient = mix(colorAmbient, vec3(0.4) * Luminance(colorSkylight), vec3(rainStrength));
		 colorAmbient *= mix(1.0f, 0.3f, timeMidnight);
		 colorAmbient = mix(colorAmbient, colorAmbient * 3.0f + colorSunlight * 0.05f, vec3(clamp(pow(1.0f - noise, 12.0f) * 1.0f, 0.0f, 1.0f)));




	directLightFalloff *= mix(1.0, 0.085, rainStrength);

	//directLightFalloff += (pow(Get3DNoise(p3), 2.0f) * 0.5f + pow(Get3DNoise(p3 * 1.5f), 2.0f) * 0.25f) * 0.02f;
	//directLightFalloff *= Get3DNoise(p2);

	vec3 color = mix(colorAmbient, colorDirect, vec3(min(1.0f, directLightFalloff)));

	color *= 1.0f;

	color = mix(color, color * 0.9, rainStrength);


	vec4 result = vec4(color.rgb, noise);

	return result;

}

void CloudPlane(inout vec3 color, vec3 viewDir, vec3 worldVector, float linearDepth, MaterialMask mask, vec3 worldLightVector, vec3 lightVector)
{
	//Initialize view ray
	//vec4 worldVector = gbufferModelViewInverse * (vec4(-GetScreenSpacePosition(texcoord.st).xyz, 0.0));


	// Ray viewRay;

	// viewRay.direction = normalize(worldVector.xyz);
	// viewRay.origin = vec3(0.0f);
	Ray viewRay = MakeRay
	(
		vec3(0.0),
		normalize(worldVector.xyz)
	);

	float sunglow = CalculateSunglow(viewDir, lightVector);



	float cloudsAltitude = 540.0f;
	float cloudsThickness = 150.0f;

	float cloudsUpperLimit = cloudsAltitude + cloudsThickness * 0.5f;
	float cloudsLowerLimit = cloudsAltitude - cloudsThickness * 0.5f;

	float density = 1.0f;

	float planeHeight = cloudsUpperLimit;
	float stepSize = 25.5f;
	planeHeight -= cloudsThickness * 0.85f;


	Plane pl;
	pl.origin = vec3(0.0f, cameraPosition.y - planeHeight, 0.0f);
	pl.normal = vec3(0.0f, 1.0f, 0.0f);

	Intersection i = RayPlaneIntersectionWorld(viewRay, pl);

	vec3 original = color.rgb;

	if (i.angle < 0.0f)
	{
		if (i.distance < linearDepth || mask.sky > 0.5 || linearDepth >= far - 0.1)
		{
			vec4 cloudSample = CloudColor(vec4(i.pos.xyz * 0.5f + vec3(30.0f) + vec3(1000.0, 0.0, 0.0), 1.0f), sunglow, worldLightVector, cloudsAltitude, cloudsThickness, false);
			 	 cloudSample.a = min(1.0f, cloudSample.a * density);


			float cloudDist = length(i.pos.xyz - cameraPosition.xyz);

			const vec3 absorption = vec3(0.2, 0.4, 1.0);

			cloudSample.rgb *= exp(-cloudDist * absorption * 0.0001 * saturate(1.0 - sunglow * 2.0) * (1.0 - rainStrength));

			cloudSample.a *= exp(-cloudDist * (0.0002 + rainStrength * 0.0009));


			//cloudSample.rgb *= sin(cloudDist * 0.3) * 0.5 + 0.5;

			color.rgb = mix(color.rgb, cloudSample.rgb * 1.0f, cloudSample.a);

		}
	}
}


float G1V(float dotNV, float k)
{
	return 1.0 / (dotNV * (1.0 - k) + k);
}

vec3 SpecularGGX(vec3 N, vec3 V, vec3 L, float roughness, float F0)
{
	float alpha = roughness * roughness;

	vec3 H = normalize(V + L);

	float dotNL = saturate(dot(N, L));
	float dotNV = saturate(dot(N, V));
	float dotNH = saturate(dot(N, H));
	float dotLH = saturate(dot(L, H));

	float F, D, vis;

	float alphaSqr = alpha * alpha;
	float pi = 3.14159265359;
	float denom = dotNH * dotNH * (alphaSqr - 1.0) + 1.0;
	D = alphaSqr / (pi * denom * denom);

	float dotLH5 = pow(1.0f - dotLH, 5.0);
	F = F0 + (1.0 - F0) * dotLH5;

	float k = alpha / 2.0;
	vis = G1V(dotNL, k) * G1V(dotNV, k);

	vec3 specular = vec3(dotNL * D * F * vis) * colorSunlight;

	//specular = vec3(0.1);
	#ifndef PHYSICALLY_BASED_MAX_ROUGHNESS
	specular *= saturate(pow(1.0 - roughness, 0.7) * 2.0);
	#endif


	return specular;
}




 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int n(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int f()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int n()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return n(f(floor(pow(float(x),.333333))));
 }
 vec3 x(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,z=f();
   ivec2 i=ivec2(v.x*m.x,v.y*m.y);
   float y=float(i.y/z),r=float(int(i.x+mod(m.x*y,z))/z);
   r+=floor(m.x*y/z);
   vec3 s=vec3(0.,0.,r);
   s.x=mod(i.x+mod(m.x*y,z),z);
   s.y=mod(i.y,z);
   s.xyz=floor(s.xyz);
   s/=z;
   s.xyz=s.xzy;
   return s;
 }
 vec2 v(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=f();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float z=i.z;
   vec2 r;
   r.x=mod(i.x+z*x,m.x);
   float s=i.x+z*x;
   r.y=i.y+floor(s/m.x)*x;
   r+=.5;
   r/=m;
   return r;
 }
 vec3 d(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,z=n();
   ivec2 f=ivec2(i.x*m.x,i.y*m.y);
   float y=float(f.y/z),r=float(int(f.x+mod(m.x*y,z))/z);
   r+=floor(m.x*y/z);
   vec3 s=vec3(0.,0.,r);
   s.x=mod(f.x+mod(m.x*y,z),z);
   s.y=mod(f.y,z);
   s.xyz=floor(s.xyz);
   s/=z;
   s.xyz=s.xzy;
   return s;
 }
 vec2 d(vec3 v,int z)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 i=v.xzy*z;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 f;
   f.x=mod(i.x+x*z,m.x);
   float s=i.x+x*z;
   f.y=i.y+floor(s/m.x)*z;
   f+=.5;
   f/=m;
   f.xy*=.5;
   return f;
 }
 vec3 f(vec3 v,int z)
 {
   return v*=1./z,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int z)
 {
   return v*=1./z,v=v+vec3(.5),v;
 }
 vec3 m(vec3 v)
 {
   int m=n();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=f();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 r(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,x=floor(v-.0001),z=floor(i-.0001);
   return x-z;
 }
 vec3 p(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),z=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/z;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 i,vec2 f,vec2 m,vec4 s,vec4 x,inout float z,out vec2 r)
 {
   bool y=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   y=!y;
   if(x.x==8||x.x==9||x.x==79||x.x<1.||!y||x.x==20.||x.x==171.||min(abs(i.x),abs(i.z))>.2)
     z=1.;
   if(x.x==50.||x.x==76.)
     {
       z=0.;
       if(i.y<.5)
         z=1.;
     }
   if(x.x==51)
     z=0.;
   if(x.x>255)
     z=0.;
   vec3 t,c;
   if(i.x>.5)
     t=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(i.x<-.5)
       t=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(i.y>.5)
         t=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(i.y<-.5)
           t=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(i.z>.5)
             t=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(i.z<-.5)
               t=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   r=clamp((f.xy-m.xy)*100000.,vec2(0.),vec2(1.));
   float w=.15,Y=.15;
   if(x.x==10.||x.x==11.)
     {
       if(abs(i.y)<.01&&y||i.y>.99)
         w=.1,Y=.1,z=0.;
       else
          z=1.;
     }
   if(x.x==51)
     w=.5,Y=.1;
   if(x.x==76)
     w=.2,Y=.2;
   if(x.x-255.+39.>=102.&&x.x-255.+39.<=112.)
     Y=.025,w=.025;
   t=normalize(s.xyz);
   c=normalize(cross(t,i.xyz)*sign(s.w));
   vec3 n=v.xyz+mix(t*w,-t*w,vec3(r.x));
   n.xyz+=mix(c*w,-c*w,vec3(r.y));
   n.xyz-=i.xyz*Y;
   return n;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA e(Ray v)
 {
   DDA i;
   i.mapPos=floor(v.origin);
   i.mapPosOrigin=i.mapPos;
   i.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.rayStep=sign(v.direction);
   i.sideDist=(sign(v.direction)*(i.mapPos-v.origin)+sign(v.direction)*.5+.5)*i.deltaDist;
   i.mask=vec3(0.);
   return i;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 i[2],out float f,out float z)
 {
   float x,r,y,s;
   f=(i[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   z=(i[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(i[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(i[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   y=(i[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   s=(i[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   f=max(max(f,x),y);
   z=min(min(z,r),s);
 }
 vec3 d(const vec3 v,const vec3 i,vec3 z)
 {
   const float x=1e-05;
   vec3 y=(i+v)*.5,m=(i-v)*.5,s=z-y,f=vec3(0.);
   f+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-m.x),x);
   f+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-m.y),x);
   f+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-m.z),x);
   return normalize(f);
 }
 bool e(const vec3 v,const vec3 i,Ray m,out vec2 f)
 {
   vec3 z=m.inv_direction*(v-m.origin),x=m.inv_direction*(i-m.origin),s=min(x,z),c=max(x,z);
   vec2 r=max(s.xx,s.yz);
   float y=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float t=min(r.x,r.y);
   f.x=y;
   f.y=t;
   return t>max(y,0.);
 }
 bool d(const vec3 v,const vec3 i,Ray m,inout float z,inout vec3 x)
 {
   vec3 y=m.inv_direction*(v-m.origin),s=m.inv_direction*(i-m.origin),f=min(s,y),c=max(s,y);
   vec2 r=max(f.xx,f.yz);
   float t=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float n=min(r.x,r.y);
   bool Y=n>max(t,0.)&&max(t,0.)<z;
   if(Y)
     x=d(v,i,m.origin+m.direction*t),z=t;
   return Y;
 }
 vec3 e(vec3 v,vec3 i,vec3 z,vec3 x,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 s=p(v);
   float t=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*t),0).x;
   f*=saturate(dot(i,z));
   {
     vec4 m=texture2DLod(shadowcolor1,s.xy-vec2(0.,.5),4);
     float r=abs(m.x*256.-(v.y+cameraPosition.y)),c=GetCausticsComposite(v,i,r),n=shadow2DLod(shadowtex0,vec3(s.xy-vec2(0.,.5),s.z+1e-06),4).x;
     f=mix(f,f*c,1.-n);
   }
   f=TintUnderwaterDepth(f);
   return f*(1.-rainStrength);
 }
 vec3 f(vec3 v,vec3 i,vec3 z,vec3 x,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 f=m(v),s=p(f+z*.99);
   float t=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*t),3).x;
   r*=saturate(dot(i,z));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 i,vec3 z,vec3 x,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 s=p(v);
   float t=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*t),2).x;
   f*=saturate(dot(i,z));
   f=TintUnderwaterDepth(f);
   return f*(1.-rainStrength);
 }struct VcxfcrgVbw{float bgoSMWoOlk;float UchydvPYLr;float bRfUKhvDSW;float DqzEnDHRia;vec3 YNIRJTVYcH;};
 vec4 h(VcxfcrgVbw v)
 {
   vec4 i;
   v.YNIRJTVYcH=max(vec3(0.),v.YNIRJTVYcH);
   i.x=v.bgoSMWoOlk;
   v.YNIRJTVYcH=pow(v.YNIRJTVYcH,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.YNIRJTVYcH.x,v.bRfUKhvDSW);
   i.z=PackTwo16BitTo32Bit(v.YNIRJTVYcH.y,v.DqzEnDHRia);
   i.w=PackTwo16BitTo32Bit(v.YNIRJTVYcH.z,v.UchydvPYLr);
   return i;
 }
 VcxfcrgVbw i(vec4 v)
 {
   VcxfcrgVbw i;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),s=UnpackTwo16BitFrom32Bit(v.z),f=UnpackTwo16BitFrom32Bit(v.w);
   i.bgoSMWoOlk=v.x;
   i.bRfUKhvDSW=m.y;
   i.DqzEnDHRia=s.y;
   i.UchydvPYLr=f.y;
   i.YNIRJTVYcH=pow(vec3(m.x,s.x,f.x),vec3(8.));
   return i;
 }
 VcxfcrgVbw c(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),z=vec2(viewWidth,viewHeight);
   v=(floor(v*z)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float c(float v,float z)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+z,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void c(inout float v,inout float i,float m,float z,vec3 f,float x)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,z);
   #else
   v*=mix(3.4,3.4,z);
   #endif
   float s=dot(f,vec3(1.));
   i*=1.-pow(z,.4);
   i/=m*.1+2e-06;
   i*=4.;
   i*=.6;
   float r=m/(s+1e-07)*.2+4e-08;
   r=min(r,1.);
   r=mix(r,1.,pow(z,.25));
   if(x<.12)
     i=0.;
 }
 float c(vec3 v,vec3 z,float m)
 {
   float i=dot(abs(v-z),vec3(.3333));
   i*=m;
   i*=.18;
   return i;
 }
 void e(inout vec3 v,vec2 z,vec3 x)
 {}
 float e(float v,float z)
 {
   return v/(z*20.01+1.);
 }
 bool d(vec3 v,float z,Ray i,bool x,inout float f,inout vec3 y)
 {
   bool m=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(x)
     return false;
   if(z>=66.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),i,f,y);
   m=r;
   #else
   if(z<40.)
     return r=d(v,v+vec3(1.,1.,1.),i,f,y),r;
   if(z==40.||z>=42.&&z<=53.)
     r=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),i,f,y),m=m||r;
   if(z==41.||z>=54.&&z<=65.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,f,y),m=m||r;
   if(z==42.||z==45.||z==46.||z==51.||z==52.||z==53.||z==54.||z==57.||z==58.||z==63.||z==64.||z==65.)
     {
       float s=.5;
       if(z==54.||z==57.||z==58.||z==63.||z==64.||z==65.)
         s=0.;
       r=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),i,f,y);
       m=m||r;
     }
   if(z==42.||z==44.||z==47.||z==50.||z==52.||z==53.||z==54.||z==56.||z==59.||z==62.||z==64.||z==65.)
     {
       float s=.5;
       if(z==54.||z==56.||z==59.||z==62.||z==64.||z==65.)
         s=0.;
       r=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),i,f,y);
       m=m||r;
     }
   if(z==43.||z==44.||z==48.||z==50.||z==51.||z==53.||z==55.||z==56.||z==60.||z==62.||z==63.||z==65.)
     {
       float s=.5;
       if(z==55.||z==56.||z==60.||z==62.||z==63.||z==65.)
         s=0.;
       r=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),i,f,y);
       m=m||r;
     }
   if(z==43.||z==45.||z==49.||z==50.||z==51.||z==52.||z==55.||z==57.||z==61.||z==62.||z==63.||z==64.)
     {
       float s=.5;
       if(z==55.||z==57.||z==61.||z==62.||z==63.||z==64.)
         s=0.;
       r=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),i,f,y);
       m=m||r;
     }
   if(z>=66.&&z<=81.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,f,y),m=m||r;
   if(z==67.||z==68.||z==69.||z==71.||z==72.||z==73.||z==75.||z==76.||z==77.||z==79.||z==80.||z==81.)
     {
       float s=8.,c=8.;
       if(z==67.||z==69.||z==71.||z==73.||z==75.||z==77.||z==79.||z==81.)
         s=0.;
       if(z==68.||z==69.||z==72.||z==73.||z==76.||z==77.||z==80.||z==81.)
         c=16.;
       r=d(v+vec3(s,6.,7.)/16.,v+vec3(c,9.,9.)/16.,i,f,y);
       m=m||r;
       r=d(v+vec3(s,12.,7.)/16.,v+vec3(c,15.,9.)/16.,i,f,y);
       m=m||r;
     }
   if(z>=70.&&z<=81.)
     {
       float s=8.,t=8.;
       if(z>=70.&&z<=73.||z>=78.&&z<=81.)
         t=16.;
       if(z>=74.&&z<=81.)
         s=0.;
       r=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,t)/16.,i,f,y);
       m=m||r;
       r=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,t)/16.,i,f,y);
       m=m||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(z>=82.&&z<=85.)
     {
       vec3 s=vec3(0),c=vec3(0);
       if(z==82.)
         s=vec3(0,0,0),c=vec3(16,16,3);
       if(z==83.)
         s=vec3(0,0,13),c=vec3(16,16,16);
       if(z==85.)
         s=vec3(0,0,0),c=vec3(3,16,16);
       if(z==84.)
         s=vec3(13,0,0),c=vec3(16,16,16);
       r=d(v+s/16.,v+c/16.,i,f,y);
       m=m||r;
     }
   if(z>=86.&&z<=101.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(z>=86.&&z<=93.)
         {
           float t=0.;
           if(z>=90.&&z<=93.)
             t=13.;
           s=vec3(0.,t,0.)/16.;
           c=vec3(16.,t+3.,16.)/16.;
         }
       if(z>=94.&&z<=97.)
         {
           float t=13.;
           if(z==96.||z==97.)
             t=0.;
           s=vec3(0.,0.,t)/16.;
           c=vec3(16.,16.,t+3.)/16.;
         }
       if(z>=98.&&z<=101.)
         {
           float t=13.;
           if(z==98.||z==99.)
             t=0.;
           s=vec3(t,0.,0.)/16.;
           c=vec3(t+3.,16.,16.)/16.;
         }
       r=d(v+s,v+c,i,f,y);
       m=m||r;
     }
   if(z>=102.&&z<=112.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(z>=102.&&z<=109.)
         {
           float t=float(z)-float(102.)+1.;
           c.y=t*2./16.;
         }
       if(z==110.)
         c.y=.0625;
       if(z==111.)
         s=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(z==112.)
         s=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       r=d(v+s,v+c,i,f,y);
       m=m||r;
     }
   #endif
   #endif
   return m;
 }
 vec3 D(vec3 v)
 {
   float z=fract(frameCounter*.0123456);
   int i=n(),s=f();
   vec3 x=BlueNoiseTemporal(texcoord.xy).xyz,c=BlueNoiseTemporal(texcoord.xy+.1).xyz,y=v,r=Fract01(cameraPosition.xyz+.5)+vec3(0.,1.7,0.),t=r;
   r=f(r,i);
   Ray m=MakeRay(r*i-vec3(1.),y);
   vec3 w=vec3(1.),Y=vec3(0.);
   for(int e=0;e<1;e++)
     {
       vec3 a=vec3(floor(m.origin)),k=abs(vec3(length(m.direction))/(m.direction+.0001)),p=sign(m.direction),o=(sign(m.direction)*(a-m.origin)+sign(m.direction)*.5+.5)*k,H;
       vec4 D=vec4(0.);
       vec3 h=vec3(0.);
       float G=.5;
       for(int R=0;R<190;R++)
         {
           h=a/float(i);
           vec2 l=d(h,i);
           D=texture2DLod(shadowcolor,l,0);
           if(abs(D.w*255.-130.)<.5)
             Y+=.06125*w*colorTorchlight*G;
           else
             {
               if(D.w*255.<254.f&&R!=0)
                 {
                   break;
                 }
             }
           H=step(o.xyz,o.yzx)*step(o.xyz,o.zxy);
           o+=H*k;
           a+=H*p;
           G=1.;
         }
       Y+=D.xyz;
     }
   Y*=1.;
   return Y;
 }
 vec3 D(vec3 i,vec3 z)
 {
   i+=Fract01(cameraPosition.xyz+.5)-.5;
   vec3 x=s(i+z*.1),r=c(v(x)).YNIRJTVYcH;
   return r;
 }
 vec3 D(vec2 v,vec3 i,float z,vec3 y)
 {
   vec3 x=texture2DLod(colortex6,v,0).xyz;
   return x;
 }
 void main()
 {
   GBufferData v=GetGBufferData();
   MaterialMask z=CalculateMasks(v.materialID);
   vec4 i=GetViewPosition(texcoord.xy,v.depth),s=gbufferModelViewInverse*vec4(i.xyz,1.),m=gbufferModelViewInverse*vec4(i.xyz,0.);
   vec3 x=normalize(i.xyz),f=normalize(m.xyz),y=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz);
   float r=length(i.xyz);
   vec3 t=vec3(0.);
   if(z.grass>.5)
     y=vec3(0.,1.,0.);
   vec3 n=D(texcoord.xy,v.normal,v.depth,i.xyz)*10.,Y=n*v.albedo.xyz;
   const float w=75.;
   if(r>w)
     {
       vec3 a=FromSH(skySHR,skySHG,skySHB,y);
       a=mix(a,vec3(.2)*(dot(y,vec3(0.,1.,0.))*.35+.65)*Luminance(colorSkylight),vec3(rainStrength));
       a*=v.mcLightmap.y;
       vec3 e=a*v.albedo.xyz*2.5;
       const float k=3.7;
       e+=v.mcLightmap.x*colorTorchlight*v.albedo.xyz*.025*k;
       vec3 p=normalize(v.albedo.xyz+.0001)*pow(length(v.albedo.xyz),1.)*colorSunlight*.13*v.mcLightmap.y;
       e+=p*v.albedo.xyz*5.;
       float h=.3;
       Y=mix(Y,e,vec3(saturate(r*h-w*h)));
     }
   t.xyz=Y;
   #ifdef HELD_LIGHT
   {
     float k=float(heldBlockLightValue+heldBlockLightValue2)/16.,p=OrenNayar(y,-f,-f),o=1./(dot(m.xyz,m.xyz)+.3);
     t+=v.albedo.xyz*k*o*p*colorTorchlight*.3;
   }
   #endif
   float k=24.*(1.-rainStrength),o=dot(y,worldLightVector),a=OrenNayar(y,-f,worldLightVector);
   if(z.leaves>.5)
     a=mix(a,.5,.5);
   if(z.grass>.5)
     v.metalness=0.;
   vec3 p=CalculateSunlightVisibility(i,z);
   #ifdef SUNLIGHT_LEAK_FIX
   float H=saturate(v.mcLightmap.y*100.);
   if(isEyeInWater<1)
     p*=H;
   #endif
   if(isEyeInWater<1)
     p*=ScreenSpaceShadow(i.xyz,v.normal.xyz,z);
   t+=TintUnderwaterDepth(DoNightEyeAtNight(a*v.albedo.xyz*p*k*colorSunlight,timeMidnight));
   vec3 e=SpecularGGX(y,-f,worldLightVector,1.-v.smoothness,v.metalness*.98+.02)*k*p;
   e*=mix(vec3(1.),v.albedo.xyz,vec3(v.metalness));
   if(isEyeInWater<.5)
     t*=1.-c(v.smoothness,v.metalness)*v.metalness,t+=DoNightEyeAtNight(e,timeMidnight);
   if(z.sky>.5||v.depth>1.)
     {
       vec3 h=f.xyz;
       if(isEyeInWater>0)
         h.xyz=refract(h.xyz,vec3(0.,-1.,0.),1.2533);
       t=SkyShading(h.xyz,worldSunVector.xyz,rainStrength);
       vec3 G=AtmosphereAbsorption(h.xyz);
       t+=v.albedo.xyz*G*.5;
       t+=RenderSunDisc(h,worldSunVector)*G*2000.*(1.-rainStrength);
       CloudPlane(t,x,-h,r,z,worldLightVector,lightVector);
     }
   if(z.glowstone>.5)
     t.xyz+=v.albedo.xyz*GI_LIGHT_BLOCK_INTENSITY;
   if(z.torch>.5)
     t.xyz+=v.albedo.xyz*pow(length(v.albedo.xyz),2.)*.5*GI_LIGHT_TORCH_INTENSITY;
   if(z.lava>.5)
     t+=v.albedo.xyz*.75*GI_LIGHT_BLOCK_INTENSITY;
   if(z.fire>.5)
     t+=v.albedo.xyz*3.*GI_LIGHT_TORCH_INTENSITY;
   float h=0.;
   t*=.001;
   t=LinearToGamma(t);
   t+=rand(texcoord.xy+sin(frameTimeCounter))*(1./65535.);
   gl_FragData[0]=vec4(t.xyz,1.);
 };




/* DRAWBUFFERS:3 */
