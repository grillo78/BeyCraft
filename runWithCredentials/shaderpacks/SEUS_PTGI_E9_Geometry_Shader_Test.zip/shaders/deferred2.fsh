#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/






in vec4 texcoord;



#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBufferData.inc"



 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int n(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int f()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int n()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return n(f(floor(pow(float(x),.333333))));
 }
 vec3 d(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,y=f();
   ivec2 n=ivec2(v.x*m.x,v.y*m.y);
   float z=float(n.y/y),i=float(int(n.x+mod(m.x*z,y))/y);
   i+=floor(m.x*z/y);
   vec3 r=vec3(0.,0.,i);
   r.x=mod(n.x+mod(m.x*z,y),y);
   r.y=mod(n.y,y);
   r.xyz=floor(r.xyz);
   r/=y;
   r.xyz=r.xzy;
   return r;
 }
 vec2 x(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=f();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 r;
   r.x=mod(i.x+y*x,m.x);
   float t=i.x+y*x;
   r.y=i.y+floor(t/m.x)*x;
   r+=.5;
   r/=m;
   return r;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=n();
   ivec2 f=ivec2(i.x*m.x,i.y*m.y);
   float z=float(f.y/y),r=float(int(f.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 t=vec3(0.,0.,r);
   t.x=mod(f.x+mod(m.x*z,y),y);
   t.y=mod(f.y,y);
   t.xyz=floor(t.xyz);
   t/=y;
   t.xyz=t.xzy;
   return t;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,m.x);
   float f=i.x+x*y;
   r.y=i.y+floor(f/m.x)*y;
   r+=.5;
   r/=m;
   r.xy*=.5;
   return r;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=n();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=f();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,x=floor(v-.0001),y=floor(i-.0001);
   return x-y;
 }
 vec3 m(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/y;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 i,vec2 m,vec2 x,vec4 f,vec4 n,inout float y,out vec2 r)
 {
   bool t=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   t=!t;
   if(n.x==8||n.x==9||n.x==79||n.x<1.||!t||n.x==20.||n.x==171.||min(abs(i.x),abs(i.z))>.2)
     y=1.;
   if(n.x==50.||n.x==76.)
     {
       y=0.;
       if(i.y<.5)
         y=1.;
     }
   if(n.x==51)
     y=0.;
   if(n.x>255)
     y=0.;
   vec3 z,a;
   if(i.x>.5)
     z=vec3(0.,0.,-1.),a=vec3(0.,-1.,0.);
   else
      if(i.x<-.5)
       z=vec3(0.,0.,1.),a=vec3(0.,-1.,0.);
     else
        if(i.y>.5)
         z=vec3(1.,0.,0.),a=vec3(0.,0.,1.);
       else
          if(i.y<-.5)
           z=vec3(1.,0.,0.),a=vec3(0.,0.,-1.);
         else
            if(i.z>.5)
             z=vec3(1.,0.,0.),a=vec3(0.,-1.,0.);
           else
              if(i.z<-.5)
               z=vec3(-1.,0.,0.),a=vec3(0.,-1.,0.);
   r=clamp((m.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float s=.15,k=.15;
   if(n.x==10.||n.x==11.)
     {
       if(abs(i.y)<.01&&t||i.y>.99)
         s=.1,k=.1,y=0.;
       else
          y=1.;
     }
   if(n.x==51)
     s=.5,k=.1;
   if(n.x==76)
     s=.2,k=.2;
   if(n.x-255.+39.>=102.&&n.x-255.+39.<=112.)
     k=.025,s=.025;
   z=normalize(f.xyz);
   a=normalize(cross(z,i.xyz)*sign(f.w));
   vec3 d=v.xyz+mix(z*s,-z*s,vec3(r.x));
   d.xyz+=mix(a*s,-a*s,vec3(r.y));
   d.xyz-=i.xyz*k;
   return d;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA e(Ray v)
 {
   DDA i;
   i.mapPos=floor(v.origin);
   i.mapPosOrigin=i.mapPos;
   i.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.rayStep=sign(v.direction);
   i.sideDist=(sign(v.direction)*(i.mapPos-v.origin)+sign(v.direction)*.5+.5)*i.deltaDist;
   i.mask=vec3(0.);
   return i;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 i[2],out float f,out float y)
 {
   float x,r,z,t;
   f=(i[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(i[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(i[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(i[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(i[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(i[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   f=max(max(f,x),z);
   y=min(min(y,r),t);
 }
 vec3 d(const vec3 v,const vec3 i,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(i+v)*.5,n=(i-v)*.5,f=y-z,r=vec3(0.);
   r+=vec3(sign(f.x),0.,0.)*step(abs(abs(f.x)-n.x),x);
   r+=vec3(0.,sign(f.y),0.)*step(abs(abs(f.y)-n.y),x);
   r+=vec3(0.,0.,sign(f.z))*step(abs(abs(f.z)-n.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 i,Ray m,out vec2 r)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(i-m.origin),f=min(x,y),n=max(x,y);
   vec2 t=max(f.xx,f.yz);
   float z=max(t.x,t.y);
   t=min(n.xx,n.yz);
   float s=min(t.x,t.y);
   r.x=z;
   r.y=s;
   return s>max(z,0.);
 }
 bool d(const vec3 v,const vec3 i,Ray m,inout float y,inout vec3 x)
 {
   vec3 z=m.inv_direction*(v-m.origin),f=m.inv_direction*(i-m.origin),n=min(f,z),t=max(f,z);
   vec2 r=max(n.xx,n.yz);
   float s=max(r.x,r.y);
   r=min(t.xx,t.yz);
   float G=min(r.x,r.y);
   bool a=G>max(s,0.)&&max(s,0.)<y;
   if(a)
     x=d(v,i,m.origin+m.direction*s),y=s;
   return a;
 }
 vec3 e(vec3 v,vec3 i,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 f=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(f.xy,f.z-.0006*s),0).x;
   r*=saturate(dot(i,y));
   {
     vec4 n=texture2DLod(shadowcolor1,f.xy-vec2(0.,.5),4);
     float t=abs(n.x*256.-(v.y+cameraPosition.y)),a=GetCausticsComposite(v,i,t),k=shadow2DLod(shadowtex0,vec3(f.xy-vec2(0.,.5),f.z+1e-06),4).x;
     r=mix(r,r*a,1.-k);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 y,vec3 i,vec3 x,vec3 z,int r)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 f=v(y),n=m(f+x*.99);
   float s=.5;
   vec3 t=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*s),3).x;
   t*=saturate(dot(i,x));
   t=TintUnderwaterDepth(t);
   return t*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 i,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 f=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(f.xy,f.z-.0006*s),2).x;
   r*=saturate(dot(i,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct VcxfcrgVbw{float bgoSMWoOlk;float UchydvPYLr;float bRfUKhvDSW;float DqzEnDHRia;vec3 YNIRJTVYcH;};
 vec4 h(VcxfcrgVbw v)
 {
   vec4 i;
   v.YNIRJTVYcH=max(vec3(0.),v.YNIRJTVYcH);
   i.x=v.bgoSMWoOlk;
   v.YNIRJTVYcH=pow(v.YNIRJTVYcH,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.YNIRJTVYcH.x,v.bRfUKhvDSW);
   i.z=PackTwo16BitTo32Bit(v.YNIRJTVYcH.y,v.DqzEnDHRia);
   i.w=PackTwo16BitTo32Bit(v.YNIRJTVYcH.z,v.UchydvPYLr);
   return i;
 }
 VcxfcrgVbw i(vec4 v)
 {
   VcxfcrgVbw i;
   vec2 f=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),n=UnpackTwo16BitFrom32Bit(v.w);
   i.bgoSMWoOlk=v.x;
   i.bRfUKhvDSW=f.y;
   i.DqzEnDHRia=m.y;
   i.UchydvPYLr=n.y;
   i.YNIRJTVYcH=pow(vec3(f.x,m.x,n.x),vec3(8.));
   return i;
 }
 VcxfcrgVbw G(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void G(inout float v,inout float i,float x,float y,vec3 f,float z)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,y);
   #else
   v*=mix(3.4,3.4,y);
   #endif
   float r=dot(f,vec3(1.));
   i*=1.-pow(y,.4);
   i/=x*.1+2e-06;
   i*=4.;
   i*=.6;
   float t=x/(r+1e-07)*.2+4e-08;
   t=min(t,1.);
   t=mix(t,1.,pow(y,.25));
   if(z<.12)
     i=0.;
 }
 float G(vec3 v,vec3 y,float m)
 {
   float i=dot(abs(v-y),vec3(.3333));
   i*=m;
   i*=.18;
   return i;
 }
 void e(inout vec3 v,vec2 x,vec3 y)
 {}
 float e(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool d(vec3 v,float y,Ray i,bool x,inout float f,inout vec3 z)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(x)
     return false;
   if(y>=66.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),i,f,z);
   r=m;
   #else
   if(y<40.)
     return m=d(v,v+vec3(1.,1.,1.),i,f,z),m;
   if(y==40.||y>=42.&&y<=53.)
     m=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),i,f,z),r=r||m;
   if(y==41.||y>=54.&&y<=65.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,f,z),r=r||m;
   if(y==42.||y==45.||y==46.||y==51.||y==52.||y==53.||y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
     {
       float t=.5;
       if(y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
         t=0.;
       m=d(v+vec3(0.,t,0.),v+vec3(.5,.5+t,.5),i,f,z);
       r=r||m;
     }
   if(y==42.||y==44.||y==47.||y==50.||y==52.||y==53.||y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
     {
       float t=.5;
       if(y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
         t=0.;
       m=d(v+vec3(.5,t,0.),v+vec3(1.,.5+t,.5),i,f,z);
       r=r||m;
     }
   if(y==43.||y==44.||y==48.||y==50.||y==51.||y==53.||y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
     {
       float t=.5;
       if(y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
         t=0.;
       m=d(v+vec3(.5,t,.5),v+vec3(1.,.5+t,1.),i,f,z);
       r=r||m;
     }
   if(y==43.||y==45.||y==49.||y==50.||y==51.||y==52.||y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
     {
       float t=.5;
       if(y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
         t=0.;
       m=d(v+vec3(0.,t,.5),v+vec3(.5,.5+t,1.),i,f,z);
       r=r||m;
     }
   if(y>=66.&&y<=81.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,f,z),r=r||m;
   if(y==67.||y==68.||y==69.||y==71.||y==72.||y==73.||y==75.||y==76.||y==77.||y==79.||y==80.||y==81.)
     {
       float t=8.,n=8.;
       if(y==67.||y==69.||y==71.||y==73.||y==75.||y==77.||y==79.||y==81.)
         t=0.;
       if(y==68.||y==69.||y==72.||y==73.||y==76.||y==77.||y==80.||y==81.)
         n=16.;
       m=d(v+vec3(t,6.,7.)/16.,v+vec3(n,9.,9.)/16.,i,f,z);
       r=r||m;
       m=d(v+vec3(t,12.,7.)/16.,v+vec3(n,15.,9.)/16.,i,f,z);
       r=r||m;
     }
   if(y>=70.&&y<=81.)
     {
       float t=8.,n=8.;
       if(y>=70.&&y<=73.||y>=78.&&y<=81.)
         n=16.;
       if(y>=74.&&y<=81.)
         t=0.;
       m=d(v+vec3(7.,6.,t)/16.,v+vec3(9.,9.,n)/16.,i,f,z);
       r=r||m;
       m=d(v+vec3(7.,12.,t)/16.,v+vec3(9.,15.,n)/16.,i,f,z);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=82.&&y<=85.)
     {
       vec3 t=vec3(0),n=vec3(0);
       if(y==82.)
         t=vec3(0,0,0),n=vec3(16,16,3);
       if(y==83.)
         t=vec3(0,0,13),n=vec3(16,16,16);
       if(y==85.)
         t=vec3(0,0,0),n=vec3(3,16,16);
       if(y==84.)
         t=vec3(13,0,0),n=vec3(16,16,16);
       m=d(v+t/16.,v+n/16.,i,f,z);
       r=r||m;
     }
   if(y>=86.&&y<=101.)
     {
       vec3 t=vec3(0.),n=vec3(1.);
       if(y>=86.&&y<=93.)
         {
           float s=0.;
           if(y>=90.&&y<=93.)
             s=13.;
           t=vec3(0.,s,0.)/16.;
           n=vec3(16.,s+3.,16.)/16.;
         }
       if(y>=94.&&y<=97.)
         {
           float s=13.;
           if(y==96.||y==97.)
             s=0.;
           t=vec3(0.,0.,s)/16.;
           n=vec3(16.,16.,s+3.)/16.;
         }
       if(y>=98.&&y<=101.)
         {
           float s=13.;
           if(y==98.||y==99.)
             s=0.;
           t=vec3(s,0.,0.)/16.;
           n=vec3(s+3.,16.,16.)/16.;
         }
       m=d(v+t,v+n,i,f,z);
       r=r||m;
     }
   if(y>=102.&&y<=112.)
     {
       vec3 t=vec3(0.),n=vec3(1.);
       if(y>=102.&&y<=109.)
         {
           float s=float(y)-float(102.)+1.;
           n.y=s*2./16.;
         }
       if(y==110.)
         n.y=.0625;
       if(y==111.)
         t=vec3(1.,0.,1.)/16.,n=vec3(15.,1.,15.)/16.;
       if(y==112.)
         t=vec3(1.,0.,1.)/16.,n=vec3(15.,.5,15.)/16.;
       m=d(v+t,v+n,i,f,z);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 float h(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 void main()
 {
   VcxfcrgVbw v=G(texcoord.xy);
   float y=v.DqzEnDHRia;
   int z=0;
   vec4 i=texture2DLod(colortex6,texcoord.xy,0);
   vec3 f=i.xyz;
   float t=Luminance(f.xyz);
   vec3 x=GetNormals(texcoord.xy);
   float r=GetDepth(texcoord.xy),n=ExpToLinearDepth(r);
   vec3 m=GetViewPosition(texcoord.xy,r).xyz;
   vec2 s=vec2(0.);
   #if GI_FILTER_QUALITY==1
   s=BlueNoiseTemporal(texcoord.xy).xy-.5;
   #endif
   float a=1.,k=1.1e-05;
   G(a,k,i.w,y,f,n);
   vec4 R=vec4(1.);
   float Y=2.*mix(1.,6.,y),w=mix(20.,15.,y)/n,o=0.;
   vec4 d=vec4(0.);
   float c=0.;
   int D=0;
   for(int h=-1;h<=1;h++)
     {
       for(int b=-1;b<=1;b++)
         {
           vec2 H=(vec2(h,b)+s)/vec2(viewWidth,viewHeight)*a,p=texcoord.xy+H.xy;
           p=clamp(p,2./vec2(viewWidth,viewHeight),1.-2./vec2(viewWidth,viewHeight));
           vec4 V=texture2DLod(colortex6,p,z);
           vec3 W=GetNormals(p);
           float l=GetDepth(p),u=ExpToLinearDepth(l),S=pow(saturate(dot(x,W)),Y),T=exp(-(abs(u-n)*w)),g=0.;
           #if GI_FILTER_QUALITY==1
           vec3 U=GetViewPosition(p,l).xyz,L=normalize(U.xyz-m.xyz);
           float P=dot(-W,L);
           bool F=P>0.&&Luminance(V.xyz)<Luminance(f.xyz);
           S=F?2.:S;
           g=exp(-G(V.xyz,f,F?k:k));
           #else
           g=exp(-G(V.xyz,f,k));
           #endif
           float E=T*g*S;
           d+=pow(V,R)*E;
           c+=E;
           D++;
         }
     }
   d/=c+.0001;
   d=pow(d,vec4(1.)/R);
   vec3 p=d.xyz;
   if(c<.0001)
     p=f;
   e(p,texcoord.xy,rand(texcoord.xy+sin(frameTimeCounter)).xyz);
   gl_FragData[0]=vec4(p,d.w);
 };




/* DRAWBUFFERS:6 */
