#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/




in vec4 texcoord;


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBufferData.inc"




 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=d();
   ivec2 n=ivec2(v.x*f.x,v.y*f.y);
   float z=float(n.y/y),i=float(int(n.x+mod(f.x*z,y))/y);
   i+=floor(f.x*z/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(n.x+mod(f.x*z,y),y);
   m.y=mod(n.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 x(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 n;
   n.x=mod(i.x+y*x,f.x);
   float m=i.x+y*x;
   n.y=i.y+floor(m/f.x)*x;
   n+=.5;
   n/=f;
   return n;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 n=ivec2(i.x*m.x,i.y*m.y);
   float z=float(n.y/y),r=float(int(n.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 s=vec3(0.,0.,r);
   s.x=mod(n.x+mod(m.x*z,y),y);
   s.y=mod(n.y,y);
   s.xyz=floor(s.xyz);
   s/=y;
   s.xyz=s.xzy;
   return s;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 f;
   f.x=mod(i.x+x*y,m.x);
   float n=i.x+x*y;
   f.y=i.y+floor(n/m.x)*y;
   f+=.5;
   f/=m;
   f.xy*=.5;
   return f;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 n()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,x=floor(v-.0001),y=floor(i-.0001);
   return x-y;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 n,vec2 m,vec4 i,vec4 x,inout float y,out vec2 r)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(x.x==8||x.x==9||x.x==79||x.x<1.||!z||x.x==20.||x.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(x.x==50.||x.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(x.x==51)
     y=0.;
   if(x.x>255)
     y=0.;
   vec3 s,a;
   if(f.x>.5)
     s=vec3(0.,0.,-1.),a=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       s=vec3(0.,0.,1.),a=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         s=vec3(1.,0.,0.),a=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           s=vec3(1.,0.,0.),a=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             s=vec3(1.,0.,0.),a=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               s=vec3(-1.,0.,0.),a=vec3(0.,-1.,0.);
   r=clamp((n.xy-m.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,t=.15;
   if(x.x==10.||x.x==11.)
     {
       if(abs(f.y)<.01&&z||f.y>.99)
         h=.1,t=.1,y=0.;
       else
          y=1.;
     }
   if(x.x==51)
     h=.5,t=.1;
   if(x.x==76)
     h=.2,t=.2;
   if(x.x-255.+39.>=102.&&x.x-255.+39.<=112.)
     t=.025,h=.025;
   s=normalize(i.xyz);
   a=normalize(cross(s,f.xyz)*sign(i.w));
   vec3 e=v.xyz+mix(s*h,-s*h,vec3(r.x));
   e.xyz+=mix(a*h,-a*h,vec3(r.y));
   e.xyz-=f.xyz*t;
   return e;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA e(Ray v)
 {
   DDA f;
   f.mapPos=floor(v.origin);
   f.mapPosOrigin=f.mapPos;
   f.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.rayStep=sign(v.direction);
   f.sideDist=(sign(v.direction)*(f.mapPos-v.origin)+sign(v.direction)*.5+.5)*f.deltaDist;
   f.mask=vec3(0.);
   return f;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float x)
 {
   float y,z,r,t;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,y),r);
   x=min(min(x,z),t);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,n=y-z,r=vec3(0.);
   r+=vec3(sign(n.x),0.,0.)*step(abs(abs(n.x)-i.x),x);
   r+=vec3(0.,sign(n.y),0.)*step(abs(abs(n.y)-i.y),x);
   r+=vec3(0.,0.,sign(n.z))*step(abs(abs(n.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),n=min(x,y),s=max(x,y);
   vec2 r=max(n.xx,n.yz);
   float z=max(r.x,r.y);
   r=min(s.xx,s.yz);
   float t=min(r.x,r.y);
   i.x=z;
   i.y=t;
   return t>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 y)
 {
   vec3 i=m.inv_direction*(v-m.origin),z=m.inv_direction*(f-m.origin),n=min(z,i),s=max(z,i);
   vec2 r=max(n.xx,n.yz);
   float t=max(r.x,r.y);
   r=min(s.xx,s.yz);
   float h=min(r.x,r.y);
   bool a=h>max(t,0.)&&max(t,0.)<x;
   if(a)
     y=d(v,f,m.origin+m.direction*t),x=t;
   return a;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float t=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*t),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float s=abs(n.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,s),a=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-a);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 f,vec3 x,vec3 y,vec3 z,int n)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 i=v(f),r=m(i+y*.99);
   float t=.5;
   vec3 s=vec3(1.)*shadow2DLod(shadowtex0,vec3(r.xy,r.z-.0006*t),3).x;
   s*=saturate(dot(x,y));
   s=TintUnderwaterDepth(s);
   return s*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float t=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*t),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct VcxfcrgVbw{float bgoSMWoOlk;float UchydvPYLr;float bRfUKhvDSW;float DqzEnDHRia;vec3 YNIRJTVYcH;};
 vec4 i(VcxfcrgVbw v)
 {
   vec4 f;
   v.YNIRJTVYcH=max(vec3(0.),v.YNIRJTVYcH);
   f.x=v.bgoSMWoOlk;
   v.YNIRJTVYcH=pow(v.YNIRJTVYcH,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.YNIRJTVYcH.x,v.bRfUKhvDSW);
   f.z=PackTwo16BitTo32Bit(v.YNIRJTVYcH.y,v.DqzEnDHRia);
   f.w=PackTwo16BitTo32Bit(v.YNIRJTVYcH.z,v.UchydvPYLr);
   return f;
 }
 VcxfcrgVbw h(vec4 v)
 {
   VcxfcrgVbw f;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),i=UnpackTwo16BitFrom32Bit(v.z),x=UnpackTwo16BitFrom32Bit(v.w);
   f.bgoSMWoOlk=v.x;
   f.bRfUKhvDSW=m.y;
   f.DqzEnDHRia=i.y;
   f.UchydvPYLr=x.y;
   f.YNIRJTVYcH=pow(vec3(m.x,i.x,x.x),vec3(8.));
   return f;
 }
 VcxfcrgVbw c(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return h(texture2DLod(colortex5,v,0));
 }
 float c(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void c(inout float v,inout float f,float x,float y,vec3 i,float n)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,y);
   #else
   v*=mix(3.4,3.4,y);
   #endif
   float r=dot(i,vec3(1.));
   f*=1.-pow(y,.4);
   f/=x*.1+2e-06;
   f*=4.;
   f*=.6;
   float s=x/(r+1e-07)*.2+4e-08;
   s=min(s,1.);
   s=mix(s,1.,pow(y,.25));
   if(n<.12)
     f=0.;
 }
 float c(vec3 v,vec3 y,float f)
 {
   float x=dot(abs(v-y),vec3(.3333));
   x*=f;
   x*=.18;
   return x;
 }
 void e(inout vec3 v,vec2 x,vec3 y)
 {}
 float e(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool d(vec3 v,float x,Ray y,bool f,inout float i,inout vec3 z)
 {
   bool m=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(f)
     return false;
   if(x>=66.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),y,i,z);
   m=r;
   #else
   if(x<40.)
     return r=d(v,v+vec3(1.,1.,1.),y,i,z),r;
   if(x==40.||x>=42.&&x<=53.)
     r=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),y,i,z),m=m||r;
   if(x==41.||x>=54.&&x<=65.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),y,i,z),m=m||r;
   if(x==42.||x==45.||x==46.||x==51.||x==52.||x==53.||x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
     {
       float s=.5;
       if(x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
         s=0.;
       r=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),y,i,z);
       m=m||r;
     }
   if(x==42.||x==44.||x==47.||x==50.||x==52.||x==53.||x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
     {
       float s=.5;
       if(x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
         s=0.;
       r=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),y,i,z);
       m=m||r;
     }
   if(x==43.||x==44.||x==48.||x==50.||x==51.||x==53.||x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
     {
       float s=.5;
       if(x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
         s=0.;
       r=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),y,i,z);
       m=m||r;
     }
   if(x==43.||x==45.||x==49.||x==50.||x==51.||x==52.||x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
     {
       float s=.5;
       if(x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
         s=0.;
       r=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),y,i,z);
       m=m||r;
     }
   if(x>=66.&&x<=81.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,y,i,z),m=m||r;
   if(x==67.||x==68.||x==69.||x==71.||x==72.||x==73.||x==75.||x==76.||x==77.||x==79.||x==80.||x==81.)
     {
       float s=8.,n=8.;
       if(x==67.||x==69.||x==71.||x==73.||x==75.||x==77.||x==79.||x==81.)
         s=0.;
       if(x==68.||x==69.||x==72.||x==73.||x==76.||x==77.||x==80.||x==81.)
         n=16.;
       r=d(v+vec3(s,6.,7.)/16.,v+vec3(n,9.,9.)/16.,y,i,z);
       m=m||r;
       r=d(v+vec3(s,12.,7.)/16.,v+vec3(n,15.,9.)/16.,y,i,z);
       m=m||r;
     }
   if(x>=70.&&x<=81.)
     {
       float s=8.,t=8.;
       if(x>=70.&&x<=73.||x>=78.&&x<=81.)
         t=16.;
       if(x>=74.&&x<=81.)
         s=0.;
       r=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,t)/16.,y,i,z);
       m=m||r;
       r=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,t)/16.,y,i,z);
       m=m||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=82.&&x<=85.)
     {
       vec3 s=vec3(0),t=vec3(0);
       if(x==82.)
         s=vec3(0,0,0),t=vec3(16,16,3);
       if(x==83.)
         s=vec3(0,0,13),t=vec3(16,16,16);
       if(x==85.)
         s=vec3(0,0,0),t=vec3(3,16,16);
       if(x==84.)
         s=vec3(13,0,0),t=vec3(16,16,16);
       r=d(v+s/16.,v+t/16.,y,i,z);
       m=m||r;
     }
   if(x>=86.&&x<=101.)
     {
       vec3 s=vec3(0.),t=vec3(1.);
       if(x>=86.&&x<=93.)
         {
           float n=0.;
           if(x>=90.&&x<=93.)
             n=13.;
           s=vec3(0.,n,0.)/16.;
           t=vec3(16.,n+3.,16.)/16.;
         }
       if(x>=94.&&x<=97.)
         {
           float n=13.;
           if(x==96.||x==97.)
             n=0.;
           s=vec3(0.,0.,n)/16.;
           t=vec3(16.,16.,n+3.)/16.;
         }
       if(x>=98.&&x<=101.)
         {
           float n=13.;
           if(x==98.||x==99.)
             n=0.;
           s=vec3(n,0.,0.)/16.;
           t=vec3(n+3.,16.,16.)/16.;
         }
       r=d(v+s,v+t,y,i,z);
       m=m||r;
     }
   if(x>=102.&&x<=112.)
     {
       vec3 s=vec3(0.),n=vec3(1.);
       if(x>=102.&&x<=109.)
         {
           float t=float(x)-float(102.)+1.;
           n.y=t*2./16.;
         }
       if(x==110.)
         n.y=.0625;
       if(x==111.)
         s=vec3(1.,0.,1.)/16.,n=vec3(15.,1.,15.)/16.;
       if(x==112.)
         s=vec3(1.,0.,1.)/16.,n=vec3(15.,.5,15.)/16.;
       r=d(v+s,v+n,y,i,z);
       m=m||r;
     }
   #endif
   #endif
   return m;
 }
 float h(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 void main()
 {
   VcxfcrgVbw v=c(texcoord.xy);
   float x=v.DqzEnDHRia;
   vec4 f=texture2DLod(colortex6,texcoord.xy,0);
   vec3 m=f.xyz;
   float s=Luminance(m.xyz);
   vec3 y=GetNormals(texcoord.xy);
   float r=GetDepthLinear(texcoord.xy);
   vec2 z=vec2(0.);
   float i=4.,t=sin(frameTimeCounter)>0.?1.:0.,n=2.,a=20.;
   vec4 h=vec4(0.),e=vec4(0.);
   float d=0.;
   int p=0;
   for(int D=-1;D<=1;D++)
     {
       for(int R=-1;R<=1;R++)
         {
           vec2 H=(vec2(D,R)+z)/vec2(viewWidth,viewHeight)*i,o=texcoord.xy+H.xy;
           o=clamp(o,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
           vec4 k=texture2DLod(colortex6,o,0);
           h+=k;
           e+=k*k;
           p++;
         }
     }
   h/=p+1e-06;
   e/=p+1e-06;
   vec3 D=h.xyz;
   float R=dot(h.xyz,vec3(1.));
   vec4 H=sqrt(max(vec4(0.),e-h*h));
   float o=dot(H.xyz,vec3(6.));
   if(d<.0001)
     D=m;
   gl_FragData[0]=vec4(f.xyz,o);
 };




/* DRAWBUFFERS:6 */
