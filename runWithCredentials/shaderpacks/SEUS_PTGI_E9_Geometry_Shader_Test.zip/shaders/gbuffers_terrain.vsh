#version 330 compatibility


#define OLD_LIGHTING_FIX		//In newest versions of the shaders mod/optifine, old lighting isn't removed properly. If OldLighting is On and this is enabled, you'll get proper results in any shaders mod/minecraft version.

#define GLOWING_REDSTONE_BLOCK // If enabled, redstone blocks are treated as light sources for GI
#define GLOWING_LAPIS_LAZULI_BLOCK // If enabled, lapis lazuli blocks are treated as light sources for GI


#define GENERAL_GRASS_FIX

#include "lib/Uniforms.inc"
#include "lib/Common.inc"


attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;



out vec4 color;
out vec4 texcoord;
out vec4 lmcoord;
out vec3 worldPosition;
out vec3 viewPos;

out vec3 worldNormal;

out vec2 blockLight;

out float materialIDs;


 int f(float m)
 {
   return int(floor(m));
 }
 int x(int m)
 {
   return m-f(mod(float(m),2.))-0;
 }
 int t(int m)
 {
   return m-f(mod(float(m),2.))-1;
 }
 int f()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int m=v.x*v.y;
   return x(f(floor(pow(float(m),.333333))));
 }
 int t()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 vec3 s(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,y=f();
   ivec2 s=ivec2(v.x*m.x,v.y*m.y);
   float z=float(s.y/y),i=float(int(s.x+mod(m.x*z,y))/y);
   i+=floor(m.x*z/y);
   vec3 r=vec3(0.,0.,i);
   r.x=mod(s.x+mod(m.x*z,y),y);
   r.y=mod(s.y,y);
   r.xyz=floor(r.xyz);
   r/=y;
   r.xyz=r.xzy;
   return r;
 }
 vec2 n(vec3 m)
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=f();
   vec3 i=m.xzy*x;
   i=floor(i+1e-05);
   float s=i.z;
   vec2 r;
   r.x=mod(i.x+s*x,v.x);
   float y=i.x+s*x;
   r.y=i.y+floor(y/v.x)*x;
   r+=.5;
   r/=v;
   return r;
 }
 vec3 d(vec2 m)
 {
   vec2 v=m;
   v.xy/=.5;
   ivec2 x=ivec2(2048,2048);
   int s=x.x*x.y,y=t();
   ivec2 r=ivec2(v.x*x.x,v.y*x.y);
   float z=float(r.y/y),i=float(int(r.x+mod(x.x*z,y))/y);
   i+=floor(x.x*z/y);
   vec3 f=vec3(0.,0.,i);
   f.x=mod(r.x+mod(x.x*z,y),y);
   f.y=mod(r.y,y);
   f.xyz=floor(f.xyz);
   f/=y;
   f.xyz=f.xzy;
   return f;
 }
 vec2 d(vec3 m,int x)
 {
   m=clamp(m,vec3(0.),vec3(1.));
   ivec2 v=ivec2(2048,2048);
   vec3 i=m.xzy*x;
   i=floor(i+1e-05);
   float s=i.z;
   vec2 r;
   r.x=mod(i.x+s*x,v.x);
   float f=i.x+s*x;
   r.y=i.y+floor(f/v.x)*x;
   r+=.5;
   r/=v;
   r.xy*=.5;
   return r;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int x=t();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 r(vec3 v)
 {
   int x=f();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int x=f();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 d()
 {
   vec3 x=cameraPosition.xyz+.5,v=previousCameraPosition.xyz+.5,s=floor(x-.0001),y=floor(v-.0001);
   return s-y;
 }
 vec3 m(vec3 m)
 {
   vec4 v=vec4(m,1.);
   v=shadowModelView*v;
   v=shadowProjection*v;
   v/=v.w;
   float x=sqrt(v.x*v.x+v.y*v.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   v.xy*=.95f/y;
   v.z=mix(v.z,.5,.8);
   v=v*.5f+.5f;
   v.xy*=.5;
   v.xy+=.5;
   return v.xyz;
 }
 vec3 d(vec3 v,vec3 m,vec2 r,vec2 y,vec4 s,vec4 f,inout float x,out vec2 i)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(f.x==8||f.x==9||f.x==79||f.x<1.||!z||f.x==20.||f.x==171.||min(abs(m.x),abs(m.z))>.2)
     x=1.;
   if(f.x==50.||f.x==76.)
     {
       x=0.;
       if(m.y<.5)
         x=1.;
     }
   if(f.x==51)
     x=0.;
   if(f.x>255)
     x=0.;
   vec3 c,w;
   if(m.x>.5)
     c=vec3(0.,0.,-1.),w=vec3(0.,-1.,0.);
   else
      if(m.x<-.5)
       c=vec3(0.,0.,1.),w=vec3(0.,-1.,0.);
     else
        if(m.y>.5)
         c=vec3(1.,0.,0.),w=vec3(0.,0.,1.);
       else
          if(m.y<-.5)
           c=vec3(1.,0.,0.),w=vec3(0.,0.,-1.);
         else
            if(m.z>.5)
             c=vec3(1.,0.,0.),w=vec3(0.,-1.,0.);
           else
              if(m.z<-.5)
               c=vec3(-1.,0.,0.),w=vec3(0.,-1.,0.);
   i=clamp((r.xy-y.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,k=.15;
   if(f.x==10.||f.x==11.)
     {
       if(abs(m.y)<.01&&z||m.y>.99)
         h=.1,k=.1,x=0.;
       else
          x=1.;
     }
   if(f.x==51)
     h=.5,k=.1;
   if(f.x==76)
     h=.2,k=.2;
   if(f.x-255.+39.>=102.&&f.x-255.+39.<=112.)
     k=.025,h=.025;
   c=normalize(s.xyz);
   w=normalize(cross(c,m.xyz)*sign(s.w));
   vec3 n=v.xyz+mix(c*h,-c*h,vec3(i.x));
   n.xyz+=mix(w*h,-w*h,vec3(i.y));
   n.xyz-=m.xyz*k;
   return n;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA e(Ray v)
 {
   DDA m;
   m.mapPos=floor(v.origin);
   m.mapPosOrigin=m.mapPos;
   m.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   m.rayStep=sign(v.direction);
   m.sideDist=(sign(v.direction)*(m.mapPos-v.origin)+sign(v.direction)*.5+.5)*m.deltaDist;
   m.mask=vec3(0.);
   return m;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 m[2],out float x,out float i)
 {
   float f,y,s,r;
   x=(m[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   i=(m[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   f=(m[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   y=(m[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   s=(m[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   r=(m[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   x=max(max(x,f),s);
   i=min(min(i,y),r);
 }
 vec3 d(const vec3 v,const vec3 m,vec3 f)
 {
   const float x=1e-05;
   vec3 s=(m+v)*.5,y=(m-v)*.5,i=f-s,r=vec3(0.);
   r+=vec3(sign(i.x),0.,0.)*step(abs(abs(i.x)-y.x),x);
   r+=vec3(0.,sign(i.y),0.)*step(abs(abs(i.y)-y.y),x);
   r+=vec3(0.,0.,sign(i.z))*step(abs(abs(i.z)-y.z),x);
   return normalize(r);
 }
 bool e(const vec3 m,const vec3 v,Ray f,out vec2 i)
 {
   vec3 x=f.inv_direction*(m-f.origin),s=f.inv_direction*(v-f.origin),y=min(s,x),r=max(s,x);
   vec2 n=max(y.xx,y.yz);
   float c=max(n.x,n.y);
   n=min(r.xx,r.yz);
   float z=min(n.x,n.y);
   i.x=c;
   i.y=z;
   return z>max(c,0.);
 }
 bool d(const vec3 m,const vec3 v,Ray f,inout float x,inout vec3 y)
 {
   vec3 s=f.inv_direction*(m-f.origin),i=f.inv_direction*(v-f.origin),r=min(i,s),n=max(i,s);
   vec2 w=max(r.xx,r.yz);
   float z=max(w.x,w.y);
   w=min(n.xx,n.yz);
   float c=min(w.x,w.y);
   bool a=c>max(z,0.)&&max(z,0.)<x;
   if(a)
     y=d(m,v,f.origin+f.direction*z),x=z;
   return a;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float w=abs(n.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,w),c=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-c);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 f,vec3 s,vec3 x,vec3 y,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 i=v(f),r=m(i+x*.99);
   float n=.5;
   vec3 w=vec3(1.)*shadow2DLod(shadowtex0,vec3(r.xy,r.z-.0006*n),3).x;
   w*=saturate(dot(s,x));
   w=TintUnderwaterDepth(w);
   return w*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct VcxfcrgVbw{float bgoSMWoOlk;float UchydvPYLr;float bRfUKhvDSW;float DqzEnDHRia;vec3 YNIRJTVYcH;};
 vec4 i(VcxfcrgVbw v)
 {
   vec4 i;
   v.YNIRJTVYcH=max(vec3(0.),v.YNIRJTVYcH);
   i.x=v.bgoSMWoOlk;
   v.YNIRJTVYcH=pow(v.YNIRJTVYcH,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.YNIRJTVYcH.x,v.bRfUKhvDSW);
   i.z=PackTwo16BitTo32Bit(v.YNIRJTVYcH.y,v.DqzEnDHRia);
   i.w=PackTwo16BitTo32Bit(v.YNIRJTVYcH.z,v.UchydvPYLr);
   return i;
 }
 VcxfcrgVbw h(vec4 v)
 {
   VcxfcrgVbw i;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),x=UnpackTwo16BitFrom32Bit(v.z),y=UnpackTwo16BitFrom32Bit(v.w);
   i.bgoSMWoOlk=v.x;
   i.bRfUKhvDSW=m.y;
   i.DqzEnDHRia=x.y;
   i.UchydvPYLr=y.y;
   i.YNIRJTVYcH=pow(vec3(m.x,x.x,y.x),vec3(8.));
   return i;
 }
 VcxfcrgVbw G(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return h(texture2DLod(colortex5,v,0));
 }
 float G(float v,float x)
 {
   float s=1.;
   #ifdef FULL_RT_REFLECTIONS
   s=clamp(pow(v,.125)+x,0.,1.);
   #else
   s=clamp(v*10.-7.,0.,1.);
   #endif
   return s;
 }
 void G(inout float v,inout float x,float m,float f,vec3 s,float y)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,f);
   #else
   v*=mix(3.4,3.4,f);
   #endif
   float i=dot(s,vec3(1.));
   x*=1.-pow(f,.4);
   x/=m*.1+2e-06;
   x*=4.;
   x*=.6;
   float r=m/(i+1e-07)*.2+4e-08;
   r=min(r,1.);
   r=mix(r,1.,pow(f,.25));
   if(y<.12)
     x=0.;
 }
 float G(vec3 v,vec3 f,float m)
 {
   float x=dot(abs(v-f),vec3(.3333));
   x*=m;
   x*=.18;
   return x;
 }
 void e(inout vec3 v,vec2 x,vec3 f)
 {}
 float e(float v,float m)
 {
   return v/(m*20.01+1.);
 }
 bool d(vec3 v,float x,Ray f,bool m,inout float s,inout vec3 y)
 {
   bool i=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(m)
     return false;
   if(x>=66.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),f,s,y);
   i=r;
   #else
   if(x<40.)
     return r=d(v,v+vec3(1.,1.,1.),f,s,y),r;
   if(x==40.||x>=42.&&x<=53.)
     r=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),f,s,y),i=i||r;
   if(x==41.||x>=54.&&x<=65.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,s,y),i=i||r;
   if(x==42.||x==45.||x==46.||x==51.||x==52.||x==53.||x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
     {
       float c=.5;
       if(x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
         c=0.;
       r=d(v+vec3(0.,c,0.),v+vec3(.5,.5+c,.5),f,s,y);
       i=i||r;
     }
   if(x==42.||x==44.||x==47.||x==50.||x==52.||x==53.||x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
     {
       float c=.5;
       if(x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
         c=0.;
       r=d(v+vec3(.5,c,0.),v+vec3(1.,.5+c,.5),f,s,y);
       i=i||r;
     }
   if(x==43.||x==44.||x==48.||x==50.||x==51.||x==53.||x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
     {
       float c=.5;
       if(x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
         c=0.;
       r=d(v+vec3(.5,c,.5),v+vec3(1.,.5+c,1.),f,s,y);
       i=i||r;
     }
   if(x==43.||x==45.||x==49.||x==50.||x==51.||x==52.||x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
     {
       float c=.5;
       if(x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
         c=0.;
       r=d(v+vec3(0.,c,.5),v+vec3(.5,.5+c,1.),f,s,y);
       i=i||r;
     }
   if(x>=66.&&x<=81.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,s,y),i=i||r;
   if(x==67.||x==68.||x==69.||x==71.||x==72.||x==73.||x==75.||x==76.||x==77.||x==79.||x==80.||x==81.)
     {
       float c=8.,w=8.;
       if(x==67.||x==69.||x==71.||x==73.||x==75.||x==77.||x==79.||x==81.)
         c=0.;
       if(x==68.||x==69.||x==72.||x==73.||x==76.||x==77.||x==80.||x==81.)
         w=16.;
       r=d(v+vec3(c,6.,7.)/16.,v+vec3(w,9.,9.)/16.,f,s,y);
       i=i||r;
       r=d(v+vec3(c,12.,7.)/16.,v+vec3(w,15.,9.)/16.,f,s,y);
       i=i||r;
     }
   if(x>=70.&&x<=81.)
     {
       float c=8.,z=8.;
       if(x>=70.&&x<=73.||x>=78.&&x<=81.)
         z=16.;
       if(x>=74.&&x<=81.)
         c=0.;
       r=d(v+vec3(7.,6.,c)/16.,v+vec3(9.,9.,z)/16.,f,s,y);
       i=i||r;
       r=d(v+vec3(7.,12.,c)/16.,v+vec3(9.,15.,z)/16.,f,s,y);
       i=i||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=82.&&x<=85.)
     {
       vec3 c=vec3(0),w=vec3(0);
       if(x==82.)
         c=vec3(0,0,0),w=vec3(16,16,3);
       if(x==83.)
         c=vec3(0,0,13),w=vec3(16,16,16);
       if(x==85.)
         c=vec3(0,0,0),w=vec3(3,16,16);
       if(x==84.)
         c=vec3(13,0,0),w=vec3(16,16,16);
       r=d(v+c/16.,v+w/16.,f,s,y);
       i=i||r;
     }
   if(x>=86.&&x<=101.)
     {
       vec3 c=vec3(0.),w=vec3(1.);
       if(x>=86.&&x<=93.)
         {
           float z=0.;
           if(x>=90.&&x<=93.)
             z=13.;
           c=vec3(0.,z,0.)/16.;
           w=vec3(16.,z+3.,16.)/16.;
         }
       if(x>=94.&&x<=97.)
         {
           float z=13.;
           if(x==96.||x==97.)
             z=0.;
           c=vec3(0.,0.,z)/16.;
           w=vec3(16.,16.,z+3.)/16.;
         }
       if(x>=98.&&x<=101.)
         {
           float z=13.;
           if(x==98.||x==99.)
             z=0.;
           c=vec3(z,0.,0.)/16.;
           w=vec3(z+3.,16.,16.)/16.;
         }
       r=d(v+c,v+w,f,s,y);
       i=i||r;
     }
   if(x>=102.&&x<=112.)
     {
       vec3 c=vec3(0.),w=vec3(1.);
       if(x>=102.&&x<=109.)
         {
           float z=float(x)-float(102.)+1.;
           w.y=z*2./16.;
         }
       if(x==110.)
         w.y=.0625;
       if(x==111.)
         c=vec3(1.,0.,1.)/16.,w=vec3(15.,1.,15.)/16.;
       if(x==112.)
         c=vec3(1.,0.,1.)/16.,w=vec3(15.,.5,15.)/16.;
       r=d(v+c,v+w,f,s,y);
       i=i||r;
     }
   #endif
   #endif
   return i;
 }
 void main()
 {
   color=gl_Color;
   texcoord=gl_MultiTexCoord0;
   lmcoord=gl_TextureMatrix[1]*gl_MultiTexCoord1;
   blockLight.x=clamp(lmcoord.x*33.05f/32.f-.0328125f,0.f,1.f);
   blockLight.y=clamp(lmcoord.y*33.75f/32.f-.0328125f,0.f,1.f);
   worldNormal=gl_Normal;
   vec4 x=gbufferModelViewInverse*gl_ModelViewMatrix*gl_Vertex;
   worldPosition=x.xyz+cameraPosition.xyz;
   viewPos=(gl_ModelViewMatrix*gl_Vertex).xyz;
   materialIDs=1.f;
   float v=0.f,y=abs(normalize(gl_Normal.xz).x),s=abs(gl_Normal.y);
   if(mc_Entity.x==31.||mc_Entity.x==38.f||mc_Entity.x==37.f||mc_Entity.x==1925.f||mc_Entity.x==1920.f||mc_Entity.x==1921.f||mc_Entity.x==2.&&gl_Normal.y<.5&&y>.01&&y<.99&&s<.9)
     materialIDs=max(materialIDs,2.f),v=1.f;
   #ifdef GENERAL_GRASS_FIX
   if(abs(worldNormal.x)>.01&&abs(worldNormal.x)<.99||abs(worldNormal.y)>.01&&abs(worldNormal.y)<.99||abs(worldNormal.z)>.01&&abs(worldNormal.z)<.99)
     materialIDs=max(materialIDs,2.f);
   #endif
   if(mc_Entity.x==175.f)
     materialIDs=max(materialIDs,2.f);
   if(mc_Entity.x==59.)
     materialIDs=max(materialIDs,2.f),v=1.f;
   if(mc_Entity.x==18.||mc_Entity.x==161.f)
     {
       if(color.x>.999&&color.y>.999&&color.z>.999)
         ;
       else
          materialIDs=max(materialIDs,3.f);
       if(abs(color.x-color.y)>.001||abs(color.x-color.z)>.001||abs(color.y-color.z)>.001)
         materialIDs=max(materialIDs,3.f);
     }
   if(mc_Entity.x==41)
     materialIDs=max(materialIDs,20.f);
   if(mc_Entity.x==42)
     materialIDs=max(materialIDs,21.f);
   if(mc_Entity.x==57)
     materialIDs=max(materialIDs,22.f);
   if(mc_Entity.x==-123)
     materialIDs=max(materialIDs,23.f);
   if(mc_Entity.x==12)
     materialIDs=max(materialIDs,24.f);
   if(mc_Entity.x==24||mc_Entity.x==-128)
     materialIDs=max(materialIDs,25.f);
   if(mc_Entity.x==1)
     materialIDs=max(materialIDs,26.f);
   if(mc_Entity.x==4)
     materialIDs=max(materialIDs,27.f);
   if(mc_Entity.x==35)
     materialIDs=max(materialIDs,28.f);
   if(mc_Entity.x==50)
     materialIDs=max(materialIDs,30.f);
   if(mc_Entity.x==10||mc_Entity.x==11)
     materialIDs=max(materialIDs,31.f);
   if(mc_Entity.x==89||mc_Entity.x==124||mc_Entity.x==169||mc_Entity.x==91)
     materialIDs=max(materialIDs,32.f);
   #ifdef GLOWING_REDSTONE_BLOCK
   if(mc_Entity.x==152)
     materialIDs=max(materialIDs,32.f);
   #endif
   #ifdef GLOWING_LAPIS_LAZULI_BLOCK
   if(mc_Entity.x==22)
     materialIDs=max(materialIDs,32.f);
   #endif
   if(mc_Entity.x==51)
     materialIDs=max(materialIDs,33.f);
   float c=1.;
   if(color.x==1.&&color.y==1.&&color.z==1.)
     c=0.;
   #ifdef OLD_LIGHTING_FIX
   if(v<.1&&c>.5)
     {
       if(worldNormal.x>.85)
         color.xyz*=1./.6;
       if(worldNormal.x<-.85)
         color.xyz*=1./.6;
       if(worldNormal.z>.85)
         color.xyz*=1.25;
       if(worldNormal.z<-.85)
         color.xyz*=1.25;
       if(worldNormal.y<-.85)
         color.xyz*=2.;
     }
   #endif
   gl_Position=gl_ProjectionMatrix*gbufferModelView*x;
   gl_Position.xyz/=gl_Position.w;
   TemporalJitterProjPos(gl_Position);
   gl_Position.xyz*=gl_Position.w;
 };



