#version 330 compatibility


#include "lib/Uniforms.inc"
#include "lib/Common.inc"



attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

out vec4 vTexcoord;
out vec4 vColor;
// out vec4 vlmcoord;
// out vec3 vnormal;

// out vec4 vviewPos;

out float vMaterialIDs;
out float vMCEntity;
// out float visWater;
// out float visStainedGlass;

out float SZEGaNoNyW;	
// out float PXJzUgDiNM;		
out vec2 qATJEDLiyF;			

out vec4 kSIUoJlAap;		
out vec4 JVKUXnCTcE;		



 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int x(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int f()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int t()
 {
   ivec2 v=ivec2(2048,2048);
   int y=v.x*v.y;
   return x(f(floor(pow(float(y),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,y=f();
   ivec2 n=ivec2(v.x*m.x,v.y*m.y);
   float s=float(n.y/y),i=float(int(n.x+mod(m.x*s,y))/y);
   i+=floor(m.x*s/y);
   vec3 r=vec3(0.,0.,i);
   r.x=mod(n.x+mod(m.x*s,y),y);
   r.y=mod(n.y,y);
   r.xyz=floor(r.xyz);
   r/=y;
   r.xyz=r.xzy;
   return r;
 }
 vec2 d(vec3 v)
 {
   ivec2 y=ivec2(viewWidth,viewHeight);
   int x=f();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float s=i.z;
   vec2 r;
   r.x=mod(i.x+s*x,y.x);
   float m=i.x+s*x;
   r.y=i.y+floor(m/y.x)*x;
   r+=.5;
   r/=y;
   return r;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=t();
   ivec2 n=ivec2(i.x*m.x,i.y*m.y);
   float s=float(n.y/y),r=float(int(n.x+mod(m.x*s,y))/y);
   r+=floor(m.x*s/y);
   vec3 f=vec3(0.,0.,r);
   f.x=mod(n.x+mod(m.x*s,y),y);
   f.y=mod(n.y,y);
   f.xyz=floor(f.xyz);
   f/=y;
   f.xyz=f.xzy;
   return f;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 x=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float s=i.z;
   vec2 r;
   r.x=mod(i.x+s*y,x.x);
   float m=i.x+s*y;
   r.y=i.y+floor(m/x.x)*y;
   r+=.5;
   r/=x;
   r.xy*=.5;
   return r;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int x=t();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=f();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int x=f();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,y=floor(v-.0001),i=floor(x-.0001);
   return y-i;
 }
 vec3 m(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/y;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 m,vec2 y,vec2 n,vec4 i,vec4 f,inout float x,out vec2 r)
 {
   bool s=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   s=!s;
   if(f.x==8||f.x==9||f.x==79||f.x<1.||!s||f.x==20.||f.x==171.||min(abs(m.x),abs(m.z))>.2)
     x=1.;
   if(f.x==50.||f.x==76.)
     {
       x=0.;
       if(m.y<.5)
         x=1.;
     }
   if(f.x==51)
     x=0.;
   if(f.x>255)
     x=0.;
   vec3 z,a;
   if(m.x>.5)
     z=vec3(0.,0.,-1.),a=vec3(0.,-1.,0.);
   else
      if(m.x<-.5)
       z=vec3(0.,0.,1.),a=vec3(0.,-1.,0.);
     else
        if(m.y>.5)
         z=vec3(1.,0.,0.),a=vec3(0.,0.,1.);
       else
          if(m.y<-.5)
           z=vec3(1.,0.,0.),a=vec3(0.,0.,-1.);
         else
            if(m.z>.5)
             z=vec3(1.,0.,0.),a=vec3(0.,-1.,0.);
           else
              if(m.z<-.5)
               z=vec3(-1.,0.,0.),a=vec3(0.,-1.,0.);
   r=clamp((y.xy-n.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,S=.15;
   if(f.x==10.||f.x==11.)
     {
       if(abs(m.y)<.01&&s||m.y>.99)
         h=.1,S=.1,x=0.;
       else
          x=1.;
     }
   if(f.x==51)
     h=.5,S=.1;
   if(f.x==76)
     h=.2,S=.2;
   if(f.x-255.+39.>=102.&&f.x-255.+39.<=112.)
     S=.025,h=.025;
   z=normalize(i.xyz);
   a=normalize(cross(z,m.xyz)*sign(i.w));
   vec3 t=v.xyz+mix(z*h,-z*h,vec3(r.x));
   t.xyz+=mix(a*h,-a*h,vec3(r.y));
   t.xyz-=m.xyz*S;
   return t;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA e(Ray v)
 {
   DDA i;
   i.mapPos=floor(v.origin);
   i.mapPosOrigin=i.mapPos;
   i.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.rayStep=sign(v.direction);
   i.sideDist=(sign(v.direction)*(i.mapPos-v.origin)+sign(v.direction)*.5+.5)*i.deltaDist;
   i.mask=vec3(0.);
   return i;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 m[2],out float i,out float x)
 {
   float y,r,f,z;
   i=(m[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(m[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(m[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(m[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   f=(m[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   z=(m[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,y),f);
   x=min(min(x,r),z);
 }
 vec3 d(const vec3 v,const vec3 m,vec3 y)
 {
   const float x=1e-05;
   vec3 i=(m+v)*.5,n=(m-v)*.5,f=y-i,r=vec3(0.);
   r+=vec3(sign(f.x),0.,0.)*step(abs(abs(f.x)-n.x),x);
   r+=vec3(0.,sign(f.y),0.)*step(abs(abs(f.y)-n.y),x);
   r+=vec3(0.,0.,sign(f.z))*step(abs(abs(f.z)-n.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 m,Ray i,out vec2 y)
 {
   vec3 x=i.inv_direction*(v-i.origin),f=i.inv_direction*(m-i.origin),n=min(f,x),r=max(f,x);
   vec2 s=max(n.xx,n.yz);
   float z=max(s.x,s.y);
   s=min(r.xx,r.yz);
   float t=min(s.x,s.y);
   y.x=z;
   y.y=t;
   return t>max(z,0.);
 }
 bool d(const vec3 v,const vec3 m,Ray i,inout float x,inout vec3 y)
 {
   vec3 z=i.inv_direction*(v-i.origin),f=i.inv_direction*(m-i.origin),n=min(f,z),r=max(f,z);
   vec2 s=max(n.xx,n.yz);
   float t=max(s.x,s.y);
   s=min(r.xx,r.yz);
   float h=min(s.x,s.y);
   bool a=h>max(t,0.)&&max(t,0.)<x;
   if(a)
     y=d(v,m,i.origin+i.direction*t),x=t;
   return a;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 t=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   t*=saturate(dot(f,y));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float r=abs(n.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,r),a=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     t=mix(t,t*h,1.-a);
   }
   t=TintUnderwaterDepth(t);
   return t*(1.-rainStrength);
 }
 vec3 f(vec3 y,vec3 f,vec3 x,vec3 i,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(y),n=m(s+x*.99);
   float r=.5;
   vec3 t=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*r),3).x;
   t*=saturate(dot(f,x));
   t=TintUnderwaterDepth(t);
   return t*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct VcxfcrgVbw{float bgoSMWoOlk;float UchydvPYLr;float bRfUKhvDSW;float DqzEnDHRia;vec3 YNIRJTVYcH;};
 vec4 i(VcxfcrgVbw v)
 {
   vec4 i;
   v.YNIRJTVYcH=max(vec3(0.),v.YNIRJTVYcH);
   i.x=v.bgoSMWoOlk;
   v.YNIRJTVYcH=pow(v.YNIRJTVYcH,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.YNIRJTVYcH.x,v.bRfUKhvDSW);
   i.z=PackTwo16BitTo32Bit(v.YNIRJTVYcH.y,v.DqzEnDHRia);
   i.w=PackTwo16BitTo32Bit(v.YNIRJTVYcH.z,v.UchydvPYLr);
   return i;
 }
 VcxfcrgVbw h(vec4 v)
 {
   VcxfcrgVbw i;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),x=UnpackTwo16BitFrom32Bit(v.z),y=UnpackTwo16BitFrom32Bit(v.w);
   i.bgoSMWoOlk=v.x;
   i.bRfUKhvDSW=m.y;
   i.DqzEnDHRia=x.y;
   i.UchydvPYLr=y.y;
   i.YNIRJTVYcH=pow(vec3(m.x,x.x,y.x),vec3(8.));
   return i;
 }
 VcxfcrgVbw D(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return h(texture2DLod(colortex5,v,0));
 }
 float D(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void D(inout float v,inout float i,float x,float y,vec3 f,float m)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,y);
   #else
   v*=mix(3.4,3.4,y);
   #endif
   float s=dot(f,vec3(1.));
   i*=1.-pow(y,.4);
   i/=x*.1+2e-06;
   i*=4.;
   i*=.6;
   float r=x/(s+1e-07)*.2+4e-08;
   r=min(r,1.);
   r=mix(r,1.,pow(y,.25));
   if(m<.12)
     i=0.;
 }
 float D(vec3 v,vec3 y,float x)
 {
   float i=dot(abs(v-y),vec3(.3333));
   i*=x;
   i*=.18;
   return i;
 }
 void e(inout vec3 v,vec2 x,vec3 y)
 {}
 float e(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool d(vec3 v,float x,Ray y,bool f,inout float i,inout vec3 r)
 {
   bool s=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(f)
     return false;
   if(x>=66.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),y,i,r);
   s=m;
   #else
   if(x<40.)
     return m=d(v,v+vec3(1.,1.,1.),y,i,r),m;
   if(x==40.||x>=42.&&x<=53.)
     m=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),y,i,r),s=s||m;
   if(x==41.||x>=54.&&x<=65.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),y,i,r),s=s||m;
   if(x==42.||x==45.||x==46.||x==51.||x==52.||x==53.||x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
     {
       float z=.5;
       if(x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
         z=0.;
       m=d(v+vec3(0.,z,0.),v+vec3(.5,.5+z,.5),y,i,r);
       s=s||m;
     }
   if(x==42.||x==44.||x==47.||x==50.||x==52.||x==53.||x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
     {
       float z=.5;
       if(x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
         z=0.;
       m=d(v+vec3(.5,z,0.),v+vec3(1.,.5+z,.5),y,i,r);
       s=s||m;
     }
   if(x==43.||x==44.||x==48.||x==50.||x==51.||x==53.||x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
     {
       float z=.5;
       if(x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
         z=0.;
       m=d(v+vec3(.5,z,.5),v+vec3(1.,.5+z,1.),y,i,r);
       s=s||m;
     }
   if(x==43.||x==45.||x==49.||x==50.||x==51.||x==52.||x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
     {
       float z=.5;
       if(x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
         z=0.;
       m=d(v+vec3(0.,z,.5),v+vec3(.5,.5+z,1.),y,i,r);
       s=s||m;
     }
   if(x>=66.&&x<=81.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,y,i,r),s=s||m;
   if(x==67.||x==68.||x==69.||x==71.||x==72.||x==73.||x==75.||x==76.||x==77.||x==79.||x==80.||x==81.)
     {
       float z=8.,a=8.;
       if(x==67.||x==69.||x==71.||x==73.||x==75.||x==77.||x==79.||x==81.)
         z=0.;
       if(x==68.||x==69.||x==72.||x==73.||x==76.||x==77.||x==80.||x==81.)
         a=16.;
       m=d(v+vec3(z,6.,7.)/16.,v+vec3(a,9.,9.)/16.,y,i,r);
       s=s||m;
       m=d(v+vec3(z,12.,7.)/16.,v+vec3(a,15.,9.)/16.,y,i,r);
       s=s||m;
     }
   if(x>=70.&&x<=81.)
     {
       float z=8.,n=8.;
       if(x>=70.&&x<=73.||x>=78.&&x<=81.)
         n=16.;
       if(x>=74.&&x<=81.)
         z=0.;
       m=d(v+vec3(7.,6.,z)/16.,v+vec3(9.,9.,n)/16.,y,i,r);
       s=s||m;
       m=d(v+vec3(7.,12.,z)/16.,v+vec3(9.,15.,n)/16.,y,i,r);
       s=s||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=82.&&x<=85.)
     {
       vec3 z=vec3(0),a=vec3(0);
       if(x==82.)
         z=vec3(0,0,0),a=vec3(16,16,3);
       if(x==83.)
         z=vec3(0,0,13),a=vec3(16,16,16);
       if(x==85.)
         z=vec3(0,0,0),a=vec3(3,16,16);
       if(x==84.)
         z=vec3(13,0,0),a=vec3(16,16,16);
       m=d(v+z/16.,v+a/16.,y,i,r);
       s=s||m;
     }
   if(x>=86.&&x<=101.)
     {
       vec3 z=vec3(0.),a=vec3(1.);
       if(x>=86.&&x<=93.)
         {
           float n=0.;
           if(x>=90.&&x<=93.)
             n=13.;
           z=vec3(0.,n,0.)/16.;
           a=vec3(16.,n+3.,16.)/16.;
         }
       if(x>=94.&&x<=97.)
         {
           float n=13.;
           if(x==96.||x==97.)
             n=0.;
           z=vec3(0.,0.,n)/16.;
           a=vec3(16.,16.,n+3.)/16.;
         }
       if(x>=98.&&x<=101.)
         {
           float n=13.;
           if(x==98.||x==99.)
             n=0.;
           z=vec3(n,0.,0.)/16.;
           a=vec3(n+3.,16.,16.)/16.;
         }
       m=d(v+z,v+a,y,i,r);
       s=s||m;
     }
   if(x>=102.&&x<=112.)
     {
       vec3 z=vec3(0.),n=vec3(1.);
       if(x>=102.&&x<=109.)
         {
           float t=float(x)-float(102.)+1.;
           n.y=t*2./16.;
         }
       if(x==110.)
         n.y=.0625;
       if(x==111.)
         z=vec3(1.,0.,1.)/16.,n=vec3(15.,1.,15.)/16.;
       if(x==112.)
         z=vec3(1.,0.,1.)/16.,n=vec3(15.,.5,15.)/16.;
       m=d(v+z,v+n,y,i,r);
       s=s||m;
     }
   #endif
   #endif
   return s;
 }
 vec4 D(vec3 v,vec2 i,out float x,inout float z)
 {
   vec3 y=v;
   int r=t();
   v=clamp(v,vec3(1./r),vec3(1.-1./r));
   if(distance(v,y)>.005/r)
     z=1.;
   float m=dot(abs(v-y),vec3(1.));
   #ifdef MC_GL_VENDOR_ATI
   v-=1./float(r)*vec3(0.,0.,1.);
   #endif
   vec2 f=d(v,r);
   f+=i.xy*(1./vec2(4096));
   f=f*2.-1.;
   x=m;
   return vec4(f,x,1.);
 }
 void main()
 {
   gl_Position=ftransform();
   vTexcoord=gl_MultiTexCoord0;
   vMCEntity=mc_Entity.x;
   vec4 v=gl_Position;
   v=shadowProjectionInverse*v;
   v=shadowModelViewInverse*v;
   v.xyz+=cameraPosition.xyz;
   vec3 x=v.xyz;
   vMaterialIDs=30.;
   float m=0.,i=0.f;
   if(mc_Entity.x==8||mc_Entity.x==9)
     m=1.f;
   if(mc_Entity.x==95||mc_Entity.x==160||mc_Entity.x==90||mc_Entity.x==165||mc_Entity.x==79)
     i=1.f;
   if(mc_Entity.x==18.||mc_Entity.x==161.f)
     vMaterialIDs=32.;
   if(mc_Entity.x==79.f||mc_Entity.x==174.f)
     vMaterialIDs=33.;
   if(mc_Entity.x==50)
     vMaterialIDs=241.;
   if(mc_Entity.x==76)
     vMaterialIDs=241.;
   if(mc_Entity.x==10||mc_Entity.x==11)
     vMaterialIDs=241.;
   if(mc_Entity.x==89||mc_Entity.x==124||mc_Entity.x==10||mc_Entity.x==11||mc_Entity.x==169||mc_Entity.x==91)
     vMaterialIDs=31.;
   if(mc_Entity.x==51)
     vMaterialIDs=241.;
   #ifdef GLOWING_LAPIS_LAZULI_BLOCK
   if(mc_Entity.x==22)
     vMaterialIDs=31.;
   #endif
   #ifdef GLOWING_REDSTONE_BLOCK
   if(mc_Entity.x==152)
     vMaterialIDs=31.;
   #endif
   if(mc_Entity.x==95||mc_Entity.x==160)
     vMaterialIDs=240.;
   vec3 y=gl_Normal,s=normalize(gl_NormalMatrix*y);
   if(abs(vMaterialIDs-2.)<.1)
     y=vec3(0.,1.,0.);
   qATJEDLiyF=mc_midTexCoord.xy;
   vColor=gl_Color;
   if(vMaterialIDs!=2.)
     {
       if(y.x>.85)
         vColor.xyz*=1./.6;
       if(y.x<-.85)
         vColor.xyz*=1./.6;
       if(y.z>.85)
         vColor.xyz*=1.25;
       if(y.z<-.85)
         vColor.xyz*=1.25;
       if(y.y<-.85)
         vColor.xyz*=2.;
     }
   SZEGaNoNyW=0.;
   vec2 r;
   vec3 f=d(v.xyz,gl_Normal.xyz,vTexcoord.xy,mc_midTexCoord.xy,at_tangent,mc_Entity,SZEGaNoNyW,r);
   if(mc_Entity.x>255)
     vMaterialIDs=mc_Entity.x-255.+39.;
   f=floor(f);
   f-=cameraPosition.xyz;
   int z=t();
   f=n(f,z);
   float a;
   kSIUoJlAap=D(f,r,a,SZEGaNoNyW);
   if(mc_Entity.x==51)
     a+=.9;
   v.xyz-=cameraPosition.xyz;
   v=shadowModelView*v;
   v=shadowProjection*v;
   gl_Position=v;
   float h=sqrt(gl_Position.x*gl_Position.x+gl_Position.y*gl_Position.y),S=1.f-SHADOW_MAP_BIAS+h*SHADOW_MAP_BIAS;
   gl_Position.xy*=.95f/S;
   gl_Position.xy*=.5;
   gl_Position.xy+=.5;
   if(m>.5)
     gl_Position.y-=1.;
   if(i>.5)
     gl_Position.x-=1.;
   gl_Position.z=mix(gl_Position.z,.5,.8);
   JVKUXnCTcE=gl_Position;
   gl_FrontColor=gl_Color;
 };



