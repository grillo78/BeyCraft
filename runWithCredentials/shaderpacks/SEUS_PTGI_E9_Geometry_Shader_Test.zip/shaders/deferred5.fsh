#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/







in vec4 texcoord;


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBufferData.inc"


 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,y=d();
   ivec2 f=ivec2(v.x*m.x,v.y*m.y);
   float z=float(f.y/y),i=float(int(f.x+mod(m.x*z,y))/y);
   i+=floor(m.x*z/y);
   vec3 t=vec3(0.,0.,i);
   t.x=mod(f.x+mod(m.x*z,y),y);
   t.y=mod(f.y,y);
   t.xyz=floor(t.xyz);
   t/=y;
   t.xyz=t.xzy;
   return t;
 }
 vec2 x(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 f=v.xzy*x;
   f=floor(f+1e-05);
   float y=f.z;
   vec2 i;
   i.x=mod(f.x+y*x,m.x);
   float t=f.x+y*x;
   i.y=f.y+floor(t/m.x)*x;
   i+=.5;
   i/=m;
   return i;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 t=ivec2(i.x*m.x,i.y*m.y);
   float z=float(t.y/y),r=float(int(t.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 d=vec3(0.,0.,r);
   d.x=mod(t.x+mod(m.x*z,y),y);
   d.y=mod(t.y,y);
   d.xyz=floor(d.xyz);
   d/=y;
   d.xyz=d.xzy;
   return d;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 f=v.xzy*y;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 i;
   i.x=mod(f.x+x*y,m.x);
   float t=f.x+x*y;
   i.y=f.y+floor(t/m.x)*y;
   i+=.5;
   i/=m;
   i.xy*=.5;
   return i;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 n()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,x=floor(v-.0001),y=floor(f-.0001);
   return x-y;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 t,vec2 d,vec4 m,vec4 i,inout float x,out vec2 y)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!r||i.x==20.||i.x==171.||min(abs(f.x),abs(f.z))>.2)
     x=1.;
   if(i.x==50.||i.x==76.)
     {
       x=0.;
       if(f.y<.5)
         x=1.;
     }
   if(i.x==51)
     x=0.;
   if(i.x>255)
     x=0.;
   vec3 z,c;
   if(f.x>.5)
     z=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       z=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         z=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           z=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             z=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               z=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   y=clamp((t.xy-d.xy)*100000.,vec2(0.),vec2(1.));
   float s=.15,k=.15;
   if(i.x==10.||i.x==11.)
     {
       if(abs(f.y)<.01&&r||f.y>.99)
         s=.1,k=.1,x=0.;
       else
          x=1.;
     }
   if(i.x==51)
     s=.5,k=.1;
   if(i.x==76)
     s=.2,k=.2;
   if(i.x-255.+39.>=102.&&i.x-255.+39.<=112.)
     k=.025,s=.025;
   z=normalize(m.xyz);
   c=normalize(cross(z,f.xyz)*sign(m.w));
   vec3 n=v.xyz+mix(z*s,-z*s,vec3(y.x));
   n.xyz+=mix(c*s,-c*s,vec3(y.y));
   n.xyz-=f.xyz*k;
   return n;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA e(Ray v)
 {
   DDA f;
   f.mapPos=floor(v.origin);
   f.mapPosOrigin=f.mapPos;
   f.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.rayStep=sign(v.direction);
   f.sideDist=(sign(v.direction)*(f.mapPos-v.origin)+sign(v.direction)*.5+.5)*f.deltaDist;
   f.mask=vec3(0.);
   return f;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float y)
 {
   float x,z,r,t;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),r);
   y=min(min(y,z),t);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,t=y-z,r=vec3(0.);
   r+=vec3(sign(t.x),0.,0.)*step(abs(abs(t.x)-i.x),x);
   r+=vec3(0.,sign(t.y),0.)*step(abs(abs(t.y)-i.y),x);
   r+=vec3(0.,0.,sign(t.z))*step(abs(abs(t.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),t=min(x,y),c=max(x,y);
   vec2 r=max(t.xx,t.yz);
   float z=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float s=min(r.x,r.y);
   i.x=z;
   i.y=s;
   return s>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 y)
 {
   vec3 z=m.inv_direction*(v-m.origin),t=m.inv_direction*(f-m.origin),i=min(t,z),c=max(t,z);
   vec2 r=max(i.xx,i.yz);
   float s=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float G=min(r.x,r.y);
   bool n=G>max(s,0.)&&max(s,0.)<x;
   if(n)
     y=d(v,f,m.origin+m.direction*s),x=s;
   return n;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float t=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*t),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 d=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float c=abs(d.x*256.-(v.y+cameraPosition.y)),s=GetCausticsComposite(v,f,c),n=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*s,1.-n);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 f,vec3 i,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 t=v(f),c=m(t+y*.99);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z-.0006*s),3).x;
   r*=saturate(dot(i,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float t=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*t),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct VcxfcrgVbw{float bgoSMWoOlk;float UchydvPYLr;float bRfUKhvDSW;float DqzEnDHRia;vec3 YNIRJTVYcH;};
 vec4 h(VcxfcrgVbw v)
 {
   vec4 i;
   v.YNIRJTVYcH=max(vec3(0.),v.YNIRJTVYcH);
   i.x=v.bgoSMWoOlk;
   v.YNIRJTVYcH=pow(v.YNIRJTVYcH,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.YNIRJTVYcH.x,v.bRfUKhvDSW);
   i.z=PackTwo16BitTo32Bit(v.YNIRJTVYcH.y,v.DqzEnDHRia);
   i.w=PackTwo16BitTo32Bit(v.YNIRJTVYcH.z,v.UchydvPYLr);
   return i;
 }
 VcxfcrgVbw i(vec4 v)
 {
   VcxfcrgVbw i;
   vec2 f=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),t=UnpackTwo16BitFrom32Bit(v.w);
   i.bgoSMWoOlk=v.x;
   i.bRfUKhvDSW=f.y;
   i.DqzEnDHRia=m.y;
   i.UchydvPYLr=t.y;
   i.YNIRJTVYcH=pow(vec3(f.x,m.x,t.x),vec3(8.));
   return i;
 }
 VcxfcrgVbw G(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void G(inout float v,inout float i,float f,float y,vec3 x,float t)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,y);
   #else
   v*=mix(3.4,3.4,y);
   #endif
   float r=dot(x,vec3(1.));
   i*=1.-pow(y,.4);
   i/=f*.1+2e-06;
   i*=4.;
   i*=.6;
   float z=f/(r+1e-07)*.2+4e-08;
   z=min(z,1.);
   z=mix(z,1.,pow(y,.25));
   if(t<.12)
     i=0.;
 }
 float G(vec3 v,vec3 y,float f)
 {
   float i=dot(abs(v-y),vec3(.3333));
   i*=f;
   i*=.18;
   return i;
 }
 void e(inout vec3 v,vec2 x,vec3 y)
 {}
 float e(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool d(vec3 v,float y,Ray x,bool f,inout float i,inout vec3 z)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(f)
     return false;
   if(y>=66.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),x,i,z);
   r=m;
   #else
   if(y<40.)
     return m=d(v,v+vec3(1.,1.,1.),x,i,z),m;
   if(y==40.||y>=42.&&y<=53.)
     m=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),x,i,z),r=r||m;
   if(y==41.||y>=54.&&y<=65.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),x,i,z),r=r||m;
   if(y==42.||y==45.||y==46.||y==51.||y==52.||y==53.||y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
     {
       float t=.5;
       if(y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
         t=0.;
       m=d(v+vec3(0.,t,0.),v+vec3(.5,.5+t,.5),x,i,z);
       r=r||m;
     }
   if(y==42.||y==44.||y==47.||y==50.||y==52.||y==53.||y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
     {
       float t=.5;
       if(y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
         t=0.;
       m=d(v+vec3(.5,t,0.),v+vec3(1.,.5+t,.5),x,i,z);
       r=r||m;
     }
   if(y==43.||y==44.||y==48.||y==50.||y==51.||y==53.||y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
     {
       float t=.5;
       if(y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
         t=0.;
       m=d(v+vec3(.5,t,.5),v+vec3(1.,.5+t,1.),x,i,z);
       r=r||m;
     }
   if(y==43.||y==45.||y==49.||y==50.||y==51.||y==52.||y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
     {
       float t=.5;
       if(y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
         t=0.;
       m=d(v+vec3(0.,t,.5),v+vec3(.5,.5+t,1.),x,i,z);
       r=r||m;
     }
   if(y>=66.&&y<=81.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,x,i,z),r=r||m;
   if(y==67.||y==68.||y==69.||y==71.||y==72.||y==73.||y==75.||y==76.||y==77.||y==79.||y==80.||y==81.)
     {
       float t=8.,c=8.;
       if(y==67.||y==69.||y==71.||y==73.||y==75.||y==77.||y==79.||y==81.)
         t=0.;
       if(y==68.||y==69.||y==72.||y==73.||y==76.||y==77.||y==80.||y==81.)
         c=16.;
       m=d(v+vec3(t,6.,7.)/16.,v+vec3(c,9.,9.)/16.,x,i,z);
       r=r||m;
       m=d(v+vec3(t,12.,7.)/16.,v+vec3(c,15.,9.)/16.,x,i,z);
       r=r||m;
     }
   if(y>=70.&&y<=81.)
     {
       float t=8.,c=8.;
       if(y>=70.&&y<=73.||y>=78.&&y<=81.)
         c=16.;
       if(y>=74.&&y<=81.)
         t=0.;
       m=d(v+vec3(7.,6.,t)/16.,v+vec3(9.,9.,c)/16.,x,i,z);
       r=r||m;
       m=d(v+vec3(7.,12.,t)/16.,v+vec3(9.,15.,c)/16.,x,i,z);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=82.&&y<=85.)
     {
       vec3 t=vec3(0),c=vec3(0);
       if(y==82.)
         t=vec3(0,0,0),c=vec3(16,16,3);
       if(y==83.)
         t=vec3(0,0,13),c=vec3(16,16,16);
       if(y==85.)
         t=vec3(0,0,0),c=vec3(3,16,16);
       if(y==84.)
         t=vec3(13,0,0),c=vec3(16,16,16);
       m=d(v+t/16.,v+c/16.,x,i,z);
       r=r||m;
     }
   if(y>=86.&&y<=101.)
     {
       vec3 t=vec3(0.),c=vec3(1.);
       if(y>=86.&&y<=93.)
         {
           float s=0.;
           if(y>=90.&&y<=93.)
             s=13.;
           t=vec3(0.,s,0.)/16.;
           c=vec3(16.,s+3.,16.)/16.;
         }
       if(y>=94.&&y<=97.)
         {
           float s=13.;
           if(y==96.||y==97.)
             s=0.;
           t=vec3(0.,0.,s)/16.;
           c=vec3(16.,16.,s+3.)/16.;
         }
       if(y>=98.&&y<=101.)
         {
           float s=13.;
           if(y==98.||y==99.)
             s=0.;
           t=vec3(s,0.,0.)/16.;
           c=vec3(s+3.,16.,16.)/16.;
         }
       m=d(v+t,v+c,x,i,z);
       r=r||m;
     }
   if(y>=102.&&y<=112.)
     {
       vec3 t=vec3(0.),c=vec3(1.);
       if(y>=102.&&y<=109.)
         {
           float s=float(y)-float(102.)+1.;
           c.y=s*2./16.;
         }
       if(y==110.)
         c.y=.0625;
       if(y==111.)
         t=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(y==112.)
         t=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       m=d(v+t,v+c,x,i,z);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 float c(vec3 v)
 {
   float y=simplex3d(v*vec3(1.,.01,1.5)+vec3(-v.z*1.2+v.y*.2,0.,0.));
   y+=simplex3d(v*vec3(1.,.01,.9)+vec3(-v.z*.7-v.y*.2,0.,0.));
   return y*1.5;
 }
 vec2 c(vec2 v,float y)
 {
   v*=8.;
   float f=c(vec3(v.xy*5.+vec2(-.025,-.025),y))-.5,x=c(vec3(v.xy*5.+vec2(.025,-.025),y))-.5,i=c(vec3(v.xy*5.+vec2(-.025,.025),y))-.5;
   vec3 t=normalize(vec3(f-x,f-i,2.5));
   return t.xy;
 }
 float h(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 float i(vec3 v,vec3 y)
 {
   return dot(abs(v-y),vec3(.3333));
 }
 void main()
 {
   VcxfcrgVbw v=G(texcoord.xy);
   float y=v.DqzEnDHRia;
   int x=0;
   vec4 f=texture2DLod(colortex6,texcoord.xy,0);
   vec3 i=f.xyz;
   float t=Luminance(i.xyz),c=f.w;
   vec3 r=GetNormals(texcoord.xy);
   float z=GetDepth(texcoord.xy),m=ExpToLinearDepth(z);
   vec3 d=GetViewPosition(texcoord.xy,z).xyz;
   vec2 s=vec2(0.);
   float a=8.*1,n=8.;
   G(a,n,f.w,y,i,m);
   float k=24.*mix(1.,6.,y),o=mix(20.,15.,y)/m,Y=0.;
   vec4 b=vec4(0.);
   float p=0.;
   int D=0;
   for(int h=-1;h<=1;h++)
     {
       for(int R=-1;R<=1;R++)
         {
           vec2 H=(vec2(h,R)+s)/vec2(viewWidth,viewHeight)*a,w=texcoord.xy+H.xy;
           float V=length(H*vec2(viewWidth,viewHeight));
           w=clamp(w,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
           vec4 U=texture2DLod(colortex6,w,x);
           vec3 W=GetNormals(w);
           float F=GetDepth(w),l=ExpToLinearDepth(F),S=pow(saturate(dot(r,W)),k),T=exp(-(abs(l-m)*o)),g=0.;
           #if GI_FILTER_QUALITY==1
           vec3 u=GetViewPosition(w,F).xyz,B=normalize(u.xyz-d.xyz);
           float P=dot(-W,B);
           bool E=P>0.&&Luminance(U.xyz)<Luminance(i.xyz);
           S=E?2.:S;
           g=exp(-G(U.xyz,i,E?n:n));
           #else
           g=exp(-G(U.xyz,i,n));
           #endif
           float L=T*g*S;
           b+=U*L;
           p+=L;
           D++;
         }
     }
   b/=p+.0001;
   vec3 h=b.xyz;
   if(p<.0001)
     h=i;
   e(h,texcoord.xy,rand(texcoord.xy+sin(frameTimeCounter)).xyz);
   float w=1.;
   if(texcoord.y<.25)
     {
       vec2 H=texcoord.xy*vec2(4.,4.),R=vec2(H.x,(H.y-floor(mod(FRAME_TIME*60.f,60.f)))/60.f);
       if(texcoord.x<.25)
         w=texture2DLod(colortex0,R.xy,0).x;
       else
          if(texcoord.x>.25&&texcoord.x<.5)
           w=texture2DLod(colortex0,R.xy,0).y;
         else
            if(texcoord.x>.5&&texcoord.x<.75)
             w=texture2DLod(colortex0,R.xy,0).z;
           else
              w=texture2DLod(colortex0,R.xy,0).w;
     }
   vec2 R=1.-abs(texcoord.xy*2.-1.);
   R=saturate(R*10.);
   float H=min(R.x,R.y);
   h.xyz*=mix(vec3(1.),BlueNoiseTemporal(texcoord.xy).xyz*2.,vec3(1.-pow(y,.5))*.25*H);
   gl_FragData[0]=vec4(h,w);
 };




/* DRAWBUFFERS:6 */
