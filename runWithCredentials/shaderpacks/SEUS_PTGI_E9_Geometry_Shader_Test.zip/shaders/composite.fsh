#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/





in vec4 texcoord;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorTorchlight;
in vec3 colorSkyUp;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;

in vec3 worldLightVector;
in vec3 worldSunVector;

in float timeMidnight;

#include "lib/Uniforms.inc"
#include "lib/Common.inc"



/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////








vec2 GetNearFragment(vec2 coord, float depth, out float minDepth)
{
	
	
	vec2 texel = 1.0 / vec2(viewWidth, viewHeight);
	vec4 depthSamples;
	depthSamples.x = texture2D(depthtex1, coord + texel * vec2(1.0, 1.0)).x;
	depthSamples.y = texture2D(depthtex1, coord + texel * vec2(1.0, -1.0)).x;
	depthSamples.z = texture2D(depthtex1, coord + texel * vec2(-1.0, 1.0)).x;
	depthSamples.w = texture2D(depthtex1, coord + texel * vec2(-1.0, -1.0)).x;

	vec2 targetFragment = vec2(0.0, 0.0);

	if (depthSamples.x < depth)
		targetFragment = vec2(1.0, 1.0);
	if (depthSamples.y < depth)
		targetFragment = vec2(1.0, -1.0);
	if (depthSamples.z < depth)
		targetFragment = vec2(-1.0, 1.0);
	if (depthSamples.w < depth)
		targetFragment = vec2(-1.0, -1.0);


	minDepth = min(min(min(depthSamples.x, depthSamples.y), depthSamples.z), depthSamples.w);

	return coord + texel * targetFragment;
}






#include "lib/Materials.inc"
#include "lib/GBufferData.inc"




 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int e(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int e()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int y=v.x*v.y;
   return t(f(floor(pow(float(y),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int y=v.x*v.y;
   return e(f(floor(pow(float(y),.333333))));
 }
 vec3 v(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=e();
   ivec2 i=ivec2(v.x*f.x,v.y*f.y);
   float z=float(i.y/y),r=float(int(i.x+mod(f.x*z,y))/y);
   r+=floor(f.x*z/y);
   vec3 m=vec3(0.,0.,r);
   m.x=mod(i.x+mod(f.x*z,y),y);
   m.y=mod(i.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 s(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int y=e();
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,f.x);
   float c=i.x+x*y;
   r.y=i.y+floor(c/f.x)*y;
   r+=.5;
   r/=f;
   return r;
 }
 vec3 d(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 c=ivec2(i.x*m.x,i.y*m.y);
   float z=float(c.y/y),r=float(int(c.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 s=vec3(0.,0.,r);
   s.x=mod(c.x+mod(m.x*z,y),y);
   s.y=mod(c.y,y);
   s.xyz=floor(s.xyz);
   s/=y;
   s.xyz=s.xzy;
   return s;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 f=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,f.x);
   float c=i.x+x*y;
   r.y=i.y+floor(c/f.x)*y;
   r+=.5;
   r/=f;
   r.xy*=.5;
   return r;
 }
 vec3 e(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 m(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 x(vec3 v)
 {
   int y=e();
   v*=1./y;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 n(vec3 v)
 {
   int f=e();
   v=v-vec3(.5);
   v*=f;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,f=floor(v-.0001),y=floor(i-.0001);
   return f-y;
 }
 vec3 p(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 i,vec2 y,vec4 c,vec4 m,inout float x,out vec2 r)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(m.x==8||m.x==9||m.x==79||m.x<1.||!z||m.x==20.||m.x==171.||min(abs(f.x),abs(f.z))>.2)
     x=1.;
   if(m.x==50.||m.x==76.)
     {
       x=0.;
       if(f.y<.5)
         x=1.;
     }
   if(m.x==51)
     x=0.;
   if(m.x>255)
     x=0.;
   vec3 s,t;
   if(f.x>.5)
     s=vec3(0.,0.,-1.),t=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       s=vec3(0.,0.,1.),t=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         s=vec3(1.,0.,0.),t=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           s=vec3(1.,0.,0.),t=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             s=vec3(1.,0.,0.),t=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               s=vec3(-1.,0.,0.),t=vec3(0.,-1.,0.);
   r=clamp((i.xy-y.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,k=.15;
   if(m.x==10.||m.x==11.)
     {
       if(abs(f.y)<.01&&z||f.y>.99)
         h=.1,k=.1,x=0.;
       else
          x=1.;
     }
   if(m.x==51)
     h=.5,k=.1;
   if(m.x==76)
     h=.2,k=.2;
   if(m.x-255.+39.>=102.&&m.x-255.+39.<=112.)
     k=.025,h=.025;
   s=normalize(c.xyz);
   t=normalize(cross(s,f.xyz)*sign(c.w));
   vec3 n=v.xyz+mix(s*h,-s*h,vec3(r.x));
   n.xyz+=mix(t*h,-t*h,vec3(r.y));
   n.xyz-=f.xyz*k;
   return n;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA r(Ray v)
 {
   DDA f;
   f.mapPos=floor(v.origin);
   f.mapPosOrigin=f.mapPos;
   f.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.rayStep=sign(v.direction);
   f.sideDist=(sign(v.direction)*(f.mapPos-v.origin)+sign(v.direction)*.5+.5)*f.deltaDist;
   f.mask=vec3(0.);
   return f;
 }
 void i(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float y)
 {
   float x,z,r,t;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),r);
   y=min(min(y,z),t);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,m=y-z,r=vec3(0.);
   r+=vec3(sign(m.x),0.,0.)*step(abs(abs(m.x)-i.x),x);
   r+=vec3(0.,sign(m.y),0.)*step(abs(abs(m.y)-i.y),x);
   r+=vec3(0.,0.,sign(m.z))*step(abs(abs(m.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),c=min(x,y),t=max(x,y);
   vec2 r=max(c.xx,c.yz);
   float z=max(r.x,r.y);
   r=min(t.xx,t.yz);
   float s=min(r.x,r.y);
   i.x=z;
   i.y=s;
   return s>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float y,inout vec3 x)
 {
   vec3 z=m.inv_direction*(v-m.origin),i=m.inv_direction*(f-m.origin),c=min(i,z),t=max(i,z);
   vec2 r=max(c.xx,c.yz);
   float s=max(r.x,r.y);
   r=min(t.xx,t.yz);
   float n=min(r.x,r.y);
   bool a=n>max(s,0.)&&max(s,0.)<y;
   if(a)
     x=d(v,f,m.origin+m.direction*s),y=s;
   return a;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=p(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 m=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float t=abs(m.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,t),n=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-n);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 i=m(v),c=p(i+y*.99);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z-.0006*s),3).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 i(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=p(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct VcxfcrgVbw{float bgoSMWoOlk;float UchydvPYLr;float bRfUKhvDSW;float DqzEnDHRia;vec3 YNIRJTVYcH;};
 vec4 h(VcxfcrgVbw v)
 {
   vec4 f;
   v.YNIRJTVYcH=max(vec3(0.),v.YNIRJTVYcH);
   f.x=v.bgoSMWoOlk;
   v.YNIRJTVYcH=pow(v.YNIRJTVYcH,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.YNIRJTVYcH.x,v.bRfUKhvDSW);
   f.z=PackTwo16BitTo32Bit(v.YNIRJTVYcH.y,v.DqzEnDHRia);
   f.w=PackTwo16BitTo32Bit(v.YNIRJTVYcH.z,v.UchydvPYLr);
   return f;
 }
 VcxfcrgVbw w(vec4 v)
 {
   VcxfcrgVbw f;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),i=UnpackTwo16BitFrom32Bit(v.z),t=UnpackTwo16BitFrom32Bit(v.w);
   f.bgoSMWoOlk=v.x;
   f.bRfUKhvDSW=m.y;
   f.DqzEnDHRia=i.y;
   f.UchydvPYLr=t.y;
   f.YNIRJTVYcH=pow(vec3(m.x,i.x,t.x),vec3(8.));
   return f;
 }
 VcxfcrgVbw G(vec2 v)
 {
   vec2 y=1./vec2(viewWidth,viewHeight),z=vec2(viewWidth,viewHeight);
   v=(floor(v*z)+.5)*y;
   return w(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float f=1.;
   #ifdef FULL_RT_REFLECTIONS
   f=clamp(pow(v,.125)+y,0.,1.);
   #else
   f=clamp(v*10.-7.,0.,1.);
   #endif
   return f;
 }
 void G(inout float v,inout float f,float y,float i,vec3 x,float z)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,i);
   #else
   v*=mix(3.4,3.4,i);
   #endif
   float r=dot(x,vec3(1.));
   f*=1.-pow(i,.4);
   f/=y*.1+2e-06;
   f*=4.;
   f*=.6;
   float s=y/(r+1e-07)*.2+4e-08;
   s=min(s,1.);
   s=mix(s,1.,pow(i,.25));
   if(z<.12)
     f=0.;
 }
 float G(vec3 v,vec3 y,float f)
 {
   float r=dot(abs(v-y),vec3(.3333));
   r*=f;
   r*=.18;
   return r;
 }
 void e(inout vec3 v,vec2 f,vec3 y)
 {}
 float h(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool d(vec3 v,float y,Ray f,bool z,inout float i,inout vec3 x)
 {
   bool r=false,s=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(z)
     return false;
   if(y>=66.)
     return false;
   s=d(v,v+vec3(1.,1.,1.),f,i,x);
   r=s;
   #else
   if(y<40.)
     return s=d(v,v+vec3(1.,1.,1.),f,i,x),s;
   if(y==40.||y>=42.&&y<=53.)
     s=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),f,i,x),r=r||s;
   if(y==41.||y>=54.&&y<=65.)
     s=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,x),r=r||s;
   if(y==42.||y==45.||y==46.||y==51.||y==52.||y==53.||y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
     {
       float t=.5;
       if(y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
         t=0.;
       s=d(v+vec3(0.,t,0.),v+vec3(.5,.5+t,.5),f,i,x);
       r=r||s;
     }
   if(y==42.||y==44.||y==47.||y==50.||y==52.||y==53.||y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
     {
       float t=.5;
       if(y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
         t=0.;
       s=d(v+vec3(.5,t,0.),v+vec3(1.,.5+t,.5),f,i,x);
       r=r||s;
     }
   if(y==43.||y==44.||y==48.||y==50.||y==51.||y==53.||y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
     {
       float t=.5;
       if(y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
         t=0.;
       s=d(v+vec3(.5,t,.5),v+vec3(1.,.5+t,1.),f,i,x);
       r=r||s;
     }
   if(y==43.||y==45.||y==49.||y==50.||y==51.||y==52.||y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
     {
       float t=.5;
       if(y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
         t=0.;
       s=d(v+vec3(0.,t,.5),v+vec3(.5,.5+t,1.),f,i,x);
       r=r||s;
     }
   if(y>=66.&&y<=81.)
     s=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,x),r=r||s;
   if(y==67.||y==68.||y==69.||y==71.||y==72.||y==73.||y==75.||y==76.||y==77.||y==79.||y==80.||y==81.)
     {
       float t=8.,c=8.;
       if(y==67.||y==69.||y==71.||y==73.||y==75.||y==77.||y==79.||y==81.)
         t=0.;
       if(y==68.||y==69.||y==72.||y==73.||y==76.||y==77.||y==80.||y==81.)
         c=16.;
       s=d(v+vec3(t,6.,7.)/16.,v+vec3(c,9.,9.)/16.,f,i,x);
       r=r||s;
       s=d(v+vec3(t,12.,7.)/16.,v+vec3(c,15.,9.)/16.,f,i,x);
       r=r||s;
     }
   if(y>=70.&&y<=81.)
     {
       float t=8.,c=8.;
       if(y>=70.&&y<=73.||y>=78.&&y<=81.)
         c=16.;
       if(y>=74.&&y<=81.)
         t=0.;
       s=d(v+vec3(7.,6.,t)/16.,v+vec3(9.,9.,c)/16.,f,i,x);
       r=r||s;
       s=d(v+vec3(7.,12.,t)/16.,v+vec3(9.,15.,c)/16.,f,i,x);
       r=r||s;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=82.&&y<=85.)
     {
       vec3 t=vec3(0),c=vec3(0);
       if(y==82.)
         t=vec3(0,0,0),c=vec3(16,16,3);
       if(y==83.)
         t=vec3(0,0,13),c=vec3(16,16,16);
       if(y==85.)
         t=vec3(0,0,0),c=vec3(3,16,16);
       if(y==84.)
         t=vec3(13,0,0),c=vec3(16,16,16);
       s=d(v+t/16.,v+c/16.,f,i,x);
       r=r||s;
     }
   if(y>=86.&&y<=101.)
     {
       vec3 t=vec3(0.),c=vec3(1.);
       if(y>=86.&&y<=93.)
         {
           float h=0.;
           if(y>=90.&&y<=93.)
             h=13.;
           t=vec3(0.,h,0.)/16.;
           c=vec3(16.,h+3.,16.)/16.;
         }
       if(y>=94.&&y<=97.)
         {
           float n=13.;
           if(y==96.||y==97.)
             n=0.;
           t=vec3(0.,0.,n)/16.;
           c=vec3(16.,16.,n+3.)/16.;
         }
       if(y>=98.&&y<=101.)
         {
           float m=13.;
           if(y==98.||y==99.)
             m=0.;
           t=vec3(m,0.,0.)/16.;
           c=vec3(m+3.,16.,16.)/16.;
         }
       s=d(v+t,v+c,f,i,x);
       r=r||s;
     }
   if(y>=102.&&y<=112.)
     {
       vec3 t=vec3(0.),m=vec3(1.);
       if(y>=102.&&y<=109.)
         {
           float n=float(y)-float(102.)+1.;
           m.y=n*2./16.;
         }
       if(y==110.)
         m.y=.0625;
       if(y==111.)
         t=vec3(1.,0.,1.)/16.,m=vec3(15.,1.,15.)/16.;
       if(y==112.)
         t=vec3(1.,0.,1.)/16.,m=vec3(15.,.5,15.)/16.;
       s=d(v+t,v+m,f,i,x);
       r=r||s;
     }
   #endif
   #endif
   return r;
 }
 vec2 D(inout float v)
 {
   return fract(sin(vec2(v+=.1,v+=.1))*vec2(43758.5,22578.1));
 }
 vec3 c(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<8./viewWidth||v.x>1.-8./viewWidth||v.y<8./viewHeight||v.y>1.-8./viewHeight)
     ;
   else
      y+=f[int(mod(float(frameCounter),4.))]*.5;
   y=(floor(y*64.)+.5)/64.;
   vec3 s=texture2D(noisetex,y).xyz;
   return s;
 }
 vec3 D(vec3 v,inout float y,int x)
 {
   vec2 f=c(texcoord.xy+vec2(y+=.1,y+=.1)).xy;
   f=fract(f+D(y)*.1);
   float t=6.28319*f.x,i=sqrt(f.y);
   vec3 r=normalize(cross(v,vec3(0.,1.,1.))),s=cross(v,r),z=r*cos(t)*i+s*sin(t)*i+v.xyz*sqrt(1.-f.y);
   return z;
 }
 vec3 D(vec3 v,vec3 y)
 {
   vec2 f=s(x(m(v)+y+1.));
   vec3 r=G(f).YNIRJTVYcH;
   return r;
 }
 vec3 D()
 {
   vec2 y=s(v(texcoord.xy)+d()/e());
   vec3 f=G(y).YNIRJTVYcH;
   return f;
 }
 vec3 D(float v,float f,float y,vec3 i)
 {
   vec3 r;
   r.x=y*cos(v);
   r.y=y*sin(v);
   r.z=f;
   vec3 s=abs(i.y)<.999?vec3(0,0,1):vec3(1,0,0),x=normalize(cross(i,vec3(0.,1.,1.))),t=cross(x,i);
   return x*r.x+t*r.y+i*r.z;
 }
 vec3 c(vec2 v,float f,vec3 y)
 {
   float i=2*3.14159*v.x,x=sqrt((1-v.y)/(1+(f*f-1)*v.y)),t=sqrt(1-x*x);
   return D(i,x,t,y);
 }
 float g(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 f(in vec2 v,in float y,in vec3 f)
 {
   float i=g(y),t=2*3.14159*v.x,x=pow(v.y,1.f/(i+1.f)),r=sqrt(1-x*x);
   return D(t,x,r,f);
 }
 float c(float v,float y)
 {
   return 1./(v*(1.-y)+y);
 }
 void g(inout vec3 v,in vec3 f)
 {
   vec3 y=normalize(f.xyz),i=v;
   float x=dot(i,y);
   i=normalize(v-y*saturate(x)*.5);
   v=i;
 }
 vec4 R(in vec2 v)
 {
   float y=GetDepth(v);
   vec4 f=gbufferProjectionInverse*vec4(v.x*2.f-1.f,v.y*2.f-1.f,2.f*y-1.f,1.f);
   f/=f.w;
   return f;
 }
 vec4 R(in vec2 v,in float y)
 {
   vec4 f=gbufferProjectionInverse*vec4(v.x*2.f-1.f,v.y*2.f-1.f,2.f*y-1.f,1.f);
   f/=f.w;
   return f;
 }
 void D(inout vec3 v,in vec3 y,in vec3 f,vec3 x,float z)
 {
   float r=length(y);
   r*=pow(eyeBrightnessSmooth.y/240.f,6.f);
   r*=rainStrength;
   float i=pow(exp(-r*1e-05),4.);
   i=max(i,.5);
   vec3 t=vec3(dot(colorSkyUp,vec3(1.)))*.05;
   v=mix(t,v,vec3(i));
 }
 vec4 D(float v,float y,vec3 m,vec3 t,vec3 x,vec3 z,vec3 s,float n,float a)
 {
   float h=1.;
   #ifdef SUNLIGHT_LEAK_FIX
   if(isEyeInWater<1)
     h=saturate(a*100.);
   #endif
   v=max(v-.05,0.);
   y=0.;
   float k=v*v,w=fract(frameCounter*.0123456);
   vec3 p=c(texcoord.xy).xyz*.99+.005,o=c(texcoord.xy+.1).xyz,l=reflect(s,f(p.xy,k,x)),G=normalize((gbufferModelView*vec4(l.xyz,0.)).xyz);
   if(dot(l,x)<0.)
     l=reflect(l,x);
   #ifdef REFLECTION_SCREEN_SPACE_TRACING
   bool g=false;
   {
     const int H=32;
     vec2 b=texcoord.xy;
     vec3 R=t.xyz;
     float Y=0.;
     vec3 V=t.xyz;
     float T=.05/saturate(dot(-s,x)+.001),P=T*2.,S=1.,U=0.;
     for(int W=0;W<H;W++)
       {
         float F=float(W),u=(F+.5)/float(H);
         vec3 C=G.xyz*T*(.1+length(V)*.1)*S;
         float L=P*(length(V)*.1);
         V+=C;
         vec2 M=ProjectBack(V).xy;
         vec3 N=GetViewPosition(M.xy,GetDepth(M.xy)).xyz;
         float I=length(V)-length(N)-.02;
         if(V.z>0.)
           {
             break;
           }
         if(I>0.&&I<L&&M.x>0.&&M.x<1.&&M.y>0.&&M.y<1.)
           {
             V-=C;
             S*=.5;
             U+=1.;
             if(U>2.)
               {
                 g=true;
                 b=M.xy;
                 R=N.xyz;
                 Y=distance(V,t.xyz)*.4;
                 break;
               }
           }
       }
     vec3 W=(gbufferModelViewInverse*vec4(R,0.)).xyz;
     if(length(W)>far)
       g=false;
     if(g)
       {
         b.xy=floor(b.xy*vec2(viewWidth,viewHeight)+.5)/vec2(viewWidth,viewHeight);
         vec3 F=pow(texture2DLod(colortex3,b.xy,0).xyz,vec3(2.2)),M=F*100.;
         UnderwaterFog(M,length(W),l,colorSkyUp,colorSunlight);
         return vec4(M,saturate(Y/4.));
       }
   }
   #endif
   int V=f(),R=e();
   vec3 b=m+x*(.01+n*.1);
   b+=Fract01(cameraPosition.xyz+.5);
   Ray M=MakeRay(e(b,V)*V-vec3(1.),l);
   vec3 H=vec3(1.),W=vec3(0.);
   float Y=0.;
   DDA F=r(M);
   float S=far;
   vec3 N=vec3(1.);
   for(int U=0;U<1;U++)
     {
       vec4 T=vec4(0.);
       vec3 I=vec3(0.);
       float L=.5;
       for(int u=0;u<REFLECTION_TRACE_LENGTH;u++)
         {
           I=F.mapPos/float(V);
           vec2 P=d(I,V);
           T=texture2DLod(shadowcolor,P,0);
           Y=T.w*255.;
           float C=1.-step(.5,abs(Y-241.));
           vec3 E=T.xyz;
           float A=dot(F.mapPos+.5-M.origin,F.mapPos+.5-M.origin),B=saturate(pow(saturate(dot(M.direction,normalize(F.mapPos+.5-M.origin))),56.*A)*5.-1.)*5.;
           W+=E*C*L*.5*B;
           if(Y<240.)
             {
               if(d(F.mapPos,Y,M,u==0,S,N))
                 {
                   break;
                 }
             }
           i(F);
           L=1.;
         }
       if(T.w*255.<1.f||T.w*255.>254.f)
         {
           vec3 P=SkyShading(M.direction,worldSunVector,rainStrength);
           P=DoNightEyeAtNight(P*12.,timeMidnight)*.083333;
           P=TintUnderwaterDepth(P);
           W+=P*.1;
           S=1000.;
           break;
         }
       vec3 P=mod(M.origin+M.direction*S,vec3(1.))-.5;
       vec2 u=vec2(0.);
       u+=vec2(P.z*-N.x,-P.y)*abs(N.x);
       u+=vec2(P.x,P.z*N.y)*abs(N.y);
       u+=vec2(P.x*N.z,-P.y)*abs(N.z);
       vec3 C=(M.origin+M.direction*S)/float(V);
       vec2 A=textureSize(colortex0,0);
       vec4 E=texture2DLod(shadowcolor1,d(I,V),0);
       vec2 B=E.xy;
       B=(floor(B*A/TEXTURE_RESOLUTION)+.5)/(A/TEXTURE_RESOLUTION);
       vec2 O=B+u.xy*(TEXTURE_RESOLUTION/A);
       vec3 J=pow(texture2D(colortex0,O).xyz,vec3(2.2));
       J*=mix(vec3(1.),T.xyz/(E.w+1e-05),vec3(E.z));
       if(Y<240.)
         {
           vec3 q=saturate(T.xyz);
           H*=J;
         }
       if(abs(Y-31.)<.1)
         W+=.09*H*GI_LIGHT_BLOCK_INTENSITY;
       vec3 q=vec3(0.),K=vec3(0.);
       if(abs(N.x)>.5)
         q=vec3(0.,1.,0.),K=vec3(0.,0.,1.);
       if(abs(N.y)>.5)
         q=vec3(1.,0.,0.),K=vec3(0.,0.,1.);
       if(abs(N.z)>.5)
         q=vec3(1.,0.,0.),K=vec3(0.,1.,0.);
       q*=1.;
       K*=1.;
       vec3 X=D(I,N),j=X,Q=saturate(X*100000.),Z=D(I+q/float(V),N);
       j+=Z;
       Q+=saturate(Z*100000.);
       vec3 ab=D(I-q/float(V),N);
       j+=ab;
       Q+=saturate(ab*100000.);
       vec3 ac=D(I+K/float(V),N);
       j+=ac;
       Q+=saturate(ac*100000.);
       vec3 ad=D(I-K/float(V),N);
       j+=ad;
       Q+=saturate(ad*100000.);
       j/=Q+vec3(.0001);
       W+=j*H;
       const float ae=2.4;
       vec3 af=e(b+M.direction*S-1.,worldLightVector,N,l,V)*H*ae*colorSunlight*h;
       if(isEyeInWater>0)
         ;
       W+=af;
     }
   vec3 P=t.xyz+G*S,I=(gbufferModelViewInverse*vec4(P.xyz,0.)).xyz;
   if(S<1000.)
     LandAtmosphericScattering(W,P,G,l,worldSunVector,1.);
   D(W,P,normalize(t.xyz),normalize(m.xyz),1.);
   UnderwaterFog(W,length(I),s,colorSkyUp,colorSunlight);
   S*=saturate(dot(-s,x))*2.;
   return vec4(W,saturate(S/4.));
 }
 vec4 l(float v)
 {
   float y=v*v,f=y*v;
   vec4 r;
   r.x=-f+3*y-3*v+1;
   r.y=3*f-6*y+4;
   r.z=-3*f+3*y+3*v+1;
   r.w=f;
   return r/6.f;
 }
 vec4 i(in sampler2D v,in vec2 f)
 {
   vec2 y=vec2(viewWidth,viewHeight);
   f*=y;
   f-=.5;
   float s=fract(f.x),t=fract(f.y);
   f.x-=s;
   f.y-=t;
   vec4 i=l(s),r=l(t),x=vec4(f.x-.5,f.x+1.5,f.y-.5,f.y+1.5),m=vec4(i.x+i.y,i.z+i.w,r.x+r.y,r.z+r.w),c=x+vec4(i.y,i.w,r.y,r.w)/m,z=texture2DLod(v,vec2(c.x,c.z)/y,0),h=texture2DLod(v,vec2(c.y,c.z)/y,0),n=texture2DLod(v,vec2(c.x,c.w)/y,0),a=texture2DLod(v,vec2(c.y,c.w)/y,0);
   float V=m.x/(m.x+m.y),N=m.z/(m.z+m.w);
   return mix(mix(a,n,V),mix(h,z,V),N);
 }
 bool l(vec3 v,vec3 y)
 {
   vec3 f=normalize(cross(dFdx(v),dFdy(v))),i=normalize(y-v),t=normalize(i);
   return distance(v,y)<.05;
 }
 vec3 y(vec2 v)
 {
   vec2 y=vec2(viewWidth,viewHeight),f=1./y,i=v*y,x=floor(i-.5)+.5,t=i-x,z=t*t,r=t*z;
   float s=.5;
   vec2 m=-s*r+2.*s*z-s*t,c=(2.-s)*r-(3.-s)*z+1.,h=-(2.-s)*r+(3.-2.*s)*z+s*t,n=s*r-s*z,N=c+h,M=f*(x+h/N);
   vec3 a=texture2DLod(colortex4,vec2(M.x,M.y),0).xyz;
   vec2 P=f*(x-1.),d=f*(x+2.);
   vec4 k=vec4(texture2DLod(colortex4,vec2(M.x,P.y),0).xyz,1.)*(N.x*m.y)+vec4(texture2DLod(colortex4,vec2(P.x,M.y),0).xyz,1.)*(m.x*N.y)+vec4(a,1.)*(N.x*N.y)+vec4(texture2DLod(colortex4,vec2(d.x,M.y),0).xyz,1.)*(n.x*N.y)+vec4(texture2DLod(colortex4,vec2(M.x,d.y),0).xyz,1.)*(N.x*n.y);
   return max(vec3(0.),k.xyz*(1./k.w));
 }
 void main()
 {
   GBufferData v=GetGBufferData();
   GBufferDataTransparent f=GetGBufferDataTransparent();
   MaterialMask y=CalculateMasks(v.materialID),i=CalculateMasks(f.materialID);
   bool x=f.depth<v.depth;
   if(x)
     v.depth=f.depth,v.normal=f.normal,v.smoothness=f.smoothness,v.metalness=0.,v.mcLightmap=f.mcLightmap,i.sky=0.;
   vec4 r=GetViewPosition(texcoord.xy,v.depth),t=gbufferModelViewInverse*vec4(r.xyz,1.),m=gbufferModelViewInverse*vec4(r.xyz,0.);
   vec3 s=normalize(r.xyz),c=normalize(m.xyz),n=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz),z=normalize((gbufferModelViewInverse*vec4(v.geoNormal,0.)).xyz);
   float a=length(r.xyz);
   vec4 M=vec4(0.);
   float h=G(v.smoothness,v.metalness);
   if(h>.0001&&i.sky<.5)
     M=D(1.-v.smoothness,v.metalness,t.xyz,r.xyz,n.xyz,z,c.xyz,y.leaves,v.mcLightmap.y);
   vec4 P=texture2DLod(colortex3,texcoord.xy,0);
   vec3 N=P.xyz;
   N.xyz=pow(N.xyz,vec3(2.2));
   if(x)
     {
       vec3 d=GetViewPosition(texcoord.xy,texture2DLod(depthtex1,texcoord.xy,0).x).xyz;
       float e=length(d.xyz),V=e-a;
       vec3 k=f.normal-f.geoNormal*1.05;
       float H=saturate(V*.5);
       vec2 l=texcoord.xy+k.xy/(a+1.5)*H;
       N.xyz=pow(texture2DLod(colortex3,l.xy,0).xyz,vec3(2.2));
       d=GetViewPosition(l.xy,texture2DLod(depthtex1,l.xy,0).x).xyz;
       r=GetViewPosition(l.xy,texture2DLod(depthtex0,l.xy,0).x);
       e=length(d.xyz);
       a=length(r.xyz);
       V=e-a;
       if(i.water>.5&&isEyeInWater<1)
         {
           N.xyz*=exp(GetWaterAbsorption()*-V);
           vec3 W=GetWaterFogColor()*.001;
           W*=exp(-GetWaterAbsorption()*((-c.y*.5+.5)*3.));
           W*=pow(curve(saturate(mix(c.y,1.,.5))),2.)*.6+.4;
           W*=(colorSkyUp+colorSunlight*2.)*1.4;
           W=TintUnderwaterDepth(W);
           float I=exp(-V*.03);
           W*=exp(-GetWaterAbsorption()*(1.-I)*20.);
           W*=eyeBrightnessSmooth.y/240.;
           N=mix(W,N,vec3(I));
         }
       if(i.stainedGlass>.5)
         {
           vec3 W=normalize(f.albedo.xyz+.0001)*pow(length(f.albedo.xyz),.5);
           N.xyz*=mix(vec3(1.),W,vec3(pow(f.albedo.w,.2)));
           N.xyz*=mix(vec3(1.),W,vec3(pow(f.albedo.w,.2)));
         }
     }
   N.xyz=pow(N.xyz,vec3(1./2.2));
   M.xyz=saturate(M.xyz);
   gl_FragData[0]=texture2DLod(colortex0,texcoord.xy,0);
   gl_FragData[1]=vec4(N.xyz,v.smoothness);
   gl_FragData[2]=M;
 };




/* DRAWBUFFERS:036 */
