#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"


const bool colortex6MipmapEnabled = false;



in vec4 texcoord;
in vec3 lightVector;

in float timeSunriseSunset;
in float timeNoon;
in float timeMidnight;
in float timeSkyDark;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSunglow;
in vec3 colorBouncedSunlight;
in vec3 colorScatteredSunlight;
in vec3 colorTorchlight;
in vec3 colorWaterMurk;
in vec3 colorWaterBlue;
in vec3 colorSkyTint;



in vec3 upVector;



#include "lib/GBufferData.inc"


 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=d();
   ivec2 n=ivec2(v.x*f.x,v.y*f.y);
   float s=float(n.y/y),i=float(int(n.x+mod(f.x*s,y))/y);
   i+=floor(f.x*s/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(n.x+mod(f.x*s,y),y);
   m.y=mod(n.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 s(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 r;
   r.x=mod(i.x+y*x,f.x);
   float s=i.x+y*x;
   r.y=i.y+floor(s/f.x)*x;
   r+=.5;
   r/=f;
   return r;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 n=ivec2(i.x*m.x,i.y*m.y);
   float s=float(n.y/y),z=float(int(n.x+mod(m.x*s,y))/y);
   z+=floor(m.x*s/y);
   vec3 r=vec3(0.,0.,z);
   r.x=mod(n.x+mod(m.x*s,y),y);
   r.y=mod(n.y,y);
   r.xyz=floor(r.xyz);
   r/=y;
   r.xyz=r.xzy;
   return r;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 f=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,f.x);
   float s=i.x+x*y;
   r.y=i.y+floor(s/f.x)*y;
   r+=.5;
   r/=f;
   r.xy*=.5;
   return r;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 x(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 e(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 e()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,x=floor(v-.0001),y=floor(f-.0001);
   return x-y;
 }
 vec3 m(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/y;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 i,vec2 n,vec4 m,vec4 x,inout float y,out vec2 r)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(x.x==8||x.x==9||x.x==79||x.x<1.||!z||x.x==20.||x.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(x.x==50.||x.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(x.x==51)
     y=0.;
   if(x.x>255)
     y=0.;
   vec3 s,c;
   if(f.x>.5)
     s=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       s=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         s=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           s=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             s=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               s=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   r=clamp((i.xy-n.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,t=.15;
   if(x.x==10.||x.x==11.)
     {
       if(abs(f.y)<.01&&z||f.y>.99)
         h=.1,t=.1,y=0.;
       else
          y=1.;
     }
   if(x.x==51)
     h=.5,t=.1;
   if(x.x==76)
     h=.2,t=.2;
   if(x.x-255.+39.>=102.&&x.x-255.+39.<=112.)
     t=.025,h=.025;
   s=normalize(m.xyz);
   c=normalize(cross(s,f.xyz)*sign(m.w));
   vec3 e=v.xyz+mix(s*h,-s*h,vec3(r.x));
   e.xyz+=mix(c*h,-c*h,vec3(r.y));
   e.xyz-=f.xyz*t;
   return e;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA p(Ray v)
 {
   DDA i;
   i.mapPos=floor(v.origin);
   i.mapPosOrigin=i.mapPos;
   i.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.rayStep=sign(v.direction);
   i.sideDist=(sign(v.direction)*(i.mapPos-v.origin)+sign(v.direction)*.5+.5)*i.deltaDist;
   i.mask=vec3(0.);
   return i;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float x)
 {
   float y,r,z,t;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,y),z);
   x=min(min(x,r),t);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 i=(f+v)*.5,n=(f-v)*.5,s=y-i,r=vec3(0.);
   r+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-n.x),x);
   r+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-n.y),x);
   r+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-n.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray i,out vec2 r)
 {
   vec3 y=i.inv_direction*(v-i.origin),x=i.inv_direction*(f-i.origin),s=min(x,y),n=max(x,y);
   vec2 m=max(s.xx,s.yz);
   float c=max(m.x,m.y);
   m=min(n.xx,n.yz);
   float z=min(m.x,m.y);
   r.x=c;
   r.y=z;
   return z>max(c,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray i,inout float x,inout vec3 y)
 {
   vec3 z=i.inv_direction*(v-i.origin),s=i.inv_direction*(f-i.origin),n=min(s,z),m=max(s,z);
   vec2 r=max(n.xx,n.yz);
   float t=max(r.x,r.y);
   r=min(m.xx,m.yz);
   float c=min(r.x,r.y);
   bool o=c>max(t,0.)&&max(t,0.)<x;
   if(o)
     y=d(v,f,i.origin+i.direction*t),x=t;
   return o;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float t=abs(n.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,t),c=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-c);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 f,vec3 x,vec3 y,vec3 i,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(f),n=m(s+y*.99);
   float t=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*t),3).x;
   r*=saturate(dot(x,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct VcxfcrgVbw{float bgoSMWoOlk;float UchydvPYLr;float bRfUKhvDSW;float DqzEnDHRia;vec3 YNIRJTVYcH;};
 vec4 h(VcxfcrgVbw v)
 {
   vec4 i;
   v.YNIRJTVYcH=max(vec3(0.),v.YNIRJTVYcH);
   i.x=v.bgoSMWoOlk;
   v.YNIRJTVYcH=pow(v.YNIRJTVYcH,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.YNIRJTVYcH.x,v.bRfUKhvDSW);
   i.z=PackTwo16BitTo32Bit(v.YNIRJTVYcH.y,v.DqzEnDHRia);
   i.w=PackTwo16BitTo32Bit(v.YNIRJTVYcH.z,v.UchydvPYLr);
   return i;
 }
 VcxfcrgVbw i(vec4 v)
 {
   VcxfcrgVbw i;
   vec2 f=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),n=UnpackTwo16BitFrom32Bit(v.w);
   i.bgoSMWoOlk=v.x;
   i.bRfUKhvDSW=f.y;
   i.DqzEnDHRia=m.y;
   i.UchydvPYLr=n.y;
   i.YNIRJTVYcH=pow(vec3(f.x,m.x,n.x),vec3(8.));
   return i;
 }
 VcxfcrgVbw D(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float D(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void D(inout float v,inout float i,float x,float f,vec3 s,float y)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,f);
   #else
   v*=mix(3.4,3.4,f);
   #endif
   float r=dot(s,vec3(1.));
   i*=1.-pow(f,.4);
   i/=x*.1+2e-06;
   i*=4.;
   i*=.6;
   float m=x/(r+1e-07)*.2+4e-08;
   m=min(m,1.);
   m=mix(m,1.,pow(f,.25));
   if(y<.12)
     i=0.;
 }
 float D(vec3 v,vec3 y,float x)
 {
   float i=dot(abs(v-y),vec3(.3333));
   i*=x;
   i*=.18;
   return i;
 }
 void e(inout vec3 v,vec2 x,vec3 y)
 {}
 float e(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool d(vec3 v,float x,Ray f,bool y,inout float i,inout vec3 z)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(y)
     return false;
   if(x>=66.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),f,i,z);
   r=m;
   #else
   if(x<40.)
     return m=d(v,v+vec3(1.,1.,1.),f,i,z),m;
   if(x==40.||x>=42.&&x<=53.)
     m=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),f,i,z),r=r||m;
   if(x==41.||x>=54.&&x<=65.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,z),r=r||m;
   if(x==42.||x==45.||x==46.||x==51.||x==52.||x==53.||x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
     {
       float s=.5;
       if(x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
         s=0.;
       m=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),f,i,z);
       r=r||m;
     }
   if(x==42.||x==44.||x==47.||x==50.||x==52.||x==53.||x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
     {
       float s=.5;
       if(x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
         s=0.;
       m=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),f,i,z);
       r=r||m;
     }
   if(x==43.||x==44.||x==48.||x==50.||x==51.||x==53.||x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
     {
       float s=.5;
       if(x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
         s=0.;
       m=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),f,i,z);
       r=r||m;
     }
   if(x==43.||x==45.||x==49.||x==50.||x==51.||x==52.||x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
     {
       float s=.5;
       if(x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
         s=0.;
       m=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),f,i,z);
       r=r||m;
     }
   if(x>=66.&&x<=81.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,z),r=r||m;
   if(x==67.||x==68.||x==69.||x==71.||x==72.||x==73.||x==75.||x==76.||x==77.||x==79.||x==80.||x==81.)
     {
       float s=8.,c=8.;
       if(x==67.||x==69.||x==71.||x==73.||x==75.||x==77.||x==79.||x==81.)
         s=0.;
       if(x==68.||x==69.||x==72.||x==73.||x==76.||x==77.||x==80.||x==81.)
         c=16.;
       m=d(v+vec3(s,6.,7.)/16.,v+vec3(c,9.,9.)/16.,f,i,z);
       r=r||m;
       m=d(v+vec3(s,12.,7.)/16.,v+vec3(c,15.,9.)/16.,f,i,z);
       r=r||m;
     }
   if(x>=70.&&x<=81.)
     {
       float s=8.,t=8.;
       if(x>=70.&&x<=73.||x>=78.&&x<=81.)
         t=16.;
       if(x>=74.&&x<=81.)
         s=0.;
       m=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,t)/16.,f,i,z);
       r=r||m;
       m=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,t)/16.,f,i,z);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=82.&&x<=85.)
     {
       vec3 s=vec3(0),c=vec3(0);
       if(x==82.)
         s=vec3(0,0,0),c=vec3(16,16,3);
       if(x==83.)
         s=vec3(0,0,13),c=vec3(16,16,16);
       if(x==85.)
         s=vec3(0,0,0),c=vec3(3,16,16);
       if(x==84.)
         s=vec3(13,0,0),c=vec3(16,16,16);
       m=d(v+s/16.,v+c/16.,f,i,z);
       r=r||m;
     }
   if(x>=86.&&x<=101.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(x>=86.&&x<=93.)
         {
           float t=0.;
           if(x>=90.&&x<=93.)
             t=13.;
           s=vec3(0.,t,0.)/16.;
           c=vec3(16.,t+3.,16.)/16.;
         }
       if(x>=94.&&x<=97.)
         {
           float t=13.;
           if(x==96.||x==97.)
             t=0.;
           s=vec3(0.,0.,t)/16.;
           c=vec3(16.,16.,t+3.)/16.;
         }
       if(x>=98.&&x<=101.)
         {
           float t=13.;
           if(x==98.||x==99.)
             t=0.;
           s=vec3(t,0.,0.)/16.;
           c=vec3(t+3.,16.,16.)/16.;
         }
       m=d(v+s,v+c,f,i,z);
       r=r||m;
     }
   if(x>=102.&&x<=112.)
     {
       vec3 s=vec3(0.),n=vec3(1.);
       if(x>=102.&&x<=109.)
         {
           float c=float(x)-float(102.)+1.;
           n.y=c*2./16.;
         }
       if(x==110.)
         n.y=.0625;
       if(x==111.)
         s=vec3(1.,0.,1.)/16.,n=vec3(15.,1.,15.)/16.;
       if(x==112.)
         s=vec3(1.,0.,1.)/16.,n=vec3(15.,.5,15.)/16.;
       m=d(v+s,v+n,f,i,z);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 float h(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 float i(vec3 v,vec3 y)
 {
   return dot(abs(v-y),vec3(.3333));
 }
 vec3 c(vec2 v)
 {
   vec2 x=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   x=(floor(x*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,x).xyz,y=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+vec3(y)*mod(frameCounter,64.f),vec3(1.));
   return i;
 }
 vec3 D(float v,float i,float f,vec3 x)
 {
   vec3 r;
   r.x=f*cos(v);
   r.y=f*sin(v);
   r.z=i;
   vec3 s=abs(x.y)<.999?vec3(0,0,1):vec3(1,0,0),y=normalize(cross(x,vec3(0.,1.,1.))),c=cross(y,x);
   return y*r.x+c*r.y+x*r.z;
 }
 vec3 c(vec2 v,float x,vec3 y)
 {
   float s=2*3.14159*v.x,i=sqrt((1-v.y)/(1+(x*x-1)*v.y)),f=sqrt(1-i*i);
   return D(s,i,f,y);
 }
 float G(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 G(in vec2 v,in float x,in vec3 y)
 {
   float s=G(x),f=2*3.14159*v.x,i=pow(v.y,1.f/(s+1.f)),c=sqrt(1-i*i);
   return D(f,i,c,y);
 }
 float R(vec2 v)
 {
   return texture2DLod(colortex3,v,0).w;
 }
 vec4 D(sampler2D v,float f,bool x,float s,float y,float z,float t)
 {
   GBufferData m=GetGBufferData();
   GBufferDataTransparent r=GetGBufferDataTransparent();
   bool n=r.depth<m.depth;
   if(n)
     m.normal=r.normal,m.smoothness=r.smoothness,m.metalness=0.,m.mcLightmap=r.mcLightmap,m.depth=r.depth;
   vec4 d=GetViewPosition(texcoord.xy,m.depth),h=gbufferModelViewInverse*vec4(d.xyz,1.),a=gbufferModelViewInverse*vec4(d.xyz,0.);
   vec3 Y=normalize(d.xyz),o=normalize(a.xyz),p=normalize((gbufferModelViewInverse*vec4(m.normal,0.)).xyz);
   float w=GetDepthLinear(texcoord.xy),G=1.-m.smoothness,k=G*G,l=D(m.smoothness,m.metalness);
   int b=0;
   vec4 H=texture2DLod(colortex6,texcoord.xy,b);
   float V=Luminance(H.xyz);
   if(l<.001)
     return H;
   float g=f*.9;
   g*=min(k*15.,1.1);
   g*=mix(H.w,1.,t);
   vec2 W=vec2(0.);
   if(x)
     {
       vec2 U=c(texcoord.xy).xy*.99+.005;
       W=U-.5;
     }
   float U=0.,S=1.1,u=e(s,m.totalTexGrad)/(k+.0001),T=e(y,m.totalTexGrad);
   vec4 P=vec4(0.),L=vec4(0.);
   float F=0.;
   vec4 I=vec4(vec3(z),1.);
   I.xyz=vec3(.5);
   I.xyz*=H.w*.95+.05;
   float B=m.smoothness;
   int A=0;
   for(int E=-1;E<=1;E++)
     {
       for(int N=-1;N<=1;N++)
         {
           vec2 M=(vec2(E,N)+W)/vec2(viewWidth,viewHeight)*g,O=texcoord.xy+M.xy;
           float J=length(M*vec2(viewWidth,viewHeight));
           O=clamp(O,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
           vec4 q=texture2DLod(colortex6,O,b);
           vec3 C=GetNormals(O);
           float Q=GetDepthLinear(O),K=pow(saturate(dot(m.normal,C)),u),j=exp(-(abs(Q-w)*S)),Z=exp(-(i(q.xyz,H.xyz)*U)),X=exp(-abs(B-R(O))*T),ab=K*j*Z*X;
           P+=vec4(pow(length(q.xyz),I.x)*normalize(q.xyz+1e-05),q.w)*ab;
           F+=ab;
           L+=q;
           A++;
         }
     }
   P/=F+.0001;
   P.xyz=pow(length(P.xyz),1./I.x)*normalize(P.xyz+1e-06);
   vec4 q=P;
   if(F<.001)
     q=H;
   return q;
 }
 void main()
 {
   vec4 x=D(colortex6,30.,false,180.,40.,.1,0.);
   gl_FragData[0]=vec4(x);
 };




/* DRAWBUFFERS:6 */
