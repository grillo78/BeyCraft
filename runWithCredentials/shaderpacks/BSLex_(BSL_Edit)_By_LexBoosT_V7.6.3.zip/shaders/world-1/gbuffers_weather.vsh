/* 
BSLex (BSL Edit) by LexBoosT
*/ 

#version 120 
#pragma optimize(on)
#define NETHER
#define VSH

#include "/program/gbuffers_weather.glsl"
