/* 
BSLex (BSL Edit) by LexBoosT
*/ 

#version 120 
#pragma optimize(on)
#extension GL_ARB_shader_texture_lod : enable

#define NETHER
#define FSH

#include "/program/gbuffers_block.glsl"
