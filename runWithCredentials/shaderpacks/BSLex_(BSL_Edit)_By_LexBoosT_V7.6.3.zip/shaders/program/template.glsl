
/*
BSLex (BSL Edit) by LexBoosT
*/

//Settings//
#include "/lib/settings.glsl"

#pragma optimize(on)

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

//Extensions//

//Varyings//

//Uniforms//

//Attributes//

//Optifine Constants//

//Common Variables//

//Common Functions//

//Includes//

//Program//
void main(){
    
}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

//Varyings//

//Uniforms//

//Attributes//

//Optifine Constants//

//Common Variables//

//Common Functions//

//Includes//

//Program//
void main(){
    
}

#endif
