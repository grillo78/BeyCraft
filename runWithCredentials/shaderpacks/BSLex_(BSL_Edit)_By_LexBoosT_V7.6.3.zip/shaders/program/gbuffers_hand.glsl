/*
BSLex (BSL Edit) by LexBoosT
*/

//Settings//
#include "/lib/settings.glsl"
#define HAND

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

//Extensions//

//Varyings//
varying float isMainHand;

varying vec2 texCoord, lmCoord;

varying vec3 normal;
varying vec3 sunVec, upVec, eastVec;

varying vec4 color;

#ifdef ADVANCED_MATERIALS
varying float dist;

varying vec3 binormal, tangent;
varying vec3 viewVector;
varying vec4 position;
varying vec4 vTexCoord, vTexCoordAM;
#endif

//Uniforms//
uniform int frameCounter;
uniform int heldItemId, heldItemId2;
uniform int isEyeInWater;
uniform int worldTime;

uniform float frameTimeCounter;
uniform float nightVision;
uniform float rainStrength;
uniform float screenBrightness;
uniform float shadowFade;
uniform float timeAngle, timeBrightness;
uniform float viewWidth, viewHeight;

uniform ivec2 eyeBrightnessSmooth;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;

uniform sampler2D texture;
uniform vec3 cameraPosition;

#ifdef WATER_CAUSTICS
#ifdef OVERWORLD
uniform sampler2D noisetex;
#endif
#endif

#ifdef ADVANCED_MATERIALS
uniform ivec2 atlasSize;
uniform sampler2D specular;
uniform sampler2D normals;
#endif

uniform vec3 fogColor;

//Common Variables//
float eBS = eyeBrightnessSmooth.y / 255.0;
float sunVisibility  = clamp(dot( sunVec,upVec) + 0.05, 0.0, 0.1) * 10.0;
float moonVisibility = clamp(dot(-sunVec,upVec) + 0.05, 0.0, 0.1) * 10.0;

#ifdef ADVANCED_MATERIALS
vec2 dcdx = dFdx(texCoord);
vec2 dcdy = dFdy(texCoord);
#endif

vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);

//Common Functions//
float GetLuminance(vec3 color){
	return dot(color,vec3(0.299, 0.587, 0.114));
}

float InterleavedGradientNoise(){
	float n = 52.9829189 * fract(0.06711056 * gl_FragCoord.x + 0.00583715 * gl_FragCoord.y);
	return fract(n + frameCounter / 8.0);
}

float GetHandItem(int id){
	return float((heldItemId == id && isMainHand > 0.5) || (heldItemId2 == id && isMainHand < 0.5));
}

//Includes//
#include "/lib/util/dither.glsl"
#include "/lib/color/blocklightColor.glsl"
#include "/lib/color/dimensionColor.glsl"
#include "/lib/util/spaceConversion.glsl"
#include "/lib/lighting/forwardLighting.glsl"

#ifdef WATER_CAUSTICS
#ifdef OVERWORLD
#include "/lib/color/waterColor.glsl"
#include "/lib/lighting/caustics.glsl"
#endif
#endif

#if AA >1
#include "/lib/util/jitter.glsl"
#endif


#ifdef ADVANCED_MATERIALS
#include "/lib/color/specularColor.glsl"
#include "/lib/util/encode.glsl"
#include "/lib/reflections/complexFresnel.glsl"
#include "/lib/surface/ggx.glsl"
#include "/lib/surface/materialGbuffers.glsl"
#include "/lib/surface/parallax.glsl"
#endif

#if MC_VERSION >= 11500
#undef PARALLAX
#undef SELF_SHADOW
#endif

//Program//
void main(){
	vec4 albedo = texture2D(texture, texCoord) * color;
	vec3 newNormal = normal;
	float skymapMod = 0.0;
	
	#ifdef ADVANCED_MATERIALS
	vec2 newCoord = vTexCoord.st * vTexCoordAM.pq + vTexCoordAM.st;
	float skipAdvMat = float(heldItemId  == 358 || (heldItemId2 == 358 && isMainHand  < 0.5));
	
	#ifdef PARALLAX
	if (skipAdvMat < 0.5){
		newCoord = GetParallaxCoord(0.0);
		albedo = texture2DGradARB(texture, newCoord, dcdx, dcdy) * color;
	}
	#endif
	
	float smoothness = 0.0, skyOcclusion = 0.0;
	vec3 fresnel3 = vec3(0.0);
	#endif
	
	if (albedo.a > 0.001){
		
		vec2 lightmap = clamp(lmCoord, vec2(0.0), vec2(1.0));
		
		lightmap.x = max(lightmap.x, GetHandItem(213));
		
		float emissive = (GetHandItem(50) + GetHandItem(83) + GetHandItem(213)) * 0.25;
		
		vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z + 0.38);
		#if AA > 1
		vec3 viewPos = ToNDC(vec3(TAAJitter(screenPos.xy, -0.5), screenPos.z));
		#else
		vec3 viewPos = ToNDC(screenPos);
		#endif
		vec3 worldPos = ToWorld(viewPos);
		
		#ifdef ADVANCED_MATERIALS
		float metalness = 0.0, f0 = 0.0, ao = 1.0;
		vec3 normalMap = vec3(0.0, 0.0, 1.0);
		
		GetMaterials(smoothness, metalness, f0, emissive, ao, normalMap, newCoord, dcdx, dcdy);
		
		#if MC_VERSION >= 11500
		normalMap = vec3(0.0, 0.0, 1.0);
		#endif
		
		mat3 tbnMatrix = mat3(tangent.x, binormal.x, normal.x,
			tangent.y, binormal.y, normal.y,
		tangent.z, binormal.z, normal.z);
		
		if (normalMap.x > -0.999 && normalMap.y > -0.999)
		newNormal = clamp(normalize(normalMap * tbnMatrix), vec3(-1.0), vec3(1.0));
		#endif
		
		albedo.rgb = pow(albedo.rgb, vec3(2.2));
		
		#ifdef WHITE_WORLD
		#ifdef HANDSW
		albedo.rgb = vec3(0.5);
		#endif
		#endif
		#ifdef BLACK_WORLD
		#ifdef HANDSW
		albedo.rgb = vec3(0.0);
		#endif
		#endif
		
		float doRecolor = GetHandItem(89) + GetHandItem(213);
		
		float ec = GetLuminance(albedo.rgb) * 1.0;
		#ifdef EMISSIVE_RECOLOR
		if (doRecolor > 0.5){
			albedo.rgb = blocklightCol * pow(ec, 1.5) / (BLOCKLIGHT_I * BLOCKLIGHT_I);
			albedo.rgb /= 0.7 * albedo.rgb + 0.7;
		}
		#else
		if (doRecolor > 0.5){
			albedo.rgb *= ec * 0.25 + 0.5;
		}
		#endif
		
		
		float NoL = clamp(dot(newNormal, lightVec) * 1.01 - 0.01, 0.0, 1.0);
		
		float NoU = clamp(dot(newNormal, upVec), -1.0, 1.0);
		float NoE = clamp(dot(newNormal, eastVec), -1.0, 1.0);
		float vanillaDiffuse = (0.25 * NoU + 0.75) + (0.667 - abs(NoE)) * (1.0 - abs(NoU)) * 0.15;
		vanillaDiffuse*= vanillaDiffuse;
		
		float parallaxShadow = 1.0;
		#ifdef ADVANCED_MATERIALS
		vec3 rawAlbedo = albedo.rgb * 0.999 + 0.001;
		albedo.rgb *= ao;
		
		#ifdef REFLECTION_SPECULAR
		float roughnessSqr = (1.0 - smoothness) * (1.0 - smoothness);
		albedo.rgb *= (1.0 - metalness * (1.0 - roughnessSqr));
		#endif
		
		float doParallax = 0.0;
		#ifdef SELF_SHADOW
		#ifdef OVERWORLD
		doParallax = float(lightmap.y > 0.0 && NoL > 0.0);
		#endif
		#ifdef END
		doParallax = float(NoL > 0.0);
		#endif
		
		if (doParallax > 0.5 && skipAdvMat < 0.5){
			parallaxShadow = GetParallaxShadow(0.0, newCoord, lightVec, tbnMatrix);
			NoL *= parallaxShadow;
		}
		#endif
		#endif
		
		vec3 shadow = vec3(0.0);
		GetLighting(albedo.rgb, shadow, viewPos, worldPos, lightmap, 1.0, NoL, vanillaDiffuse,
		parallaxShadow, emissive, 0.0,1.0);
		
		#ifdef ADVANCED_MATERIALS
		skyOcclusion = lightmap.y * lightmap.y * (3.0 - 2.0 * lightmap.y);
		
		vec3 baseReflectance = mix(vec3(f0), rawAlbedo, metalness);
		float fresnel = pow(clamp(1.0 + dot(newNormal, normalize(viewPos.xyz)), 0.0, 1.0), 5.0);
		
		fresnel3 = mix(baseReflectance, vec3(1.0), fresnel);
		#if MATERIAL_FORMAT == 0
		if (f0 >= 0.9 && f0 < 1.0) {
			baseReflectance = GetMetalCol(f0);
			fresnel3 = ComplexFresnel(fresnel, f0);
			#ifdef ALBEDO_METAL
			fresnel3 *= rawAlbedo;
			#endif
		}
		#endif
		
		float so = pow(max(ao * 2.0 - 1.0, 0.0), 2.0);
		fresnel3 *= so;
		albedo.rgb = albedo.rgb * (1.0 - fresnel3 * smoothness * smoothness * (1.0 - metalness));
		
		#if defined OVERWORLD || defined END
		vec3 specularColor = GetSpecularColor(lightmap.y, metalness, baseReflectance);
		
		albedo.rgb += GetSpecularHighlight(newNormal, viewPos, lightVec, smoothness, baseReflectance,
		specularColor, 0.0, shadow * vanillaDiffuse);
		#endif
		
		#if defined REFLECTION_SPECULAR && defined REFLECTION_ROUGH
		normalMap = mix(vec3(0.0, 0.0, 1.0), normalMap, smoothness);
		newNormal = clamp(normalize(normalMap * tbnMatrix), vec3(-1.0), vec3(1.0));
		#endif
		#endif
		
		
		#ifdef MODE_RAGE
		#ifdef MODE_RAGE_PLUS
		if ((heldItemId==10278)|| (heldItemId==10267) || (heldItemId==10262) ||( heldItemId == 10268)  || (heldItemId == 10272)  || (heldItemId == 10276)  || (heldItemId == 10283)  || (heldItemId == 10261)  || (heldItemId == 10346)  || (heldItemId == 19999)
		|| (heldItemId2==10278)|| (heldItemId2==10267)|| (heldItemId2==10262)||( heldItemId2 == 10268) || (heldItemId2 == 10272) || (heldItemId2 == 10276) || (heldItemId2 == 10283) || (heldItemId2 == 10261) || (heldItemId2 == 10346) || (heldItemId2 == 19999))
		albedo += vec4(.2,0,0,0.1)*pow(distance(texCoord.st,vec2(1.0)),4.0 * GLINT_INTENSITY);
		#endif
		#endif
		
		#if defined WATER_CAUSTICS && defined OVERWORLD
		if (isEyeInWater == 1) {
			float skyLightMap = lightmap.y * lightmap.y * (3.0 - 2.0 * lightmap.y);
			shadow *= NoL;
			albedo.rgb = GetCaustics(albedo.rgb, worldPos.xyz, cameraPosition.xyz, shadow, skyLightMap, lightmap.x);
		}
		#endif
	} else discard;
	
	/* DRAWBUFFERS:0 */
	gl_FragData[0] = albedo;
	
	#if defined ADVANCED_MATERIALS && defined REFLECTION_SPECULAR
	/* DRAWBUFFERS:0367 */
	gl_FragData[1]=vec4(smoothness,skyOcclusion,0.,1.);
	gl_FragData[2]=vec4(EncodeNormal(newNormal),float(gl_FragCoord.z<1.),1.);
	gl_FragData[3]=vec4(fresnel3,1.);
	#endif
}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

//Varyings//
varying float isMainHand;

varying vec2 texCoord,lmCoord;

varying vec3 normal;
varying vec3 sunVec,upVec,eastVec;

varying vec4 color;
varying vec4 position;

#ifdef ADVANCED_MATERIALS
varying float dist;

varying vec3 binormal,tangent;
varying vec3 viewVector;

varying vec4 vTexCoord,vTexCoordAM;
#endif

//Uniforms//
uniform int worldTime;

uniform float frameTimeCounter;
uniform float timeAngle;

uniform vec3 cameraPosition;

uniform mat4 gbufferModelView,gbufferModelViewInverse;
uniform mat4 gbufferProjection;

#if AA>1
uniform int frameCounter;
uniform float viewWidth,viewHeight;
#endif

//Attributes//
attribute vec4 mc_Entity;

#ifdef ADVANCED_MATERIALS
attribute vec4 mc_midTexCoord;
attribute vec4 at_tangent;
#endif

//Includes//

#if AA>1
#include "/lib/util/jitter.glsl"
#endif

//Program//
void main(){
	texCoord=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
	
	lmCoord=(gl_TextureMatrix[1]*gl_MultiTexCoord1).xy;
	lmCoord=clamp((lmCoord-.03125)*1.06667,0.,1.);
	
	normal=normalize(gl_NormalMatrix*gl_Normal);
	
	#ifdef ADVANCED_MATERIALS
	binormal=normalize(gl_NormalMatrix*cross(at_tangent.xyz,gl_Normal.xyz)*at_tangent.w);
	tangent=normalize(gl_NormalMatrix*at_tangent.xyz);
	
	mat3 tbnMatrix=mat3(tangent.x,binormal.x,normal.x,
		tangent.y,binormal.y,normal.y,
	tangent.z,binormal.z,normal.z);
	
	viewVector=tbnMatrix*(gl_ModelViewMatrix*gl_Vertex).xyz;
	
	dist=length(gl_ModelViewMatrix*gl_Vertex);
	
	vec2 midCoord=(gl_TextureMatrix[0]*mc_midTexCoord).st;
	vec2 texMinMidCoord=texCoord-midCoord;
	
	vTexCoordAM.pq=abs(texMinMidCoord)*2;
	vTexCoordAM.st=min(texCoord,midCoord-texMinMidCoord);
	
	vTexCoord.xy=sign(texMinMidCoord)*.5+.5;
	#endif
	
	isMainHand=float(gl_ModelViewMatrix[3][0]>0.);
	
	const vec2 sunRotationData=vec2(cos(sunPathRotation*.01745329251994),-sin(sunPathRotation*.01745329251994));
	float ang=fract(timeAngle-.25);
	ang=(ang+(cos(ang*3.14159265358979)*-.5+.5-ang)/3.)*6.28318530717959;
	sunVec=normalize((gbufferModelView*vec4(vec3(-sin(ang),cos(ang)*sunRotationData)*2000.,1.)).xyz);
	
	upVec=normalize(gbufferModelView[1].xyz);
	eastVec=normalize(gbufferModelView[0].xyz);
	
	vec4 position=gbufferModelViewInverse*gl_ModelViewMatrix*gl_Vertex;
	
	#ifdef MOUVEMENTS_MAINS
	position-=vec4(.03*sin(frameTimeCounter*3.),.015*cos(frameTimeCounter*4.),0.,0.)*gbufferModelView;
	#endif
	
	#ifdef MOUVEMENTS_MAINS_2
	position.y+=sin(frameTimeCounter*3.)*.02;
	position.z-=cos(frameTimeCounter*3.)*.002;
	#endif
	
	position=gbufferModelView*position;
	
	position.z-=ADVANCE_HAND_POS;
	position.y+=ADVANCE_HAND_POS2;
	position.x+=DECALLAGE_MAINS;
	
	gl_Position=gl_ProjectionMatrix*position;
	
	color=gl_Color;
	
	#if AA>1
	gl_Position.xy=TAAJitter(gl_Position.xy,gl_Position.w);
	#endif
}
#endif