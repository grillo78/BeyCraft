/*
BSLex (BSL Edit) by LexBoosT
*/

//Settings//
#include "/lib/settings.glsl"

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

//Extensions//

//Varyings//
varying vec2 texCoord, lmCoord;

varying vec3 normal;
varying vec3 sunVec, upVec, eastVec;
varying vec4 color;

#ifdef ADVANCED_MATERIALS
varying float dist;

varying vec3 binormal, tangent;
varying vec3 viewVector;

varying vec4 vTexCoord, vTexCoordAM;
#endif

//Uniforms//
uniform int blockEntityId;
uniform int frameCounter;
uniform int isEyeInWater;
uniform int worldTime;
uniform int heldItemId;
uniform int heldItemId2;

uniform float frameTimeCounter;
uniform float nightVision;
uniform float rainStrength;
uniform float screenBrightness;
uniform float shadowFade;
uniform float timeAngle, timeBrightness;
uniform float viewWidth, viewHeight;

uniform ivec2 eyeBrightnessSmooth;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;

uniform sampler2D texture;

#ifdef WATER_CAUSTICS
#ifdef OVERWORLD
uniform vec3 cameraPosition;
uniform sampler2D noisetex;
#endif
#endif

#ifdef ADVANCED_MATERIALS
uniform ivec2 atlasSize;
uniform sampler2D specular;
uniform sampler2D normals;
#endif

uniform vec3 fogColor;

//Common Variables//
float eBS = eyeBrightnessSmooth.y / 255.0;
float sunVisibility  = clamp(dot( sunVec,upVec) + 0.05, 0.0, 0.1) * 10.0;
float moonVisibility = clamp(dot(-sunVec,upVec) + 0.05, 0.0, 0.1) * 10.0;

#ifdef ADVANCED_MATERIALS
vec2 dcdx = dFdx(texCoord);
vec2 dcdy = dFdy(texCoord);
#endif

vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);

//Common Functions//
float GetLuminance(vec3 color){
	return dot(color,vec3(0.299, 0.587, 0.114));
}

float InterleavedGradientNoise(){
	float n = 52.9829189 * fract(0.06711056 * gl_FragCoord.x + 0.00583715 * gl_FragCoord.y);
	return fract(n + frameCounter / 8.0);
}

//Includes//
#include "/lib/color/blocklightColor.glsl"
#include "/lib/color/dimensionColor.glsl"
#include "/lib/util/dither.glsl"
#include "/lib/util/spaceConversion.glsl"
#include "/lib/lighting/forwardLighting.glsl"

#ifdef WATER_CAUSTICS
#ifdef OVERWORLD
#include "/lib/color/waterColor.glsl"
#include "/lib/lighting/caustics.glsl"
#endif
#endif

#if AA >1
#include "/lib/util/jitter.glsl"
#endif


#ifdef ADVANCED_MATERIALS
#include "/lib/color/specularColor.glsl"
#include "/lib/util/encode.glsl"
#include "/lib/reflections/complexFresnel.glsl"
#include "/lib/surface/ggx.glsl"
#include "/lib/surface/materialGbuffers.glsl"
#include "/lib/surface/parallax.glsl"
#endif

#if MC_VERSION >= 11500
#undef PARALLAX
#undef SELF_SHADOW
#endif

//Program//
void main(){
	vec4 albedo = texture2D(texture, texCoord) * color;
	vec3 newNormal = normal;
	
	
	#ifdef NEW_END_PORTAL
	if (blockEntityId == 10888) {
		vec4[16] colors = vec4[](
			vec4(0.5922, 0.3569, 0.9725, 1.0),
			vec4(0.8392, 0.3059, 1.0, 0.616),
			vec4(0.7451, 0.0941, 0.9451, 0.432),
			vec4(0.898, 0.0157, 0.9804, 0.651),
			vec4(0.149, 0.0157, 0.4549, 1.0),
			vec4(0.2353, 0.0431, 0.9412, 1.0),
			vec4(0.3961, 0.0353, 0.6392, 0.527),
			vec4(0.8784, 0.0275, 0.9922, 0.377),
			vec4(0.7216, 0.5294, 0.9765, 0.363),
			vec4(0.5804, 0.4392, 0.8431, 0.384),
			vec4(0.53406537, 0.55311275, 1.5943265 ,1),
			vec4(0.5765, 0.2431, 0.851, 0.452),
			vec4(0.5902973 , 0.4286982 , 0.64408666,1),
			vec4(0.5882, 0.1176, 0.8039, 0.479),
			vec4(0.7843, 0.4078, 0.9608, 0.418),
			vec4(0.8784, 0.0275, 0.9922, 0.349));
			albedo.rgb = colors[15].rgb*0.001;
			for (int i = 1; i < 13; i++) {
				float colormult = 1.0/(16-i+20.0);
				albedo.rgb *= 0.69 * (1.0 + float(i > 1));
				float rotation = (i - 0.1 * i + 0.71 * i - 11 * i + 21) * 0.01 + i * 0.01;
				float Cos = cos(radians(rotation));
				float Sin = sin(radians(rotation));
				vec2 offset = vec2(0.0, 1.0/(3600.0/24.0)) * pow(16.0 - i, 2.0) * 0.004;
				vec2 Coord = mat2(Cos, Sin, -Sin, Cos) * (gl_FragCoord.xy);
				albedo += texture2D(texture, Coord + fract(frameTimeCounter * offset) + vec2(-0.334,0))*colors[i-1]*colormult;
			}
		}
		#endif
		
		#ifdef ADVANCED_MATERIALS
		vec2 newCoord = vTexCoord.st * vTexCoordAM.pq + vTexCoordAM.st;
		float parallaxFade = clamp((dist - PARALLAX_DISTANCE) / 32.0, 0.0, 1.0);
		float skipAdvMat = float(blockEntityId == 10063);
		
		#ifdef PARALLAX
		if (skipAdvMat < 0.5){
			newCoord = GetParallaxCoord(parallaxFade);
			albedo = texture2DGradARB(texture, newCoord, dcdx, dcdy) * color;
		}
		#endif
		
		float smoothness = 0.0, skyOcclusion = 0.0;
		vec3 fresnel3 = vec3(0.0);
		
		#endif
		
		float skymapMod = 0.0;
		
		if (albedo.a > 0.001){
			vec2 lightmap = clamp(lmCoord, vec2(0.0), vec2(1.0));
			
			float emissive = 0.0;
			
			vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
			#if AA > 1
			vec3 viewPos = ToNDC(vec3(TAAJitter(screenPos.xy, -0.5), screenPos.z));
			#else
			vec3 viewPos = ToNDC(screenPos);
			#endif
			vec3 worldPos = ToWorld(viewPos);
			
			#ifdef ADVANCED_MATERIALS
			float metalness = 0.0, f0 = 0.0, ao = 1.0;
			vec3 normalMap = vec3(0.0, 0.0, 1.0);
			
			GetMaterials(smoothness, metalness, f0, emissive, ao, normalMap, newCoord, dcdx, dcdy);
			
			#if MC_VERSION >= 11500
			normalMap = vec3(0.0, 0.0, 1.0);
			#endif
			
			mat3 tbnMatrix = mat3(tangent.x, binormal.x, normal.x,
				tangent.y, binormal.y, normal.y,
			tangent.z, binormal.z, normal.z);
			
			if (normalMap.x > -0.999 && normalMap.y > -0.999)
			newNormal = clamp(normalize(normalMap * tbnMatrix), vec3(-1.0), vec3(1.0));
			#endif
			
			albedo.rgb = pow(albedo.rgb, vec3(2.2));
			
			#ifdef WHITE_WORLD
			albedo.rgb = vec3(0.5);
			#endif
			#ifdef BLACK_WORLD
			albedo.rgb = vec3(0.0);
			#endif
			
			float NoL = clamp(dot(newNormal, lightVec) * 1.01 - 0.01, 0.0, 1.0);
			
			float NoU = clamp(dot(newNormal, upVec), -1.0, 1.0);
			float NoE = clamp(dot(newNormal, eastVec), -1.0, 1.0);
			float vanillaDiffuse = (0.25 * NoU + 0.75) + (0.667 - abs(NoE)) * (1.0 - abs(NoU)) * 0.15;
			vanillaDiffuse*= vanillaDiffuse;
			
			float parallaxShadow = 1.0;
			#ifdef ADVANCED_MATERIALS
			vec3 rawAlbedo = albedo.rgb * 0.999 + 0.001;
			albedo.rgb *= ao;
			
			#ifdef REFLECTION_SPECULAR
			float roughnessSqr = (1.0 - smoothness) * (1.0 - smoothness);
			albedo.rgb *= (1.0 - metalness * (1.0 - roughnessSqr));
			#endif
			
			float doParallax = 0.0;
			#ifdef SELF_SHADOW
			#ifdef OVERWORLD
			doParallax = float(lightmap.y > 0.0 && NoL > 0.0);
			#endif
			#ifdef END
			doParallax = float(NoL > 0.0);
			#endif
			
			if (doParallax > 0.5){
				parallaxShadow = GetParallaxShadow(parallaxFade, newCoord, lightVec, tbnMatrix);
				NoL *= parallaxShadow;
			}
			#endif
			#endif
			
			vec3 shadow = vec3(0.0);
			GetLighting(albedo.rgb, shadow, viewPos, worldPos, lightmap, color.a, NoL, vanillaDiffuse,
			parallaxShadow, emissive, 0.0,0.0);
			
			#ifdef ADVANCED_MATERIALS
			skyOcclusion = lightmap.y * lightmap.y * (3.0 - 2.0 * lightmap.y);
			
			vec3 baseReflectance = mix(vec3(f0), rawAlbedo, metalness);
			float fresnel = pow(clamp(1.0 + dot(newNormal, normalize(viewPos.xyz)), 0.0, 1.0), 5.0);
			
			fresnel3 = mix(baseReflectance, vec3(1.0), fresnel);
			#if MATERIAL_FORMAT == 0
			if (f0 >= 0.9 && f0 < 1.0) {
				baseReflectance = GetMetalCol(f0);
				fresnel3 = ComplexFresnel(fresnel, f0);
				#ifdef ALBEDO_METAL
				fresnel3 *= rawAlbedo;
				#endif
			}
			#endif
			
			float so = pow(max(ao * 2.0 - 1.0, 0.0), 2.0);
			fresnel3 *= so;
			albedo.rgb = albedo.rgb * (1.0 - fresnel3 * smoothness * smoothness * (1.0 - metalness));
			
			#if defined OVERWORLD || defined END
			vec3 specularColor = GetSpecularColor(lightmap.y, metalness, baseReflectance);
			
			albedo.rgb += GetSpecularHighlight(newNormal, viewPos, lightVec, smoothness, baseReflectance,
			specularColor, 0.0, shadow * vanillaDiffuse);
			#endif
			
			#if defined REFLECTION_SPECULAR && defined REFLECTION_ROUGH
			normalMap = mix(vec3(0.0, 0.0, 1.0), normalMap, smoothness);
			newNormal = clamp(normalize(normalMap * tbnMatrix), vec3(-1.0), vec3(1.0));
			#endif
			#endif
			
			#if defined WATER_CAUSTICS && defined OVERWORLD
			if (isEyeInWater == 1) {
				float skyLightMap = lightmap.y * lightmap.y * (3.0 - 2.0 * lightmap.y);
				shadow *= NoL;
				albedo.rgb = GetCaustics(albedo.rgb, worldPos.xyz, cameraPosition.xyz, shadow, skyLightMap, lightmap.x);
			}
			#endif
			
			#ifdef SHOW_LIGHT_LEVELS
			float showLightLevelFactor = fract(frameTimeCounter / 2.0);
			if (showLightLevelFactor > 0.5) showLightLevelFactor = 1 - showLightLevelFactor;
			if (lmCoord.x < 0.5 && vanillaDiffuse > 0.99) albedo.rgb += mix(albedo.rgb,vec3(SLV_R, SLV_G, SLV_B),SLV_I /10) * showLightLevelFactor;
			#endif
			
			
		} else discard;
		
		
		/* DRAWBUFFERS:0 */
		gl_FragData[0] = albedo;
		
		#if defined ADVANCED_MATERIALS && defined REFLECTION_SPECULAR
		/* DRAWBUFFERS:0367 */
		gl_FragData[1]=vec4(smoothness,skyOcclusion,0.,1.);
		gl_FragData[2]=vec4(EncodeNormal(newNormal),float(gl_FragCoord.z<1.),1.);
		gl_FragData[3]=vec4(fresnel3,1.);
		#endif
	}
	
	#endif
	
	//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
	#ifdef VSH
	
	//Varyings//
	varying vec2 texCoord,lmCoord;
	
	varying vec3 normal;
	varying vec3 sunVec,upVec,eastVec;
	
	varying vec4 color;
	varying vec4 position;
	#ifdef ADVANCED_MATERIALS
	varying float dist;
	varying vec3 binormal,tangent;
	varying vec3 viewVector;
	
	varying vec4 vTexCoord,vTexCoordAM;
	#endif
	
	//Uniforms//
	uniform int worldTime;
	
	uniform float frameTimeCounter;
	uniform float timeAngle;
	
	uniform vec3 cameraPosition;
	
	uniform mat4 gbufferModelView,gbufferModelViewInverse;
	
	#if AA>1
	uniform int frameCounter;
	
	uniform float viewWidth,viewHeight;
	#endif
	
	//Attributes//
	attribute vec4 mc_Entity;
	
	#ifdef ADVANCED_MATERIALS
	attribute vec4 mc_midTexCoord;
	attribute vec4 at_tangent;
	#endif
	
	//Includes//
	#if AA>1
	#include "/lib/util/jitter.glsl"
	#endif
	
	#ifdef WORLD_CURVATURE
	#include "/lib/vertex/worldCurvature.glsl"
	#endif
	
	//Program//
	void main(){
		texCoord=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
		
		lmCoord=(gl_TextureMatrix[1]*gl_MultiTexCoord1).xy;
		lmCoord=clamp((lmCoord-.03125)*1.06667,0.,1.);
		
		normal=normalize(gl_NormalMatrix*gl_Normal);
		
		#ifdef ADVANCED_MATERIALS
		binormal=normalize(gl_NormalMatrix*cross(at_tangent.xyz,gl_Normal.xyz)*at_tangent.w);
		tangent=normalize(gl_NormalMatrix*at_tangent.xyz);
		
		mat3 tbnMatrix=mat3(tangent.x,binormal.x,normal.x,
			tangent.y,binormal.y,normal.y,
		tangent.z,binormal.z,normal.z);
		
		viewVector=tbnMatrix*(gl_ModelViewMatrix*gl_Vertex).xyz;
		
		dist=length(gl_ModelViewMatrix*gl_Vertex);
		
		vec2 midCoord=(gl_TextureMatrix[0]*mc_midTexCoord).st;
		vec2 texMinMidCoord=texCoord-midCoord;
		
		vTexCoordAM.pq=abs(texMinMidCoord)*2;
		vTexCoordAM.st=min(texCoord,midCoord-texMinMidCoord);
		
		vTexCoord.xy=sign(texMinMidCoord)*.5+.5;
		#endif
		
		color=gl_Color;
		
		const vec2 sunRotationData=vec2(cos(sunPathRotation*.01745329251994),-sin(sunPathRotation*.01745329251994));
		float ang=fract(timeAngle-.25);
		ang=(ang+(cos(ang*3.14159265358979)*-.5+.5-ang)/3.)*6.28318530717959;
		sunVec=normalize((gbufferModelView*vec4(vec3(-sin(ang),cos(ang)*sunRotationData)*2000.,1.)).xyz);
		
		upVec=normalize(gbufferModelView[1].xyz);
		eastVec=normalize(gbufferModelView[0].xyz);
		
		vec4 position=gbufferModelViewInverse*gl_ModelViewMatrix*gl_Vertex;
		
		#ifdef MOUVEMENT_CAM
		position+=vec4(.03*sin(frameTimeCounter*3.),.015*cos(frameTimeCounter*4.),0.,0.)*gbufferModelView;
		#endif
		
		#ifdef WORLD_CURVATURE
		position.y-=WorldCurvature(position.xz);
		#else
		gl_Position=ftransform();
		#endif
		
		gl_Position=gl_ProjectionMatrix*gbufferModelView*position;
		
		#if AA>1
		gl_Position.xy=TAAJitter(gl_Position.xy,gl_Position.w);
		#endif
	}
	
	#endif