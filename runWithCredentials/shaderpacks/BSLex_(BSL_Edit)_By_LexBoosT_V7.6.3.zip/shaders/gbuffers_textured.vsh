/* 
BSLex (BSL Edit) by LexBoosT
*/ 

#version 120
#pragma optimize(on)
#define OVERWORLD
#define VSH

#include "/program/gbuffers_textured.glsl"
