/* 
BSLex (BSL Edit) by LexBoosT
*/ 

#version 120
#pragma optimize(on)
#define OVERWORLD
#define VSH

#include "/program/final.glsl"
