/* 
BSLex (BSL Edit) by LexBoosT
*/ 

#version 120
#pragma optimize(on)
#extension GL_ARB_shader_texture_lod : enable

#define OVERWORLD
#define FSH

#include "/program/gbuffers_hand.glsl"
