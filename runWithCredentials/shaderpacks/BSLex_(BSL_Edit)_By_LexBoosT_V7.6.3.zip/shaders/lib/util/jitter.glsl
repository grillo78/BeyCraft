uniform int framemod8;

vec2 jitterOffsets[8] = vec2[8](vec2(1./8.,-3./8.),
								vec2(-1.,3.)/8.,
								vec2(5.0,1.)/8.,
								vec2(-3,-5.)/8.,
								vec2(-5.,5.)/8.,
								vec2(-7.,-1.)/8.,
								vec2(3,7.)/8.,
								vec2(7.,-7.)/8.);
							   
vec2 TAAJitter(vec2 coord, float w){
	vec2 offset = jitterOffsets[framemod8] * 0.130 * (w / vec2(viewWidth, viewHeight));
	return coord + offset;
}