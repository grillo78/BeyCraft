float lexClosest(vec2 pos)
{
	const int ditherPattern[64]=int[64](
		0,32,8,40,2,34,10,42,
		48,16,56,24,50,18,58,26,
		12,44,4,36,14,46,6,38,
		60,28,52,20,62,30,54,22,
		3,35,11,43,1,33,9,41,
		51,19,59,27,49,17,57,25,
		15,47,7,39,13,45,5,37,
		63,31,55,23,61,29,53,21
		);
	
	vec2 positon=floor(mod(vec2(texCoord.s*viewWidth,texCoord.t*viewHeight),8.f));
	int dither2=ditherPattern[int(positon.x)+int(positon.y)*8];
	
	return float(dither2)/64.;
}