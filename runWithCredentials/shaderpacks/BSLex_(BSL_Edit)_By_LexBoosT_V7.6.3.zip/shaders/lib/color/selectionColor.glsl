vec3 selectionColSqrt=vec3(COMPOSANTE_R,COMPOSANTE_G,COMPOSANTE_B)*COMPOSANTE_I/255.;
vec3 selectionCol=selectionColSqrt*selectionColSqrt;