vec3 hue(float h)
{
    h = fract(h) * 6.0;
    return clamp(1.5-abs(h-vec3(1.5,3.5,5.5)),0.0,1.0)+clamp(vec3(0.0,0.0,1.0-h),0.0,1.0);
}
