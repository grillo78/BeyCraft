/* 
BSLex (BSL Edit) by LexBoosT
*/ 

#version 120 
#pragma optimize(on)
#define END
#define VSH

#include "/program/gbuffers_beaconbeam.glsl"
