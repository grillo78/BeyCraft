#version 330 compatibility
#extension GL_ARB_shading_language_packing : enable
#extension GL_ARB_shader_bit_encoding : enable


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBuffersCommon.inc"


in vec4 texcoord;
in vec4 color;
// in vec4 lmcoord;

// in vec3 normal;
in vec4 viewPos;
in vec3 voxelSpacePos;

in float materialIDs;
in float mcEntity;
in float isWater;
in float isStainedGlass;


in float invalidForVolume;
in float WJuPXyHGkb;
in float fragDepth;

in vec2 MqBwqzvRTV;


 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=d();
   ivec2 n=ivec2(v.x*f.x,v.y*f.y);
   float z=float(n.y/y),i=float(int(n.x+mod(f.x*z,y))/y);
   i+=floor(f.x*z/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(n.x+mod(f.x*z,y),y);
   m.y=mod(n.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 s(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 r;
   r.x=mod(i.x+y*x,f.x);
   float n=i.x+y*x;
   r.y=i.y+floor(n/f.x)*x;
   r+=.5;
   r/=f;
   return r;
 }
 vec3 x(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 n=ivec2(i.x*m.x,i.y*m.y);
   float z=float(n.y/y),r=float(int(n.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 s=vec3(0.,0.,r);
   s.x=mod(n.x+mod(m.x*z,y),y);
   s.y=mod(n.y,y);
   s.xyz=floor(s.xyz);
   s/=y;
   s.xyz=s.xzy;
   return s;
 }
 vec2 d(vec3 v,int f)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 i=v.xzy*f;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*f,m.x);
   float n=i.x+x*f;
   r.y=i.y+floor(n/m.x)*f;
   r+=.5;
   r/=m;
   r.xy*=.5;
   return r;
 }
 vec3 f(vec3 v,int f)
 {
   return v*=1./f,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int f)
 {
   return v*=1./f,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int x=f();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 r(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int f=d();
   v=v-vec3(.5);
   v*=f;
   return v;
 }
 vec3 n()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,x=floor(v-.0001),y=floor(i-.0001);
   return x-y;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 n,vec2 x,vec4 i,vec4 m,inout float y,out vec2 r)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(m.x==8||m.x==9||m.x==79||m.x<1.||!z||m.x==20.||m.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(m.x==50.||m.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(m.x==51)
     y=0.;
   if(m.x>255)
     y=0.;
   vec3 s,c;
   if(f.x>.5)
     s=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       s=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         s=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           s=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             s=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               s=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   r=clamp((n.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,L=.15;
   if(m.x==10.||m.x==11.)
     {
       if(abs(f.y)<.01&&z||f.y>.99)
         h=.1,L=.1,y=0.;
       else
          y=1.;
     }
   if(m.x==51)
     h=.5,L=.1;
   if(m.x==76)
     h=.2,L=.2;
   if(m.x-255.+39.>=103.&&m.x-255.+39.<=113.)
     L=.025,h=.025;
   s=normalize(i.xyz);
   c=normalize(cross(s,f.xyz)*sign(i.w));
   vec3 e=v.xyz+mix(s*h,-s*h,vec3(r.x));
   e.xyz+=mix(c*h,-c*h,vec3(r.y));
   e.xyz-=f.xyz*L;
   return e;
 }struct ChqUiAvDkU{vec3 vSNsAVOjDa;vec3 vSNsAVOjDaOrigin;vec3 UgsYTfdINL;vec3 LkVOyZfKEL;vec3 ZPrwqHNnFV;vec3 nqlOapzPzv;};
 ChqUiAvDkU e(Ray v)
 {
   ChqUiAvDkU f;
   f.vSNsAVOjDa=floor(v.origin);
   f.vSNsAVOjDaOrigin=f.vSNsAVOjDa;
   f.UgsYTfdINL=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.LkVOyZfKEL=sign(v.direction);
   f.ZPrwqHNnFV=(sign(v.direction)*(f.vSNsAVOjDa-v.origin)+sign(v.direction)*.5+.5)*f.UgsYTfdINL;
   f.nqlOapzPzv=vec3(0.);
   return f;
 }
 void i(inout ChqUiAvDkU v)
 {
   v.nqlOapzPzv=step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.yzx)*step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.zxy),v.ZPrwqHNnFV+=v.nqlOapzPzv*v.UgsYTfdINL,v.vSNsAVOjDa+=v.nqlOapzPzv*v.LkVOyZfKEL;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float x)
 {
   float y,r,z,c;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   c=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,y),z);
   x=min(min(x,r),c);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,m=y-z,r=vec3(0.);
   r+=vec3(sign(m.x),0.,0.)*step(abs(abs(m.x)-i.x),x);
   r+=vec3(0.,sign(m.y),0.)*step(abs(abs(m.y)-i.y),x);
   r+=vec3(0.,0.,sign(m.z))*step(abs(abs(m.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),n=min(x,y),s=max(x,y);
   vec2 r=max(n.xx,n.yz);
   float z=max(r.x,r.y);
   r=min(s.xx,s.yz);
   float c=min(r.x,r.y);
   i.x=z;
   i.y=c;
   return c>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 y)
 {
   vec3 i=m.inv_direction*(v-m.origin),z=m.inv_direction*(f-m.origin),n=min(z,i),r=max(z,i);
   vec2 s=max(n.xx,n.yz);
   float c=max(s.x,s.y);
   s=min(r.xx,r.yz);
   float h=min(s.x,s.y);
   bool a=h>max(c,0.)&&max(c,0.)<x;
   if(a)
     y=d(v,f,m.origin+m.direction*c),x=c;
   return a;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float n=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*n),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 s=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float c=abs(s.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,c),L=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-L);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 f,vec3 x,vec3 y,vec3 z,int n)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 i=v(f),s=m(i+y*.99);
   float r=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*r),3).x;
   c*=saturate(dot(x,y));
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float h=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*r),3).x;
   vec3 e=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   e*=e;
   c=mix(c,c*e,vec3(1.-h));
   #endif
   return c*(1.-rainStrength);
 }
 vec3 i(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float n=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*n),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float c=shadow2DLod(shadowtex0,vec3(i.xy-vec2(.5,0.),i.z-.0006*n),3).x;
   vec3 s=texture2DLod(shadowcolor,vec2(i.xy-vec2(.5,0.)),3).xyz;
   s*=s;
   r=mix(r,r*s,vec3(1.-c));
   #endif
   return r*(1.-rainStrength);
 }struct SgvRpoZFEp{float hBzGxfOWHl;float rPdSyvYhOi;float AqljTTtzgc;float IiJpNLRFqV;vec3 AChndccCtU;};
 vec4 h(SgvRpoZFEp v)
 {
   vec4 f;
   v.AChndccCtU=max(vec3(0.),v.AChndccCtU);
   f.x=v.hBzGxfOWHl;
   v.AChndccCtU=pow(v.AChndccCtU,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.AChndccCtU.x,v.AqljTTtzgc);
   f.z=PackTwo16BitTo32Bit(v.AChndccCtU.y,v.IiJpNLRFqV);
   f.w=PackTwo16BitTo32Bit(v.AChndccCtU.z,v.rPdSyvYhOi);
   return f;
 }
 SgvRpoZFEp w(vec4 v)
 {
   SgvRpoZFEp f;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),i=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   f.hBzGxfOWHl=v.x;
   f.AqljTTtzgc=m.y;
   f.IiJpNLRFqV=i.y;
   f.rPdSyvYhOi=s.y;
   f.AChndccCtU=pow(vec3(m.x,i.x,s.x),vec3(8.));
   return f;
 }
 SgvRpoZFEp R(vec2 v)
 {
   vec2 f=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*f;
   return w(texture2DLod(colortex5,v,0));
 }
 float R(float v,float f)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+f,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool R(vec3 v,float f,Ray x,bool y,inout float i,inout vec3 r)
 {
   bool m=false,s=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(y)
     return false;
   if(f>=67.)
     return false;
   s=d(v,v+vec3(1.,1.,1.),x,i,r);
   m=s;
   #else
   if(f<40.)
     return s=d(v,v+vec3(1.,1.,1.),x,i,r),s;
   if(f==40.||f==41.||f>=43.&&f<=54.)
     {
       float z=.5;
       if(f==41.)
         z=.9375;
       s=d(v+vec3(0.,0.,0.),v+vec3(1.,z,1.),x,i,r);
       m=m||s;
     }
   if(f==42.||f>=55.&&f<=66.)
     s=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),x,i,r),m=m||s;
   if(f==43.||f==46.||f==47.||f==52.||f==53.||f==54.||f==55.||f==58.||f==59.||f==64.||f==65.||f==66.)
     {
       float z=.5;
       if(f==55.||f==58.||f==59.||f==64.||f==65.||f==66.)
         z=0.;
       s=d(v+vec3(0.,z,0.),v+vec3(.5,.5+z,.5),x,i,r);
       m=m||s;
     }
   if(f==43.||f==45.||f==48.||f==51.||f==53.||f==54.||f==55.||f==57.||f==60.||f==63.||f==65.||f==66.)
     {
       float z=.5;
       if(f==55.||f==57.||f==60.||f==63.||f==65.||f==66.)
         z=0.;
       s=d(v+vec3(.5,z,0.),v+vec3(1.,.5+z,.5),x,i,r);
       m=m||s;
     }
   if(f==44.||f==45.||f==49.||f==51.||f==52.||f==54.||f==56.||f==57.||f==61.||f==63.||f==64.||f==66.)
     {
       float z=.5;
       if(f==56.||f==57.||f==61.||f==63.||f==64.||f==66.)
         z=0.;
       s=d(v+vec3(.5,z,.5),v+vec3(1.,.5+z,1.),x,i,r);
       m=m||s;
     }
   if(f==44.||f==46.||f==50.||f==51.||f==52.||f==53.||f==56.||f==58.||f==62.||f==63.||f==64.||f==65.)
     {
       float z=.5;
       if(f==56.||f==58.||f==62.||f==63.||f==64.||f==65.)
         z=0.;
       s=d(v+vec3(0.,z,.5),v+vec3(.5,.5+z,1.),x,i,r);
       m=m||s;
     }
   if(f>=67.&&f<=82.)
     s=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,x,i,r),m=m||s;
   if(f==68.||f==69.||f==70.||f==72.||f==73.||f==74.||f==76.||f==77.||f==78.||f==80.||f==81.||f==82.)
     {
       float z=8.,c=8.;
       if(f==68.||f==70.||f==72.||f==74.||f==76.||f==78.||f==80.||f==82.)
         z=0.;
       if(f==69.||f==70.||f==73.||f==74.||f==77.||f==78.||f==81.||f==82.)
         c=16.;
       s=d(v+vec3(z,6.,7.)/16.,v+vec3(c,9.,9.)/16.,x,i,r);
       m=m||s;
       s=d(v+vec3(z,12.,7.)/16.,v+vec3(c,15.,9.)/16.,x,i,r);
       m=m||s;
     }
   if(f>=71.&&f<=82.)
     {
       float z=8.,c=8.;
       if(f>=71.&&f<=74.||f>=79.&&f<=82.)
         c=16.;
       if(f>=75.&&f<=82.)
         z=0.;
       s=d(v+vec3(7.,6.,z)/16.,v+vec3(9.,9.,c)/16.,x,i,r);
       m=m||s;
       s=d(v+vec3(7.,12.,z)/16.,v+vec3(9.,15.,c)/16.,x,i,r);
       m=m||s;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(f>=83.&&f<=86.)
     {
       vec3 z=vec3(0),c=vec3(0);
       if(f==83.)
         z=vec3(0,0,0),c=vec3(16,16,3);
       if(f==84.)
         z=vec3(0,0,13),c=vec3(16,16,16);
       if(f==86.)
         z=vec3(0,0,0),c=vec3(3,16,16);
       if(f==85.)
         z=vec3(13,0,0),c=vec3(16,16,16);
       s=d(v+z/16.,v+c/16.,x,i,r);
       m=m||s;
     }
   if(f>=87.&&f<=102.)
     {
       vec3 z=vec3(0.),c=vec3(1.);
       if(f>=87.&&f<=94.)
         {
           float n=0.;
           if(f>=91.&&f<=94.)
             n=13.;
           z=vec3(0.,n,0.)/16.;
           c=vec3(16.,n+3.,16.)/16.;
         }
       if(f>=95.&&f<=98.)
         {
           float n=13.;
           if(f==97.||f==98.)
             n=0.;
           z=vec3(0.,0.,n)/16.;
           c=vec3(16.,16.,n+3.)/16.;
         }
       if(f>=99.&&f<=102.)
         {
           float n=13.;
           if(f==99.||f==100.)
             n=0.;
           z=vec3(n,0.,0.)/16.;
           c=vec3(n+3.,16.,16.)/16.;
         }
       s=d(v+z,v+c,x,i,r);
       m=m||s;
     }
   if(f>=103.&&f<=113.)
     {
       vec3 z=vec3(0.),c=vec3(1.);
       if(f>=103.&&f<=110.)
         {
           float n=float(f)-float(103.)+1.;
           c.y=n*2./16.;
         }
       if(f==111.)
         c.y=.0625;
       if(f==112.)
         z=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(f==113.)
         z=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       s=d(v+z,v+c,x,i,r);
       m=m||s;
     }
   #endif
   #endif
   return m;
 }
 vec4 e(in sampler2D v,in vec2 f)
 {
   vec2 m=vec2(64.f,64.f);
   f*=m;
   f+=.5f;
   vec2 x=floor(f),i=fract(f);
   i.x=i.x*i.x*(3.f-2.f*i.x);
   i.y=i.y*i.y*(3.f-2.f*i.y);
   f=x+i;
   f-=.5f;
   f/=m;
   return texture2D(v,f);
 }
 float R(in float v,in float f,in float x)
 {
   if(v>f)
     return v;
   float z=2.f*x-f,y=2.f*f-3.f*x,i=v/f;
   return(z*i+y)*i*i+x;
 }
 float A(vec3 v)
 {
   float f=.5f;
   vec2 i=v.xz/20.f;
   i.xy-=v.y/20.f;
   i.x=-i.x;
   i.x+=FRAME_TIME/40.f*f;
   i.y-=FRAME_TIME/40.f*f;
   float x=1.f,m=x,r=0.f,s=e(noisetex,i*vec2(2.f,1.2f)+vec2(0.f,i.x*2.1f)).x;
   i/=2.1f;
   i.y-=FRAME_TIME/20.f*f;
   i.x-=FRAME_TIME/30.f*f;
   r+=s*.5;
   x=2.1f;
   m+=x;
   s=e(noisetex,i*vec2(2.f,1.4f)+vec2(0.f,-i.x*2.1f)).x;
   i/=1.5f;
   i.x+=FRAME_TIME/20.f*f;
   s*=x;
   r+=s;
   x=17.25f;
   m+=x;
   s=e(noisetex,i*vec2(1.f,.75f)+vec2(0.f,i.x*1.1f)).x;
   i/=1.5f;
   i.x-=FRAME_TIME/55.f*f;
   s*=x;
   r+=s;
   x=15.25f;
   m+=x;
   s=e(noisetex,i*vec2(1.f,.75f)+vec2(0.f,-i.x*1.7f)).x;
   i/=1.9f;
   i.x+=FRAME_TIME/155.f*f;
   s*=x;
   r+=s;
   x=29.25f;
   m+=x;
   s=abs(e(noisetex,i*vec2(1.f,.8f)+vec2(0.f,-i.x*1.7f)).x*2.f-1.f);
   i/=2.f;
   i.x+=FRAME_TIME/155.f*f;
   s=1.f-R(s,.2f,.1f);
   s*=x;
   r+=s;
   x=15.25f;
   m+=x;
   s=abs(e(noisetex,i*vec2(1.f,.8f)+vec2(0.f,i.x*1.7f)).x*2.f-1.f);
   s=1.f-R(s,.2f,.1f);
   s*=x;
   r+=s;
   r/=m;
   return r;
 }
 void main()
 {
   vec4 f=texture2D(texture,texcoord.xy,0);
   vec3 v=f.xyz*color.xyz;
   float i=1.;
   if(WJuPXyHGkb<.5)
     {
       i=min(f.w*7.,1.);
       vec3 m=(shadowModelViewInverse*vec4(viewPos.xyz,1.)).xyz;
       m+=cameraPosition.xyz;
       gl_FragData[0]=vec4(v.xyz,i);
       gl_FragData[1]=vec4(m.y/256.,1.-isWater,0.,i);
     }
   else
     {
       if(invalidForVolume>.0001)
         {
           discard;
         }
       vec3 x=voxelSpacePos+cameraPosition.xyz;
       v*=v;
       if(abs(mcEntity-50.)<.1)
         v.xyz=GetColorTorchlight()*.1*GI_LIGHT_TORCH_INTENSITY;
       if(abs(mcEntity-76.)<.1)
         v.xyz=vec3(1.,.02,.01)*.05*GI_LIGHT_TORCH_INTENSITY;
       if(abs(mcEntity-51.)<.1)
         v.xyz=vec3(2.,.35,.025);
       float z=clamp((abs(color.x-color.y)+abs(color.x-color.z)+abs(color.y-color.z))*500.,0.,1.);
       gl_FragData[0]=vec4(v.xyz,(materialIDs+.1)/255.*i);
       gl_FragData[1]=vec4(MqBwqzvRTV.xy,z,dot(f.xyz,vec3(.33333)));
     }
 };



