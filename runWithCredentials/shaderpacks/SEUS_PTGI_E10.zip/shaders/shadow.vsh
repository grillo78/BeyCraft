#version 330 compatibility


#include "lib/Uniforms.inc"
#include "lib/Common.inc"



attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

out vec4 vTexcoord;
out vec4 vColor;
// out vec4 lmcoord;

// out vec3 normal;
out vec4 vViewPos;
out float vMaterialIDs;

out float vMCEntity;
// out float isWater;
// out float isStainedGlass;

out float gdJEbClnco;		
out float QFCvNwHBOO;			
out float osfOhmadXh;			
out vec2 gqjYlSaPNv;			

out vec4 ntDWlgNgJU;		
out vec4 RTdfGOYUwP;		
// out vec3 voxelSpacePos;		    



 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 x=ivec2(viewWidth,viewHeight);
   int s=x.x*x.y,y=d();
   ivec2 n=ivec2(v.x*x.x,v.y*x.y);
   float f=float(n.y/y),i=float(int(n.x+mod(x.x*f,y))/y);
   i+=floor(x.x*f/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(n.x+mod(x.x*f,y),y);
   m.y=mod(n.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 x(vec3 v)
 {
   ivec2 x=ivec2(viewWidth,viewHeight);
   int y=d();
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float s=i.z;
   vec2 n;
   n.x=mod(i.x+s*y,x.x);
   float m=i.x+s*y;
   n.y=i.y+floor(m/x.x)*y;
   n+=.5;
   n/=x;
   return n;
 }
 vec3 v(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 x=ivec2(2048,2048);
   int s=x.x*x.y,y=f();
   ivec2 n=ivec2(i.x*x.x,i.y*x.y);
   float z=float(n.y/y),r=float(int(n.x+mod(x.x*z,y))/y);
   r+=floor(x.x*z/y);
   vec3 m=vec3(0.,0.,r);
   m.x=mod(n.x+mod(x.x*z,y),y);
   m.y=mod(n.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 x=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float s=i.z;
   vec2 n;
   n.x=mod(i.x+s*y,x.x);
   float m=i.x+s*y;
   n.y=i.y+floor(m/x.x)*y;
   n+=.5;
   n/=x;
   n.xy*=.5;
   return n;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 m(vec3 v)
 {
   int x=f();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 r(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=d();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 m()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,y=floor(v-.0001),s=floor(x-.0001);
   return y-s;
 }
 vec3 p(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float s=sqrt(x.x*x.x+x.y*x.y),y=1.f-SHADOW_MAP_BIAS+s*SHADOW_MAP_BIAS;
   x.xy*=.95f/y;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xy*=.5;
   x.xy+=.5;
   return x.xyz;
 }
 vec3 d(vec3 v,vec3 m,vec2 x,vec2 y,vec4 n,vec4 f,inout float i,out vec2 s)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(f.x==8||f.x==9||f.x==79||f.x<1.||!r||f.x==20.||f.x==171.||min(abs(m.x),abs(m.z))>.2)
     i=1.;
   if(f.x==50.||f.x==76.)
     {
       i=0.;
       if(m.y<.5)
         i=1.;
     }
   if(f.x==51)
     i=0.;
   if(f.x>255)
     i=0.;
   vec3 z,a;
   if(m.x>.5)
     z=vec3(0.,0.,-1.),a=vec3(0.,-1.,0.);
   else
      if(m.x<-.5)
       z=vec3(0.,0.,1.),a=vec3(0.,-1.,0.);
     else
        if(m.y>.5)
         z=vec3(1.,0.,0.),a=vec3(0.,0.,1.);
       else
          if(m.y<-.5)
           z=vec3(1.,0.,0.),a=vec3(0.,0.,-1.);
         else
            if(m.z>.5)
             z=vec3(1.,0.,0.),a=vec3(0.,-1.,0.);
           else
              if(m.z<-.5)
               z=vec3(-1.,0.,0.),a=vec3(0.,-1.,0.);
   s=clamp((x.xy-y.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,o=.15;
   if(f.x==10.||f.x==11.)
     {
       if(abs(m.y)<.01&&r||m.y>.99)
         h=.1,o=.1,i=0.;
       else
          i=1.;
     }
   if(f.x==51)
     h=.5,o=.1;
   if(f.x==76)
     h=.2,o=.2;
   if(f.x-255.+39.>=103.&&f.x-255.+39.<=113.)
     o=.025,h=.025;
   z=normalize(n.xyz);
   a=normalize(cross(z,m.xyz)*sign(n.w));
   vec3 e=v.xyz+mix(z*h,-z*h,vec3(s.x));
   e.xyz+=mix(a*h,-a*h,vec3(s.y));
   e.xyz-=m.xyz*o;
   return e;
 }struct ChqUiAvDkU{vec3 vSNsAVOjDa;vec3 vSNsAVOjDaOrigin;vec3 UgsYTfdINL;vec3 LkVOyZfKEL;vec3 ZPrwqHNnFV;vec3 nqlOapzPzv;};
 ChqUiAvDkU e(Ray v)
 {
   ChqUiAvDkU i;
   i.vSNsAVOjDa=floor(v.origin);
   i.vSNsAVOjDaOrigin=i.vSNsAVOjDa;
   i.UgsYTfdINL=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.LkVOyZfKEL=sign(v.direction);
   i.ZPrwqHNnFV=(sign(v.direction)*(i.vSNsAVOjDa-v.origin)+sign(v.direction)*.5+.5)*i.UgsYTfdINL;
   i.nqlOapzPzv=vec3(0.);
   return i;
 }
 void i(inout ChqUiAvDkU v)
 {
   v.nqlOapzPzv=step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.yzx)*step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.zxy),v.ZPrwqHNnFV+=v.nqlOapzPzv*v.UgsYTfdINL,v.vSNsAVOjDa+=v.nqlOapzPzv*v.LkVOyZfKEL;
 }
 void d(in Ray v,in vec3 m[2],out float i,out float x)
 {
   float y,z,r,f;
   i=(m[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(m[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(m[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(m[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(m[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   f=(m[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,y),r);
   x=min(min(x,z),f);
 }
 vec3 d(const vec3 v,const vec3 x,vec3 y)
 {
   const float i=1e-05;
   vec3 s=(x+v)*.5,n=(x-v)*.5,m=y-s,f=vec3(0.);
   f+=vec3(sign(m.x),0.,0.)*step(abs(abs(m.x)-n.x),i);
   f+=vec3(0.,sign(m.y),0.)*step(abs(abs(m.y)-n.y),i);
   f+=vec3(0.,0.,sign(m.z))*step(abs(abs(m.z)-n.z),i);
   return normalize(f);
 }
 bool e(const vec3 v,const vec3 m,Ray x,out vec2 i)
 {
   vec3 y=x.inv_direction*(v-x.origin),s=x.inv_direction*(m-x.origin),n=min(s,y),f=max(s,y);
   vec2 r=max(n.xx,n.yz);
   float z=max(r.x,r.y);
   r=min(f.xx,f.yz);
   float h=min(r.x,r.y);
   i.x=z;
   i.y=h;
   return h>max(z,0.);
 }
 bool d(const vec3 v,const vec3 m,Ray x,inout float y,inout vec3 i)
 {
   vec3 s=x.inv_direction*(v-x.origin),f=x.inv_direction*(m-x.origin),n=min(f,s),r=max(f,s);
   vec2 a=max(n.xx,n.yz);
   float z=max(a.x,a.y);
   a=min(r.xx,r.yz);
   float h=min(a.x,a.y);
   bool c=h>max(z,0.)&&max(z,0.)<y;
   if(c)
     i=d(v,m,x.origin+x.direction*z),y=z;
   return c;
 }
 vec3 e(vec3 v,vec3 m,vec3 y,vec3 x,int i)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 n=p(v);
   float s=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*s),0).x;
   f*=saturate(dot(m,y));
   {
     vec4 r=texture2DLod(shadowcolor1,n.xy-vec2(0.,.5),4);
     float z=abs(r.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,m,z),a=shadow2DLod(shadowtex0,vec3(n.xy-vec2(0.,.5),n.z+1e-06),4).x;
     f=mix(f,f*h,1.-a);
   }
   f=TintUnderwaterDepth(f);
   return f*(1.-rainStrength);
 }
 vec3 f(vec3 v,vec3 x,vec3 y,vec3 f,int i)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=m(v),n=p(s+y*.99);
   float z=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*z),3).x;
   r*=saturate(dot(x,y));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float h=shadow2DLod(shadowtex0,vec3(n.xy-vec2(.5,0.),n.z-.0006*z),3).x;
   vec3 a=texture2DLod(shadowcolor,vec2(n.xy-vec2(.5,0.)),3).xyz;
   a*=a;
   r=mix(r,r*a,vec3(1.-h));
   #endif
   return r*(1.-rainStrength);
 }
 vec3 i(vec3 v,vec3 m,vec3 y,vec3 x,int i)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 n=p(v);
   float s=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*s),2).x;
   f*=saturate(dot(m,y));
   f=TintUnderwaterDepth(f);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float z=shadow2DLod(shadowtex0,vec3(n.xy-vec2(.5,0.),n.z-.0006*s),3).x;
   vec3 r=texture2DLod(shadowcolor,vec2(n.xy-vec2(.5,0.)),3).xyz;
   r*=r;
   f=mix(f,f*r,vec3(1.-z));
   #endif
   return f*(1.-rainStrength);
 }struct SgvRpoZFEp{float hBzGxfOWHl;float rPdSyvYhOi;float AqljTTtzgc;float IiJpNLRFqV;vec3 AChndccCtU;};
 vec4 h(SgvRpoZFEp v)
 {
   vec4 i;
   v.AChndccCtU=max(vec3(0.),v.AChndccCtU);
   i.x=v.hBzGxfOWHl;
   v.AChndccCtU=pow(v.AChndccCtU,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.AChndccCtU.x,v.AqljTTtzgc);
   i.z=PackTwo16BitTo32Bit(v.AChndccCtU.y,v.IiJpNLRFqV);
   i.w=PackTwo16BitTo32Bit(v.AChndccCtU.z,v.rPdSyvYhOi);
   return i;
 }
 SgvRpoZFEp w(vec4 v)
 {
   SgvRpoZFEp i;
   vec2 x=UnpackTwo16BitFrom32Bit(v.y),n=UnpackTwo16BitFrom32Bit(v.z),m=UnpackTwo16BitFrom32Bit(v.w);
   i.hBzGxfOWHl=v.x;
   i.AqljTTtzgc=x.y;
   i.IiJpNLRFqV=n.y;
   i.rPdSyvYhOi=m.y;
   i.AChndccCtU=pow(vec3(x.x,n.x,m.x),vec3(8.));
   return i;
 }
 SgvRpoZFEp G(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return w(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool G(vec3 v,float x,Ray y,bool m,inout float i,inout vec3 n)
 {
   bool f=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(m)
     return false;
   if(x>=67.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),y,i,n);
   f=r;
   #else
   if(x<40.)
     return r=d(v,v+vec3(1.,1.,1.),y,i,n),r;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float s=.5;
       if(x==41.)
         s=.9375;
       r=d(v+vec3(0.,0.,0.),v+vec3(1.,s,1.),y,i,n);
       f=f||r;
     }
   if(x==42.||x>=55.&&x<=66.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),y,i,n),f=f||r;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float s=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         s=0.;
       r=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),y,i,n);
       f=f||r;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float s=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         s=0.;
       r=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),y,i,n);
       f=f||r;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float s=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         s=0.;
       r=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),y,i,n);
       f=f||r;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float s=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         s=0.;
       r=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),y,i,n);
       f=f||r;
     }
   if(x>=67.&&x<=82.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,y,i,n),f=f||r;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float s=8.,z=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         s=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         z=16.;
       r=d(v+vec3(s,6.,7.)/16.,v+vec3(z,9.,9.)/16.,y,i,n);
       f=f||r;
       r=d(v+vec3(s,12.,7.)/16.,v+vec3(z,15.,9.)/16.,y,i,n);
       f=f||r;
     }
   if(x>=71.&&x<=82.)
     {
       float s=8.,z=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         z=16.;
       if(x>=75.&&x<=82.)
         s=0.;
       r=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,z)/16.,y,i,n);
       f=f||r;
       r=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,z)/16.,y,i,n);
       f=f||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 s=vec3(0),z=vec3(0);
       if(x==83.)
         s=vec3(0,0,0),z=vec3(16,16,3);
       if(x==84.)
         s=vec3(0,0,13),z=vec3(16,16,16);
       if(x==86.)
         s=vec3(0,0,0),z=vec3(3,16,16);
       if(x==85.)
         s=vec3(13,0,0),z=vec3(16,16,16);
       r=d(v+s/16.,v+z/16.,y,i,n);
       f=f||r;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 s=vec3(0.),z=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float h=0.;
           if(x>=91.&&x<=94.)
             h=13.;
           s=vec3(0.,h,0.)/16.;
           z=vec3(16.,h+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float h=13.;
           if(x==97.||x==98.)
             h=0.;
           s=vec3(0.,0.,h)/16.;
           z=vec3(16.,16.,h+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float h=13.;
           if(x==99.||x==100.)
             h=0.;
           s=vec3(h,0.,0.)/16.;
           z=vec3(h+3.,16.,16.)/16.;
         }
       r=d(v+s,v+z,y,i,n);
       f=f||r;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 s=vec3(0.),z=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float h=float(x)-float(103.)+1.;
           z.y=h*2./16.;
         }
       if(x==111.)
         z.y=.0625;
       if(x==112.)
         s=vec3(1.,0.,1.)/16.,z=vec3(15.,1.,15.)/16.;
       if(x==113.)
         s=vec3(1.,0.,1.)/16.,z=vec3(15.,.5,15.)/16.;
       r=d(v+s,v+z,y,i,n);
       f=f||r;
     }
   #endif
   #endif
   return f;
 }
 vec4 G(vec3 x,vec2 v,out float i,inout float s)
 {
   vec3 y=x;
   int n=f();
   x=clamp(x,vec3(1./n),vec3(1.-1./n));
   if(distance(x,y)>.005/n)
     s=1.;
   float r=dot(abs(x-y),vec3(1.));
   #ifdef MC_GL_VENDOR_ATI
   x-=1./float(n)*vec3(0.,0.,1.);
   #endif
   vec2 m=d(x,n);
   m+=v.xy*(1./vec2(4096));
   m=m*2.-1.;
   i=r;
   return vec4(m,i,1.);
 }
 void main()
 {
   gl_Position=ftransform();
   vTexcoord=gl_MultiTexCoord0;
   vMCEntity=mc_Entity.x;
   vViewPos=gl_ModelViewMatrix*gl_Vertex;
   vec4 v=gl_Position;
   v=shadowProjectionInverse*v;
   v=shadowModelViewInverse*v;
   v.xyz+=cameraPosition.xyz;
   vec3 x=v.xyz;
   vMaterialIDs=30.;
   float s=0.,z=0.f,i=0.f;
   if(mc_Entity.x==8||mc_Entity.x==9)
     s=1.f;
   if(mc_Entity.x==95||mc_Entity.x==160||mc_Entity.x==90||mc_Entity.x==165||mc_Entity.x==79)
     i=1.f;
   if(mc_Entity.x==79)
     z=1.f;
   if(mc_Entity.x==18.||mc_Entity.x==161.f)
     vMaterialIDs=36.;
   if(mc_Entity.x==79.f||mc_Entity.x==174.f)
     vMaterialIDs=37.;
   if(mc_Entity.x==50)
     vMaterialIDs=241.;
   if(mc_Entity.x==76)
     vMaterialIDs=241.;
   if(mc_Entity.x==10||mc_Entity.x==11)
     vMaterialIDs=241.;
   if(mc_Entity.x==89||mc_Entity.x==124||mc_Entity.x==10||mc_Entity.x==11||mc_Entity.x==169||mc_Entity.x==91)
     vMaterialIDs=31.;
   if(mc_Entity.x==51)
     vMaterialIDs=241.;
   #ifdef GLOWING_LAPIS_LAZULI_BLOCK
   if(mc_Entity.x==22)
     vMaterialIDs=31.;
   #endif
   #ifdef GLOWING_REDSTONE_BLOCK
   if(mc_Entity.x==152)
     vMaterialIDs=31.;
   #endif
   #ifdef GLOWING_EMERALD_BLOCK
   if(mc_Entity.x==133)
     vMaterialIDs=31.;
   #endif
   if(mc_Entity.x==95||mc_Entity.x==160)
     vMaterialIDs=240.;
   if(mc_Entity.x==188)
     vMaterialIDs=32.;
   if(mc_Entity.x==189)
     vMaterialIDs=33.;
   if(mc_Entity.x==190)
     vMaterialIDs=34.;
   if(mc_Entity.x==191)
     vMaterialIDs=35.;
   vec3 y=gl_Normal,r=normalize(gl_NormalMatrix*y);
   if(abs(vMaterialIDs-2.)<.1)
     y=vec3(0.,1.,0.);
   gqjYlSaPNv=mc_midTexCoord.xy;
   vColor=gl_Color;
   if(vMaterialIDs!=2.)
     {
       if(y.x>.85)
         vColor.xyz*=1./.6;
       if(y.x<-.85)
         vColor.xyz*=1./.6;
       if(y.z>.85)
         vColor.xyz*=1.25;
       if(y.z<-.85)
         vColor.xyz*=1.25;
       if(y.y<-.85)
         vColor.xyz*=2.;
     }
   gdJEbClnco=0.;
   {
     vec2 m;
     vec3 h=d(v.xyz,gl_Normal.xyz,vTexcoord.xy,mc_midTexCoord.xy,at_tangent,mc_Entity,gdJEbClnco,m);
     if(mc_Entity.x>255)
       vMaterialIDs=mc_Entity.x-255.+39.;
     h=floor(h);
     h-=cameraPosition.xyz;
     int a=f();
     h=n(h,a);
     ntDWlgNgJU=G(h,m,osfOhmadXh,gdJEbClnco);
     if(mc_Entity.x==51)
       osfOhmadXh+=.9;
     osfOhmadXh=osfOhmadXh;
   }
   {
     v.xyz-=cameraPosition.xyz;
     v=shadowModelView*v;
     v=shadowProjection*v;
     gl_Position=v;
     float h=sqrt(gl_Position.x*gl_Position.x+gl_Position.y*gl_Position.y),a=1.f-SHADOW_MAP_BIAS+h*SHADOW_MAP_BIAS;
     gl_Position.xy*=.95f/a;
     gl_Position.xy*=.5;
     gl_Position.xy+=.5;
     if(s>.5)
       gl_Position.y-=1.;
     if(i>.5)
       gl_Position.x-=1.;
     gl_Position.z=mix(gl_Position.z,.5,.8);
     RTdfGOYUwP=gl_Position;
     gl_FrontColor=gl_Color;
   }
 };



