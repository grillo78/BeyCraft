#version 330 compatibility



/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

/////////ADJUSTABLE VARIABLES//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////ADJUSTABLE VARIABLES//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



//#define HALF_RES_TRACE

/////////INTERNAL VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////INTERNAL VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Do not change the name of these variables or their type. The Shaders Mod reads these lines and determines values to send to the inner-workings
//of the shaders mod. The shaders mod only reads these lines and doesn't actually know the real value assigned to these variables in GLSL.
//Some of these variables are critical for proper operation. Change at your own risk.

const bool colortex4Clear = false;
const bool colortex5Clear = false;
//END OF INTERNAL VARIABLES//




in vec4 texcoord;

in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSkyUp;
in vec3 colorTorchlight;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;


in vec3 worldLightVector;
in vec3 worldSunVector;


in mat4 gbufferPreviousModelViewInverse;
in mat4 gbufferPreviousProjectionInverse;


#include "lib/Uniforms.inc"
#include "lib/Common.inc"

#include "lib/Materials.inc"


/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////






// vec4 GetViewPosition(in vec2 coord, in float depth) 
// {	
// 	vec2 tcoord = coord;
// 	TemporalJitterProjPosInv01(tcoord);

// 	vec4 fragposition = gbufferProjectionInverse * vec4(tcoord.s * 2.0f - 1.0f, tcoord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
// 		 fragposition /= fragposition.w;

	
// 	return fragposition;
// }




vec2 GetNearFragment(vec2 coord, float depth, out float minDepth)
{
	
	
	vec2 texel = 1.0 / vec2(viewWidth, viewHeight);
	vec4 depthSamples;
	depthSamples.x = texture2D(depthtex1, coord + texel * vec2(1.0, 1.0)).x;
	depthSamples.y = texture2D(depthtex1, coord + texel * vec2(1.0, -1.0)).x;
	depthSamples.z = texture2D(depthtex1, coord + texel * vec2(-1.0, 1.0)).x;
	depthSamples.w = texture2D(depthtex1, coord + texel * vec2(-1.0, -1.0)).x;

	vec2 targetFragment = vec2(0.0, 0.0);

	if (depthSamples.x < depth)
		targetFragment = vec2(1.0, 1.0);
	if (depthSamples.y < depth)
		targetFragment = vec2(1.0, -1.0);
	if (depthSamples.z < depth)
		targetFragment = vec2(-1.0, 1.0);
	if (depthSamples.w < depth)
		targetFragment = vec2(-1.0, -1.0);


	minDepth = min(min(min(depthSamples.x, depthSamples.y), depthSamples.z), depthSamples.w);

	return coord + texel * targetFragment;
}










#include "lib/GBufferData.inc"





 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int y=v.x*v.y;
   return t(f(floor(pow(float(y),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int y=v.x*v.y;
   return d(f(floor(pow(float(y),.333333))));
 }
 vec3 v(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=d();
   ivec2 i=ivec2(v.x*f.x,v.y*f.y);
   float z=float(i.y/y),r=float(int(i.x+mod(f.x*z,y))/y);
   r+=floor(f.x*z/y);
   vec3 m=vec3(0.,0.,r);
   m.x=mod(i.x+mod(f.x*z,y),y);
   m.y=mod(i.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 s(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int z=d();
   vec3 i=v.xzy*z;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*z,f.x);
   float s=i.x+x*z;
   r.y=i.y+floor(s/f.x)*z;
   r+=.5;
   r/=f;
   return r;
 }
 vec3 x(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 s=ivec2(i.x*m.x,i.y*m.y);
   float z=float(s.y/y),r=float(int(s.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 n=vec3(0.,0.,r);
   n.x=mod(s.x+mod(m.x*z,y),y);
   n.y=mod(s.y,y);
   n.xyz=floor(n.xyz);
   n/=y;
   n.xyz=n.xzy;
   return n;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 f;
   f.x=mod(i.x+x*y,m.x);
   float s=i.x+x*y;
   f.y=i.y+floor(s/m.x)*y;
   f+=.5;
   f/=m;
   f.xy*=.5;
   return f;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 s(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 m(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 e(vec3 v)
 {
   int y=d();
   v*=1./y;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 n(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 e()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,y=floor(v-.0001),x=floor(i-.0001);
   return y-x;
 }
 vec3 r(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/y;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 i,vec2 f,vec2 z,vec4 m,vec4 s,inout float y,out vec2 r)
 {
   bool x=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   x=!x;
   if(s.x==8||s.x==9||s.x==79||s.x<1.||!x||s.x==20.||s.x==171.||min(abs(i.x),abs(i.z))>.2)
     y=1.;
   if(s.x==50.||s.x==76.)
     {
       y=0.;
       if(i.y<.5)
         y=1.;
     }
   if(s.x==51)
     y=0.;
   if(s.x>255)
     y=0.;
   vec3 c,a;
   if(i.x>.5)
     c=vec3(0.,0.,-1.),a=vec3(0.,-1.,0.);
   else
      if(i.x<-.5)
       c=vec3(0.,0.,1.),a=vec3(0.,-1.,0.);
     else
        if(i.y>.5)
         c=vec3(1.,0.,0.),a=vec3(0.,0.,1.);
       else
          if(i.y<-.5)
           c=vec3(1.,0.,0.),a=vec3(0.,0.,-1.);
         else
            if(i.z>.5)
             c=vec3(1.,0.,0.),a=vec3(0.,-1.,0.);
           else
              if(i.z<-.5)
               c=vec3(-1.,0.,0.),a=vec3(0.,-1.,0.);
   r=clamp((f.xy-z.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,w=.15;
   if(s.x==10.||s.x==11.)
     {
       if(abs(i.y)<.01&&x||i.y>.99)
         h=.1,w=.1,y=0.;
       else
          y=1.;
     }
   if(s.x==51)
     h=.5,w=.1;
   if(s.x==76)
     h=.2,w=.2;
   if(s.x-255.+39.>=103.&&s.x-255.+39.<=113.)
     w=.025,h=.025;
   c=normalize(m.xyz);
   a=normalize(cross(c,i.xyz)*sign(m.w));
   vec3 n=v.xyz+mix(c*h,-c*h,vec3(r.x));
   n.xyz+=mix(a*h,-a*h,vec3(r.y));
   n.xyz-=i.xyz*w;
   return n;
 }struct ChqUiAvDkU{vec3 vSNsAVOjDa;vec3 vSNsAVOjDaOrigin;vec3 UgsYTfdINL;vec3 LkVOyZfKEL;vec3 ZPrwqHNnFV;vec3 nqlOapzPzv;};
 ChqUiAvDkU p(Ray v)
 {
   ChqUiAvDkU i;
   i.vSNsAVOjDa=floor(v.origin);
   i.vSNsAVOjDaOrigin=i.vSNsAVOjDa;
   i.UgsYTfdINL=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.LkVOyZfKEL=sign(v.direction);
   i.ZPrwqHNnFV=(sign(v.direction)*(i.vSNsAVOjDa-v.origin)+sign(v.direction)*.5+.5)*i.UgsYTfdINL;
   i.nqlOapzPzv=vec3(0.);
   return i;
 }
 void i(inout ChqUiAvDkU v)
 {
   v.nqlOapzPzv=step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.yzx)*step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.zxy),v.ZPrwqHNnFV+=v.nqlOapzPzv*v.UgsYTfdINL,v.vSNsAVOjDa+=v.nqlOapzPzv*v.LkVOyZfKEL;
 }
 void d(in Ray v,in vec3 i[2],out float f,out float y)
 {
   float x,z,r,w;
   f=(i[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(i[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(i[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(i[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(i[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   w=(i[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   f=max(max(f,x),r);
   y=min(min(y,z),w);
 }
 vec3 d(const vec3 v,const vec3 i,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(i+v)*.5,n=(i-v)*.5,s=y-z,f=vec3(0.);
   f+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-n.x),x);
   f+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-n.y),x);
   f+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-n.z),x);
   return normalize(f);
 }
 bool e(const vec3 v,const vec3 i,Ray m,out vec2 f)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(i-m.origin),s=min(x,y),a=max(x,y);
   vec2 r=max(s.xx,s.yz);
   float z=max(r.x,r.y);
   r=min(a.xx,a.yz);
   float n=min(r.x,r.y);
   f.x=z;
   f.y=n;
   return n>max(z,0.);
 }
 bool d(const vec3 v,const vec3 i,Ray m,inout float y,inout vec3 x)
 {
   vec3 z=m.inv_direction*(v-m.origin),s=m.inv_direction*(i-m.origin),f=min(s,z),a=max(s,z);
   vec2 r=max(f.xx,f.yz);
   float t=max(r.x,r.y);
   r=min(a.xx,a.yz);
   float n=min(r.x,r.y);
   bool c=n>max(t,0.)&&max(t,0.)<y;
   if(c)
     x=d(v,i,m.origin+m.direction*t),y=t;
   return c;
 }
 vec3 e(vec3 v,vec3 i,vec3 y,vec3 z,int f)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 s=r(v);
   float x=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*x),0).x;
   c*=saturate(dot(i,y));
   {
     vec4 m=texture2DLod(shadowcolor1,s.xy-vec2(0.,.5),4);
     float w=abs(m.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,i,w),t=shadow2DLod(shadowtex0,vec3(s.xy-vec2(0.,.5),s.z+1e-06),4).x;
     c=mix(c,c*h,1.-t);
   }
   c=TintUnderwaterDepth(c);
   return c*(1.-rainStrength);
 }
 vec3 f(vec3 v,vec3 i,vec3 y,vec3 z,int f)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 x=m(v),s=r(x+y*.99);
   float w=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*w),3).x;
   c*=saturate(dot(i,y));
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float n=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*w),3).x;
   vec3 h=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   h*=h;
   c=mix(c,c*h,vec3(1.-n));
   #endif
   return c*(1.-rainStrength);
 }
 vec3 i(vec3 v,vec3 i,vec3 y,vec3 z,int f)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 s=r(v);
   float x=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*x),2).x;
   c*=saturate(dot(i,y));
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float n=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*x),3).x;
   vec3 m=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   m*=m;
   c=mix(c,c*m,vec3(1.-n));
   #endif
   return c*(1.-rainStrength);
 }struct SgvRpoZFEp{float hBzGxfOWHl;float rPdSyvYhOi;float AqljTTtzgc;float IiJpNLRFqV;vec3 AChndccCtU;};
 vec4 h(SgvRpoZFEp v)
 {
   vec4 i;
   v.AChndccCtU=max(vec3(0.),v.AChndccCtU);
   i.x=v.hBzGxfOWHl;
   v.AChndccCtU=pow(v.AChndccCtU,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.AChndccCtU.x,v.AqljTTtzgc);
   i.z=PackTwo16BitTo32Bit(v.AChndccCtU.y,v.IiJpNLRFqV);
   i.w=PackTwo16BitTo32Bit(v.AChndccCtU.z,v.rPdSyvYhOi);
   return i;
 }
 SgvRpoZFEp w(vec4 v)
 {
   SgvRpoZFEp i;
   vec2 s=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),f=UnpackTwo16BitFrom32Bit(v.w);
   i.hBzGxfOWHl=v.x;
   i.AqljTTtzgc=s.y;
   i.IiJpNLRFqV=m.y;
   i.rPdSyvYhOi=f.y;
   i.AChndccCtU=pow(vec3(s.x,m.x,f.x),vec3(8.));
   return i;
 }
 SgvRpoZFEp g(vec2 v)
 {
   vec2 y=1./vec2(viewWidth,viewHeight),x=vec2(viewWidth,viewHeight);
   v=(floor(v*x)+.5)*y;
   return w(texture2DLod(colortex5,v,0));
 }
 float e(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool d(vec3 v,float y,Ray i,bool z,inout float x,inout vec3 f)
 {
   bool m=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(z)
     return false;
   if(y>=67.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),i,x,f);
   m=r;
   #else
   if(y<40.)
     return r=d(v,v+vec3(1.,1.,1.),i,x,f),r;
   if(y==40.||y==41.||y>=43.&&y<=54.)
     {
       float c=.5;
       if(y==41.)
         c=.9375;
       r=d(v+vec3(0.,0.,0.),v+vec3(1.,c,1.),i,x,f);
       m=m||r;
     }
   if(y==42.||y>=55.&&y<=66.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,x,f),m=m||r;
   if(y==43.||y==46.||y==47.||y==52.||y==53.||y==54.||y==55.||y==58.||y==59.||y==64.||y==65.||y==66.)
     {
       float c=.5;
       if(y==55.||y==58.||y==59.||y==64.||y==65.||y==66.)
         c=0.;
       r=d(v+vec3(0.,c,0.),v+vec3(.5,.5+c,.5),i,x,f);
       m=m||r;
     }
   if(y==43.||y==45.||y==48.||y==51.||y==53.||y==54.||y==55.||y==57.||y==60.||y==63.||y==65.||y==66.)
     {
       float c=.5;
       if(y==55.||y==57.||y==60.||y==63.||y==65.||y==66.)
         c=0.;
       r=d(v+vec3(.5,c,0.),v+vec3(1.,.5+c,.5),i,x,f);
       m=m||r;
     }
   if(y==44.||y==45.||y==49.||y==51.||y==52.||y==54.||y==56.||y==57.||y==61.||y==63.||y==64.||y==66.)
     {
       float c=.5;
       if(y==56.||y==57.||y==61.||y==63.||y==64.||y==66.)
         c=0.;
       r=d(v+vec3(.5,c,.5),v+vec3(1.,.5+c,1.),i,x,f);
       m=m||r;
     }
   if(y==44.||y==46.||y==50.||y==51.||y==52.||y==53.||y==56.||y==58.||y==62.||y==63.||y==64.||y==65.)
     {
       float c=.5;
       if(y==56.||y==58.||y==62.||y==63.||y==64.||y==65.)
         c=0.;
       r=d(v+vec3(0.,c,.5),v+vec3(.5,.5+c,1.),i,x,f);
       m=m||r;
     }
   if(y>=67.&&y<=82.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,x,f),m=m||r;
   if(y==68.||y==69.||y==70.||y==72.||y==73.||y==74.||y==76.||y==77.||y==78.||y==80.||y==81.||y==82.)
     {
       float c=8.,s=8.;
       if(y==68.||y==70.||y==72.||y==74.||y==76.||y==78.||y==80.||y==82.)
         c=0.;
       if(y==69.||y==70.||y==73.||y==74.||y==77.||y==78.||y==81.||y==82.)
         s=16.;
       r=d(v+vec3(c,6.,7.)/16.,v+vec3(s,9.,9.)/16.,i,x,f);
       m=m||r;
       r=d(v+vec3(c,12.,7.)/16.,v+vec3(s,15.,9.)/16.,i,x,f);
       m=m||r;
     }
   if(y>=71.&&y<=82.)
     {
       float c=8.,w=8.;
       if(y>=71.&&y<=74.||y>=79.&&y<=82.)
         w=16.;
       if(y>=75.&&y<=82.)
         c=0.;
       r=d(v+vec3(7.,6.,c)/16.,v+vec3(9.,9.,w)/16.,i,x,f);
       m=m||r;
       r=d(v+vec3(7.,12.,c)/16.,v+vec3(9.,15.,w)/16.,i,x,f);
       m=m||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=83.&&y<=86.)
     {
       vec3 c=vec3(0),s=vec3(0);
       if(y==83.)
         c=vec3(0,0,0),s=vec3(16,16,3);
       if(y==84.)
         c=vec3(0,0,13),s=vec3(16,16,16);
       if(y==86.)
         c=vec3(0,0,0),s=vec3(3,16,16);
       if(y==85.)
         c=vec3(13,0,0),s=vec3(16,16,16);
       r=d(v+c/16.,v+s/16.,i,x,f);
       m=m||r;
     }
   if(y>=87.&&y<=102.)
     {
       vec3 c=vec3(0.),s=vec3(1.);
       if(y>=87.&&y<=94.)
         {
           float h=0.;
           if(y>=91.&&y<=94.)
             h=13.;
           c=vec3(0.,h,0.)/16.;
           s=vec3(16.,h+3.,16.)/16.;
         }
       if(y>=95.&&y<=98.)
         {
           float w=13.;
           if(y==97.||y==98.)
             w=0.;
           c=vec3(0.,0.,w)/16.;
           s=vec3(16.,16.,w+3.)/16.;
         }
       if(y>=99.&&y<=102.)
         {
           float h=13.;
           if(y==99.||y==100.)
             h=0.;
           c=vec3(h,0.,0.)/16.;
           s=vec3(h+3.,16.,16.)/16.;
         }
       r=d(v+c,v+s,i,x,f);
       m=m||r;
     }
   if(y>=103.&&y<=113.)
     {
       vec3 c=vec3(0.),s=vec3(1.);
       if(y>=103.&&y<=110.)
         {
           float n=float(y)-float(103.)+1.;
           s.y=n*2./16.;
         }
       if(y==111.)
         s.y=.0625;
       if(y==112.)
         c=vec3(1.,0.,1.)/16.,s=vec3(15.,1.,15.)/16.;
       if(y==113.)
         c=vec3(1.,0.,1.)/16.,s=vec3(15.,.5,15.)/16.;
       r=d(v+c,v+s,i,x,f);
       m=m||r;
     }
   #endif
   #endif
   return m;
 }
 vec2 c(inout float v)
 {
   return fract(sin(vec2(v+=.1,v+=.1))*vec2(43758.5,22578.1));
 }
 float G(vec2 v)
 {
   v*=vec2(viewWidth,viewHeight);
   const float y=1.61803,x=1.32472;
   return fract(dot(v,1./vec2(y,x*x)));
 }
 vec3 D(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 m[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   else
      y+=m[int(mod(frameCounter,8.f))]*.5;
   y=(floor(y*64.)+.5)/64.;
   vec3 x=texture2D(noisetex,y).xyz;
   return x;
 }
 vec3 D(vec3 v,vec2 y)
 {
   y=y*.99+.005;
   #if GI_RESPONSIVENESS<1
   #endif
   float c=6.28319*y.x,x=sqrt(y.y);
   vec3 m=normalize(cross(v,vec3(0.,1.,1.))),s=cross(v,m),i=m*cos(c)*x+s*sin(c)*x+v.xyz*sqrt(1.-y.y);
   return i;
 }
 vec3 C(inout float v)
 {
   vec3 y=D(texcoord.xy).xyz;
   y=fract(y+vec3(c(v),c(v).x)*.1);
   y=y*2.-1.;
   y=normalize(y);
   return y;
 }
 vec3 C(vec3 v,vec3 y)
 {
   vec2 c=s(e(m(v)+y+1.+e()));
   vec3 x=g(c).AChndccCtU;
   return x;
 }
 vec3 C()
 {
   vec2 y=s(v(texcoord.xy)+e()/d());
   vec3 x=g(y).AChndccCtU;
   return x;
 }
 vec3 C(vec3 v,vec3 m,vec3 y,vec3 c,vec3 x,MaterialMask s,float z,vec2 r,float h,out float n)
 {
   float w=fract(frameCounter*.0123456),a=1.;
   #ifdef SUNLIGHT_LEAK_FIX
   if(isEyeInWater<1)
     a=saturate(z*100.);
   #endif
   float e=1.;
   #ifdef CAVE_GI_LEAK_FIX
   if(isEyeInWater<1)
     e=saturate(z*10.);
   #endif
   vec3 t=D(texcoord.xy+vec2(0.,0.)).xyz,l=D(c,t.xy);
   n=10000.;
   vec3 U=l;
   #ifdef GI_SCREEN_SPACE_TRACING
   bool G=false;
   {
     const int L=8;
     float g=.25*-m.z;
     g=mix(g,.8,.5);
     float R=.07*-m.z;
     R=mix(R,1.,.5);
     R=.4;
     vec2 o=texcoord.xy;
     vec3 S=m.xyz,V=normalize((gbufferModelView*vec4(l.xyz,0.)).xyz);
     for(int T=0;T<L;T++)
       {
         float F=float(T),Y=(F+.5)/float(L),b=g*Y;
         vec3 A=m.xyz+V*b,P=ProjectBack(A),M=GetViewPositionNoJitter(P.xy,GetDepth(P.xy)).xyz;
         float I=length(A)-length(M)-.02;
         if(I>0.&&I<R)
           {
             G=true;
             o=P.xy;
             S=M.xyz;
             break;
           }
       }
     vec3 T=(gbufferModelViewInverse*vec4(S,1.)).xyz;
     T+=Fract01(cameraPosition.xyz+.5)+.5;
     if(G)
       {
         vec3 F=pow(texture2DLod(colortex7,o.xy-r*.5,0).xyz,vec3(2.2));
         F*=1.-saturate(h*1.1);
         return F*100.;
       }
   }
   #endif
   int R=f();
   float F=1./float(R);
   vec3 g=v+y*(.0001*length(v));
   g+=Fract01(cameraPosition.xyz+.5);
   Ray T=MakeRay(f(g,R)*R-vec3(1.,1.,1.),l);
   ChqUiAvDkU P=p(T);
   vec3 L=vec3(1.),o=vec3(0.);
   float S=0.,V=1.;
   {
     vec4 M=vec4(0.);
     vec3 A=vec3(0.);
     float b=.5;
     for(int I=0;I<DIFFUSE_TRACE_LENGTH;I++)
       {
         A=P.vSNsAVOjDa/float(R);
         vec2 Y=d(A,R);
         M=texture2DLod(shadowcolor,Y,0);
         S=M.w*255.;
         float Z=1.-step(.5,abs(S-241.));
         vec3 u=M.xyz;
         o+=u*Z*b*.5;
         #ifdef GI_LEAF_TRANSPARENCY
         if(abs(S-36.)<.1)
           {
             if(t.z<pow(.2,V))
               {
                 i(P);
                 b=1.;
                 V+=1.;
                 L*=pow(M.xyz,vec3(.25));
                 continue;
               }
           }
         #endif
         if(S<240.)
           {
             if(d(P.vSNsAVOjDa,S,T,I==0,n,U))
               {
                 break;
               }
           }
         i(P);
         b=1.;
       }
     float I=0.;
     if(S<1.f||S>254.f)
       {
         vec3 Y=T.direction;
         if(isEyeInWater>0)
           Y=refract(Y,vec3(0.,-1.,0.),1.3333);
         vec3 u=SkyShading(Y,worldSunVector,rainStrength);
         u*=saturate(Y.y*10.+1.);
         u=DoNightEyeAtNight(u*12.,timeMidnight)*.083333;
         u=TintUnderwaterDepth(u);
         if(length(Y)<.1)
           I=300.;
         o+=u*.1*e*L;
       }
     else
       {
         if(abs(S-31.)<.1)
           o+=.09*L*M.xyz*GI_LIGHT_BLOCK_INTENSITY;
         if(S>=32.&&S<=35.)
           {
             float u=0.;
             if(abs(S-32.)<.1)
               u=max(-U.z,0.);
             if(abs(S-33.)<.1)
               u=max(U.x,0.);
             if(abs(S-34.)<.1)
               u=max(U.z,0.);
             if(abs(S-35.)<.1)
               u=max(-U.x,0.);
             o+=.04*L*u*vec3(2.,.35,.025)*GI_LIGHT_BLOCK_INTENSITY;
           }
         if(S<240.)
           {
             vec3 u=saturate(M.xyz);
             L*=u;
             o+=C(A,U)*L;
             const float Y=2.4;
             vec3 Z=i(g+T.direction*n-1.,worldLightVector,U,l,R),k=DoNightEyeAtNight(Z*L*Y*colorSunlight*a*e*12.,timeMidnight)/12.;
             o+=k;
             I=n;
           }
       }
     UnderwaterFog(o,I,l,colorSkyUp,colorSunlight);
   }
   if(s.grass<.5)
     o/=saturate(dot(c,l))+.01,o*=saturate(dot(y,l));
   return o;
 }
 vec3 D()
 {
   int y=f();
   vec3 c=v(texcoord.xy),s=n(c),x=f(s-vec3(1.,1.,0.),y);
   vec2 m=d(x,y);
   float z=1.;
   #ifdef CAVE_GI_LEAK_FIX
   if(isEyeInWater<1)
     z*=saturate(eyeBrightnessSmooth.y/240.*20.);
   #endif
   float r=1000.;
   r=min(r,texture2DLod(shadowcolor,d(f(s-vec3(0.,0.,0.),y),y)+vec2(.5,.5)/float(4096),0).w);
   r=min(r,texture2DLod(shadowcolor,d(f(s-vec3(0.,0.,0.),y),y)+vec2(-.5,-.5)/float(4096),0).w);
   r=min(r,texture2DLod(shadowcolor,d(f(s-vec3(0.,1.,0.),y),y)+vec2(0.,0.)/float(4096),0).w);
   r=min(r,texture2DLod(shadowcolor,d(f(s-vec3(0.,-1.,0.),y),y)+vec2(0.,0.)/float(4096),0).w);
   float w=texture2DLod(shadowcolor,d(f(s-vec3(0.,0.,0.),y),y),0).w;
   if(r*255.>240.||w*255.<240.)
     return vec3(0.);
   vec3 h=vec3(0.);
   for(int e=0;e<GI_SECONDARY_SAMPLES;e++)
     {
       float t=sin(frameTimeCounter*1.1)+s.x*.11+s.y*.12+s.z*.13+e*.1;
       vec3 a=normalize(rand(vec2(t))*2.-1.);
       a.x+=a.x==a.y||a.x==a.z?.01:0.;
       a.y+=a.y==a.z?.01:0.;
       vec3 S=s+vec3(1.,1.,1.);
       Ray g=MakeRay(f(S,y)*y-vec3(1.,1.,1.),a);
       ChqUiAvDkU U=p(g);
       vec3 L=vec3(1.);
       float u=1000.;
       for(int o=0;o<1;o++)
         {
           vec4 T=vec4(0.);
           float I=0.;
           vec3 Y=vec3(0.);
           float R=.2;
           for(int F=0;F<DIFFUSE_TRACE_LENGTH;F++)
             {
               Y=U.vSNsAVOjDa/float(y);
               vec2 l=d(Y,y);
               T=texture2DLod(shadowcolor,l,0);
               I=T.w*255.;
               float G=1.-step(.5,abs(I-241.));
               vec3 P=T.xyz;
               h+=P*R*G*(F==0?.5:1.);
               if(I<240.)
                 {
                   break;
                 }
               i(U);
               R=saturate(R*1.3);
             }
           u=distance(U.vSNsAVOjDa.xyz,U.vSNsAVOjDaOrigin.xyz);
           float l=0.,G=1.;
           if(abs(U.vSNsAVOjDa.x-U.vSNsAVOjDaOrigin.x)<2||abs(U.vSNsAVOjDa.y-U.vSNsAVOjDaOrigin.y)<2||abs(U.vSNsAVOjDa.z-U.vSNsAVOjDaOrigin.z)<2)
             G=0.;
           if(I<1.f||I>254.f)
             {
               vec3 P=g.direction;
               if(isEyeInWater>0)
                 P=refract(P,vec3(0.,-1.,0.),1.3333);
               vec3 F=SkyShading(P,worldSunVector,rainStrength);
               F*=saturate(P.y*10.+1.);
               F=DoNightEyeAtNight(F*12.,timeMidnight)*.083333;
               F=TintUnderwaterDepth(F);
               if(isEyeInWater>0)
                 ;
               if(length(P)<.1)
                 l=300.;
               h+=F*.1*z;
             }
           vec3 P=-U.nqlOapzPzv*U.LkVOyZfKEL;
           if(abs(I-31.)<.1)
             h+=.09*T.xyz*GI_LIGHT_BLOCK_INTENSITY;
           if(I>=32.&&I<=35.)
             {
               float F=0.;
               if(abs(I-32.)<.1)
                 F=max(-P.z,0.);
               if(abs(I-33.)<.1)
                 F=max(P.x,0.);
               if(abs(I-34.)<.1)
                 F=max(P.z,0.);
               if(abs(I-35.)<.1)
                 F=max(-P.x,0.);
               h+=.02*L*F*vec3(2.,.35,.025)*GI_LIGHT_BLOCK_INTENSITY;
             }
           if(I<240.)
             {
               vec3 F=saturate(T.xyz);
               L*=F;
               vec3 A=-(U.nqlOapzPzv*U.LkVOyZfKEL);
               const float b=2.4;
               vec3 Z=f(Y,worldLightVector,A,a,y),M=DoNightEyeAtNight(Z*b*colorSunlight*G*L*z*12.,timeMidnight)/12.;
               h+=M*2.;
               h+=C(Y,A)*L;
               l=u;
             }
           {
             vec2 F=IntersectSphere(s,g.direction,vec3(0.,1.5,0.),.75);
             if(u>F.y&&F.y>-.5)
               ;
           }
           UnderwaterFog(h,l,a,colorSkyUp,colorSunlight);
         }
     }
   h/=float(GI_SECONDARY_SAMPLES);
   return saturate(h);
 }
 vec4 T(float v)
 {
   float y=v*v,m=y*v;
   vec4 i;
   i.x=-m+3*y-3*v+1;
   i.y=3*m-6*y+4;
   i.z=-3*m+3*y+3*v+1;
   i.w=m;
   return i/6.f;
 }
 vec4 G(in sampler2D v,in vec2 i)
 {
   vec2 y=vec2(viewWidth,viewHeight);
   i*=y;
   i-=.5;
   float m=fract(i.x),s=fract(i.y);
   i.x-=m;
   i.y-=s;
   vec4 c=T(m),x=T(s),f=vec4(i.x-.5,i.x+1.5,i.y-.5,i.y+1.5),r=vec4(c.x+c.y,c.z+c.w,x.x+x.y,x.z+x.w),a=f+vec4(c.y,c.w,x.y,x.w)/r,z=texture2DLod(v,vec2(a.x,a.z)/y,0),h=texture2DLod(v,vec2(a.y,a.z)/y,0),w=texture2DLod(v,vec2(a.x,a.w)/y,0),t=texture2DLod(v,vec2(a.y,a.w)/y,0);
   float n=r.x/(r.x+r.y),l=r.z/(r.z+r.w);
   return mix(mix(t,w,n),mix(h,z,n),l);
 }
 bool T(vec3 v,vec3 y)
 {
   vec3 c=normalize(cross(dFdx(v),dFdy(v))),s=normalize(y-v),x=normalize(s);
   float r=.02+length(v)*.04;
   return distance(v,y)<r;
 }
 vec3 F(vec2 v)
 {
   vec2 y=vec2(viewWidth,viewHeight),m=1./y,s=v*y,x=floor(s-.5)+.5,c=s-x,z=c*c,i=c*z;
   float f=.5;
   vec2 r=-f*i+2.*f*z-f*c,a=(2.-f)*i-(3.-f)*z+1.,h=-(2.-f)*i+(3.-2.*f)*z+f*c,n=f*i-f*z,t=a+h,U=m*(x+h/t);
   vec3 F=texture2DLod(colortex4,vec2(U.x,U.y),0).xyz;
   vec2 w=m*(x-1.),P=m*(x+2.);
   vec4 l=vec4(texture2DLod(colortex4,vec2(U.x,w.y),0).xyz,1.)*(t.x*r.y)+vec4(texture2DLod(colortex4,vec2(w.x,U.y),0).xyz,1.)*(r.x*t.y)+vec4(F,1.)*(t.x*t.y)+vec4(texture2DLod(colortex4,vec2(P.x,U.y),0).xyz,1.)*(n.x*t.y)+vec4(texture2DLod(colortex4,vec2(U.x,P.y),0).xyz,1.)*(t.x*n.y);
   return max(vec3(0.),l.xyz*(1./l.w));
 }
 vec2 C(float v,vec2 i,out float y,out vec3 s,out vec4 f)
 {
   float x;
   vec2 c=GetNearFragment(texcoord.xy,v,x);
   y=texture2D(depthtex1,c).x;
   vec4 m=vec4(texcoord.xy*2.-1.,y*2.-1.,1.),r=gbufferProjectionInverse*m;
   r.xyz/=r.w;
   vec4 z=gbufferModelViewInverse*vec4(r.xyz,1.);
   f=z;
   f.xyz+=cameraPosition-previousCameraPosition;
   vec4 a=gbufferPreviousModelView*vec4(f.xyz,1.),n=gbufferPreviousProjection*vec4(a.xyz,1.);
   n.xyz/=n.w;
   s=m.xyz-n.xyz;
   float F=length(s.xy)*10.,w=clamp(F*500.,0.,1.);
   vec2 h=i.xy-s.xy*.5;
   if(y<.7)
     h=texcoord.xy;
   return h;
 }
 void main()
 {
   GBufferData v=GetGBufferData();
   MaterialMask y=CalculateMasks(v.materialID);
   vec4 i=GetViewPosition(texcoord.xy,v.depth),s=gbufferModelViewInverse*vec4(i.xyz,1.),c=gbufferModelViewInverse*vec4(i.xyz,0.);
   vec3 x=normalize(i.xyz),m=normalize(c.xyz),r=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz),z=normalize((gbufferModelViewInverse*vec4(v.geoNormal,0.)).xyz);
   float f=length(i.xyz),a=dot(v.mcLightmap.xy,vec2(.5));
   if(y.grass>.5)
     r=vec3(0.,1.,0.),z=vec3(0.,1.,0.);
   vec4 n=vec4(texcoord.xy,0.,0.);
   float t;
   vec3 U;
   vec4 w;
   vec2 P=C(v.depth,n.xy,t,U,w),I=P.xy;
   I-=(vec2(mod(frameCounter/2,2.f),mod(frameCounter,2.f))-.5)/vec2(viewWidth,viewHeight)*1.5;
   vec3 l=F(I.xy);
   SgvRpoZFEp R=g(P.xy);
   float S=1./(saturate(-dot(v.geoNormal,x))*100.+1.);
   vec4 Y=vec4(P.xy,0.,0.);
   TemporalJitterProjPosPrevInv(Y);
   vec4 u=gbufferPreviousProjectionInverse*vec4(P.xy*2.-1.,texture2DLod(colortex7,Y.xy,0).w*2.-1.,1.);
   u/=u.w;
   vec3 o=(gbufferPreviousModelViewInverse*vec4(u.xyz,1.)).xyz;
   R.hBzGxfOWHl+=1.;
   R.hBzGxfOWHl=min(R.hBzGxfOWHl,2.);
   vec2 L=1./vec2(viewWidth,viewHeight),M=1.-L;
   float A=0.,G=1.-exp2(-R.hBzGxfOWHl);
   if(!T(w.xyz,o.xyz)||(P.x<L.x||P.x>M.x||P.y<L.y||P.y>M.y)||abs(S-R.AqljTTtzgc)>.01)
     G=0.,A=.99,R.hBzGxfOWHl=0.;
   float e;
   vec3 b=C(s.xyz,i.xyz,r.xyz,z,m.xyz,y,v.mcLightmap.y,U.xy,A,e);
   b=max(vec3(0.),b);
   b=mix(b,l,vec3(G));
   A=max(A,mix(A,.9,saturate(-U.z*120.)));
   R.AqljTTtzgc=S;
   R.IiJpNLRFqV=mix(R.IiJpNLRFqV,A,mix(.5,1.,A));
   R.rPdSyvYhOi=a;
   vec3 V=D();
   R.AChndccCtU=mix(C(),V,vec3(.015));
   vec4 d=h(R);
   gl_FragData[0]=vec4(b,saturate(t));
   gl_FragData[1]=vec4(d);
   gl_FragData[2]=vec4(b,1.);
 };




/* DRAWBUFFERS:456 */
