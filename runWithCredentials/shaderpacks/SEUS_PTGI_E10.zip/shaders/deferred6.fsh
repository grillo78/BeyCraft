#version 330 compatibility

/*
 _______ _________ _______  _______  _
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////











const int 		shadowMapResolution 	= 4096;
const float 	shadowDistance 			= 120.0; // Shadow distance. Set lower if you prefer nicer close shadows. Set higher if you prefer nicer distant shadows. [80.0 120.0 180.0 240.0]
const float 	shadowIntervalSize 		= 1.0f;
const bool 		shadowHardwareFiltering0 = true;

const bool 		shadowtexMipmap = true;
const bool 		shadowtex1Mipmap = false;
const bool 		shadowtex1Nearest = false;
const bool 		shadowcolor0Mipmap = false;
const bool 		shadowcolor0Nearest = false;
const bool 		shadowcolor1Mipmap = false;
const bool 		shadowcolor1Nearest = false;

const float shadowDistanceRenderMul = 1.0f;

const int 		RGB8 					= 0;
const int 		RGBA8 					= 0;
const int 		RGBA16 					= 0;
const int 		RGBA16F 				= 0;
const int 		RGBA32F 				= 0;
const int 		RG16 					= 0;
const int 		RGB16 					= 0;
const int 		R11F_G11F_B10F 			= 0;
const int 		colortex0Format 			= RGB8;
const int 		colortex1Format 			= RGBA16;
const int 		colortex2Format 			= RGBA16;
const int 		colortex3Format 			= RGBA16;
const int 		colortex4Format 			= RGBA16F;
const int 		colortex5Format 			= RGBA32F;
const int 		colortex6Format 			= RGBA16F;
const int 		colortex7Format 			= RGBA16;


const int 		superSamplingLevel 		= 0;

const float		sunPathRotation 		= -40.0f;

const int 		noiseTextureResolution  = 64;

const float 	ambientOcclusionLevel 	= 0.06f;


const bool colortex7Clear = false;

const float wetnessHalflife = 100.0;
const float drynessHalflife = 100.0;




in vec4 texcoord;

in vec3 lightVector;
in vec3 worldLightVector;
in vec3 worldSunVector;

in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSkyUp;
in vec3 colorTorchlight;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;









#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/Materials.inc"



/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// vec4 GetViewPosition(in vec2 coord, in float depth) 
// {	
// 	vec2 tcoord = coord;
// 	TemporalJitterProjPosInv01(tcoord);

// 	vec4 fragposition = gbufferProjectionInverse * vec4(tcoord.s * 2.0f - 1.0f, tcoord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
// 		 fragposition /= fragposition.w;

	
// 	return fragposition;
// }




/////////////////////////STRUCTS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////STRUCTS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#include "lib/GBufferData.inc"




struct Plane {
	vec3 normal;
	vec3 origin;
};

struct Intersection {
	vec3 pos;
	float distance;
	float angle;
};

/////////////////////////STRUCT FUNCTIONS//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////STRUCT FUNCTIONS//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





Intersection 	RayPlaneIntersectionWorld(in Ray ray, in Plane plane)
{
	float rayPlaneAngle = dot(ray.direction, plane.normal);

	float planeRayDist = 100000000.0f;
	vec3 intersectionPos = ray.direction * planeRayDist;

	if (rayPlaneAngle > 0.0001f || rayPlaneAngle < -0.0001f)
	{
		planeRayDist = dot((plane.origin), plane.normal) / rayPlaneAngle;
		intersectionPos = ray.direction * planeRayDist;
		intersectionPos = -intersectionPos;

		intersectionPos += cameraPosition.xyz;
	}

	Intersection i;

	i.pos = intersectionPos;
	i.distance = planeRayDist;
	i.angle = rayPlaneAngle;

	return i;
}

Intersection 	RayPlaneIntersection(in Ray ray, in Plane plane)
{
	float rayPlaneAngle = dot(ray.direction, plane.normal);

	float planeRayDist = 100000000.0f;
	vec3 intersectionPos = ray.direction * planeRayDist;

	if (rayPlaneAngle > 0.0001f || rayPlaneAngle < -0.0001f)
	{
		planeRayDist = dot((plane.origin - ray.origin), plane.normal) / rayPlaneAngle;
		intersectionPos = ray.origin + ray.direction * planeRayDist;
		// intersectionPos = -intersectionPos;

		// intersectionPos += cameraPosition.xyz;
	}

	Intersection i;

	i.pos = intersectionPos;
	i.distance = planeRayDist;
	i.angle = rayPlaneAngle;

	return i;
}






vec3 WorldPosToShadowProjPosBias(vec3 worldPos, vec3 worldNormal, out float dist, out float distortFactor)
{
	vec3 sn = normalize((shadowModelView * vec4(worldNormal.xyz, 0.0)).xyz) * vec3(1, 1, -1);

	vec4 sp = (shadowModelView * vec4(worldPos, 1.0));
	sp = shadowProjection * sp;
	sp /= sp.w;

	dist = sqrt(sp.x * sp.x + sp.y * sp.y);
	distortFactor = (1.0f - SHADOW_MAP_BIAS) + dist * SHADOW_MAP_BIAS;

	sp.xyz += sn * 0.002 * distortFactor;
	sp.xy *= 0.95f / distortFactor;
	sp.z = mix(sp.z, 0.5, 0.8);
	sp = sp * 0.5f + 0.5f;		//Transform from shadow space to shadow map coordinates


	//move to quadrant
	sp.xy *= 0.5;
	sp.xy += 0.5;

	return sp.xyz;
}

vec3 CalculateSunlightVisibility(vec4 screenSpacePosition, MaterialMask nqlOapzPzv, vec3 worldGeoNormal) {				//Calculates shadows
	if (rainStrength >= 0.99f)
		return vec3(1.0f);



	//if (shadingStruct.directionect > 0.0f) {
		float distance = sqrt(  screenSpacePosition.x * screenSpacePosition.x 	//Get surface distance in meters
							  + screenSpacePosition.y * screenSpacePosition.y
							  + screenSpacePosition.z * screenSpacePosition.z);

		vec4 ssp = screenSpacePosition;

		// if (isEyeInWater > 0.5)
		// {
		// 	ssp.xy *= 0.82;
		// }

		vec3 worldPos = (gbufferModelViewInverse * ssp).xyz;

		// worldPos += worldGeoNormal * 0.04;

		if (nqlOapzPzv.grass > 0.5)
		{
			worldGeoNormal.xyz = vec3(0, 1, 0);
		}


		float dist;
		float distortFactor;
		vec3 shadowProjPos = WorldPosToShadowProjPosBias(worldPos.xyz, worldGeoNormal, dist, distortFactor);

		// float fademult = 0.15f;
			// shadowMult = clamp((shadowDistance * 1.4f * fademult) - (distance * fademult), 0.0f, 1.0f);	//Calculate shadowMult to fade shadows out

		float shadowMult = 1.0;

		float shading = 0.0;
		vec3 result = vec3(0.0);

		if (shadowMult > 0.0) 
		{

			float diffthresh = dist * 1.0f + 0.10f;
				  diffthresh *= 2.0f / (shadowMapResolution / 2048.0f);
			// diffthresh = 0.0;
				  //diffthresh /= shadingStruct.directionect + 0.1f;


			// shadowProjPos.xyz += shadowNormal * 0.0004 * (dist + 0.5);




			float vpsSpread = 0.105 / distortFactor;

			float avgDepth = 0.0;
			float minDepth = 11.0;
			int c;

			for (int i = -1; i <= 1; i++)
			{
				for (int j = -1; j <= 1; j++)
				{
					vec2 lookupCoord = shadowProjPos.xy + (vec2(i, j) / shadowMapResolution) * 8.0 * vpsSpread;
					//avgDepth += pow(texture2DLod(shadowtex1, lookupCoord, 2).x, 4.1);
					float depthSample = texture2DLod(shadowtex1, lookupCoord, 2).x;
					minDepth = min(minDepth, depthSample);
					avgDepth += pow(min(max(0.0, shadowProjPos.z - depthSample) * 1.0, 0.025), 2.0);
					c++;
				}
			}

			avgDepth /= c;
			avgDepth = pow(avgDepth, 1.0 / 2.0);

			// float penumbraSize = min(abs(shadowProjPos.z - minDepth), 0.15);
			float penumbraSize = avgDepth;

			//if (nqlOapzPzv.leaves > 0.5)
			//{
				//penumbraSize = 0.02;
			//}

			int count = 0;
			float spread = penumbraSize * 0.055 * vpsSpread + 0.55 / shadowMapResolution;


			vec3 noise = BlueNoiseTemporal(texcoord.st);

			diffthresh *= 0.5 + avgDepth * 50.0;





















			const int latSamples = 5;
			const int lonSamples = 5;

			// shadowProjPos.xyz += shadowNormal * diffthresh * 0.001;
			// shadowProjPos.xyz += shadowNormal * diffthresh * 0.001;

			for (int i = 0; i < 25; i++)
			{
				float fi = float(i + noise.x) / 10.0;
				float r = float(i + noise.x) * 3.14159265 * 2.0 * 1.61;

				vec2 radialPos = vec2(cos(r), sin(r));
				vec2 coordOffset = radialPos * spread * sqrt(fi) * 2.0;

				// shading += shadow2DLod(shadowtex0, vec3(shadowProjPos.st + coordOffset, shadowProjPos.z - 0.0012f * diffthresh - (noise.z * 0.00005)), 0).x;
				shading += shadow2DLod(shadowtex0, vec3(shadowProjPos.st + coordOffset, shadowProjPos.z - 0.0012 * dist - (noise.z * 0.00005)), 0).x;
				count += 1;
			}
			shading /= count;




			result = vec3(shading);


			// stained glass shadow
			{
				float stainedGlassShadow = shadow2DLod(shadowtex0, vec3(shadowProjPos.st - vec2(0.5, 0.0), shadowProjPos.z - 0.0012 * diffthresh), 2).x;
				vec3 stainedGlassColor = texture2DLod(shadowcolor, vec2(shadowProjPos.st - vec2(0.5, 0.0)), 2).rgb;
				stainedGlassColor *= stainedGlassColor;
				result = mix(result, result * stainedGlassColor, vec3(1.0 - stainedGlassShadow));

				// result = mix(result, vec3(0.0), vec3(1.0 - stainedGlassShadow));
			}

			// CAUSTICS
			// water shadow (caustics)
			{
				// float waterDepth = abs(texture2DLod(shadowcolor1, shadowProjPos.st - vec2(0.0, 0.5), 4).x * 256.0 - (worldPos.y + cameraPosition.y));
				float waterDepth = abs(texture2DLod(shadowcolor1, shadowProjPos.st - vec2(0.0, 0.5), 3).x * 256.0 - (worldPos.y + cameraPosition.y));

				// float caustics = GetCausticsDeferred(worldPos, waterDepth);
				vec3 caustics = vec3(0.0);
				caustics.r = GetCausticsDeferred(worldPos, 										worldLightVector, waterDepth);
				// caustics.g = GetCausticsDeferred(worldPos + vec3(0.003 * waterDepth, 0.0, 0.0), worldLightVector, waterDepth);
				// caustics.b = GetCausticsDeferred(worldPos + vec3(0.006 * waterDepth, 0.0, 0.0), worldLightVector, waterDepth);
				caustics.g = caustics.r;
				caustics.b = caustics.r;

				float waterShadow = shadow2DLod(shadowtex0, vec3(shadowProjPos.st - vec2(0.0, 0.5), shadowProjPos.z - 0.0012 * diffthresh - noise.z * 0.0001), 3).x;
				result = mix(result, 
					// result * caustics * exp(-GetWaterAbsorption() * waterDepth), 
					result * caustics, 
					vec3(1.0 - waterShadow));
			}
		}



		result = mix(vec3(1.0), result, shadowMult);





		return result;
	//} else {
	//	return vec3(0.0f);
	//}
}


vec3 SubsurfaceScatteringSunlight(vec3 worldNormal, vec3 worldPos, vec3 albedo)
{
	vec4 shadowProjPos = shadowModelView * vec4(worldPos.xyz, 1.0);	//Transform from world space to shadow space
	shadowProjPos = shadowProjection * shadowProjPos;
	shadowProjPos /= shadowProjPos.w;

	float dist = sqrt(shadowProjPos.x * shadowProjPos.x + shadowProjPos.y * shadowProjPos.y);
	float distortFactor = (1.0f - SHADOW_MAP_BIAS) + dist * SHADOW_MAP_BIAS;
	shadowProjPos.xy *= 0.95f / distortFactor;
	shadowProjPos.z = mix(shadowProjPos.z, 0.5, 0.8);
	shadowProjPos = shadowProjPos * 0.5f + 0.5f;		//Transform from shadow space to shadow map coordinates

	//move to quadrant
	shadowProjPos.xy *= 0.5;
	shadowProjPos.xy += 0.5;

	float subsurfaceDepth = 0.0;
	float depthThresh = 0.0005;
	float weights = 0.0;

	vec2 dither = BlueNoiseTemporal(texcoord.st).xy - 0.5;

	for (int i = -1; i <= 1; i++)
	{
		for (int j = -1; j <= 1; j++)
		{
			vec2 coordOffset = vec2(i + dither.x, j + dither.y) * 0.001;
			subsurfaceDepth += max(0.0, (shadowProjPos.z - texture2DLod(shadowtex1, shadowProjPos.xy + coordOffset, 0).x) / depthThresh);
			weights += 1.0;
		}
	}

	subsurfaceDepth /= weights;

	// subsurfaceDepth = exp(-subsurfaceDepth * 10.0);

	vec3 subsurfaceColor = 1.0 - (normalize(albedo.rgb + 0.000001) * 0.3);
	// vec3 subsurfaceColor = 1.0 - (albedo.rgb * 0.5);
	// vec3 subsurfaceColor = 1.0 - (albedo.rgb * 0.8);
	// vec3 subsurfaceColor = 1.0 - vec3(0.7, 0.5, 0.1);
	vec3 sss = exp(-subsurfaceDepth * subsurfaceColor * 6.0) * (1.0 - subsurfaceColor);

	return sss * 24.0 * colorSunlight;
}


float ScreenSpaceShadow(vec3 origin, vec3 normal, MaterialMask nqlOapzPzv)
{
	if (nqlOapzPzv.sky > 0.5 || rainStrength >= 0.999)
	{
		return 1.0;
	}

	if (isEyeInWater > 0.5)
	{
		origin.xy /= 0.82;
	}

	vec3 viewDir = normalize(origin.xyz);


	float nearCutoff = 0.50;
	float traceBias = 0.015;


	//Prevent self-intersection issues
	float viewDirDiff = dot(fwidth(viewDir), vec3(0.333333));


	vec3 rayPos = origin;
	vec3 rayDir = lightVector * 0.01;
	rayDir *= viewDirDiff * 2000.001;
	rayDir *= -origin.z * 0.28 + nearCutoff;


	rayPos += rayDir * -origin.z * 0.000017 * traceBias;



	float randomness = rand(texcoord.st + sin(frameTimeCounter)).x;

	rayPos += rayDir * randomness;



	float zThickness = 0.025 * -origin.z;

	float shadow = 1.0;

	float numSamplesf = 64.0;
	//numSamplesf /= -origin.z * 0.125 + nearCutoff;

	int numSamples = int(numSamplesf);


	float shadowStrength = 0.9;

	if (nqlOapzPzv.grass > 0.5)
	{
		shadowStrength = 0.6;
		zThickness *= 2.0;
	}
	if (nqlOapzPzv.leaves > 0.5)
	{
		shadowStrength = 0.4;
	}

	// shadowStrength = pow(shadowStrength, exp2(-length(origin) * 0.05));

	// vec3 prevRayProjPos = ProjectBack(rayPos);

	for (int i = 0; i < 6; i++)
	{
		float fi = float(i) / float(12);

		rayPos += rayDir;

		vec2 rayProjPos = ProjectBack(rayPos).xy;


		TemporalJitterProjPos01(rayProjPos);




		// vec2 pixelPos = floor(rayProjPos.xy * vec2(viewWidth, viewHeight));
		// vec2 pixelPosPrev = floor(prevRayProjPos.xy * vec2(viewWidth, viewHeight));
		// if (pixelPos.x == pixelPosPrev.x || pixelPos.y == pixelPosPrev.y)
		// {
		// 	continue;
		// }

		// prevRayProjPos = rayProjPos;

		/*
		float sampleDepth = GetDepthLinear(rayProjPos.xy);

		float depthDiff = -rayPos.z - sampleDepth;
		*/

		vec3 samplePos = GetViewPositionNoJitter(rayProjPos.xy, GetDepth(rayProjPos.xy)).xyz;

		float depthDiff = samplePos.z - rayPos.z - 0.02 * -origin.z * traceBias;

		if (depthDiff > 0.0 && depthDiff < zThickness)
		{
			shadow *= 1.0 - shadowStrength;
		}
	}

	return shadow;
}


float OrenNayar(vec3 normal, vec3 eyeDir, vec3 lightDir)
{
	const float PI = 3.14159;
	const float roughness = 0.55;

	// interpolating normals will change the length of the normal, so renormalize the normal.



	// normal = normalize(normal + surface.lightVector * pow(clamp(dot(eyeDir, surface.lightVector), 0.0, 1.0), 5.0) * 0.5);

	// normal = normalize(normal + eyeDir * clamp(dot(normal, eyeDir), 0.0f, 1.0f));

	// calculate intermediary values
	float NdotL = dot(normal, lightDir);
	float NdotV = dot(normal, eyeDir);

	float angleVN = acos(NdotV);
	float angleLN = acos(NdotL);

	float alpha = max(angleVN, angleLN);
	float beta = min(angleVN, angleLN);
	float gamma = dot(eyeDir - normal * dot(eyeDir, normal), lightDir - normal * dot(lightDir, normal));

	float roughnessSquared = roughness * roughness;

	// calculate A and B
	float A = 1.0 - 0.5 * (roughnessSquared / (roughnessSquared + 0.57));

	float B = 0.45 * (roughnessSquared / (roughnessSquared + 0.09));

	float C = sin(alpha) * tan(beta);

	// put it all together
	float L1 = max(0.0, NdotL) * (A + B * max(0.0, gamma) * C);

	//return max(0.0f, surface.NdotL * 0.99f + 0.01f);
	return clamp(L1, 0.0f, 1.0f);
}





float GetCoverage(in float coverage, in float density, in float clouds)
{
	clouds = clamp(clouds - (1.0f - coverage), 0.0f, 1.0f -density) / (1.0f - density);
		clouds = max(0.0f, clouds * 1.1f - 0.1f);
	 clouds = clouds = clouds * clouds * (3.0f - 2.0f * clouds);
	 // clouds = pow(clouds, 1.0f);
	return clouds;
}

float   CalculateSunglow(vec3 npos, vec3 lightVector) {

	float curve = 4.0f;

	vec3 halfVector2 = normalize(-lightVector + npos);
	float factor = 1.0f - dot(halfVector2, npos);

	return factor * factor * factor * factor;
}

vec4 CloudColor(in vec4 worldPosition, in float sunglow, in vec3 worldLightVector, in float altitude, in float thickness, const bool isShadowPass)
{

	float cloudHeight = altitude;
	float cloudDepth  = thickness;
	float cloudUpperHeight = cloudHeight + (cloudDepth / 2.0f);
	float cloudLowerHeight = cloudHeight - (cloudDepth / 2.0f);

	//worldPosition.xz /= 1.0f + max(0.0f, length(worldPosition.xz - cameraPosition.xz) / 5000.0f);

	vec3 p = worldPosition.xyz / 150.0f;



	float t = frameTimeCounter * 1.0f;
		  t *= 0.5;


	 p += (Get3DNoise(p * 2.0f + vec3(0.0f, t * 0.00f, 0.0f)) * 2.0f - 1.0f) * 0.10f;
	 p.z -= (Get3DNoise(p * 0.25f + vec3(0.0f, t * 0.00f, 0.0f)) * 2.0f - 1.0f) * 0.45f;
	 p.x -= (Get3DNoise(p * 0.125f + vec3(0.0f, t * 0.00f, 0.0f)) * 2.0f - 1.0f) * 2.2f;
	p.xz -= (Get3DNoise(p * 0.0525f + vec3(0.0f, t * 0.00f, 0.0f)) * 2.0f - 1.0f) * 2.7f;


	p.x *= 0.5f;
	p.x -= t * 0.01f;

	vec3 p1 = p * vec3(1.0f, 0.5f, 1.0f)  + vec3(0.0f, t * 0.01f, 0.0f);
	float noise  = 	Get3DNoise(p * vec3(1.0f, 0.5f, 1.0f) + vec3(0.0f, t * 0.01f, 0.0f));	p *= 2.0f;	p.x -= t * 0.057f;	vec3 p2 = p;
		  noise += (2.0f - abs(Get3DNoise(p) * 2.0f - 0.0f)) * (0.15f);						p *= 3.0f;	p.xz -= t * 0.035f;	p.x *= 2.0f;	vec3 p3 = p;
		  noise += (3.0f - abs(Get3DNoise(p) * 3.0f - 0.0f)) * (0.050f);						p *= 3.0f;	p.xz -= t * 0.035f;	vec3 p4 = p;
		  noise += (3.0f - abs(Get3DNoise(p) * 3.0f - 0.0f)) * (0.015f);						p *= 3.0f;	p.xz -= t * 0.035f;
		  if (!isShadowPass)
		  {
		 		noise += ((Get3DNoise(p))) * (0.022f);												p *= 3.0f;
		  		noise += ((Get3DNoise(p))) * (0.009f);
		  }
		  noise /= 1.475f;

	//cloud edge
	float coverage = 0.701f;
		  coverage = mix(coverage, 0.97f, rainStrength);

		  float dist = length(worldPosition.xz - cameraPosition.xz * 0.5);
		  coverage *= max(0.0f, 1.0f - dist / 14000.0f);
	float density = 0.1f + rainStrength * 0.3;

	if (isShadowPass)
	{
		return vec4(GetCoverage(0.4f, 0.4f, noise));
	}

	noise = GetCoverage(coverage, density, noise);

	const float lightOffset = 0.4f;



	float sundiff = Get3DNoise(p1 + worldLightVector.xyz * lightOffset);
		  sundiff += (2.0f - abs(Get3DNoise(p2 + worldLightVector.xyz * lightOffset / 2.0f) * 2.0f - 0.0f)) * (0.55f);
		  				float largeSundiff = sundiff;
		  				      largeSundiff = -GetCoverage(coverage, 0.0f, largeSundiff * 1.3f);
		  sundiff += (3.0f - abs(Get3DNoise(p3 + worldLightVector.xyz * lightOffset / 5.0f) * 3.0f - 0.0f)) * (0.045f);
		  sundiff += (3.0f - abs(Get3DNoise(p4 + worldLightVector.xyz * lightOffset / 8.0f) * 3.0f - 0.0f)) * (0.015f);
		  sundiff /= 1.5f;

		  sundiff *= max(0.0f, 1.0f - dist / 14000.0f);

		  sundiff = -GetCoverage(coverage * 1.0f, 0.0f, sundiff);
	float secondOrder 	= pow(clamp(sundiff * 1.1f + 1.45f, 0.0f, 1.0f), 4.0f);
	float firstOrder 	= pow(clamp(largeSundiff * 1.1f + 1.66f, 0.0f, 1.0f), 3.0f);



	float directLightFalloff = firstOrder * secondOrder;
	float anisoBackFactor = mix(clamp(pow(noise, 1.6f) * 2.5f, 0.0f, 1.0f), 1.0f, pow(sunglow, 1.0f));

		  directLightFalloff *= anisoBackFactor;
	 	  directLightFalloff *= mix(11.5f, 1.0f, pow(sunglow, 0.5f));

	//noise *= saturate(1.0 - directLightFalloff);

	vec3 colorDirect = colorSunlight * 51.215f;
		 colorDirect = mix(colorDirect, colorDirect * vec3(0.2f, 0.2f, 0.2f), timeMidnight);
		 colorDirect *= 1.0f + pow(sunglow, 2.0f) * 120.0f * pow(directLightFalloff, 1.1f) * (1.0 - rainStrength * 0.8);
		 colorDirect *= 1.0f;


	vec3 colorAmbient = mix(colorSkylight, colorSunlight * 2.0f, vec3(0.15f)) * 0.93f;
		 colorAmbient = mix(colorAmbient, vec3(0.4) * Luminance(colorSkylight), vec3(rainStrength));
		 colorAmbient *= mix(1.0f, 0.3f, timeMidnight);
		 colorAmbient = mix(colorAmbient, colorAmbient * 3.0f + colorSunlight * 0.05f, vec3(clamp(pow(1.0f - noise, 12.0f) * 1.0f, 0.0f, 1.0f)));




	directLightFalloff *= mix(1.0, 0.085, rainStrength);

	//directLightFalloff += (pow(Get3DNoise(p3), 2.0f) * 0.5f + pow(Get3DNoise(p3 * 1.5f), 2.0f) * 0.25f) * 0.02f;
	//directLightFalloff *= Get3DNoise(p2);

	vec3 color = mix(colorAmbient, colorDirect, vec3(min(1.0f, directLightFalloff)));

	color *= 1.0f;

	color = mix(color, color * 0.9, rainStrength);


	vec4 result = vec4(color.rgb, noise);

	return result;

}

void CloudPlane(inout vec3 color, vec3 viewDir, vec3 worldVector, float linearDepth, MaterialMask nqlOapzPzv, vec3 worldLightVector, vec3 lightVector)
{
	//Initialize view ray
	//vec4 worldVector = gbufferModelViewInverse * (vec4(-GetScreenSpacePosition(texcoord.st).xyz, 0.0));


	// Ray viewRay;

	// viewRay.direction = normalize(worldVector.xyz);
	// viewRay.origin = vec3(0.0f);
	Ray viewRay = MakeRay
	(
		vec3(0.0),
		normalize(worldVector.xyz)
	);

	float sunglow = CalculateSunglow(viewDir, lightVector);



	float cloudsAltitude = 540.0f;
	float cloudsThickness = 150.0f;

	float cloudsUpperLimit = cloudsAltitude + cloudsThickness * 0.5f;
	float cloudsLowerLimit = cloudsAltitude - cloudsThickness * 0.5f;

	float density = 1.0f;

	float planeHeight = cloudsUpperLimit;
	float stepSize = 25.5f;
	planeHeight -= cloudsThickness * 0.85f;


	Plane pl;
	pl.origin = vec3(0.0f, cameraPosition.y - planeHeight, 0.0f);
	pl.normal = vec3(0.0f, 1.0f, 0.0f);

	Intersection i = RayPlaneIntersectionWorld(viewRay, pl);

	vec3 original = color.rgb;

	if (i.angle < 0.0f)
	{
		if (i.distance < linearDepth || nqlOapzPzv.sky > 0.5 || linearDepth >= far - 0.1)
		{
			vec4 cloudSample = CloudColor(vec4(i.pos.xyz * 0.5f + vec3(30.0f) + vec3(1000.0, 0.0, 0.0), 1.0f), sunglow, worldLightVector, cloudsAltitude, cloudsThickness, false);
			 	 cloudSample.a = min(1.0f, cloudSample.a * density);


			float cloudDist = length(i.pos.xyz - cameraPosition.xyz);

			const vec3 absorption = vec3(0.2, 0.4, 1.0);

			cloudSample.rgb *= exp(-cloudDist * absorption * 0.0001 * saturate(1.0 - sunglow * 2.0) * (1.0 - rainStrength));

			cloudSample.a *= exp(-cloudDist * (0.0002 + rainStrength * 0.0009));


			//cloudSample.rgb *= sin(cloudDist * 0.3) * 0.5 + 0.5;

			color.rgb = mix(color.rgb, cloudSample.rgb * 1.0f, cloudSample.a);

		}
	}
}


float G1V(float dotNV, float k)
{
	return 1.0 / (dotNV * (1.0 - k) + k);
}

vec3 SpecularGGX(vec3 N, vec3 V, vec3 L, float roughness, float F0)
{
	float alpha = roughness * roughness;

	vec3 H = normalize(V + L);

	float dotNL = saturate(dot(N, L));
	float dotNV = saturate(dot(N, V));
	float dotNH = saturate(dot(N, H));
	float dotLH = saturate(dot(L, H));

	float F, D, vis;

	float alphaSqr = alpha * alpha;
	float pi = 3.14159265359;
	float denom = dotNH * dotNH * (alphaSqr - 1.0) + 1.0;
	D = alphaSqr / (pi * denom * denom);

	float dotLH5 = pow(1.0f - dotLH, 5.0);
	F = F0 + (1.0 - F0) * dotLH5;

	float k = alpha / 2.0;
	vis = G1V(dotNL, k) * G1V(dotNV, k);

	vec3 specular = vec3(dotNL * D * F * vis) * colorSunlight;

	//specular = vec3(0.1);
	#ifndef PHYSICALLY_BASED_MAX_ROUGHNESS
	specular *= saturate(pow(1.0 - roughness, 0.7) * 2.0);
	#endif


	return specular;
}




 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int n(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int f()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int n()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return n(f(floor(pow(float(x),.333333))));
 }
 vec3 d(vec2 v)
 {
   ivec2 s=ivec2(viewWidth,viewHeight);
   int x=s.x*s.y,z=f();
   ivec2 n=ivec2(v.x*s.x,v.y*s.y);
   float y=float(n.y/z),i=float(int(n.x+mod(s.x*y,z))/z);
   i+=floor(s.x*y/z);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(n.x+mod(s.x*y,z),z);
   m.y=mod(n.y,z);
   m.xyz=floor(m.xyz);
   m/=z;
   m.xyz=m.xzy;
   return m;
 }
 vec2 v(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=f();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float z=i.z;
   vec2 n;
   n.x=mod(i.x+z*x,m.x);
   float s=i.x+z*x;
   n.y=i.y+floor(s/m.x)*x;
   n+=.5;
   n/=m;
   return n;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 s=ivec2(2048,2048);
   int x=s.x*s.y,z=n();
   ivec2 f=ivec2(i.x*s.x,i.y*s.y);
   float y=float(f.y/z),r=float(int(f.x+mod(s.x*y,z))/z);
   r+=floor(s.x*y/z);
   vec3 m=vec3(0.,0.,r);
   m.x=mod(f.x+mod(s.x*y,z),z);
   m.y=mod(f.y,z);
   m.xyz=floor(m.xyz);
   m/=z;
   m.xyz=m.xzy;
   return m;
 }
 vec2 d(vec3 v,int z)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 i=v.xzy*z;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 n;
   n.x=mod(i.x+x*z,m.x);
   float f=i.x+x*z;
   n.y=i.y+floor(f/m.x)*z;
   n+=.5;
   n/=m;
   n.xy*=.5;
   return n;
 }
 vec3 f(vec3 v,int z)
 {
   return v*=1./z,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int z)
 {
   return v*=1./z,v=v+vec3(.5),v;
 }
 vec3 m(vec3 v)
 {
   int m=n();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=f();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 x(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,x=floor(v-.0001),z=floor(i-.0001);
   return x-z;
 }
 vec3 e(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),z=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/z;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 i,vec2 s,vec2 n,vec4 f,vec4 m,inout float x,out vec2 z)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(m.x==8||m.x==9||m.x==79||m.x<1.||!r||m.x==20.||m.x==171.||min(abs(i.x),abs(i.z))>.2)
     x=1.;
   if(m.x==50.||m.x==76.)
     {
       x=0.;
       if(i.y<.5)
         x=1.;
     }
   if(m.x==51)
     x=0.;
   if(m.x>255)
     x=0.;
   vec3 y,c;
   if(i.x>.5)
     y=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(i.x<-.5)
       y=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(i.y>.5)
         y=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(i.y<-.5)
           y=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(i.z>.5)
             y=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(i.z<-.5)
               y=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   z=clamp((s.xy-n.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,w=.15;
   if(m.x==10.||m.x==11.)
     {
       if(abs(i.y)<.01&&r||i.y>.99)
         h=.1,w=.1,x=0.;
       else
          x=1.;
     }
   if(m.x==51)
     h=.5,w=.1;
   if(m.x==76)
     h=.2,w=.2;
   if(m.x-255.+39.>=103.&&m.x-255.+39.<=113.)
     w=.025,h=.025;
   y=normalize(f.xyz);
   c=normalize(cross(y,i.xyz)*sign(f.w));
   vec3 o=v.xyz+mix(y*h,-y*h,vec3(z.x));
   o.xyz+=mix(c*h,-c*h,vec3(z.y));
   o.xyz-=i.xyz*w;
   return o;
 }struct ChqUiAvDkU{vec3 vSNsAVOjDa;vec3 vSNsAVOjDaOrigin;vec3 UgsYTfdINL;vec3 LkVOyZfKEL;vec3 ZPrwqHNnFV;vec3 nqlOapzPzv;};
 ChqUiAvDkU p(Ray v)
 {
   ChqUiAvDkU i;
   i.vSNsAVOjDa=floor(v.origin);
   i.vSNsAVOjDaOrigin=i.vSNsAVOjDa;
   i.UgsYTfdINL=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.LkVOyZfKEL=sign(v.direction);
   i.ZPrwqHNnFV=(sign(v.direction)*(i.vSNsAVOjDa-v.origin)+sign(v.direction)*.5+.5)*i.UgsYTfdINL;
   i.nqlOapzPzv=vec3(0.);
   return i;
 }
 void h(inout ChqUiAvDkU v)
 {
   v.nqlOapzPzv=step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.yzx)*step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.zxy),v.ZPrwqHNnFV+=v.nqlOapzPzv*v.UgsYTfdINL,v.vSNsAVOjDa+=v.nqlOapzPzv*v.LkVOyZfKEL;
 }
 void d(in Ray v,in vec3 i[2],out float f,out float z)
 {
   float x,y,r,n;
   f=(i[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   z=(i[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(i[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   y=(i[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(i[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   n=(i[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   f=max(max(f,x),r);
   z=min(min(z,y),n);
 }
 vec3 d(const vec3 v,const vec3 i,vec3 z)
 {
   const float x=1e-05;
   vec3 y=(i+v)*.5,m=(i-v)*.5,s=z-y,f=vec3(0.);
   f+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-m.x),x);
   f+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-m.y),x);
   f+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-m.z),x);
   return normalize(f);
 }
 bool e(const vec3 v,const vec3 i,Ray m,out vec2 n)
 {
   vec3 z=m.inv_direction*(v-m.origin),x=m.inv_direction*(i-m.origin),s=min(x,z),f=max(x,z);
   vec2 r=max(s.xx,s.yz);
   float y=max(r.x,r.y);
   r=min(f.xx,f.yz);
   float c=min(r.x,r.y);
   n.x=y;
   n.y=c;
   return c>max(y,0.);
 }
 bool d(const vec3 v,const vec3 i,Ray m,inout float x,inout vec3 z)
 {
   vec3 y=m.inv_direction*(v-m.origin),s=m.inv_direction*(i-m.origin),f=min(s,y),n=max(s,y);
   vec2 r=max(f.xx,f.yz);
   float c=max(r.x,r.y);
   r=min(n.xx,n.yz);
   float h=min(r.x,r.y);
   bool t=h>max(c,0.)&&max(c,0.)<x;
   if(t)
     z=d(v,i,m.origin+m.direction*c),x=c;
   return t;
 }
 vec3 e(vec3 v,vec3 i,vec3 z,vec3 x,int n)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 m=e(v);
   float y=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z-.0006*y),0).x;
   f*=saturate(dot(i,z));
   {
     vec4 s=texture2DLod(shadowcolor1,m.xy-vec2(0.,.5),4);
     float r=abs(s.x*256.-(v.y+cameraPosition.y)),c=GetCausticsComposite(v,i,r),w=shadow2DLod(shadowtex0,vec3(m.xy-vec2(0.,.5),m.z+1e-06),4).x;
     f=mix(f,f*c,1.-w);
   }
   f=TintUnderwaterDepth(f);
   return f*(1.-rainStrength);
 }
 vec3 f(vec3 v,vec3 i,vec3 z,vec3 x,int n)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 f=m(v),s=e(f+z*.99);
   float y=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*y),3).x;
   r*=saturate(dot(i,z));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float h=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*y),3).x;
   vec3 c=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   c*=c;
   r=mix(r,r*c,vec3(1.-h));
   #endif
   return r*(1.-rainStrength);
 }
 vec3 h(vec3 v,vec3 i,vec3 z,vec3 x,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 m=e(v);
   float n=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z-.0006*n),2).x;
   f*=saturate(dot(i,z));
   f=TintUnderwaterDepth(f);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float r=shadow2DLod(shadowtex0,vec3(m.xy-vec2(.5,0.),m.z-.0006*n),3).x;
   vec3 s=texture2DLod(shadowcolor,vec2(m.xy-vec2(.5,0.)),3).xyz;
   s*=s;
   f=mix(f,f*s,vec3(1.-r));
   #endif
   return f*(1.-rainStrength);
 }struct SgvRpoZFEp{float hBzGxfOWHl;float rPdSyvYhOi;float AqljTTtzgc;float IiJpNLRFqV;vec3 AChndccCtU;};
 vec4 w(SgvRpoZFEp v)
 {
   vec4 i;
   v.AChndccCtU=max(vec3(0.),v.AChndccCtU);
   i.x=v.hBzGxfOWHl;
   v.AChndccCtU=pow(v.AChndccCtU,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.AChndccCtU.x,v.AqljTTtzgc);
   i.z=PackTwo16BitTo32Bit(v.AChndccCtU.y,v.IiJpNLRFqV);
   i.w=PackTwo16BitTo32Bit(v.AChndccCtU.z,v.rPdSyvYhOi);
   return i;
 }
 SgvRpoZFEp i(vec4 v)
 {
   SgvRpoZFEp i;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),s=UnpackTwo16BitFrom32Bit(v.z),f=UnpackTwo16BitFrom32Bit(v.w);
   i.hBzGxfOWHl=v.x;
   i.AqljTTtzgc=m.y;
   i.IiJpNLRFqV=s.y;
   i.rPdSyvYhOi=f.y;
   i.AChndccCtU=pow(vec3(m.x,s.x,f.x),vec3(8.));
   return i;
 }
 SgvRpoZFEp c(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),z=vec2(viewWidth,viewHeight);
   v=(floor(v*z)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float c(float v,float z)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+z,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool c(vec3 v,float z,Ray i,bool x,inout float f,inout vec3 n)
 {
   bool m=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(x)
     return false;
   if(z>=67.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),i,f,n);
   m=r;
   #else
   if(z<40.)
     return r=d(v,v+vec3(1.,1.,1.),i,f,n),r;
   if(z==40.||z==41.||z>=43.&&z<=54.)
     {
       float y=.5;
       if(z==41.)
         y=.9375;
       r=d(v+vec3(0.,0.,0.),v+vec3(1.,y,1.),i,f,n);
       m=m||r;
     }
   if(z==42.||z>=55.&&z<=66.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,f,n),m=m||r;
   if(z==43.||z==46.||z==47.||z==52.||z==53.||z==54.||z==55.||z==58.||z==59.||z==64.||z==65.||z==66.)
     {
       float y=.5;
       if(z==55.||z==58.||z==59.||z==64.||z==65.||z==66.)
         y=0.;
       r=d(v+vec3(0.,y,0.),v+vec3(.5,.5+y,.5),i,f,n);
       m=m||r;
     }
   if(z==43.||z==45.||z==48.||z==51.||z==53.||z==54.||z==55.||z==57.||z==60.||z==63.||z==65.||z==66.)
     {
       float y=.5;
       if(z==55.||z==57.||z==60.||z==63.||z==65.||z==66.)
         y=0.;
       r=d(v+vec3(.5,y,0.),v+vec3(1.,.5+y,.5),i,f,n);
       m=m||r;
     }
   if(z==44.||z==45.||z==49.||z==51.||z==52.||z==54.||z==56.||z==57.||z==61.||z==63.||z==64.||z==66.)
     {
       float y=.5;
       if(z==56.||z==57.||z==61.||z==63.||z==64.||z==66.)
         y=0.;
       r=d(v+vec3(.5,y,.5),v+vec3(1.,.5+y,1.),i,f,n);
       m=m||r;
     }
   if(z==44.||z==46.||z==50.||z==51.||z==52.||z==53.||z==56.||z==58.||z==62.||z==63.||z==64.||z==65.)
     {
       float y=.5;
       if(z==56.||z==58.||z==62.||z==63.||z==64.||z==65.)
         y=0.;
       r=d(v+vec3(0.,y,.5),v+vec3(.5,.5+y,1.),i,f,n);
       m=m||r;
     }
   if(z>=67.&&z<=82.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,f,n),m=m||r;
   if(z==68.||z==69.||z==70.||z==72.||z==73.||z==74.||z==76.||z==77.||z==78.||z==80.||z==81.||z==82.)
     {
       float y=8.,s=8.;
       if(z==68.||z==70.||z==72.||z==74.||z==76.||z==78.||z==80.||z==82.)
         y=0.;
       if(z==69.||z==70.||z==73.||z==74.||z==77.||z==78.||z==81.||z==82.)
         s=16.;
       r=d(v+vec3(y,6.,7.)/16.,v+vec3(s,9.,9.)/16.,i,f,n);
       m=m||r;
       r=d(v+vec3(y,12.,7.)/16.,v+vec3(s,15.,9.)/16.,i,f,n);
       m=m||r;
     }
   if(z>=71.&&z<=82.)
     {
       float y=8.,s=8.;
       if(z>=71.&&z<=74.||z>=79.&&z<=82.)
         s=16.;
       if(z>=75.&&z<=82.)
         y=0.;
       r=d(v+vec3(7.,6.,y)/16.,v+vec3(9.,9.,s)/16.,i,f,n);
       m=m||r;
       r=d(v+vec3(7.,12.,y)/16.,v+vec3(9.,15.,s)/16.,i,f,n);
       m=m||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(z>=83.&&z<=86.)
     {
       vec3 y=vec3(0),s=vec3(0);
       if(z==83.)
         y=vec3(0,0,0),s=vec3(16,16,3);
       if(z==84.)
         y=vec3(0,0,13),s=vec3(16,16,16);
       if(z==86.)
         y=vec3(0,0,0),s=vec3(3,16,16);
       if(z==85.)
         y=vec3(13,0,0),s=vec3(16,16,16);
       r=d(v+y/16.,v+s/16.,i,f,n);
       m=m||r;
     }
   if(z>=87.&&z<=102.)
     {
       vec3 y=vec3(0.),s=vec3(1.);
       if(z>=87.&&z<=94.)
         {
           float c=0.;
           if(z>=91.&&z<=94.)
             c=13.;
           y=vec3(0.,c,0.)/16.;
           s=vec3(16.,c+3.,16.)/16.;
         }
       if(z>=95.&&z<=98.)
         {
           float c=13.;
           if(z==97.||z==98.)
             c=0.;
           y=vec3(0.,0.,c)/16.;
           s=vec3(16.,16.,c+3.)/16.;
         }
       if(z>=99.&&z<=102.)
         {
           float c=13.;
           if(z==99.||z==100.)
             c=0.;
           y=vec3(c,0.,0.)/16.;
           s=vec3(c+3.,16.,16.)/16.;
         }
       r=d(v+y,v+s,i,f,n);
       m=m||r;
     }
   if(z>=103.&&z<=113.)
     {
       vec3 y=vec3(0.),s=vec3(1.);
       if(z>=103.&&z<=110.)
         {
           float c=float(z)-float(103.)+1.;
           s.y=c*2./16.;
         }
       if(z==111.)
         s.y=.0625;
       if(z==112.)
         y=vec3(1.,0.,1.)/16.,s=vec3(15.,1.,15.)/16.;
       if(z==113.)
         y=vec3(1.,0.,1.)/16.,s=vec3(15.,.5,15.)/16.;
       r=d(v+y,v+s,i,f,n);
       m=m||r;
     }
   #endif
   #endif
   return m;
 }
 vec3 R(vec3 v)
 {
   float z=fract(frameCounter*.0123456);
   int y=n(),s=f();
   vec3 x=BlueNoiseTemporal(texcoord.xy).xyz,i=BlueNoiseTemporal(texcoord.xy+.1).xyz,r=v,m=Fract01(cameraPosition.xyz+.5)+vec3(0.,1.7,0.),c=m;
   m=f(m,y);
   Ray o=MakeRay(m*y-vec3(1.),r);
   vec3 h=vec3(1.),w=vec3(0.);
   for(int e=0;e<1;e++)
     {
       vec3 t=vec3(floor(o.origin)),L=abs(vec3(length(o.direction))/(o.direction+.0001)),Y=sign(o.direction),a=(sign(o.direction)*(t-o.origin)+sign(o.direction)*.5+.5)*L,U;
       vec4 p=vec4(0.);
       vec3 l=vec3(0.);
       float G=.5;
       for(int R=0;R<190;R++)
         {
           l=t/float(y);
           vec2 V=d(l,y);
           p=texture2DLod(shadowcolor,V,0);
           if(abs(p.w*255.-130.)<.5)
             w+=.06125*h*colorTorchlight*G;
           else
             {
               if(p.w*255.<254.f&&R!=0)
                 {
                   break;
                 }
             }
           U=step(a.xyz,a.yzx)*step(a.xyz,a.zxy);
           a+=U*L;
           t+=U*Y;
           G=1.;
         }
       w+=p.xyz;
     }
   w*=1.;
   return w;
 }
 vec3 R(vec3 i,vec3 z)
 {
   i+=Fract01(cameraPosition.xyz+.5)-.5;
   vec3 y=s(i+z*.1),x=c(v(y)).AChndccCtU;
   return x;
 }
 vec3 R(vec2 v,vec3 i,float y,vec3 z)
 {
   vec3 x=texture2DLod(colortex6,v,0).xyz;
   return x;
 }
 void main()
 {
   GBufferData v=GetGBufferData();
   MaterialMask z=CalculateMasks(v.materialID);
   vec4 i=GetViewPosition(texcoord.xy,v.depth),y=gbufferModelViewInverse*vec4(i.xyz,1.),s=gbufferModelViewInverse*vec4(i.xyz,0.);
   vec3 x=normalize(i.xyz),m=normalize(s.xyz),f=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz),n=normalize((gbufferModelViewInverse*vec4(v.geoNormal,0.)).xyz);
   float r=length(i.xyz);
   vec3 o=vec3(0.);
   if(z.grass>.5)
     f=vec3(0.,1.,0.);
   vec3 t=R(texcoord.xy,v.normal,v.depth,i.xyz)*10.,w=t*v.albedo.xyz;
   const float h=75.;
   if(r>h)
     {
       vec3 e=FromSH(skySHR,skySHG,skySHB,f);
       e=mix(e,vec3(.2)*(dot(f,vec3(0.,1.,0.))*.35+.65)*Luminance(colorSkylight),vec3(rainStrength));
       e*=v.mcLightmap.y;
       vec3 a=e*v.albedo.xyz*2.5;
       const float L=3.7;
       a+=v.mcLightmap.x*colorTorchlight*v.albedo.xyz*.025*L;
       vec3 U=normalize(v.albedo.xyz+.0001)*pow(length(v.albedo.xyz),1.)*colorSunlight*.13*v.mcLightmap.y;
       a+=U*v.albedo.xyz*5.;
       float G=.3;
       w=mix(w,a,vec3(saturate(r*G-h*G)));
     }
   o.xyz=w;
   #ifdef HELD_LIGHT
   {
     float G=float(heldBlockLightValue+heldBlockLightValue2)/16.,e=OrenNayar(f,-m,-m),L=1./(dot(s.xyz,s.xyz)+.3);
     o+=v.albedo.xyz*G*L*e*colorTorchlight*.3;
   }
   #endif
   #ifdef VISUALIZE_DANGEROUS_LIGHT_LEVEL
   {
     float e=BlockLightTorchLinear(v.mcLightmap.x)*16.;
     e=e;
     o.x+=e<=6.75?1.:0.;
   }
   #endif
   float G=24.*(1.-rainStrength),a=dot(f,worldLightVector),e=OrenNayar(f,-m,worldLightVector);
   if(z.leaves>.5)
     e=mix(e,.5,.5);
   if(z.grass>.5)
     v.metalness=0.;
   vec3 L=CalculateSunlightVisibility(i,z,n);
   #ifdef SUNLIGHT_LEAK_FIX
   float U=saturate(v.mcLightmap.y*100.);
   if(isEyeInWater<1)
     L*=U;
   #endif
   if(isEyeInWater<1)
     L*=ScreenSpaceShadow(i.xyz,v.normal.xyz,z);
   o+=TintUnderwaterDepth(DoNightEyeAtNight(e*v.albedo.xyz*L*G*colorSunlight,timeMidnight));
   vec3 l=SpecularGGX(f,-m,worldLightVector,1.-v.smoothness,v.metalness*.98+.02)*G*L;
   l*=mix(vec3(1.),v.albedo.xyz,vec3(v.metalness));
   if(isEyeInWater<.5)
     o*=1.-c(v.smoothness,v.metalness)*v.metalness,o+=DoNightEyeAtNight(l,timeMidnight);
   if(z.sky>.5||v.depth>1.)
     {
       vec3 p=m.xyz;
       if(isEyeInWater>0)
         p.xyz=refract(p.xyz,vec3(0.,-1.,0.),1.2533);
       o=SkyShading(p.xyz,worldSunVector.xyz,rainStrength);
       vec3 V=AtmosphereAbsorption(p.xyz);
       o+=v.albedo.xyz*V*.5;
       o+=RenderSunDisc(p,worldSunVector)*V*2000.*(1.-rainStrength);
       CloudPlane(o,x,-p,r,z,worldLightVector,lightVector);
     }
   if(z.glowstone>.5)
     o.xyz+=v.albedo.xyz*GI_LIGHT_BLOCK_INTENSITY;
   if(z.torch>.5)
     o.xyz+=v.albedo.xyz*pow(length(v.albedo.xyz),2.)*.5*GI_LIGHT_TORCH_INTENSITY;
   if(z.lava>.5)
     o+=v.albedo.xyz*.75*GI_LIGHT_BLOCK_INTENSITY;
   if(z.fire>.5)
     o+=v.albedo.xyz*3.*GI_LIGHT_TORCH_INTENSITY;
   if(z.litFurnace>.5)
     {
       float V=saturate(v.albedo.x-(v.albedo.y+v.albedo.z)*.5-.2);
       o+=v.albedo.xyz*V*2.*GI_LIGHT_TORCH_INTENSITY*vec3(2.,.35,.025);
     }
   float V=0.;
   o*=.001;
   o=LinearToGamma(o);
   o+=rand(texcoord.xy+sin(frameTimeCounter))*(1./65535.);
   gl_FragData[0]=vec4(o.xyz,1.);
 };




/* DRAWBUFFERS:3 */
