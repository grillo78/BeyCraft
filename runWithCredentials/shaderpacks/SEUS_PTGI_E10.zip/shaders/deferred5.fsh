#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/







in vec4 texcoord;


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBufferData.inc"


 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 x(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,y=d();
   ivec2 f=ivec2(v.x*m.x,v.y*m.y);
   float z=float(f.y/y),i=float(int(f.x+mod(m.x*z,y))/y);
   i+=floor(m.x*z/y);
   vec3 r=vec3(0.,0.,i);
   r.x=mod(f.x+mod(m.x*z,y),y);
   r.y=mod(f.y,y);
   r.xyz=floor(r.xyz);
   r/=y;
   r.xyz=r.xzy;
   return r;
 }
 vec2 n(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 f=v.xzy*x;
   f=floor(f+1e-05);
   float y=f.z;
   vec2 i;
   i.x=mod(f.x+y*x,m.x);
   float s=f.x+y*x;
   i.y=f.y+floor(s/m.x)*x;
   i+=.5;
   i/=m;
   return i;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 n=ivec2(i.x*m.x,i.y*m.y);
   float z=float(n.y/y),r=float(int(n.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 s=vec3(0.,0.,r);
   s.x=mod(n.x+mod(m.x*z,y),y);
   s.y=mod(n.y,y);
   s.xyz=floor(s.xyz);
   s/=y;
   s.xyz=s.xzy;
   return s;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 f=v.xzy*y;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 i;
   i.x=mod(f.x+x*y,m.x);
   float s=f.x+x*y;
   i.y=f.y+floor(s/m.x)*y;
   i+=.5;
   i/=m;
   i.xy*=.5;
   return i;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 n()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,x=floor(v-.0001),y=floor(f-.0001);
   return x-y;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 m,vec2 x,vec4 i,vec4 n,inout float y,out vec2 r)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(n.x==8||n.x==9||n.x==79||n.x<1.||!z||n.x==20.||n.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(n.x==50.||n.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(n.x==51)
     y=0.;
   if(n.x>255)
     y=0.;
   vec3 s,c;
   if(f.x>.5)
     s=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       s=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         s=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           s=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             s=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               s=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   r=clamp((m.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,L=.15;
   if(n.x==10.||n.x==11.)
     {
       if(abs(f.y)<.01&&z||f.y>.99)
         h=.1,L=.1,y=0.;
       else
          y=1.;
     }
   if(n.x==51)
     h=.5,L=.1;
   if(n.x==76)
     h=.2,L=.2;
   if(n.x-255.+39.>=103.&&n.x-255.+39.<=113.)
     L=.025,h=.025;
   s=normalize(i.xyz);
   c=normalize(cross(s,f.xyz)*sign(i.w));
   vec3 e=v.xyz+mix(s*h,-s*h,vec3(r.x));
   e.xyz+=mix(c*h,-c*h,vec3(r.y));
   e.xyz-=f.xyz*L;
   return e;
 }struct ChqUiAvDkU{vec3 vSNsAVOjDa;vec3 vSNsAVOjDaOrigin;vec3 UgsYTfdINL;vec3 LkVOyZfKEL;vec3 ZPrwqHNnFV;vec3 nqlOapzPzv;};
 ChqUiAvDkU e(Ray v)
 {
   ChqUiAvDkU f;
   f.vSNsAVOjDa=floor(v.origin);
   f.vSNsAVOjDaOrigin=f.vSNsAVOjDa;
   f.UgsYTfdINL=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.LkVOyZfKEL=sign(v.direction);
   f.ZPrwqHNnFV=(sign(v.direction)*(f.vSNsAVOjDa-v.origin)+sign(v.direction)*.5+.5)*f.UgsYTfdINL;
   f.nqlOapzPzv=vec3(0.);
   return f;
 }
 void w(inout ChqUiAvDkU v)
 {
   v.nqlOapzPzv=step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.yzx)*step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.zxy),v.ZPrwqHNnFV+=v.nqlOapzPzv*v.UgsYTfdINL,v.vSNsAVOjDa+=v.nqlOapzPzv*v.LkVOyZfKEL;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float y)
 {
   float x,z,r,c;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   c=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),r);
   y=min(min(y,z),c);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,n=(f-v)*.5,i=y-z,r=vec3(0.);
   r+=vec3(sign(i.x),0.,0.)*step(abs(abs(i.x)-n.x),x);
   r+=vec3(0.,sign(i.y),0.)*step(abs(abs(i.y)-n.y),x);
   r+=vec3(0.,0.,sign(i.z))*step(abs(abs(i.z)-n.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),n=min(x,y),s=max(x,y);
   vec2 r=max(n.xx,n.yz);
   float z=max(r.x,r.y);
   r=min(s.xx,s.yz);
   float c=min(r.x,r.y);
   i.x=z;
   i.y=c;
   return c>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float y,inout vec3 x)
 {
   vec3 i=m.inv_direction*(v-m.origin),s=m.inv_direction*(f-m.origin),n=min(s,i),r=max(s,i);
   vec2 c=max(n.xx,n.yz);
   float z=max(c.x,c.y);
   c=min(r.xx,r.yz);
   float G=min(c.x,c.y);
   bool t=G>max(z,0.)&&max(z,0.)<y;
   if(t)
     x=d(v,f,m.origin+m.direction*z),y=z;
   return t;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float c=abs(n.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,c),t=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-t);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 f,vec3 i,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(f),n=m(s+y*.99);
   float r=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*r),3).x;
   c*=saturate(dot(i,y));
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(n.xy-vec2(.5,0.),n.z-.0006*r),3).x;
   vec3 h=texture2DLod(shadowcolor,vec2(n.xy-vec2(.5,0.)),3).xyz;
   h*=h;
   c=mix(c,c*h,vec3(1.-t));
   #endif
   return c*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float c=shadow2DLod(shadowtex0,vec3(i.xy-vec2(.5,0.),i.z-.0006*s),3).x;
   vec3 h=texture2DLod(shadowcolor,vec2(i.xy-vec2(.5,0.)),3).xyz;
   h*=h;
   r=mix(r,r*h,vec3(1.-c));
   #endif
   return r*(1.-rainStrength);
 }struct SgvRpoZFEp{float hBzGxfOWHl;float rPdSyvYhOi;float AqljTTtzgc;float IiJpNLRFqV;vec3 AChndccCtU;};
 vec4 h(SgvRpoZFEp v)
 {
   vec4 f;
   v.AChndccCtU=max(vec3(0.),v.AChndccCtU);
   f.x=v.hBzGxfOWHl;
   v.AChndccCtU=pow(v.AChndccCtU,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.AChndccCtU.x,v.AqljTTtzgc);
   f.z=PackTwo16BitTo32Bit(v.AChndccCtU.y,v.IiJpNLRFqV);
   f.w=PackTwo16BitTo32Bit(v.AChndccCtU.z,v.rPdSyvYhOi);
   return f;
 }
 SgvRpoZFEp i(vec4 v)
 {
   SgvRpoZFEp f;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),i=UnpackTwo16BitFrom32Bit(v.z),n=UnpackTwo16BitFrom32Bit(v.w);
   f.hBzGxfOWHl=v.x;
   f.AqljTTtzgc=m.y;
   f.IiJpNLRFqV=i.y;
   f.rPdSyvYhOi=n.y;
   f.AChndccCtU=pow(vec3(m.x,i.x,n.x),vec3(8.));
   return f;
 }
 SgvRpoZFEp G(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool G(vec3 v,float y,Ray f,bool x,inout float i,inout vec3 z)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(x)
     return false;
   if(y>=67.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),f,i,z);
   r=m;
   #else
   if(y<40.)
     return m=d(v,v+vec3(1.,1.,1.),f,i,z),m;
   if(y==40.||y==41.||y>=43.&&y<=54.)
     {
       float c=.5;
       if(y==41.)
         c=.9375;
       m=d(v+vec3(0.,0.,0.),v+vec3(1.,c,1.),f,i,z);
       r=r||m;
     }
   if(y==42.||y>=55.&&y<=66.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,z),r=r||m;
   if(y==43.||y==46.||y==47.||y==52.||y==53.||y==54.||y==55.||y==58.||y==59.||y==64.||y==65.||y==66.)
     {
       float c=.5;
       if(y==55.||y==58.||y==59.||y==64.||y==65.||y==66.)
         c=0.;
       m=d(v+vec3(0.,c,0.),v+vec3(.5,.5+c,.5),f,i,z);
       r=r||m;
     }
   if(y==43.||y==45.||y==48.||y==51.||y==53.||y==54.||y==55.||y==57.||y==60.||y==63.||y==65.||y==66.)
     {
       float c=.5;
       if(y==55.||y==57.||y==60.||y==63.||y==65.||y==66.)
         c=0.;
       m=d(v+vec3(.5,c,0.),v+vec3(1.,.5+c,.5),f,i,z);
       r=r||m;
     }
   if(y==44.||y==45.||y==49.||y==51.||y==52.||y==54.||y==56.||y==57.||y==61.||y==63.||y==64.||y==66.)
     {
       float c=.5;
       if(y==56.||y==57.||y==61.||y==63.||y==64.||y==66.)
         c=0.;
       m=d(v+vec3(.5,c,.5),v+vec3(1.,.5+c,1.),f,i,z);
       r=r||m;
     }
   if(y==44.||y==46.||y==50.||y==51.||y==52.||y==53.||y==56.||y==58.||y==62.||y==63.||y==64.||y==65.)
     {
       float c=.5;
       if(y==56.||y==58.||y==62.||y==63.||y==64.||y==65.)
         c=0.;
       m=d(v+vec3(0.,c,.5),v+vec3(.5,.5+c,1.),f,i,z);
       r=r||m;
     }
   if(y>=67.&&y<=82.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,z),r=r||m;
   if(y==68.||y==69.||y==70.||y==72.||y==73.||y==74.||y==76.||y==77.||y==78.||y==80.||y==81.||y==82.)
     {
       float c=8.,s=8.;
       if(y==68.||y==70.||y==72.||y==74.||y==76.||y==78.||y==80.||y==82.)
         c=0.;
       if(y==69.||y==70.||y==73.||y==74.||y==77.||y==78.||y==81.||y==82.)
         s=16.;
       m=d(v+vec3(c,6.,7.)/16.,v+vec3(s,9.,9.)/16.,f,i,z);
       r=r||m;
       m=d(v+vec3(c,12.,7.)/16.,v+vec3(s,15.,9.)/16.,f,i,z);
       r=r||m;
     }
   if(y>=71.&&y<=82.)
     {
       float c=8.,s=8.;
       if(y>=71.&&y<=74.||y>=79.&&y<=82.)
         s=16.;
       if(y>=75.&&y<=82.)
         c=0.;
       m=d(v+vec3(7.,6.,c)/16.,v+vec3(9.,9.,s)/16.,f,i,z);
       r=r||m;
       m=d(v+vec3(7.,12.,c)/16.,v+vec3(9.,15.,s)/16.,f,i,z);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=83.&&y<=86.)
     {
       vec3 c=vec3(0),s=vec3(0);
       if(y==83.)
         c=vec3(0,0,0),s=vec3(16,16,3);
       if(y==84.)
         c=vec3(0,0,13),s=vec3(16,16,16);
       if(y==86.)
         c=vec3(0,0,0),s=vec3(3,16,16);
       if(y==85.)
         c=vec3(13,0,0),s=vec3(16,16,16);
       m=d(v+c/16.,v+s/16.,f,i,z);
       r=r||m;
     }
   if(y>=87.&&y<=102.)
     {
       vec3 c=vec3(0.),s=vec3(1.);
       if(y>=87.&&y<=94.)
         {
           float h=0.;
           if(y>=91.&&y<=94.)
             h=13.;
           c=vec3(0.,h,0.)/16.;
           s=vec3(16.,h+3.,16.)/16.;
         }
       if(y>=95.&&y<=98.)
         {
           float n=13.;
           if(y==97.||y==98.)
             n=0.;
           c=vec3(0.,0.,n)/16.;
           s=vec3(16.,16.,n+3.)/16.;
         }
       if(y>=99.&&y<=102.)
         {
           float n=13.;
           if(y==99.||y==100.)
             n=0.;
           c=vec3(n,0.,0.)/16.;
           s=vec3(n+3.,16.,16.)/16.;
         }
       m=d(v+c,v+s,f,i,z);
       r=r||m;
     }
   if(y>=103.&&y<=113.)
     {
       vec3 c=vec3(0.),n=vec3(1.);
       if(y>=103.&&y<=110.)
         {
           float s=float(y)-float(103.)+1.;
           n.y=s*2./16.;
         }
       if(y==111.)
         n.y=.0625;
       if(y==112.)
         c=vec3(1.,0.,1.)/16.,n=vec3(15.,1.,15.)/16.;
       if(y==113.)
         c=vec3(1.,0.,1.)/16.,n=vec3(15.,.5,15.)/16.;
       m=d(v+c,v+n,f,i,z);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 void d(inout float v,inout float y,float f,float i,vec3 c,float z)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.6,i);
   #else
   v*=mix(2.4,3.4,i);
   #endif
   float x=dot(c,vec3(1.));
   y*=1.-pow(i,.4);
   y/=f*.1+2e-06;
   y*=4.;
   y*=.6;
   float r=f/(x+1e-07)*.1+4e-08;
   r=min(r,1.);
   r=mix(r,1.,pow(i,.25));
   if(z<.12)
     y=0.;
 }
 float G(vec3 v,vec3 y,float m)
 {
   float f=dot(abs(v-y),vec3(.3333));
   f*=m;
   f*=.18;
   return f;
 }
 vec4 e(sampler2D v,vec2 f,bool y,float m,float i,out float r)
 {
   SgvRpoZFEp n=G(f.xy);
   r=n.IiJpNLRFqV;
   vec4 c=texture2DLod(v,f.xy,0);
   vec3 x=c.xyz;
   float s=c.w;
   vec3 z=GetNormals(f.xy);
   float t=GetDepth(f.xy),h=ExpToLinearDepth(t);
   vec3 L=GetViewPosition(f.xy,t).xyz;
   vec2 e=vec2(0.);
   if(y)
     e=BlueNoiseTemporal(f.xy).xy-.5;
   float a=m*1,o=i;
   d(a,o,c.w,r,x,h);
   float R=24.*mix(4.,1.,r),U=mix(20.,10.,r)/h,Y=0.;
   vec4 V=vec4(0.);
   float p=0.;
   int C=0;
   for(int w=-1;w<=1;w++)
     {
       for(int b=-1;b<=1;b++)
         {
           vec2 l=(vec2(w,b)+e)/vec2(viewWidth,viewHeight)*a,g=f.xy+l.xy;
           float A=length(l*vec2(viewWidth,viewHeight));
           g=clamp(g,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
           vec4 F=texture2DLod(v,g,0);
           vec3 S=GetNormals(g);
           float I=GetDepth(g),B=ExpToLinearDepth(I),u=pow(saturate(dot(z,S)),R),T=exp(-(abs(B-h)*U)),E=0.;
           #if GI_FILTER_QUALITY==1
           vec3 Z=GetViewPosition(g,I).xyz,D=normalize(Z.xyz-L.xyz);
           float P=dot(-S,D);
           bool N=P>0.&&Luminance(F.xyz)<Luminance(x.xyz);
           u=N?2.:u;
           E=exp(-G(F.xyz,x,N?o:o));
           #else
           E=exp(-G(F.xyz,x,o));
           #endif
           float O=T*E*u;
           V+=F*O;
           p+=O;
           C++;
         }
     }
   V/=p+.0001;
   if(p<.0001)
     V=c;
   return V;
 }
 float c(vec3 v)
 {
   float y=simplex3d(v*vec3(1.,.01,1.5)+vec3(-v.z*1.2+v.y*.2,0.,0.));
   y+=simplex3d(v*vec3(1.,.01,.9)+vec3(-v.z*.7-v.y*.2,0.,0.));
   return y*1.5;
 }
 vec2 c(vec2 v,float y)
 {
   v*=8.;
   float f=c(vec3(v.xy*5.+vec2(-.025,-.025),y))-.5,i=c(vec3(v.xy*5.+vec2(.025,-.025),y))-.5,x=c(vec3(v.xy*5.+vec2(-.025,.025),y))-.5;
   vec3 n=normalize(vec3(f-i,f-x,2.5));
   return n.xy;
 }
 float e(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 float h(vec3 v,vec3 y)
 {
   return dot(abs(v-y),vec3(.3333));
 }
 void main()
 {
   float v;
   vec4 f=e(colortex6,texcoord.xy,false,8.,8.,v);
   float y=1.;
   if(texcoord.y<.25)
     {
       vec2 n=texcoord.xy*vec2(4.,4.),i=vec2(n.x,(n.y-floor(mod(FRAME_TIME*60.f,60.f)))/60.f);
       if(texcoord.x<.25)
         y=texture2DLod(colortex0,i.xy,0).x;
       else
          if(texcoord.x>.25&&texcoord.x<.5)
           y=texture2DLod(colortex0,i.xy,0).y;
         else
            if(texcoord.x>.5&&texcoord.x<.75)
             y=texture2DLod(colortex0,i.xy,0).z;
           else
              y=texture2DLod(colortex0,i.xy,0).w;
     }
   vec2 i=1.-abs(texcoord.xy*2.-1.);
   i=saturate(i*10.);
   float x=min(i.x,i.y);
   f.xyz*=mix(vec3(1.),BlueNoiseTemporal(texcoord.xy).xyz*2.,vec3(1.-pow(v,2.5))*.35*x);
   gl_FragData[0]=vec4(f.xyz,y);
 };




/* DRAWBUFFERS:6 */
