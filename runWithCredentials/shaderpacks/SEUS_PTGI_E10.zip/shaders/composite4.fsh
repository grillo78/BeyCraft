#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"


const bool colortex6MipmapEnabled = false;


in vec4 texcoord;

in vec3 lightVector;
in vec3 worldLightVector;
in vec3 worldSunVector;

in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSkyUp;
in vec3 colorTorchlight;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;

#include "lib/GBufferData.inc"


// vec4 GetViewPosition(in vec2 coord, in float depth) 
// {	
// 	vec4 tcoord = vec4(coord.xy, 0.0, 0.0);

// 	vec4 fragposition = gbufferProjectionInverse * vec4(tcoord.s * 2.0f - 1.0f, tcoord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
// 		 fragposition /= fragposition.w;

	
// 	return fragposition;
// }





#include "lib/Materials.inc"


 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int z=v.x*v.y;
   return t(f(floor(pow(float(z),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int z=v.x*v.y;
   return d(f(floor(pow(float(z),.333333))));
 }
 vec3 e(vec2 v)
 {
   ivec2 s=ivec2(viewWidth,viewHeight);
   int x=s.x*s.y,z=d();
   ivec2 f=ivec2(v.x*s.x,v.y*s.y);
   float y=float(f.y/z),i=float(int(f.x+mod(s.x*y,z))/z);
   i+=floor(s.x*y/z);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(f.x+mod(s.x*y,z),z);
   m.y=mod(f.y,z);
   m.xyz=floor(m.xyz);
   m/=z;
   m.xyz=m.xzy;
   return m;
 }
 vec2 x(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 f=v.xzy*x;
   f=floor(f+1e-05);
   float y=f.z;
   vec2 i;
   i.x=mod(f.x+y*x,m.x);
   float s=f.x+y*x;
   i.y=f.y+floor(s/m.x)*x;
   i+=.5;
   i/=m;
   return i;
 }
 vec3 n(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 s=ivec2(2048,2048);
   int x=s.x*s.y,z=f();
   ivec2 m=ivec2(i.x*s.x,i.y*s.y);
   float y=float(m.y/z),r=float(int(m.x+mod(s.x*y,z))/z);
   r+=floor(s.x*y/z);
   vec3 n=vec3(0.,0.,r);
   n.x=mod(m.x+mod(s.x*y,z),z);
   n.y=mod(m.y,z);
   n.xyz=floor(n.xyz);
   n/=z;
   n.xyz=n.xzy;
   return n;
 }
 vec2 d(vec3 v,int z)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 i=v.xzy*z;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 f;
   f.x=mod(i.x+x*z,m.x);
   float s=i.x+x*z;
   f.y=i.y+floor(s/m.x)*z;
   f+=.5;
   f/=m;
   f.xy*=.5;
   return f;
 }
 vec3 e(vec3 v,int z)
 {
   return v*=1./z,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 f(vec3 v,int z)
 {
   return v*=1./z,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 r(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 e()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,z=floor(v-.0001),x=floor(f-.0001);
   return z-x;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),z=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/z;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 s,vec2 z,vec4 i,vec4 m,inout float x,out vec2 n)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(m.x==8||m.x==9||m.x==79||m.x<1.||!r||m.x==20.||m.x==171.||min(abs(f.x),abs(f.z))>.2)
     x=1.;
   if(m.x==50.||m.x==76.)
     {
       x=0.;
       if(f.y<.5)
         x=1.;
     }
   if(m.x==51)
     x=0.;
   if(m.x>255)
     x=0.;
   vec3 y,c;
   if(f.x>.5)
     y=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       y=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         y=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           y=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             y=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               y=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   n=clamp((s.xy-z.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,L=.15;
   if(m.x==10.||m.x==11.)
     {
       if(abs(f.y)<.01&&r||f.y>.99)
         h=.1,L=.1,x=0.;
       else
          x=1.;
     }
   if(m.x==51)
     h=.5,L=.1;
   if(m.x==76)
     h=.2,L=.2;
   if(m.x-255.+39.>=103.&&m.x-255.+39.<=113.)
     L=.025,h=.025;
   y=normalize(i.xyz);
   c=normalize(cross(y,f.xyz)*sign(i.w));
   vec3 e=v.xyz+mix(y*h,-y*h,vec3(n.x));
   e.xyz+=mix(c*h,-c*h,vec3(n.y));
   e.xyz-=f.xyz*L;
   return e;
 }struct ChqUiAvDkU{vec3 vSNsAVOjDa;vec3 vSNsAVOjDaOrigin;vec3 UgsYTfdINL;vec3 LkVOyZfKEL;vec3 ZPrwqHNnFV;vec3 nqlOapzPzv;};
 ChqUiAvDkU p(Ray v)
 {
   ChqUiAvDkU f;
   f.vSNsAVOjDa=floor(v.origin);
   f.vSNsAVOjDaOrigin=f.vSNsAVOjDa;
   f.UgsYTfdINL=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.LkVOyZfKEL=sign(v.direction);
   f.ZPrwqHNnFV=(sign(v.direction)*(f.vSNsAVOjDa-v.origin)+sign(v.direction)*.5+.5)*f.UgsYTfdINL;
   f.nqlOapzPzv=vec3(0.);
   return f;
 }
 void w(inout ChqUiAvDkU v)
 {
   v.nqlOapzPzv=step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.yzx)*step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.zxy),v.ZPrwqHNnFV+=v.nqlOapzPzv*v.UgsYTfdINL,v.vSNsAVOjDa+=v.nqlOapzPzv*v.LkVOyZfKEL;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float z)
 {
   float x,y,r,c;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   z=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   y=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   c=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),r);
   z=min(min(z,y),c);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 z)
 {
   const float x=1e-05;
   vec3 y=(f+v)*.5,m=(f-v)*.5,s=z-y,i=vec3(0.);
   i+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-m.x),x);
   i+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-m.y),x);
   i+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-m.z),x);
   return normalize(i);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 z=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),s=min(x,z),c=max(x,z);
   vec2 r=max(s.xx,s.yz);
   float y=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float n=min(r.x,r.y);
   i.x=y;
   i.y=n;
   return n>max(y,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 z)
 {
   vec3 y=m.inv_direction*(v-m.origin),s=m.inv_direction*(f-m.origin),i=min(s,y),c=max(s,y);
   vec2 r=max(i.xx,i.yz);
   float n=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float p=min(r.x,r.y);
   bool t=p>max(n,0.)&&max(n,0.)<x;
   if(t)
     z=d(v,f,m.origin+m.direction*n),x=n;
   return t;
 }
 vec3 e(vec3 v,vec3 f,vec3 z,vec3 x,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 s=m(v);
   float n=.5;
   vec3 i=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*n),0).x;
   i*=saturate(dot(f,z));
   {
     vec4 c=texture2DLod(shadowcolor1,s.xy-vec2(0.,.5),4);
     float r=abs(c.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,r),t=shadow2DLod(shadowtex0,vec3(s.xy-vec2(0.,.5),s.z+1e-06),4).x;
     i=mix(i,i*h,1.-t);
   }
   i=TintUnderwaterDepth(i);
   return i*(1.-rainStrength);
 }
 vec3 f(vec3 z,vec3 f,vec3 x,vec3 y,int n)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 i=v(z),s=m(i+x*.99);
   float h=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*h),3).x;
   r*=saturate(dot(f,x));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*h),3).x;
   vec3 c=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   c*=c;
   r=mix(r,r*c,vec3(1.-t));
   #endif
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 z,vec3 x,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 s=m(v);
   float i=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*i),2).x;
   r*=saturate(dot(f,z));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float n=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*i),3).x;
   vec3 c=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   c*=c;
   r=mix(r,r*c,vec3(1.-n));
   #endif
   return r*(1.-rainStrength);
 }struct SgvRpoZFEp{float hBzGxfOWHl;float rPdSyvYhOi;float AqljTTtzgc;float IiJpNLRFqV;vec3 AChndccCtU;};
 vec4 h(SgvRpoZFEp v)
 {
   vec4 f;
   v.AChndccCtU=max(vec3(0.),v.AChndccCtU);
   f.x=v.hBzGxfOWHl;
   v.AChndccCtU=pow(v.AChndccCtU,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.AChndccCtU.x,v.AqljTTtzgc);
   f.z=PackTwo16BitTo32Bit(v.AChndccCtU.y,v.IiJpNLRFqV);
   f.w=PackTwo16BitTo32Bit(v.AChndccCtU.z,v.rPdSyvYhOi);
   return f;
 }
 SgvRpoZFEp i(vec4 v)
 {
   SgvRpoZFEp f;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),s=UnpackTwo16BitFrom32Bit(v.z),i=UnpackTwo16BitFrom32Bit(v.w);
   f.hBzGxfOWHl=v.x;
   f.AqljTTtzgc=m.y;
   f.IiJpNLRFqV=s.y;
   f.rPdSyvYhOi=i.y;
   f.AChndccCtU=pow(vec3(m.x,s.x,i.x),vec3(8.));
   return f;
 }
 SgvRpoZFEp G(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),z=vec2(viewWidth,viewHeight);
   v=(floor(v*z)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float G(float v,float z)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+z,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool G(vec3 v,float z,Ray f,bool y,inout float x,inout vec3 i)
 {
   bool m=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(y)
     return false;
   if(z>=67.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),f,x,i);
   m=r;
   #else
   if(z<40.)
     return r=d(v,v+vec3(1.,1.,1.),f,x,i),r;
   if(z==40.||z==41.||z>=43.&&z<=54.)
     {
       float s=.5;
       if(z==41.)
         s=.9375;
       r=d(v+vec3(0.,0.,0.),v+vec3(1.,s,1.),f,x,i);
       m=m||r;
     }
   if(z==42.||z>=55.&&z<=66.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,x,i),m=m||r;
   if(z==43.||z==46.||z==47.||z==52.||z==53.||z==54.||z==55.||z==58.||z==59.||z==64.||z==65.||z==66.)
     {
       float s=.5;
       if(z==55.||z==58.||z==59.||z==64.||z==65.||z==66.)
         s=0.;
       r=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),f,x,i);
       m=m||r;
     }
   if(z==43.||z==45.||z==48.||z==51.||z==53.||z==54.||z==55.||z==57.||z==60.||z==63.||z==65.||z==66.)
     {
       float s=.5;
       if(z==55.||z==57.||z==60.||z==63.||z==65.||z==66.)
         s=0.;
       r=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),f,x,i);
       m=m||r;
     }
   if(z==44.||z==45.||z==49.||z==51.||z==52.||z==54.||z==56.||z==57.||z==61.||z==63.||z==64.||z==66.)
     {
       float s=.5;
       if(z==56.||z==57.||z==61.||z==63.||z==64.||z==66.)
         s=0.;
       r=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),f,x,i);
       m=m||r;
     }
   if(z==44.||z==46.||z==50.||z==51.||z==52.||z==53.||z==56.||z==58.||z==62.||z==63.||z==64.||z==65.)
     {
       float s=.5;
       if(z==56.||z==58.||z==62.||z==63.||z==64.||z==65.)
         s=0.;
       r=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),f,x,i);
       m=m||r;
     }
   if(z>=67.&&z<=82.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,x,i),m=m||r;
   if(z==68.||z==69.||z==70.||z==72.||z==73.||z==74.||z==76.||z==77.||z==78.||z==80.||z==81.||z==82.)
     {
       float s=8.,c=8.;
       if(z==68.||z==70.||z==72.||z==74.||z==76.||z==78.||z==80.||z==82.)
         s=0.;
       if(z==69.||z==70.||z==73.||z==74.||z==77.||z==78.||z==81.||z==82.)
         c=16.;
       r=d(v+vec3(s,6.,7.)/16.,v+vec3(c,9.,9.)/16.,f,x,i);
       m=m||r;
       r=d(v+vec3(s,12.,7.)/16.,v+vec3(c,15.,9.)/16.,f,x,i);
       m=m||r;
     }
   if(z>=71.&&z<=82.)
     {
       float s=8.,c=8.;
       if(z>=71.&&z<=74.||z>=79.&&z<=82.)
         c=16.;
       if(z>=75.&&z<=82.)
         s=0.;
       r=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,c)/16.,f,x,i);
       m=m||r;
       r=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,c)/16.,f,x,i);
       m=m||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(z>=83.&&z<=86.)
     {
       vec3 s=vec3(0),c=vec3(0);
       if(z==83.)
         s=vec3(0,0,0),c=vec3(16,16,3);
       if(z==84.)
         s=vec3(0,0,13),c=vec3(16,16,16);
       if(z==86.)
         s=vec3(0,0,0),c=vec3(3,16,16);
       if(z==85.)
         s=vec3(13,0,0),c=vec3(16,16,16);
       r=d(v+s/16.,v+c/16.,f,x,i);
       m=m||r;
     }
   if(z>=87.&&z<=102.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(z>=87.&&z<=94.)
         {
           float h=0.;
           if(z>=91.&&z<=94.)
             h=13.;
           s=vec3(0.,h,0.)/16.;
           c=vec3(16.,h+3.,16.)/16.;
         }
       if(z>=95.&&z<=98.)
         {
           float n=13.;
           if(z==97.||z==98.)
             n=0.;
           s=vec3(0.,0.,n)/16.;
           c=vec3(16.,16.,n+3.)/16.;
         }
       if(z>=99.&&z<=102.)
         {
           float h=13.;
           if(z==99.||z==100.)
             h=0.;
           s=vec3(h,0.,0.)/16.;
           c=vec3(h+3.,16.,16.)/16.;
         }
       r=d(v+s,v+c,f,x,i);
       m=m||r;
     }
   if(z>=103.&&z<=113.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(z>=103.&&z<=110.)
         {
           float n=float(z)-float(103.)+1.;
           c.y=n*2./16.;
         }
       if(z==111.)
         c.y=.0625;
       if(z==112.)
         s=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(z==113.)
         s=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       r=d(v+s,v+c,f,x,i);
       m=m||r;
     }
   #endif
   #endif
   return m;
 }
 float h(float v,float z)
 {
   return 1./(v*(1.-z)+z);
 }
 void G(inout vec3 v,in vec3 z,in vec3 x,vec3 f,float y)
 {
   float i=length(z);
   i*=pow(eyeBrightnessSmooth.y/240.f,6.f);
   i*=rainStrength;
   float s=pow(exp(-i*3e-06),4.);
   vec3 r=vec3(dot(colorSkyUp,vec3(1.)));
   v=mix(r,v,vec3(s));
 }
 vec4 c(vec2 v)
 {
   vec2 z=vec2(v.x,(v.y-floor(mod(FRAME_TIME*60.f,60.f)))/60.f);
   return texture2DLod(colortex4,z.xy,0);
 }
 float c(vec3 v,float z)
 {
   vec3 f=v.xyz+cameraPosition.xyz,m=refract(worldLightVector,vec3(0.,1.,0.),.750188);
   f+=m*((v.y+cameraPosition.y)/m.y);
   vec4 s=c(mod(f.xz/4.,vec2(1.)))*13.;
   float x=pow(z/2.,.5),i=pow(s.x,saturate(x*.5+.5));
   i=mix(i,s.y,saturate(x-1.));
   i=mix(i,s.z,saturate(x-2.));
   i=mix(i,s.w,saturate(x-3.));
   return i;
 }
 float i(float v,float z)
 {
   return exp(-pow(v/(.9*z),2.));
 }
 float m(vec3 v,vec3 z)
 {
   return dot(abs(v-z),vec3(.3333));
 }
 vec3 a(vec2 v)
 {
   vec2 z=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   z=(floor(z*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,z).xyz,s=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+vec3(s)*mod(frameCounter,64.f),vec3(1.));
   return i;
 }
 vec3 G(float v,float f,float x,vec3 z)
 {
   vec3 i;
   i.x=x*cos(v);
   i.y=x*sin(v);
   i.z=f;
   vec3 s=abs(z.y)<.999?vec3(0,0,1):vec3(1,0,0),c=normalize(cross(z,vec3(0.,1.,1.))),r=cross(c,z);
   return c*i.x+r*i.y+z*i.z;
 }
 vec3 G(vec2 v,float f,vec3 z)
 {
   float s=2*3.14159*v.x,x=sqrt((1-v.y)/(1+(f*f-1)*v.y)),i=sqrt(1-x*x);
   return G(s,x,i,z);
 }
 float g(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 a(in vec2 v,in float z,in vec3 i)
 {
   float s=g(z),f=2*3.14159*v.x,x=pow(v.y,1.f/(s+1.f)),c=sqrt(1-x*x);
   return G(f,x,c,i);
 }
 float R(vec2 v)
 {
   return texture2DLod(colortex3,v,0).w;
 }
 float R(float v,float z)
 {
   return v/(z*20.01+1.);
 }
 vec2 a(vec2 v,float z)
 {
   vec2 s=v;
   mat2 m=mat2(cos(z),-sin(z),sin(z),cos(z));
   v=m*v;
   return v;
 }
 vec4 G(sampler2D v,float x,bool z,float f,float s,float i,float y)
 {
   GBufferData c=GetGBufferData();
   GBufferDataTransparent n=GetGBufferDataTransparent();
   bool r=n.depth<c.depth;
   if(r)
     c.normal=n.normal,c.smoothness=n.smoothness,c.metalness=0.,c.mcLightmap=n.mcLightmap,c.depth=n.depth;
   vec4 h=GetViewPosition(texcoord.xy,c.depth),L=gbufferModelViewInverse*vec4(h.xyz,1.),d=gbufferModelViewInverse*vec4(h.xyz,0.);
   vec3 t=normalize(h.xyz),p=normalize(d.xyz),o=normalize((gbufferModelViewInverse*vec4(c.normal,0.)).xyz);
   float w=GetDepthLinear(texcoord.xy),l=dot(-t,c.normal.xyz),e=1.-c.smoothness,V=e*e,g=G(c.smoothness,c.metalness);
   vec4 U=texture2DLod(colortex6,texcoord.xy,0);
   float A=Luminance(U.xyz);
   if(g<.001)
     return U;
   float C=x*.9;
   C*=min(V*15.,1.1);
   C*=mix(U.w,1.,1.);
   vec2 b=vec2(0.);
   if(z)
     {
       vec2 T=a(texcoord.xy).xy*.99+.005;
       b=T-.5;
     }
   float D=0.,Y=1.1,T=R(f,c.totalTexGrad)/(V+.0001),S=R(s,c.totalTexGrad);
   vec4 P=vec4(0.),M=vec4(0.);
   float F=0.;
   vec4 I=vec4(vec3(i),1.);
   I.xyz=vec3(.5);
   I.xyz*=U.w*.95+.05;
   float Z=c.smoothness;
   vec2 E=normalize(cross(c.normal,t).xy),k=a(E,1.5708);
   float u=1.-pow(1.-saturate(l),1.);
   E*=mix(.1675,.5,u);
   k*=mix(mix(.7,.7,V),.5,u);
   vec3 N=reflect(-t,c.normal);
   int O=0;
   for(int q=-1;q<=1;q++)
     {
       for(int W=-1;W<=1;W++)
         {
           vec2 B=vec2(q,W)+b;
           B=B.x*E+B.y*k;
           B*=C*1.5/vec2(viewWidth,viewHeight);
           vec2 H=texcoord.xy+B.xy;
           float j=length(B*vec2(viewWidth,viewHeight));
           if(j*.025>U.w+.1)
             {
               continue;
             }
           H=clamp(H,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
           vec4 K=texture2DLod(colortex6,H,0);
           vec3 J=GetNormals(H);
           float Q=GetDepthLinear(H),X=pow(saturate(dot(N,reflect(-t,J))),105./V),ab=exp(-(abs(Q-w)*Y)),ac=exp(-(m(K.xyz,U.xyz)*D)),ad=exp(-abs(Z-R(H))*S),ae=X*ab*ac*ad;
           P+=vec4(pow(length(K.xyz),I.x)*normalize(K.xyz+1e-05),K.w)*ae;
           F+=ae;
           M+=K;
           O++;
         }
     }
   P/=F+.0001;
   P.xyz=pow(length(P.xyz),1./I.x)*normalize(P.xyz+1e-06);
   vec4 B=P;
   if(F<.001)
     B=U;
   return B;
 }
 void main()
 {
   GBufferData v=GetGBufferData();
   GBufferDataTransparent z=GetGBufferDataTransparent();
   MaterialMask s=CalculateMasks(v.materialID),f=CalculateMasks(z.materialID);
   bool i=z.depth<v.depth;
   if(i)
     v.normal=z.normal,v.smoothness=z.smoothness,v.metalness=0.,v.mcLightmap=z.mcLightmap,v.depth=z.depth,f.sky=0.;
   vec4 c=GetViewPosition(texcoord.xy,v.depth),x=gbufferModelViewInverse*vec4(c.xyz,1.),m=gbufferModelViewInverse*vec4(c.xyz,0.);
   vec3 r=normalize(c.xyz),n=normalize(m.xyz),y=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz);
   float t=ExpToLinearDepth(v.depth),p=1.-v.smoothness,L=p*p,a=G(v.smoothness,v.metalness);
   int w=0;
   vec4 e=texture2DLod(colortex6,texcoord.xy,w),U=e;
   float B=1.-v.smoothness,l=B*B;
   vec3 d=y,V=-n,H=normalize(reflect(-V,d)+d*l),o=normalize(V+H);
   float g=saturate(dot(d,H)),F=saturate(dot(d,V)),b=saturate(dot(d,o)),R=saturate(dot(H,o)),T=v.metalness*.98+.02,Y=pow(1.-R,5.),S=T+(1.-T)*Y,u=l/2.,k=h(g,u)*h(F+.8,u),C=g*S*k;
   U.xyz*=mix(vec3(1.),v.albedo.xyz,vec3(v.metalness));
   C=mix(C,1.,v.metalness);
   if(v.depth>.99999)
     C=0.;
   if(f.water>.5&&isEyeInWater>0)
     {
       if(length(refract(V,d,1.3333))<.5)
         C=1.;
       else
          C=0.;
     }
   C*=G(v.smoothness,v.metalness);
   vec4 K=texture2DLod(colortex3,texcoord.xy,0);
   vec3 P=pow(K.xyz,vec3(2.2)),I=P;
   I*=120.;
   UnderwaterFog(I,length(m.xyz),n,colorSkyUp,colorSunlight);
   I=mix(I,U.xyz*1.2,vec3(saturate(C)));
   I+=P*v.metalness*120.;
   if(f.sky<.5&&!i&&isEyeInWater<1)
     LandAtmosphericScattering(I,c.xyz,r.xyz,n.xyz,worldSunVector.xyz,1.);
   G(I,c.xyz,r.xyz,n.xyz,1.);
   {
     #ifdef GODRAYS
     #else
     if(isEyeInWater>0)
       #endif
     {
       float D=BlueNoiseTemporal(texcoord.xy).x,E=120.;
       if(isEyeInWater>0)
         E=20.;
       vec3 q=vec3(0.),W=(gbufferModelViewInverse*vec4(0.,0.,0.,1.)).xyz;
       for(int A=0;A<10;A++)
         {
           float O=float(A+D)/float(10);
           vec3 Z=n.xyz*E*O+W;
           if(length(m.xyz)<length(Z-W))
             {
               break;
             }
           float N,J;
           vec3 j=WorldPosToShadowProjPos(Z.xyz,N,J),M=shadow2DLod(shadowtex0,vec3(j.xy,j.z+1e-06),3).xxx;
           #ifdef GODRAYS_STAINED_GLASS_TINT
           float Q=shadow2DLod(shadowtex0,vec3(j.xy-vec2(.5,0.),j.z-1e-06),3).x;
           vec3 X=texture2DLod(shadowcolor,vec2(j.xy-vec2(.5,0.)),3).xyz;
           X*=X;
           M=mix(M,M*X,vec3(1.-Q));
           #endif
           if(isEyeInWater>0)
             {
               float af=abs(texture2DLod(shadowcolor1,j.xy-vec2(0.,.5),4).x*256.-(Z.y+cameraPosition.y)),ag=GetCausticsComposite(Z,worldLightVector,af),ah=shadow2DLod(shadowtex0,vec3(j.xy-vec2(0.,.5),j.z+1e-06),4).x;
               M=mix(M,M*ag,vec3(1.-ah));
               q+=M*exp(-GetWaterAbsorption()*(E*O))*exp(-GetWaterAbsorption()*af);
             }
           else
              q+=M*colorSunlight*.1;
         }
       float M=dot(worldLightVector,n.xyz),j=1.;
       if(isEyeInWater>0)
         M=dot(refract(worldLightVector,vec3(0.,-1.,0.),.750019),n.xyz);
       else
          j=1./(max(0.,pow(worldLightVector.y,2.)*2.)+.4);
       float J=M*M,X=PhaseMie(.8,M,J);
       I+=TintUnderwaterDepth(q*colorSunlight*GetWaterFogColor()*.075*X*j);
     }
   }
   I/=120.;
   I*=exp(-t*blindness);
   I=pow(I.xyz,vec3(.454545));
   gl_FragData[0]=vec4(I,K.w);
 };





/* DRAWBUFFERS:3 */
