#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"



const bool colortex6MipmapEnabled = false;



in vec4 texcoord;
in vec3 lightVector;

in float timeSunriseSunset;
in float timeNoon;
in float timeMidnight;
in float timeSkyDark;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSunglow;
in vec3 colorBouncedSunlight;
in vec3 colorScatteredSunlight;
in vec3 colorTorchlight;
in vec3 colorWaterMurk;
in vec3 colorWaterBlue;
in vec3 colorSkyTint;


in vec3 upVector;


#include "lib/GBufferData.inc"

 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=d();
   ivec2 n=ivec2(v.x*f.x,v.y*f.y);
   float z=float(n.y/y),i=float(int(n.x+mod(f.x*z,y))/y);
   i+=floor(f.x*z/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(n.x+mod(f.x*z,y),y);
   m.y=mod(n.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 s(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 n;
   n.x=mod(i.x+y*x,f.x);
   float s=i.x+y*x;
   n.y=i.y+floor(s/f.x)*x;
   n+=.5;
   n/=f;
   return n;
 }
 vec3 x(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 n=ivec2(i.x*m.x,i.y*m.y);
   float z=float(n.y/y),r=float(int(n.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 s=vec3(0.,0.,r);
   s.x=mod(n.x+mod(m.x*z,y),y);
   s.y=mod(n.y,y);
   s.xyz=floor(s.xyz);
   s/=y;
   s.xyz=s.xzy;
   return s;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 f=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 n;
   n.x=mod(i.x+x*y,f.x);
   float s=i.x+x*y;
   n.y=i.y+floor(s/f.x)*y;
   n+=.5;
   n/=f;
   n.xy*=.5;
   return n;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 r(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 e(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 e()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,x=floor(v-.0001),y=floor(f-.0001);
   return x-y;
 }
 vec3 m(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/y;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 i,vec2 n,vec4 s,vec4 m,inout float x,out vec2 y)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(m.x==8||m.x==9||m.x==79||m.x<1.||!r||m.x==20.||m.x==171.||min(abs(f.x),abs(f.z))>.2)
     x=1.;
   if(m.x==50.||m.x==76.)
     {
       x=0.;
       if(f.y<.5)
         x=1.;
     }
   if(m.x==51)
     x=0.;
   if(m.x>255)
     x=0.;
   vec3 z,c;
   if(f.x>.5)
     z=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       z=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         z=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           z=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             z=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               z=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   y=clamp((i.xy-n.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,L=.15;
   if(m.x==10.||m.x==11.)
     {
       if(abs(f.y)<.01&&r||f.y>.99)
         h=.1,L=.1,x=0.;
       else
          x=1.;
     }
   if(m.x==51)
     h=.5,L=.1;
   if(m.x==76)
     h=.2,L=.2;
   if(m.x-255.+39.>=103.&&m.x-255.+39.<=113.)
     L=.025,h=.025;
   z=normalize(s.xyz);
   c=normalize(cross(z,f.xyz)*sign(s.w));
   vec3 e=v.xyz+mix(z*h,-z*h,vec3(y.x));
   e.xyz+=mix(c*h,-c*h,vec3(y.y));
   e.xyz-=f.xyz*L;
   return e;
 }struct ChqUiAvDkU{vec3 vSNsAVOjDa;vec3 vSNsAVOjDaOrigin;vec3 UgsYTfdINL;vec3 LkVOyZfKEL;vec3 ZPrwqHNnFV;vec3 nqlOapzPzv;};
 ChqUiAvDkU p(Ray v)
 {
   ChqUiAvDkU i;
   i.vSNsAVOjDa=floor(v.origin);
   i.vSNsAVOjDaOrigin=i.vSNsAVOjDa;
   i.UgsYTfdINL=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.LkVOyZfKEL=sign(v.direction);
   i.ZPrwqHNnFV=(sign(v.direction)*(i.vSNsAVOjDa-v.origin)+sign(v.direction)*.5+.5)*i.UgsYTfdINL;
   i.nqlOapzPzv=vec3(0.);
   return i;
 }
 void w(inout ChqUiAvDkU v)
 {
   v.nqlOapzPzv=step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.yzx)*step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.zxy),v.ZPrwqHNnFV+=v.nqlOapzPzv*v.UgsYTfdINL,v.vSNsAVOjDa+=v.nqlOapzPzv*v.LkVOyZfKEL;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float x)
 {
   float y,z,r,n;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   n=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,y),r);
   x=min(min(x,z),n);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,m=y-z,r=vec3(0.);
   r+=vec3(sign(m.x),0.,0.)*step(abs(abs(m.x)-i.x),x);
   r+=vec3(0.,sign(m.y),0.)*step(abs(abs(m.y)-i.y),x);
   r+=vec3(0.,0.,sign(m.z))*step(abs(abs(m.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),n=min(x,y),s=max(x,y);
   vec2 r=max(n.xx,n.yz);
   float z=max(r.x,r.y);
   r=min(s.xx,s.yz);
   float c=min(r.x,r.y);
   i.x=z;
   i.y=c;
   return c>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 y)
 {
   vec3 i=m.inv_direction*(v-m.origin),z=m.inv_direction*(f-m.origin),n=min(z,i),s=max(z,i);
   vec2 r=max(n.xx,n.yz);
   float c=max(r.x,r.y);
   r=min(s.xx,s.yz);
   float h=min(r.x,r.y);
   bool t=h>max(c,0.)&&max(c,0.)<x;
   if(t)
     y=d(v,f,m.origin+m.direction*c),x=c;
   return t;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float n=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*n),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 s=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float c=abs(s.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,c),t=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-t);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 y,vec3 f,vec3 x,vec3 z,int i)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(y),n=m(s+x*.99);
   float r=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*r),3).x;
   c*=saturate(dot(f,x));
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(n.xy-vec2(.5,0.),n.z-.0006*r),3).x;
   vec3 h=texture2DLod(shadowcolor,vec2(n.xy-vec2(.5,0.)),3).xyz;
   h*=h;
   c=mix(c,c*h,vec3(1.-t));
   #endif
   return c*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float n=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*n),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float c=shadow2DLod(shadowtex0,vec3(i.xy-vec2(.5,0.),i.z-.0006*n),3).x;
   vec3 s=texture2DLod(shadowcolor,vec2(i.xy-vec2(.5,0.)),3).xyz;
   s*=s;
   r=mix(r,r*s,vec3(1.-c));
   #endif
   return r*(1.-rainStrength);
 }struct SgvRpoZFEp{float hBzGxfOWHl;float rPdSyvYhOi;float AqljTTtzgc;float IiJpNLRFqV;vec3 AChndccCtU;};
 vec4 h(SgvRpoZFEp v)
 {
   vec4 i;
   v.AChndccCtU=max(vec3(0.),v.AChndccCtU);
   i.x=v.hBzGxfOWHl;
   v.AChndccCtU=pow(v.AChndccCtU,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.AChndccCtU.x,v.AqljTTtzgc);
   i.z=PackTwo16BitTo32Bit(v.AChndccCtU.y,v.IiJpNLRFqV);
   i.w=PackTwo16BitTo32Bit(v.AChndccCtU.z,v.rPdSyvYhOi);
   return i;
 }
 SgvRpoZFEp i(vec4 v)
 {
   SgvRpoZFEp i;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),f=UnpackTwo16BitFrom32Bit(v.z),n=UnpackTwo16BitFrom32Bit(v.w);
   i.hBzGxfOWHl=v.x;
   i.AqljTTtzgc=m.y;
   i.IiJpNLRFqV=f.y;
   i.rPdSyvYhOi=n.y;
   i.AChndccCtU=pow(vec3(m.x,f.x,n.x),vec3(8.));
   return i;
 }
 SgvRpoZFEp R(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float R(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool R(vec3 v,float x,Ray f,bool y,inout float i,inout vec3 n)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(y)
     return false;
   if(x>=67.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),f,i,n);
   r=m;
   #else
   if(x<40.)
     return m=d(v,v+vec3(1.,1.,1.),f,i,n),m;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float z=.5;
       if(x==41.)
         z=.9375;
       m=d(v+vec3(0.,0.,0.),v+vec3(1.,z,1.),f,i,n);
       r=r||m;
     }
   if(x==42.||x>=55.&&x<=66.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,n),r=r||m;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float z=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         z=0.;
       m=d(v+vec3(0.,z,0.),v+vec3(.5,.5+z,.5),f,i,n);
       r=r||m;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float z=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         z=0.;
       m=d(v+vec3(.5,z,0.),v+vec3(1.,.5+z,.5),f,i,n);
       r=r||m;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float z=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         z=0.;
       m=d(v+vec3(.5,z,.5),v+vec3(1.,.5+z,1.),f,i,n);
       r=r||m;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float z=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         z=0.;
       m=d(v+vec3(0.,z,.5),v+vec3(.5,.5+z,1.),f,i,n);
       r=r||m;
     }
   if(x>=67.&&x<=82.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,n),r=r||m;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float z=8.,c=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         z=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         c=16.;
       m=d(v+vec3(z,6.,7.)/16.,v+vec3(c,9.,9.)/16.,f,i,n);
       r=r||m;
       m=d(v+vec3(z,12.,7.)/16.,v+vec3(c,15.,9.)/16.,f,i,n);
       r=r||m;
     }
   if(x>=71.&&x<=82.)
     {
       float z=8.,c=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         c=16.;
       if(x>=75.&&x<=82.)
         z=0.;
       m=d(v+vec3(7.,6.,z)/16.,v+vec3(9.,9.,c)/16.,f,i,n);
       r=r||m;
       m=d(v+vec3(7.,12.,z)/16.,v+vec3(9.,15.,c)/16.,f,i,n);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 z=vec3(0),c=vec3(0);
       if(x==83.)
         z=vec3(0,0,0),c=vec3(16,16,3);
       if(x==84.)
         z=vec3(0,0,13),c=vec3(16,16,16);
       if(x==86.)
         z=vec3(0,0,0),c=vec3(3,16,16);
       if(x==85.)
         z=vec3(13,0,0),c=vec3(16,16,16);
       m=d(v+z/16.,v+c/16.,f,i,n);
       r=r||m;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 z=vec3(0.),c=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float h=0.;
           if(x>=91.&&x<=94.)
             h=13.;
           z=vec3(0.,h,0.)/16.;
           c=vec3(16.,h+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float h=13.;
           if(x==97.||x==98.)
             h=0.;
           z=vec3(0.,0.,h)/16.;
           c=vec3(16.,16.,h+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float s=13.;
           if(x==99.||x==100.)
             s=0.;
           z=vec3(s,0.,0.)/16.;
           c=vec3(s+3.,16.,16.)/16.;
         }
       m=d(v+z,v+c,f,i,n);
       r=r||m;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 z=vec3(0.),c=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float s=float(x)-float(103.)+1.;
           c.y=s*2./16.;
         }
       if(x==111.)
         c.y=.0625;
       if(x==112.)
         z=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(x==113.)
         z=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       m=d(v+z,v+c,f,i,n);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 float e(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 float h(vec3 v,vec3 y)
 {
   return dot(abs(v-y),vec3(.3333));
 }
 vec3 c(vec2 v)
 {
   vec2 x=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   x=(floor(x*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,x).xyz,y=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+vec3(y)*mod(frameCounter,64.f),vec3(1.));
   return i;
 }
 vec3 R(float v,float m,float f,vec3 i)
 {
   vec3 r;
   r.x=f*cos(v);
   r.y=f*sin(v);
   r.z=m;
   vec3 x=abs(i.y)<.999?vec3(0,0,1):vec3(1,0,0),z=normalize(cross(i,vec3(0.,1.,1.))),c=cross(z,i);
   return z*r.x+c*r.y+i*r.z;
 }
 vec3 R(vec2 v,float x,vec3 y)
 {
   float z=2*3.14159*v.x,i=sqrt((1-v.y)/(1+(x*x-1)*v.y)),f=sqrt(1-i*i);
   return R(z,i,f,y);
 }
 float G(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 G(in vec2 v,in float x,in vec3 y)
 {
   float z=G(x),f=2*3.14159*v.x,i=pow(v.y,1.f/(z+1.f)),c=sqrt(1-i*i);
   return R(f,i,c,y);
 }
 float a(vec2 v)
 {
   return texture2DLod(colortex3,v,0).w;
 }
 float G(float v,float x)
 {
   return v/(x*20.01+1.);
 }
 vec2 a(vec2 v,float x)
 {
   vec2 z=v;
   mat2 m=mat2(cos(x),-sin(x),sin(x),cos(x));
   v=m*v;
   return v;
 }
 vec4 G(sampler2D v,float f,bool x,float i,float z,float y,float n)
 {
   GBufferData m=GetGBufferData();
   GBufferDataTransparent r=GetGBufferDataTransparent();
   bool s=r.depth<m.depth;
   if(s)
     m.normal=r.normal,m.smoothness=r.smoothness,m.metalness=0.,m.mcLightmap=r.mcLightmap,m.depth=r.depth;
   vec4 t=GetViewPosition(texcoord.xy,m.depth),L=gbufferModelViewInverse*vec4(t.xyz,1.),d=gbufferModelViewInverse*vec4(t.xyz,0.);
   vec3 e=normalize(t.xyz),o=normalize(d.xyz),U=normalize((gbufferModelViewInverse*vec4(m.normal,0.)).xyz);
   float w=GetDepthLinear(texcoord.xy),l=dot(-e,m.normal.xyz),p=1.-m.smoothness,V=p*p,b=R(m.smoothness,m.metalness);
   vec4 g=texture2DLod(colortex6,texcoord.xy,0);
   float A=Luminance(g.xyz);
   if(b<.001)
     return g;
   float T=f*.9;
   T*=min(V*15.,1.1);
   T*=mix(g.w,1.,1.);
   vec2 C=vec2(0.);
   if(x)
     {
       vec2 P=c(texcoord.xy).xy*.99+.005;
       C=P-.5;
     }
   float S=0.,Y=1.1,P=G(i,m.totalTexGrad)/(V+.0001),u=G(z,m.totalTexGrad);
   vec4 F=vec4(0.),D=vec4(0.);
   float I=0.;
   vec4 Z=vec4(vec3(y),1.);
   Z.xyz=vec3(.5);
   Z.xyz*=g.w*.95+.05;
   float N=m.smoothness;
   vec2 O=normalize(cross(m.normal,e).xy),q=a(O,1.5708);
   float H=1.-pow(1.-saturate(l),1.);
   O*=mix(.1675,.5,H);
   q*=mix(mix(.7,.7,V),.5,H);
   vec3 B=reflect(-e,m.normal);
   int E=0;
   for(int W=-1;W<=1;W++)
     {
       for(int k=-1;k<=1;k++)
         {
           vec2 j=vec2(W,k)+C;
           j=j.x*O+j.y*q;
           j*=T*1.5/vec2(viewWidth,viewHeight);
           vec2 M=texcoord.xy+j.xy;
           float K=length(j*vec2(viewWidth,viewHeight));
           if(K*.025>g.w+.1)
             {
               continue;
             }
           M=clamp(M,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
           vec4 J=texture2DLod(colortex6,M,0);
           vec3 Q=GetNormals(M);
           float X=GetDepthLinear(M),ab=pow(saturate(dot(B,reflect(-e,Q))),105./V),ac=exp(-(abs(X-w)*Y)),ad=exp(-(h(J.xyz,g.xyz)*S)),ae=exp(-abs(N-a(M))*u),af=ab*ac*ad*ae;
           F+=vec4(pow(length(J.xyz),Z.x)*normalize(J.xyz+1e-05),J.w)*af;
           I+=af;
           D+=J;
           E++;
         }
     }
   F/=I+.0001;
   F.xyz=pow(length(F.xyz),1./Z.x)*normalize(F.xyz+1e-06);
   vec4 j=F;
   if(I<.001)
     j=g;
   return j;
 }
 void main()
 {
   vec4 x=G(colortex6,15.,false,180.,40.,.1,0.);
   gl_FragData[0]=vec4(x);
 };





/* DRAWBUFFERS:6 */
