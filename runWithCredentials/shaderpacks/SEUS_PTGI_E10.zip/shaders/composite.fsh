#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/





in vec4 texcoord;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorTorchlight;
in vec3 colorSkyUp;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;

in vec3 worldLightVector;
in vec3 worldSunVector;

in float timeMidnight;

#include "lib/Uniforms.inc"
#include "lib/Common.inc"



/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////








vec2 GetNearFragment(vec2 coord, float depth, out float minDepth)
{
	
	
	vec2 texel = 1.0 / vec2(viewWidth, viewHeight);
	vec4 depthSamples;
	depthSamples.x = texture2D(depthtex1, coord + texel * vec2(1.0, 1.0)).x;
	depthSamples.y = texture2D(depthtex1, coord + texel * vec2(1.0, -1.0)).x;
	depthSamples.z = texture2D(depthtex1, coord + texel * vec2(-1.0, 1.0)).x;
	depthSamples.w = texture2D(depthtex1, coord + texel * vec2(-1.0, -1.0)).x;

	vec2 targetFragment = vec2(0.0, 0.0);

	if (depthSamples.x < depth)
		targetFragment = vec2(1.0, 1.0);
	if (depthSamples.y < depth)
		targetFragment = vec2(1.0, -1.0);
	if (depthSamples.z < depth)
		targetFragment = vec2(-1.0, 1.0);
	if (depthSamples.w < depth)
		targetFragment = vec2(-1.0, -1.0);


	minDepth = min(min(min(depthSamples.x, depthSamples.y), depthSamples.z), depthSamples.w);

	return coord + texel * targetFragment;
}






#include "lib/Materials.inc"
#include "lib/GBufferData.inc"




 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int e(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int e()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int y=v.x*v.y;
   return t(f(floor(pow(float(y),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int y=v.x*v.y;
   return e(f(floor(pow(float(y),.333333))));
 }
 vec3 v(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=e();
   ivec2 d=ivec2(v.x*f.x,v.y*f.y);
   float z=float(d.y/y),i=float(int(d.x+mod(f.x*z,y))/y);
   i+=floor(f.x*z/y);
   vec3 s=vec3(0.,0.,i);
   s.x=mod(d.x+mod(f.x*z,y),y);
   s.y=mod(d.y,y);
   s.xyz=floor(s.xyz);
   s/=y;
   s.xyz=s.xzy;
   return s;
 }
 vec2 s(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int y=e();
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,f.x);
   float c=i.x+x*y;
   r.y=i.y+floor(c/f.x)*y;
   r+=.5;
   r/=f;
   return r;
 }
 vec3 d(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 s=ivec2(2048,2048);
   int x=s.x*s.y,y=f();
   ivec2 d=ivec2(i.x*s.x,i.y*s.y);
   float z=float(d.y/y),r=float(int(d.x+mod(s.x*z,y))/y);
   r+=floor(s.x*z/y);
   vec3 m=vec3(0.,0.,r);
   m.x=mod(d.x+mod(s.x*z,y),y);
   m.y=mod(d.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 f=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,f.x);
   float c=i.x+x*y;
   r.y=i.y+floor(c/f.x)*y;
   r+=.5;
   r/=f;
   r.xy*=.5;
   return r;
 }
 vec3 e(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 n(vec3 v)
 {
   int y=f();
   v=v-vec3(.5);
   v*=y;
   return v;
 }
 vec3 x(vec3 v)
 {
   int y=e();
   v*=1./y;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 r(vec3 v)
 {
   int y=e();
   v=v-vec3(.5);
   v*=y;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,y=floor(v-.0001),z=floor(i-.0001);
   return y-z;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 d,vec2 y,vec4 i,vec4 s,inout float x,out vec2 r)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(s.x==8||s.x==9||s.x==79||s.x<1.||!z||s.x==20.||s.x==171.||min(abs(f.x),abs(f.z))>.2)
     x=1.;
   if(s.x==50.||s.x==76.)
     {
       x=0.;
       if(f.y<.5)
         x=1.;
     }
   if(s.x==51)
     x=0.;
   if(s.x>255)
     x=0.;
   vec3 c,t;
   if(f.x>.5)
     c=vec3(0.,0.,-1.),t=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       c=vec3(0.,0.,1.),t=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         c=vec3(1.,0.,0.),t=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           c=vec3(1.,0.,0.),t=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             c=vec3(1.,0.,0.),t=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               c=vec3(-1.,0.,0.),t=vec3(0.,-1.,0.);
   r=clamp((d.xy-y.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,w=.15;
   if(s.x==10.||s.x==11.)
     {
       if(abs(f.y)<.01&&z||f.y>.99)
         h=.1,w=.1,x=0.;
       else
          x=1.;
     }
   if(s.x==51)
     h=.5,w=.1;
   if(s.x==76)
     h=.2,w=.2;
   if(s.x-255.+39.>=103.&&s.x-255.+39.<=113.)
     w=.025,h=.025;
   c=normalize(i.xyz);
   t=normalize(cross(c,f.xyz)*sign(i.w));
   vec3 n=v.xyz+mix(c*h,-c*h,vec3(r.x));
   n.xyz+=mix(t*h,-t*h,vec3(r.y));
   n.xyz-=f.xyz*w;
   return n;
 }struct ChqUiAvDkU{vec3 vSNsAVOjDa;vec3 vSNsAVOjDaOrigin;vec3 UgsYTfdINL;vec3 LkVOyZfKEL;vec3 ZPrwqHNnFV;vec3 nqlOapzPzv;};
 ChqUiAvDkU p(Ray v)
 {
   ChqUiAvDkU f;
   f.vSNsAVOjDa=floor(v.origin);
   f.vSNsAVOjDaOrigin=f.vSNsAVOjDa;
   f.UgsYTfdINL=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.LkVOyZfKEL=sign(v.direction);
   f.ZPrwqHNnFV=(sign(v.direction)*(f.vSNsAVOjDa-v.origin)+sign(v.direction)*.5+.5)*f.UgsYTfdINL;
   f.nqlOapzPzv=vec3(0.);
   return f;
 }
 void i(inout ChqUiAvDkU v)
 {
   v.nqlOapzPzv=step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.yzx)*step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.zxy),v.ZPrwqHNnFV+=v.nqlOapzPzv*v.UgsYTfdINL,v.vSNsAVOjDa+=v.nqlOapzPzv*v.LkVOyZfKEL;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float y)
 {
   float x,z,r,t;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),r);
   y=min(min(y,z),t);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,s=y-z,r=vec3(0.);
   r+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-i.x),x);
   r+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-i.y),x);
   r+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray s,out vec2 i)
 {
   vec3 y=s.inv_direction*(v-s.origin),x=s.inv_direction*(f-s.origin),d=min(x,y),c=max(x,y);
   vec2 r=max(d.xx,d.yz);
   float z=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float m=min(r.x,r.y);
   i.x=z;
   i.y=m;
   return m>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray s,inout float y,inout vec3 x)
 {
   vec3 z=s.inv_direction*(v-s.origin),i=s.inv_direction*(f-s.origin),c=min(i,z),t=max(i,z);
   vec2 r=max(c.xx,c.yz);
   float m=max(r.x,r.y);
   r=min(t.xx,t.yz);
   float n=min(r.x,r.y);
   bool w=n>max(m,0.)&&max(m,0.)<y;
   if(w)
     x=d(v,f,s.origin+s.direction*m),y=m;
   return w;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 d=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float t=abs(d.x*256.-(v.y+cameraPosition.y)),c=GetCausticsComposite(v,f,t),w=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*c,1.-w);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 i=n(v),s=m(i+y*.99);
   float t=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*t),3).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float w=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*t),3).x;
   vec3 c=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   c*=c;
   r=mix(r,r*c,vec3(1.-w));
   #endif
   return r*(1.-rainStrength);
 }
 vec3 i(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float t=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*t),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float w=shadow2DLod(shadowtex0,vec3(i.xy-vec2(.5,0.),i.z-.0006*t),3).x;
   vec3 s=texture2DLod(shadowcolor,vec2(i.xy-vec2(.5,0.)),3).xyz;
   s*=s;
   r=mix(r,r*s,vec3(1.-w));
   #endif
   return r*(1.-rainStrength);
 }struct SgvRpoZFEp{float hBzGxfOWHl;float rPdSyvYhOi;float AqljTTtzgc;float IiJpNLRFqV;vec3 AChndccCtU;};
 vec4 h(SgvRpoZFEp v)
 {
   vec4 f;
   v.AChndccCtU=max(vec3(0.),v.AChndccCtU);
   f.x=v.hBzGxfOWHl;
   v.AChndccCtU=pow(v.AChndccCtU,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.AChndccCtU.x,v.AqljTTtzgc);
   f.z=PackTwo16BitTo32Bit(v.AChndccCtU.y,v.IiJpNLRFqV);
   f.w=PackTwo16BitTo32Bit(v.AChndccCtU.z,v.rPdSyvYhOi);
   return f;
 }
 SgvRpoZFEp w(vec4 v)
 {
   SgvRpoZFEp f;
   vec2 s=UnpackTwo16BitFrom32Bit(v.y),i=UnpackTwo16BitFrom32Bit(v.z),t=UnpackTwo16BitFrom32Bit(v.w);
   f.hBzGxfOWHl=v.x;
   f.AqljTTtzgc=s.y;
   f.IiJpNLRFqV=i.y;
   f.rPdSyvYhOi=t.y;
   f.AChndccCtU=pow(vec3(s.x,i.x,t.x),vec3(8.));
   return f;
 }
 SgvRpoZFEp G(vec2 v)
 {
   vec2 y=1./vec2(viewWidth,viewHeight),z=vec2(viewWidth,viewHeight);
   v=(floor(v*z)+.5)*y;
   return w(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool G(vec3 v,float y,Ray f,bool z,inout float i,inout vec3 x)
 {
   bool r=false,s=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(z)
     return false;
   if(y>=67.)
     return false;
   s=d(v,v+vec3(1.,1.,1.),f,i,x);
   r=s;
   #else
   if(y<40.)
     return s=d(v,v+vec3(1.,1.,1.),f,i,x),s;
   if(y==40.||y==41.||y>=43.&&y<=54.)
     {
       float c=.5;
       if(y==41.)
         c=.9375;
       s=d(v+vec3(0.,0.,0.),v+vec3(1.,c,1.),f,i,x);
       r=r||s;
     }
   if(y==42.||y>=55.&&y<=66.)
     s=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,x),r=r||s;
   if(y==43.||y==46.||y==47.||y==52.||y==53.||y==54.||y==55.||y==58.||y==59.||y==64.||y==65.||y==66.)
     {
       float c=.5;
       if(y==55.||y==58.||y==59.||y==64.||y==65.||y==66.)
         c=0.;
       s=d(v+vec3(0.,c,0.),v+vec3(.5,.5+c,.5),f,i,x);
       r=r||s;
     }
   if(y==43.||y==45.||y==48.||y==51.||y==53.||y==54.||y==55.||y==57.||y==60.||y==63.||y==65.||y==66.)
     {
       float c=.5;
       if(y==55.||y==57.||y==60.||y==63.||y==65.||y==66.)
         c=0.;
       s=d(v+vec3(.5,c,0.),v+vec3(1.,.5+c,.5),f,i,x);
       r=r||s;
     }
   if(y==44.||y==45.||y==49.||y==51.||y==52.||y==54.||y==56.||y==57.||y==61.||y==63.||y==64.||y==66.)
     {
       float c=.5;
       if(y==56.||y==57.||y==61.||y==63.||y==64.||y==66.)
         c=0.;
       s=d(v+vec3(.5,c,.5),v+vec3(1.,.5+c,1.),f,i,x);
       r=r||s;
     }
   if(y==44.||y==46.||y==50.||y==51.||y==52.||y==53.||y==56.||y==58.||y==62.||y==63.||y==64.||y==65.)
     {
       float c=.5;
       if(y==56.||y==58.||y==62.||y==63.||y==64.||y==65.)
         c=0.;
       s=d(v+vec3(0.,c,.5),v+vec3(.5,.5+c,1.),f,i,x);
       r=r||s;
     }
   if(y>=67.&&y<=82.)
     s=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,x),r=r||s;
   if(y==68.||y==69.||y==70.||y==72.||y==73.||y==74.||y==76.||y==77.||y==78.||y==80.||y==81.||y==82.)
     {
       float c=8.,t=8.;
       if(y==68.||y==70.||y==72.||y==74.||y==76.||y==78.||y==80.||y==82.)
         c=0.;
       if(y==69.||y==70.||y==73.||y==74.||y==77.||y==78.||y==81.||y==82.)
         t=16.;
       s=d(v+vec3(c,6.,7.)/16.,v+vec3(t,9.,9.)/16.,f,i,x);
       r=r||s;
       s=d(v+vec3(c,12.,7.)/16.,v+vec3(t,15.,9.)/16.,f,i,x);
       r=r||s;
     }
   if(y>=71.&&y<=82.)
     {
       float c=8.,t=8.;
       if(y>=71.&&y<=74.||y>=79.&&y<=82.)
         t=16.;
       if(y>=75.&&y<=82.)
         c=0.;
       s=d(v+vec3(7.,6.,c)/16.,v+vec3(9.,9.,t)/16.,f,i,x);
       r=r||s;
       s=d(v+vec3(7.,12.,c)/16.,v+vec3(9.,15.,t)/16.,f,i,x);
       r=r||s;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=83.&&y<=86.)
     {
       vec3 c=vec3(0),t=vec3(0);
       if(y==83.)
         c=vec3(0,0,0),t=vec3(16,16,3);
       if(y==84.)
         c=vec3(0,0,13),t=vec3(16,16,16);
       if(y==86.)
         c=vec3(0,0,0),t=vec3(3,16,16);
       if(y==85.)
         c=vec3(13,0,0),t=vec3(16,16,16);
       s=d(v+c/16.,v+t/16.,f,i,x);
       r=r||s;
     }
   if(y>=87.&&y<=102.)
     {
       vec3 c=vec3(0.),t=vec3(1.);
       if(y>=87.&&y<=94.)
         {
           float w=0.;
           if(y>=91.&&y<=94.)
             w=13.;
           c=vec3(0.,w,0.)/16.;
           t=vec3(16.,w+3.,16.)/16.;
         }
       if(y>=95.&&y<=98.)
         {
           float w=13.;
           if(y==97.||y==98.)
             w=0.;
           c=vec3(0.,0.,w)/16.;
           t=vec3(16.,16.,w+3.)/16.;
         }
       if(y>=99.&&y<=102.)
         {
           float w=13.;
           if(y==99.||y==100.)
             w=0.;
           c=vec3(w,0.,0.)/16.;
           t=vec3(w+3.,16.,16.)/16.;
         }
       s=d(v+c,v+t,f,i,x);
       r=r||s;
     }
   if(y>=103.&&y<=113.)
     {
       vec3 c=vec3(0.),t=vec3(1.);
       if(y>=103.&&y<=110.)
         {
           float m=float(y)-float(103.)+1.;
           t.y=m*2./16.;
         }
       if(y==111.)
         t.y=.0625;
       if(y==112.)
         c=vec3(1.,0.,1.)/16.,t=vec3(15.,1.,15.)/16.;
       if(y==113.)
         c=vec3(1.,0.,1.)/16.,t=vec3(15.,.5,15.)/16.;
       s=d(v+c,v+t,f,i,x);
       r=r||s;
     }
   #endif
   #endif
   return r;
 }
 vec2 g(inout float v)
 {
   return fract(sin(vec2(v+=.1,v+=.1))*vec2(43758.5,22578.1));
 }
 vec3 c(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<8./viewWidth||v.x>1.-8./viewWidth||v.y<8./viewHeight||v.y>1.-8./viewHeight)
     ;
   else
      y+=f[int(mod(float(frameCounter),4.))]*.5;
   y=(floor(y*64.)+.5)/64.;
   vec3 x=texture2D(noisetex,y).xyz;
   return x;
 }
 vec3 G(vec3 v,inout float y,int x)
 {
   vec2 f=c(texcoord.xy+vec2(y+=.1,y+=.1)).xy;
   f=fract(f+g(y)*.1);
   float z=6.28319*f.x,i=sqrt(f.y);
   vec3 t=normalize(cross(v,vec3(0.,1.,1.))),r=cross(v,t),s=t*cos(z)*i+r*sin(z)*i+v.xyz*sqrt(1.-f.y);
   return s;
 }
 vec3 c(vec3 v,vec3 y)
 {
   vec2 f=s(x(n(v)+y+1.));
   vec3 r=G(f).AChndccCtU;
   return r;
 }
 vec3 G()
 {
   vec2 y=s(v(texcoord.xy)+d()/e());
   vec3 x=G(y).AChndccCtU;
   return x;
 }
 vec3 G(float v,float f,float y,vec3 i)
 {
   vec3 s;
   s.x=y*cos(v);
   s.y=y*sin(v);
   s.z=f;
   vec3 x=abs(i.y)<.999?vec3(0,0,1):vec3(1,0,0),c=normalize(cross(i,vec3(0.,1.,1.))),t=cross(c,i);
   return c*s.x+t*s.y+i*s.z;
 }
 vec3 c(vec2 v,float y,vec3 x)
 {
   float f=2*3.14159*v.x,z=sqrt((1-v.y)/(1+(y*y-1)*v.y)),i=sqrt(1-z*z);
   return G(f,z,i,x);
 }
 float l(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 e(in vec2 v,in float y,in vec3 x)
 {
   float f=l(y),i=2*3.14159*v.x,z=pow(v.y,1.f/(f+1.f)),c=sqrt(1-z*z);
   return G(i,z,c,x);
 }
 float g(float v,float y)
 {
   return 1./(v*(1.-y)+y);
 }
 void h(inout vec3 v,in vec3 f)
 {
   vec3 y=normalize(f.xyz),i=v;
   float x=dot(i,y);
   i=normalize(v-y*saturate(x)*.5);
   v=i;
 }
 vec4 R(in vec2 v)
 {
   float y=GetDepth(v);
   vec4 f=gbufferProjectionInverse*vec4(v.x*2.f-1.f,v.y*2.f-1.f,2.f*y-1.f,1.f);
   f/=f.w;
   return f;
 }
 vec4 R(in vec2 v,in float y)
 {
   vec4 f=gbufferProjectionInverse*vec4(v.x*2.f-1.f,v.y*2.f-1.f,2.f*y-1.f,1.f);
   f/=f.w;
   return f;
 }
 void G(inout vec3 v,in vec3 y,in vec3 f,vec3 x,float z)
 {
   float r=length(y);
   r*=pow(eyeBrightnessSmooth.y/240.f,6.f);
   r*=rainStrength;
   float i=pow(exp(-r*1e-05),4.);
   i=max(i,.5);
   vec3 c=vec3(dot(colorSkyUp,vec3(1.)))*.05;
   v=mix(c,v,vec3(i));
 }
 vec4 G(float v,float y,vec3 s,vec3 r,vec3 x,vec3 z,vec3 t,float w,float n)
 {
   float m=1.;
   #ifdef SUNLIGHT_LEAK_FIX
   if(isEyeInWater<1)
     m=saturate(n*100.);
   #endif
   v=max(v-.05,0.);
   y=0.;
   float h=v*v,l=fract(frameCounter*.0123456);
   vec3 a=c(texcoord.xy).xyz*.99+.005,o=c(texcoord.xy+.1).xyz,U=reflect(t,e(a.xy,h,x)),T=normalize((gbufferModelView*vec4(U.xyz,0.)).xyz);
   if(dot(U,x)<0.)
     U=reflect(U,x);
   #ifdef REFLECTION_SCREEN_SPACE_TRACING
   bool g=false;
   {
     const int R=32;
     vec2 b=texcoord.xy;
     vec3 L=r.xyz;
     float C=0.;
     vec3 V=r.xyz;
     float S=.05/saturate(dot(-t,x)+.001),P=S*2.,k=1.,Y=0.;
     for(int D=0;D<R;D++)
       {
         float A=float(D),u=(A+.5)/float(R);
         vec3 F=T.xyz*S*(.1+length(V)*.1)*k;
         float I=P*(length(V)*.1);
         V+=F;
         vec2 E=ProjectBack(V).xy;
         vec3 N=GetViewPosition(E.xy,GetDepth(E.xy)).xyz;
         float Z=length(V)-length(N)-.02;
         if(V.z>0.)
           {
             break;
           }
         if(Z>0.&&Z<I&&E.x>0.&&E.x<1.&&E.y>0.&&E.y<1.)
           {
             V-=F;
             k*=.5;
             Y+=1.;
             if(Y>2.)
               {
                 g=true;
                 b=E.xy;
                 L=N.xyz;
                 C=distance(V,r.xyz)*.4;
                 break;
               }
           }
       }
     vec3 D=(gbufferModelViewInverse*vec4(L,0.)).xyz;
     if(length(D)>far)
       g=false;
     if(g)
       {
         b.xy=floor(b.xy*vec2(viewWidth,viewHeight)+.5)/vec2(viewWidth,viewHeight);
         TemporalJitterProjPos01(b);
         vec3 F=pow(texture2DLod(colortex3,b.xy,0).xyz,vec3(2.2)),E=F*100.;
         LandAtmosphericScattering(E,L,T,U,worldSunVector,1.);
         G(E,L,normalize(r.xyz),normalize(s.xyz),1.);
         UnderwaterFog(E,length(L),t,colorSkyUp,colorSunlight);
         return vec4(E,saturate(C/4.));
       }
   }
   #endif
   int V=f(),L=e();
   vec3 E=s+x*(.01+w*.1);
   E+=Fract01(cameraPosition.xyz+.5);
   Ray R=MakeRay(e(E,V)*V-vec3(1.),U);
   vec3 S=vec3(1.),b=vec3(0.);
   float D=0.;
   ChqUiAvDkU F=p(R);
   float C=far;
   vec3 N=vec3(1.);
   for(int A=0;A<1;A++)
     {
       vec4 P=vec4(0.);
       vec3 Y=vec3(0.);
       float k=.5;
       for(int Z=0;Z<REFLECTION_TRACE_LENGTH;Z++)
         {
           Y=F.vSNsAVOjDa/float(V);
           vec2 I=d(Y,V);
           P=texture2DLod(shadowcolor,I,0);
           D=P.w*255.;
           float u=1.-step(.5,abs(D-241.));
           vec3 M=P.xyz;
           float O=dot(F.vSNsAVOjDa+.5-R.origin,F.vSNsAVOjDa+.5-R.origin),H=saturate(pow(saturate(dot(R.direction,normalize(F.vSNsAVOjDa+.5-R.origin))),56.*O)*5.-1.)*5.;
           b+=M*u*k*.5*H;
           if(D<240.)
             {
               if(G(F.vSNsAVOjDa,D,R,Z==0,C,N))
                 {
                   break;
                 }
             }
           i(F);
           k=1.;
         }
       if(P.w*255.<1.f||P.w*255.>254.f)
         {
           vec3 Z=SkyShading(R.direction,worldSunVector,rainStrength);
           Z=DoNightEyeAtNight(Z*12.,timeMidnight)*.083333;
           Z=TintUnderwaterDepth(Z);
           b+=Z*.1;
           C=1000.;
           break;
         }
       vec3 Z=mod(R.origin+R.direction*C,vec3(1.))-.5;
       vec2 I=vec2(0.);
       I+=vec2(Z.z*-N.x,-Z.y)*abs(N.x);
       I+=vec2(Z.x,Z.z*N.y)*abs(N.y);
       I+=vec2(Z.x*N.z,-Z.y)*abs(N.z);
       vec3 u=(R.origin+R.direction*C)/float(V);
       vec2 O=textureSize(colortex0,0);
       vec4 M=texture2DLod(shadowcolor1,d(Y,V),0);
       vec2 H=M.xy;
       H=(floor(H*O/TEXTURE_RESOLUTION)+.5)/(O/TEXTURE_RESOLUTION);
       vec2 q=H+I.xy*(TEXTURE_RESOLUTION/O);
       vec3 B=pow(texture2D(colortex0,q).xyz,vec3(2.2));
       B*=mix(vec3(1.),P.xyz/(M.w+1e-05),vec3(M.z));
       if(D<240.)
         {
           vec3 W=saturate(P.xyz);
           S*=B;
         }
       if(abs(D-31.)<.1)
         b+=.09*S*GI_LIGHT_BLOCK_INTENSITY;
       vec3 W=vec3(0.),j=vec3(0.);
       if(abs(N.x)>.5)
         W=vec3(0.,1.,0.),j=vec3(0.,0.,1.);
       if(abs(N.y)>.5)
         W=vec3(1.,0.,0.),j=vec3(0.,0.,1.);
       if(abs(N.z)>.5)
         W=vec3(1.,0.,0.),j=vec3(0.,1.,0.);
       W*=1.;
       j*=1.;
       vec3 K=c(Y,N),X=K,J=saturate(K*100000.),Q=c(Y+W/float(V),N);
       X+=Q;
       J+=saturate(Q*100000.);
       vec3 ab=c(Y-W/float(V),N);
       X+=ab;
       J+=saturate(ab*100000.);
       vec3 ac=c(Y+j/float(V),N);
       X+=ac;
       J+=saturate(ac*100000.);
       vec3 ad=c(Y-j/float(V),N);
       X+=ad;
       J+=saturate(ad*100000.);
       X/=J+vec3(.0001);
       b+=X*S;
       const float ae=2.4;
       vec3 af=e(E+R.direction*C-1.,worldLightVector,N,U,V)*S*ae*colorSunlight*m;
       if(isEyeInWater>0)
         ;
       b+=af;
     }
   vec3 Z=r.xyz+T*C,Y=(gbufferModelViewInverse*vec4(Z.xyz,0.)).xyz;
   if(C<1000.)
     LandAtmosphericScattering(b,Z,T,U,worldSunVector,1.);
   G(b,Z,normalize(r.xyz),normalize(s.xyz),1.);
   UnderwaterFog(b,length(Y),t,colorSkyUp,colorSunlight);
   C*=saturate(dot(-t,x))*2.;
   return vec4(b,saturate(C/4.));
 }
 vec4 T(float v)
 {
   float y=v*v,f=y*v;
   vec4 r;
   r.x=-f+3*y-3*v+1;
   r.y=3*f-6*y+4;
   r.z=-3*f+3*y+3*v+1;
   r.w=f;
   return r/6.f;
 }
 vec4 T(in sampler2D v,in vec2 f)
 {
   vec2 y=vec2(viewWidth,viewHeight);
   f*=y;
   f-=.5;
   float s=fract(f.x),i=fract(f.y);
   f.x-=s;
   f.y-=i;
   vec4 c=T(s),t=T(i),x=vec4(f.x-.5,f.x+1.5,f.y-.5,f.y+1.5),r=vec4(c.x+c.y,c.z+c.w,t.x+t.y,t.z+t.w),d=x+vec4(c.y,c.w,t.y,t.w)/r,z=texture2DLod(v,vec2(d.x,d.z)/y,0),w=texture2DLod(v,vec2(d.y,d.z)/y,0),h=texture2DLod(v,vec2(d.x,d.w)/y,0),a=texture2DLod(v,vec2(d.y,d.w)/y,0);
   float n=r.x/(r.x+r.y),V=r.z/(r.z+r.w);
   return mix(mix(a,h,n),mix(w,z,n),V);
 }
 bool i(vec3 v,vec3 y)
 {
   vec3 x=normalize(cross(dFdx(v),dFdy(v))),i=normalize(y-v),t=normalize(i);
   return distance(v,y)<.05;
 }
 vec3 y(vec2 v)
 {
   vec2 y=vec2(viewWidth,viewHeight),x=1./y,f=v*y,i=floor(f-.5)+.5,t=f-i,z=t*t,c=t*z;
   float s=.5;
   vec2 r=-s*c+2.*s*z-s*t,m=(2.-s)*c-(3.-s)*z+1.,w=-(2.-s)*c+(3.-2.*s)*z+s*t,d=s*c-s*z,n=m+w,a=x*(i+w/n);
   vec3 h=texture2DLod(colortex4,vec2(a.x,a.y),0).xyz;
   vec2 Z=x*(i-1.),V=x*(i+2.);
   vec4 R=vec4(texture2DLod(colortex4,vec2(a.x,Z.y),0).xyz,1.)*(n.x*r.y)+vec4(texture2DLod(colortex4,vec2(Z.x,a.y),0).xyz,1.)*(r.x*n.y)+vec4(h,1.)*(n.x*n.y)+vec4(texture2DLod(colortex4,vec2(V.x,a.y),0).xyz,1.)*(d.x*n.y)+vec4(texture2DLod(colortex4,vec2(a.x,V.y),0).xyz,1.)*(n.x*d.y);
   return max(vec3(0.),R.xyz*(1./R.w));
 }
 void main()
 {
   GBufferData v=GetGBufferData();
   GBufferDataTransparent y=GetGBufferDataTransparent();
   MaterialMask f=CalculateMasks(v.materialID),i=CalculateMasks(y.materialID);
   bool x=y.depth<v.depth;
   if(x)
     v.depth=y.depth,v.normal=y.normal,v.smoothness=y.smoothness,v.metalness=0.,v.mcLightmap=y.mcLightmap,i.sky=0.;
   vec4 r=GetViewPosition(texcoord.xy,v.depth),s=gbufferModelViewInverse*vec4(r.xyz,1.),c=gbufferModelViewInverse*vec4(r.xyz,0.);
   vec3 t=normalize(r.xyz),d=normalize(c.xyz),z=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz),w=normalize((gbufferModelViewInverse*vec4(v.geoNormal,0.)).xyz);
   float a=length(r.xyz);
   vec4 m=vec4(0.);
   float Z=G(v.smoothness,v.metalness);
   if(Z>.0001&&i.sky<.5)
     m=G(1.-v.smoothness,v.metalness,s.xyz,r.xyz,z.xyz,w,d.xyz,f.leaves,v.mcLightmap.y);
   vec4 n=texture2DLod(colortex3,texcoord.xy,0);
   vec3 h=n.xyz;
   h.xyz=pow(h.xyz,vec3(2.2));
   if(x)
     {
       vec3 R=GetViewPosition(texcoord.xy,texture2DLod(depthtex1,texcoord.xy,0).x).xyz;
       float e=length(R.xyz),V=e-a;
       vec3 N=y.normal-y.geoNormal*1.05;
       float S=saturate(V*.5);
       vec2 E=texcoord.xy+N.xy/(a+1.5)*S;
       {
         float p=ExpToLinearDepth(texture2DLod(depthtex1,E,0).x),Y=ExpToLinearDepth(texture2DLod(depthtex0,E,0).x);
         if(Y>=p)
           E=texcoord.xy;
       }
       h.xyz=pow(texture2DLod(colortex3,E.xy,0).xyz,vec3(2.2));
       R=GetViewPosition(E.xy,texture2DLod(depthtex1,E.xy,0).x).xyz;
       r=GetViewPosition(E.xy,texture2DLod(depthtex0,E.xy,0).x);
       e=length(R.xyz);
       a=length(r.xyz);
       V=e-a;
       if(i.water>.5&&isEyeInWater<1)
         {
           h.xyz*=exp(GetWaterAbsorption()*-V);
           vec3 b=GetWaterFogColor()*.001;
           b*=exp(-GetWaterAbsorption()*((-d.y*.5+.5)*3.));
           b*=pow(curve(saturate(mix(d.y,1.,.5))),2.)*.6+.4;
           b*=(colorSkyUp+colorSunlight*2.)*1.4;
           b=TintUnderwaterDepth(b);
           float Y=exp(-V*.03);
           b*=exp(-GetWaterAbsorption()*(1.-Y)*20.);
           b*=eyeBrightnessSmooth.y/240.;
           h=mix(b,h,vec3(Y));
         }
       if(i.stainedGlass>.5)
         {
           vec3 U=normalize(y.albedo.xyz+.0001)*pow(length(y.albedo.xyz),.5);
           h.xyz*=mix(vec3(1.),U,vec3(pow(y.albedo.w,.2)));
           h.xyz*=mix(vec3(1.),U,vec3(pow(y.albedo.w,.2)));
         }
     }
   h.xyz=pow(h.xyz,vec3(1./2.2));
   m.xyz=saturate(m.xyz);
   gl_FragData[0]=texture2DLod(colortex0,texcoord.xy,0);
   gl_FragData[1]=vec4(h.xyz,v.smoothness);
   gl_FragData[2]=m;
 };




/* DRAWBUFFERS:036 */
