#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/




in vec4 texcoord;


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBufferData.inc"




 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=d();
   ivec2 n=ivec2(v.x*f.x,v.y*f.y);
   float z=float(n.y/y),i=float(int(n.x+mod(f.x*z,y))/y);
   i+=floor(f.x*z/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(n.x+mod(f.x*z,y),y);
   m.y=mod(n.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 r(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 f=v.xzy*x;
   f=floor(f+1e-05);
   float y=f.z;
   vec2 i;
   i.x=mod(f.x+y*x,m.x);
   float s=f.x+y*x;
   i.y=f.y+floor(s/m.x)*x;
   i+=.5;
   i/=m;
   return i;
 }
 vec3 x(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 n=ivec2(i.x*m.x,i.y*m.y);
   float z=float(n.y/y),r=float(int(n.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 s=vec3(0.,0.,r);
   s.x=mod(n.x+mod(m.x*z,y),y);
   s.y=mod(n.y,y);
   s.xyz=floor(s.xyz);
   s/=y;
   s.xyz=s.xzy;
   return s;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 f=v.xzy*y;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 i;
   i.x=mod(f.x+x*y,m.x);
   float s=f.x+x*y;
   i.y=f.y+floor(s/m.x)*y;
   i+=.5;
   i/=m;
   i.xy*=.5;
   return i;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 n()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,y=floor(v-.0001),i=floor(x-.0001);
   return y-i;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 n,vec2 m,vec4 i,vec4 x,inout float y,out vec2 s)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(x.x==8||x.x==9||x.x==79||x.x<1.||!r||x.x==20.||x.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(x.x==50.||x.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(x.x==51)
     y=0.;
   if(x.x>255)
     y=0.;
   vec3 z,c;
   if(f.x>.5)
     z=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       z=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         z=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           z=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             z=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               z=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   s=clamp((n.xy-m.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,L=.15;
   if(x.x==10.||x.x==11.)
     {
       if(abs(f.y)<.01&&r||f.y>.99)
         h=.1,L=.1,y=0.;
       else
          y=1.;
     }
   if(x.x==51)
     h=.5,L=.1;
   if(x.x==76)
     h=.2,L=.2;
   if(x.x-255.+39.>=103.&&x.x-255.+39.<=113.)
     L=.025,h=.025;
   z=normalize(i.xyz);
   c=normalize(cross(z,f.xyz)*sign(i.w));
   vec3 e=v.xyz+mix(z*h,-z*h,vec3(s.x));
   e.xyz+=mix(c*h,-c*h,vec3(s.y));
   e.xyz-=f.xyz*L;
   return e;
 }struct ChqUiAvDkU{vec3 vSNsAVOjDa;vec3 vSNsAVOjDaOrigin;vec3 UgsYTfdINL;vec3 LkVOyZfKEL;vec3 ZPrwqHNnFV;vec3 nqlOapzPzv;};
 ChqUiAvDkU e(Ray v)
 {
   ChqUiAvDkU f;
   f.vSNsAVOjDa=floor(v.origin);
   f.vSNsAVOjDaOrigin=f.vSNsAVOjDa;
   f.UgsYTfdINL=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.LkVOyZfKEL=sign(v.direction);
   f.ZPrwqHNnFV=(sign(v.direction)*(f.vSNsAVOjDa-v.origin)+sign(v.direction)*.5+.5)*f.UgsYTfdINL;
   f.nqlOapzPzv=vec3(0.);
   return f;
 }
 void i(inout ChqUiAvDkU v)
 {
   v.nqlOapzPzv=step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.yzx)*step(v.ZPrwqHNnFV.xyz,v.ZPrwqHNnFV.zxy),v.ZPrwqHNnFV+=v.nqlOapzPzv*v.UgsYTfdINL,v.vSNsAVOjDa+=v.nqlOapzPzv*v.LkVOyZfKEL;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float x)
 {
   float y,z,r,c;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   c=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,y),r);
   x=min(min(x,z),c);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,n=y-z,r=vec3(0.);
   r+=vec3(sign(n.x),0.,0.)*step(abs(abs(n.x)-i.x),x);
   r+=vec3(0.,sign(n.y),0.)*step(abs(abs(n.y)-i.y),x);
   r+=vec3(0.,0.,sign(n.z))*step(abs(abs(n.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),n=min(x,y),c=max(x,y);
   vec2 r=max(n.xx,n.yz);
   float z=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float s=min(r.x,r.y);
   i.x=z;
   i.y=s;
   return s>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 y)
 {
   vec3 i=m.inv_direction*(v-m.origin),z=m.inv_direction*(f-m.origin),n=min(z,i),c=max(z,i);
   vec2 r=max(n.xx,n.yz);
   float s=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float h=min(r.x,r.y);
   bool t=h>max(s,0.)&&max(s,0.)<x;
   if(t)
     y=d(v,f,m.origin+m.direction*s),x=s;
   return t;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float c=abs(n.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,c),t=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-t);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 f,vec3 x,vec3 y,vec3 z,int i)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 n=v(f),c=m(n+y*.99);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z-.0006*s),3).x;
   r*=saturate(dot(x,y));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(c.xy-vec2(.5,0.),c.z-.0006*s),3).x;
   vec3 h=texture2DLod(shadowcolor,vec2(c.xy-vec2(.5,0.)),3).xyz;
   h*=h;
   r=mix(r,r*h,vec3(1.-t));
   #endif
   return r*(1.-rainStrength);
 }
 vec3 i(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float n=shadow2DLod(shadowtex0,vec3(i.xy-vec2(.5,0.),i.z-.0006*s),3).x;
   vec3 h=texture2DLod(shadowcolor,vec2(i.xy-vec2(.5,0.)),3).xyz;
   h*=h;
   r=mix(r,r*h,vec3(1.-n));
   #endif
   return r*(1.-rainStrength);
 }struct SgvRpoZFEp{float hBzGxfOWHl;float rPdSyvYhOi;float AqljTTtzgc;float IiJpNLRFqV;vec3 AChndccCtU;};
 vec4 w(SgvRpoZFEp v)
 {
   vec4 f;
   v.AChndccCtU=max(vec3(0.),v.AChndccCtU);
   f.x=v.hBzGxfOWHl;
   v.AChndccCtU=pow(v.AChndccCtU,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.AChndccCtU.x,v.AqljTTtzgc);
   f.z=PackTwo16BitTo32Bit(v.AChndccCtU.y,v.IiJpNLRFqV);
   f.w=PackTwo16BitTo32Bit(v.AChndccCtU.z,v.rPdSyvYhOi);
   return f;
 }
 SgvRpoZFEp h(vec4 v)
 {
   SgvRpoZFEp f;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),i=UnpackTwo16BitFrom32Bit(v.z),x=UnpackTwo16BitFrom32Bit(v.w);
   f.hBzGxfOWHl=v.x;
   f.AqljTTtzgc=m.y;
   f.IiJpNLRFqV=i.y;
   f.rPdSyvYhOi=x.y;
   f.AChndccCtU=pow(vec3(m.x,i.x,x.x),vec3(8.));
   return f;
 }
 SgvRpoZFEp c(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return h(texture2DLod(colortex5,v,0));
 }
 float c(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool c(vec3 v,float x,Ray y,bool f,inout float i,inout vec3 r)
 {
   bool m=false,s=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(f)
     return false;
   if(x>=67.)
     return false;
   s=d(v,v+vec3(1.,1.,1.),y,i,r);
   m=s;
   #else
   if(x<40.)
     return s=d(v,v+vec3(1.,1.,1.),y,i,r),s;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float z=.5;
       if(x==41.)
         z=.9375;
       s=d(v+vec3(0.,0.,0.),v+vec3(1.,z,1.),y,i,r);
       m=m||s;
     }
   if(x==42.||x>=55.&&x<=66.)
     s=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),y,i,r),m=m||s;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float z=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         z=0.;
       s=d(v+vec3(0.,z,0.),v+vec3(.5,.5+z,.5),y,i,r);
       m=m||s;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float z=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         z=0.;
       s=d(v+vec3(.5,z,0.),v+vec3(1.,.5+z,.5),y,i,r);
       m=m||s;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float z=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         z=0.;
       s=d(v+vec3(.5,z,.5),v+vec3(1.,.5+z,1.),y,i,r);
       m=m||s;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float z=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         z=0.;
       s=d(v+vec3(0.,z,.5),v+vec3(.5,.5+z,1.),y,i,r);
       m=m||s;
     }
   if(x>=67.&&x<=82.)
     s=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,y,i,r),m=m||s;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float z=8.,c=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         z=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         c=16.;
       s=d(v+vec3(z,6.,7.)/16.,v+vec3(c,9.,9.)/16.,y,i,r);
       m=m||s;
       s=d(v+vec3(z,12.,7.)/16.,v+vec3(c,15.,9.)/16.,y,i,r);
       m=m||s;
     }
   if(x>=71.&&x<=82.)
     {
       float z=8.,c=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         c=16.;
       if(x>=75.&&x<=82.)
         z=0.;
       s=d(v+vec3(7.,6.,z)/16.,v+vec3(9.,9.,c)/16.,y,i,r);
       m=m||s;
       s=d(v+vec3(7.,12.,z)/16.,v+vec3(9.,15.,c)/16.,y,i,r);
       m=m||s;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 z=vec3(0),c=vec3(0);
       if(x==83.)
         z=vec3(0,0,0),c=vec3(16,16,3);
       if(x==84.)
         z=vec3(0,0,13),c=vec3(16,16,16);
       if(x==86.)
         z=vec3(0,0,0),c=vec3(3,16,16);
       if(x==85.)
         z=vec3(13,0,0),c=vec3(16,16,16);
       s=d(v+z/16.,v+c/16.,y,i,r);
       m=m||s;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 z=vec3(0.),c=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float h=0.;
           if(x>=91.&&x<=94.)
             h=13.;
           z=vec3(0.,h,0.)/16.;
           c=vec3(16.,h+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float n=13.;
           if(x==97.||x==98.)
             n=0.;
           z=vec3(0.,0.,n)/16.;
           c=vec3(16.,16.,n+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float n=13.;
           if(x==99.||x==100.)
             n=0.;
           z=vec3(n,0.,0.)/16.;
           c=vec3(n+3.,16.,16.)/16.;
         }
       s=d(v+z,v+c,y,i,r);
       m=m||s;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 z=vec3(0.),c=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float n=float(x)-float(103.)+1.;
           c.y=n*2./16.;
         }
       if(x==111.)
         c.y=.0625;
       if(x==112.)
         z=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(x==113.)
         z=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       s=d(v+z,v+c,y,i,r);
       m=m||s;
     }
   #endif
   #endif
   return m;
 }
 float e(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 void main()
 {
   SgvRpoZFEp v=c(texcoord.xy);
   float x=v.IiJpNLRFqV;
   vec4 f=texture2DLod(colortex6,texcoord.xy,0);
   vec3 m=f.xyz;
   float z=Luminance(m.xyz);
   vec3 y=GetNormals(texcoord.xy);
   float s=GetDepthLinear(texcoord.xy);
   vec2 r=vec2(0.);
   float i=4.,n=sin(frameTimeCounter)>0.?1.:0.;
   vec4 h=vec4(0.),e=vec4(0.);
   float t=0.;
   int L=0;
   for(int a=-1;a<=1;a++)
     {
       for(int R=-1;R<=1;R++)
         {
           vec2 d=(vec2(a,R)+r)/vec2(viewWidth,viewHeight)*i,o=texcoord.xy+d.xy;
           o=clamp(o,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
           vec4 U=texture2DLod(colortex6,o,0);
           h+=U;
           e+=U*U;
           L++;
         }
     }
   h/=L+1e-06;
   e/=L+1e-06;
   vec3 U=h.xyz;
   float R=dot(h.xyz,vec3(1.));
   vec4 d=sqrt(max(vec4(0.),e-h*h));
   float o=dot(d.xyz,vec3(6.));
   if(t<.0001)
     U=m;
   gl_FragData[0]=vec4(f.xyz,o);
 };




/* DRAWBUFFERS:6 */
