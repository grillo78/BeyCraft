#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT fsh
#define DEFERRED 1


#include "/program/deferred/D1_Raytrace.glsl"