#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT fsh
#define GBUFFERS_SKYBASIC


#if   PROG_SKYBASIC == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.glsl"
#elif PROG_SKYBASIC == G_OPAQUE
#include "/program/gbuffers/gbuffers_opaque.glsl"
#elif PROG_SKYBASIC == G_TRANSPARENT
#include "/program/gbuffers/gbuffers_transparent.glsl"
#endif