#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT gsh
#define COMPOSITE 0


#include "/program/composite/C0_Init.glsl"