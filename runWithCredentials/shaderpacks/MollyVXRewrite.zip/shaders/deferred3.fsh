#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT fsh
#define DEFERRED 3


#include "/program/deferred/D3_D8_FilterSpatial.glsl"