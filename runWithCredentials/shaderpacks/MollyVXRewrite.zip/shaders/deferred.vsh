#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT vsh
#define DEFERRED 0


#include "/program/deferred/D0_Precompute_Sky.glsl"