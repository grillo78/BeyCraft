struct gbuffer {
    mat2x4 color;
    mat2x3 normal;
    mat2x3 specular;
    mat2   lightmap;
    vec2   depthtex;
    ivec2  materialIDs;
    float  shadowed;
    bool   forwardSolidMask;
    bool   gbufferForward;
};

struct material {
    vec2 roughness;
    vec2 reflectiveness;
    vec2 F0;
    vec2 metalness;
    vec2 emissiveness;

    float land;

    float water;
    float translucent;
    float emitter;
};

gbuffer calculateGbufferInformation(mat2 coord) {
    gbuffer info;

    info.color[0]         = texture2DLod(colortex0, coord[1], 0.0);
    info.color[1]         = texture2DLod(colortex3, coord[0], 0.0);

    info.depthtex.x       = texture2D(depthtex0, coord[0]).x;
    info.depthtex.y       = texture2D(depthtex1, coord[1]).x;

    info.forwardSolidMask = info.color[1].a >= 1.0;
    info.gbufferForward   = info.depthtex.y > info.depthtex.x;

    vec4  passthrough1    = texture2DLod(colortex1, coord[1], 0.0);
    vec4  passthrough2    = texture2DLod(colortex2, coord[0], 0.0);

    vec3  lightInfo1      = decode3x16(passthrough1.y);
    vec3  lightInfo2      = decode3x16(passthrough2.y);

    vec3  matInfo1        = decode3x16(passthrough1.z);
    vec3  matInfo2        = decode3x16(passthrough2.z);

    if (!info.gbufferForward) {
        passthrough2 = passthrough1;
        lightInfo2   = lightInfo1;
        matInfo2     = matInfo1;
    }

    if (info.forwardSolidMask) {
        info.depthtex.y = info.depthtex.x;
        passthrough1    = passthrough2;
        lightInfo1      = lightInfo2;
        matInfo1        = matInfo2;
    }

    info.normal[0]        = decodeNormal3x16(passthrough1.x);
    info.normal[1]        = decodeNormal3x16(passthrough2.x);
    
    info.specular[0]      = toLinear(matInfo1);
    info.specular[1]      = toLinear(matInfo2);

    info.lightmap[0]      = pow2(lightInfo1.xy);
    info.lightmap[1]      = pow2(lightInfo2.xy);

    info.shadowed         = passthrough1.a * 2.0 - 1.0;

    info.materialIDs.x    = decodeMaterialIDs(lightInfo1.z);
    info.materialIDs.y    = decodeMaterialIDs(lightInfo2.z);

    return info;
}

material calculateMaterialMasks(mat2x3 specular, mat2x4 albedo, vec2 depthtex, ivec2 materialIDs, bool forward) {
    const vec2 roughnessRestraints = vec2(0.005, 1.0);
    material mat;

    mat.land             = float(depthtex.y < 1.0);

    mat.water            = getMaterialID(materialIDs.y, 1);
    mat.translucent      = getMaterialID(materialIDs.x, 2);
    mat.emitter          = getMaterialID(materialIDs.x, 3);

    mat.roughness.x      = clamp(pow2(1.0 - specular[0].r), roughnessRestraints.x, roughnessRestraints.y);
    mat.roughness.y      = forward ? pow2(0.001) : clamp(pow2(1.0 - specular[1].r), roughnessRestraints.x, roughnessRestraints.y);
    mat.reflectiveness.x = specular[1].r;
    mat.reflectiveness.y = forward ? 1.0 : specular[1].r;
    mat.F0.x             = mix(0.02, 1.0, specular[0].g);
    mat.F0.y             = forward ? 0.02 : mix(0.02, 1.0, specular[1].g);
    mat.metalness.x      = specular[0].g;
    mat.metalness.y      = specular[1].g;
    mat.emissiveness.x   = Emissive_Mapping == Resource_Pack ? specular[0].b * 15.0 : pow(min1(length(albedo[0].rgb * 0.8)), 4.0) * 5.0 * mat.emitter;
    mat.emissiveness.y   = Emissive_Mapping == Resource_Pack ? specular[1].b * 15.0 : pow(min1(length(albedo[1].rgb * 0.8)), 4.0) * 5.0 * mat.emitter;

    return mat;
}