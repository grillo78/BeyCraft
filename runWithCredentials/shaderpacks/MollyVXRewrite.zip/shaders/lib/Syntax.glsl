#if   FORMAT == vsh

    #define attribute in
    //#define inout out

#elif FORMAT == gsh

    //#define inout in

#elif FORMAT == fsh

    //#define inout in

#endif