//Constants
const float atmosphere_MuS_min = -0.35;

const int resMu  = 64;
const int resV   = 16;
const int resR   = 32;
const int resMuS = 32;

const ivec4 res4D = ivec4(resMu, resV, resR, resMuS);
const ivec2 res2D = ivec2(resMu * resR, resV * resMuS);

//----------------------------------------------------------------------------//

const float atmosphere_planetRadius = 6531e3; // m^1

const float atmosphere_mieg = 0.5; // unitless

// Limits
const float atmosphere_lowerLimitAltitude = -10e3; // m^1
const float atmosphere_upperLimitAltitude = 80e3; // m^1

// Distribution
const vec2 atmosphere_scaleHeights = vec2(8.0e3, 1.2e3); // m^1

// Coefficients
const float airNumberDensity       = 2.5035422e25; // m^3
const float ozoneConcentrationPeak = 8e-6; // unitless
const float ozoneNumberDensity     = airNumberDensity * exp(-35e3 / 8e3) * ozoneConcentrationPeak; // m^3 | airNumberDensity ASL * relative density at altitude of peak ozone concentration * peak ozone concentration
const vec3  ozoneCrossSection      = vec3(4.51103766177301E-21, 3.2854797958699E-21, 1.96774621921165E-22); // cm^2 -> m^2 | single-wavelength values.

const vec3 atmosphere_coefficientRayleigh = vec3(5.8000e-6, 1.3500e-5, 14.3100e-5);  // m^3 | Want to calculate this myself at some point. | 1 / wavelength^4
const vec3 atmosphere_coefficientOzone    = ozoneCrossSection * ozoneNumberDensity; // m^3 | ozone cross section * ozone number density
const vec3 atmosphere_coefficientMie      = vec3(2.6000e-6, 2.6000e-6, 2.6000e-6);  // m^3 | Should be >= 2e-6, depends heavily on conditions. Current value is just one that looks good.

//--// The rest are set from the above constants //---------------------------//

// Limits
const float atmosphere_lowerLimitRadius = atmosphere_planetRadius + atmosphere_lowerLimitAltitude;
const float atmosphere_upperLimitRadius = atmosphere_planetRadius + atmosphere_upperLimitAltitude;

const float atmosphere_lowerLimitRadiusSquared = atmosphere_lowerLimitRadius * atmosphere_lowerLimitRadius;
const float atmosphere_upperLimitRadiusSquared = atmosphere_upperLimitRadius * atmosphere_upperLimitRadius;

// Distribution
const vec2 atmosphere_inverseScaleHeights = 1.0 / atmosphere_scaleHeights;
const vec2 atmosphere_scaledPlanetRadius  = atmosphere_planetRadius / atmosphere_scaleHeights;

// Coefficients
const mat2x3 atmosphere_coefficientsScattering  = mat2x3(atmosphere_coefficientRayleigh, atmosphere_coefficientMie);
const mat3   atmosphere_coefficientsAttenuation = mat3(atmosphere_coefficientRayleigh, atmosphere_coefficientMie * 1.11, atmosphere_coefficientOzone); // commonly called the extinction coefficient


// Phases
float PhaseRayleigh(float cosTheta) {
	return (cosTheta * cosTheta + 1.0) * 0.375 / TAU;
}
float PhaseMie(float cosTheta, float g) {
	float gg = g * g;
	float p1 = (0.375 * (1.0 - gg)) / (PI * (2.0 + gg));
	float p2 = (cosTheta * cosTheta + 1.0) * pow(-2.0 * g * cosTheta + 1.0 + gg, -1.5);
	return p1 * p2;
}


// Transmittance Lookup
bool AtmosphereRayIntersectsLowerLimit(float R, float Mu) {
	return Mu < 0.0 && R * R * (Mu * Mu - 1.0) + atmosphere_lowerLimitRadiusSquared >= 0.0;
}
float AtmosphereDistanceToUpperLimit(float R, float Mu) {
	float discriminant = R * R * (Mu * Mu - 1.0) + atmosphere_upperLimitRadiusSquared;
	return -R * Mu + sqrt(discriminant);
}
float AtmosphereDistanceToLowerLimit(float R, float Mu) {
	float discriminant = R * R * (Mu * Mu - 1.0) + atmosphere_lowerLimitRadiusSquared;
	return -R * Mu - sqrt(discriminant);
}

vec2 AtmosphereTransmittanceLookupUv(float R, float Mu) {
	const float H = sqrt(atmosphere_upperLimitRadiusSquared - atmosphere_lowerLimitRadiusSquared);

	float rho = sqrt(R * R - atmosphere_lowerLimitRadiusSquared);

	float d = AtmosphereDistanceToUpperLimit(R, Mu);
	float dMin = atmosphere_upperLimitRadius - R;
	float dMax = rho + H;

	float uvMu = (d - dMin) / (dMax - dMin);
	float uvR  = rho / H;

	return vec2(uvMu, uvR);
}
void AtmosphereTransmittanceLookupUvReverse(vec2 coord, out float R, out float Mu) {
	float uvMu = coord.x;
	float uvR  = coord.y;

	const float H = sqrt(atmosphere_upperLimitRadiusSquared - atmosphere_lowerLimitRadiusSquared);

	float rho = H * uvR;
	R = sqrt(rho * rho + atmosphere_lowerLimitRadiusSquared);

	float dMin = atmosphere_upperLimitRadius - R;
	float dMax = rho + H;
	float d = dMin + uvMu * (dMax - dMin);
	Mu = d == 0.0 ? 1.0 : (H * H - rho * rho - d * d) / (2.0 * R * d);
}

vec4 AtmosphereScatteringLookupUv(float R, float Mu, float MuS, float V) {
	const float H = sqrt(atmosphere_upperLimitRadiusSquared - atmosphere_lowerLimitRadiusSquared);

	float rho = sqrt(R * R - atmosphere_lowerLimitRadiusSquared);
	float uvR = AddUvMargin(rho / H, resR);

	float RMu = R * Mu;
	float discriminant = RMu * RMu - R * R + atmosphere_lowerLimitRadiusSquared;
	float uvMu = 0.5;
	if (AtmosphereRayIntersectsLowerLimit(R, Mu)) {
		float d = -RMu - sqrt(discriminant);
		float dMin = R - atmosphere_lowerLimitRadius;
		float dMax = rho;
		uvMu -= 0.5 * AddUvMargin(dMax == dMin ? 0.0 : (d - dMin) / (dMax - dMin), resMu / 2);
	} else {
		float d = -RMu + sqrt(discriminant + H * H);
		float dMin = atmosphere_upperLimitRadius - R;
		float dMax = rho + H;
		uvMu += 0.5 * AddUvMargin((d - dMin) / (dMax - dMin), resMu / 2);
	}

	float d = AtmosphereDistanceToUpperLimit(atmosphere_lowerLimitRadius, MuS);
	float dMin = atmosphere_upperLimitRadius - atmosphere_lowerLimitRadius;
	float dMax = H;
	float a = (d - dMin) / (dMax - dMin);
	float A = -2.0 * atmosphere_MuS_min * atmosphere_lowerLimitRadius / (dMax - dMin);
	float uvMuS = AddUvMargin(max0((1.0 - a / A)) / (1.0 + a), resMuS);

	float uvV = AddUvMargin((V + 1.0) / 2.0, resV);

	return vec4(uvMu, uvV, uvR, uvMuS);
}
void AtmosphereScatteringLookupUvReverse(vec4 coord, out float R, out float Mu, out float MuS, out float V) {
	float uvMu  = coord.x;
	float uvV   = RemoveUvMargin(coord.y, resV);
	float uvR   = RemoveUvMargin(coord.z, resR);
	float uvMuS = RemoveUvMargin(coord.w, resMuS);

	const float H = sqrt(atmosphere_upperLimitRadiusSquared - atmosphere_lowerLimitRadiusSquared);

	float rho = H * uvR;
	R = sqrt(rho * rho + atmosphere_lowerLimitRadiusSquared);

	if (uvMu < 0.5) {
		float dMin = R - atmosphere_lowerLimitRadius;
		float dMax = rho;
		float d = dMin + (dMax - dMin) * RemoveUvMargin(1.0 - 2.0 * uvMu, resMu / 2);
		Mu = d == 0.0 ? -1.0 : -(rho * rho + d * d) / (2.0 * R * d);
	} else {
		float dMin = atmosphere_upperLimitRadius - R;
		float dMax = rho + H;
		float d = dMin + (dMax - dMin) * RemoveUvMargin(2.0 * uvMu - 1.0, resMu / 2);
		Mu = d == 0.0 ? 1.0 : (H * H - rho * rho - d * d) / (2.0 * R * d);
	}

	float dMin = atmosphere_upperLimitRadius - atmosphere_lowerLimitRadius;
	float dMax = H;
	float A = -2.0 * atmosphere_MuS_min * atmosphere_lowerLimitRadius / (dMax - dMin);
	float a = (A - uvMuS * A) / (1.0 + uvMuS * A);
	float d = dMin + min(a, A) * (dMax - dMin);
	MuS = d == 0.0 ? 1.0 : (H * H - d * d) / (2.0 * atmosphere_lowerLimitRadius * d);

	V = uvV * 2.0 - 1.0;
}


// Transmittance Lookup
vec3 TextureRGBE8(sampler2D sampler, vec2 coord, ivec2 resolution) {
	coord = coord * resolution - 0.5;
	ivec2 i = ivec2(floor(coord));
	vec2 f = coord - i;

	vec3 s0 = DecodeRGBE8(texelFetch(sampler, i + ivec2(0,0), 0));
	vec3 s1 = DecodeRGBE8(texelFetch(sampler, i + ivec2(1,0), 0));
	vec3 s2 = DecodeRGBE8(texelFetch(sampler, i + ivec2(0,1), 0));
	vec3 s3 = DecodeRGBE8(texelFetch(sampler, i + ivec2(1,1), 0));

	return mix(mix(s0, s1, f.x), mix(s2, s3, f.x), f.y);
}
vec3 TextureRGBE8(sampler2D sampler, vec2 coord) {
	return TextureRGBE8(sampler, coord, textureSize(sampler, 0));
}
vec3 AtmosphereTransmittance(sampler2D sampler, float coreDistance, float cosViewZenithAngle) {
	vec2 coord = AtmosphereTransmittanceLookupUv(coreDistance, cosViewZenithAngle);
	     coord = AddUvMargin(coord, textureSize(sampler, 0));
	return TextureRGBE8(sampler, coord);
}
vec3 AtmosphereTransmittance(sampler2D sampler, float coreDistance, float cosViewZenithAngle, float distance) {
	// Transmittance from A to B is same as transmittance from B to A
	// Transmittance over a distance should always be done from the lowest point to the highest point.

	float endR  = sqrt(distance * distance + 2 * coreDistance * cosViewZenithAngle * distance + coreDistance * coreDistance);
	float endMu = (coreDistance * cosViewZenithAngle + distance) / endR;

	if (endR < coreDistance && cosViewZenithAngle < 0.0) {
		return AtmosphereTransmittance(sampler, endR, -endMu) / AtmosphereTransmittance(sampler, coreDistance, -cosViewZenithAngle);
	} else {
		return AtmosphereTransmittance(sampler, coreDistance, cosViewZenithAngle) / AtmosphereTransmittance(sampler, endR, endMu);
	}
}
vec3 AtmosphereTransmittance(sampler2D sampler, vec3 position, vec3 direction) {
	float coreDistance = length(position);
	return AtmosphereTransmittance(sampler, coreDistance, dot(position, direction) / coreDistance);
}
vec3 AtmosphereTransmittance(sampler2D sampler, vec3 position, vec3 direction, float distance) {
	float coreDistance = length(position);
	return AtmosphereTransmittance(sampler, coreDistance, dot(position, direction) / coreDistance, distance);
}


// Scatter Lookup
vec2 LookupUv4DTo2D(vec4 coord, const ivec4 resolution) {
	vec2 xy = coord.xy;
	ivec2 zw = ivec2(floor(coord.zw)) * resolution.xy;
	return xy + zw;
}
ivec2 LookupUv4DTo2D(ivec4 coord, const ivec4 resolution) {
	return coord.xy + coord.zw * resolution.xy;
}
vec4 Lookup2DTo4D(ivec2 texel, const ivec4 resolution) {
	vec2 uvXY = vec2(texel % resolution.xy) / resolution.xy;
	vec2 uvZW = floor(vec2(texel.xy) / vec2(resolution.xy)) / resolution.zw;

	return vec4(uvXY, uvZW);
}

vec3 Texture4DRGBE8(sampler2D sampler, vec4 coord, ivec4 res) {
	coord = coord * res - 0.5;
	ivec4 i = ivec4(floor(coord));
	vec4 f = coord - i;

	vec3 s0  = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(0,0,0,0), res), 0));
	vec3 s1  = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(1,0,0,0), res), 0));
	vec3 s2  = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(0,1,0,0), res), 0));
	vec3 s3  = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(1,1,0,0), res), 0));
	vec3 s4  = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(0,0,1,0), res), 0));
	vec3 s5  = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(1,0,1,0), res), 0));
	vec3 s6  = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(0,1,1,0), res), 0));
	vec3 s7  = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(1,1,1,0), res), 0));
	vec3 s8  = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(0,0,0,1), res), 0));
	vec3 s9  = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(1,0,0,1), res), 0));
	vec3 s10 = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(0,1,0,1), res), 0));
	vec3 s11 = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(1,1,0,1), res), 0));
	vec3 s12 = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(0,0,1,1), res), 0));
	vec3 s13 = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(1,0,1,1), res), 0));
	vec3 s14 = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(0,1,1,1), res), 0));
	vec3 s15 = DecodeRGBE8(texelFetch(sampler, LookupUv4DTo2D(i + ivec4(1,1,1,1), res), 0));

	return mix(
		mix(mix(mix(s0,  s1,  f.x), mix(s2,  s3,  f.x), f.y),
			mix(mix(s4,  s5,  f.x), mix(s6,  s7,  f.x), f.y),
			f.z),
		mix(mix(mix(s8,  s9,  f.x), mix(s10, s11, f.x), f.y),
			mix(mix(s12, s13, f.x), mix(s14, s15, f.x), f.y),
			f.z),
		f.w);
}

vec3 AtmosphereScattering(sampler2D samplerScattering, float R, float Mu, float MuS, float V) {
	vec4 uv = AtmosphereScatteringLookupUv(R, Mu, MuS, V);
	vec3 single_rayleigh = PhaseRayleigh(V)             * Texture4DRGBE8(samplerScattering, uv                , res4D);
	vec3 single_mie      = PhaseMie(V, atmosphere_mieg) * Texture4DRGBE8(samplerScattering, uv + vec4(0,0,0,1), res4D);
	vec3 multi           =                                Texture4DRGBE8(samplerScattering, uv + vec4(0,0,0,2), res4D);

	return clamp(single_rayleigh + single_mie + multi, 0.0, 1e35);
}
vec3 AtmosphereScattering(sampler2D samplerScattering, vec3 p, vec3 d, vec3 l) {
	float R   = length(p);
	float Mu  = dot(p, d) / R;
	float MuS = dot(p, l) / R;
	float V   = dot(d, l);

	return clamp(AtmosphereScattering(samplerScattering, R, Mu, MuS, V) * ((vec3(Atmosphere_Red, Atmosphere_Green, Atmosphere_Blue) / 255)) * Atmosphere_Brightness * 0.03, 0.0, 1e35);
}

vec3 AtmosphereScattering(sampler2D samplerScattering, sampler2D samplerTransmittance, vec3 p, vec3 d, vec3 l, float ed) {
	return clamp(AtmosphereScattering(samplerScattering, p, d, l) - AtmosphereScattering(samplerScattering, p + d * ed, d, l) * AtmosphereTransmittance(samplerTransmittance, p, d, ed), 0.0, 1e35);
}