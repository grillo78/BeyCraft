bool IntersectAABB(vec3 pos, vec3 dir, vec3 minBounds, vec3 maxBounds, out float dist, inout vec3 hitNormal) {
	vec3 minBoundsDist = (minBounds - pos) / dir;
	vec3 maxBoundsDist = (maxBounds - pos) / dir;

	vec3 minDists = min(minBoundsDist, maxBoundsDist);
	vec3 maxDists = max(minBoundsDist, maxBoundsDist);

	// Check if no intersection
/*
    if(minDists.x > maxDists.y
    || minDists.x > maxDists.z
    || minDists.y > maxDists.x
    || minDists.y > maxDists.z
    || minDists.z > maxDists.x
    || minDists.z > maxDists.y) {*/
    if(
    any(greaterThan(minDists,maxDists.yxx))||
    any(greaterThan(minDists,maxDists.zzx))) {
				return false;
	}

	// Intersect
	vec3 positiveDir = step(0.0, dir);
	vec3 dists = mix(maxBoundsDist, minBoundsDist, positiveDir);
	     dists = max0(dists);

/*
    if (dists.x > dists.y) {
        if (dists.x > dists.z) {
            dist = dists.x;
            hitNormal = vec3(-positiveDir.x * 2.0 + 1.0, 0.0, 0.0);
        } else {
            dist = dists.z;
            hitNormal = vec3(0.0, 0.0, -positiveDir.z * 2.0 + 1.0);
        }
    } else if (dists.y > dists.z) {
        dist = dists.y;
        hitNormal = vec3(0.0, -positiveDir.y * 2.0 + 1.0, 0.0);
    } else {
        dist = dists.z;
        hitNormal = vec3(0.0, 0.0, -positiveDir.z * 2.0 + 1.0);
    }
*/
    dist = max(max(dists.x,dists.y),dists.z);
    hitNormal = (-positiveDir * 2.0 + 1.0) * float(equal(dists,vec3(dist)));

	// Check to make sure we're not intersecting something in the wrong direction
	return dist > 0.0;
}

bool IntersectFluid(vec3 origin, ivec3 index, vec3 direction, int id, int dataValue, out vec3 hitPos, inout vec3 hitNormal) {
	// This is currently just so water doesn't look like garbage.
	float dist;
	if (IntersectAABB(origin - index, direction, vec3(0,0,0), vec3(1, 8.0/9.0, 1), dist, hitNormal)) {
		hitPos = dist * direction + origin;
		return true;
	}

	return false;
}
bool IntersectSlab(vec3 origin, ivec3 index, vec3 direction, int dataValue, out vec3 hitPos, inout vec3 hitNormal) {
	// Is a top half slab?
	bool topHalf = dataValue >= 8;

	vec3 minBounds = vec3(0, topHalf ? 0.5 : 0.0, 0);
	vec3 maxBounds = vec3(1, topHalf ? 1.0 : 0.5, 1);

	float dist;
	if (IntersectAABB(origin - index, direction, minBounds, maxBounds, dist, hitNormal)) {
		hitPos = dist * direction + origin;
		return true;
	}

	return false;
}
bool IntersectStairs(vec3 origin, ivec3 index, vec3 direction, int dataValue, out vec3 hitPos, inout vec3 hitNormal) {
	// Corner handling is so slow...

	// Is upside down?
	bool isUpsideDown = dataValue >= 4;
	// Stair direction
	int  facing       = dataValue % 4;

	vec3 slabMinBounds = vec3(0, isUpsideDown ? 0.5 : 0.0, 0);
	vec3 slabMaxBounds = vec3(1, isUpsideDown ? 1.0 : 0.5, 1);

	float slabDist;
	vec3 slabNormal;
	bool slabIntersected = IntersectAABB(origin - index, direction, slabMinBounds, slabMaxBounds, slabDist, slabNormal);

	// Inside corner check
	const ivec3[4] offs = ivec3[4](ivec3(1,0,0),ivec3(-1,0,0),ivec3(0,0,1),ivec3(0,0,-1));
	vec4[2] insideCornerVoxel = ReadVoxel(index + offs[facing]);
	int insideCornerId = ExtractVoxelId(insideCornerVoxel);

	bool icIsStair =
	insideCornerId == 53 ||
	insideCornerId == 67 ||
	insideCornerId == 108 ||
	insideCornerId == 109 ||
	insideCornerId == 114 ||
	insideCornerId == 128 ||
	insideCornerId == 134 ||
	insideCornerId == 135 ||
	insideCornerId == 136 ||
	insideCornerId == 156 ||
	insideCornerId == 163 ||
	insideCornerId == 164 ||
	insideCornerId == 180 ||
	insideCornerId == 203;

	vec3 stepMinBounds = vec3(facing == 0 ? 0.5 : 0.0, isUpsideDown ? 0.0 : 0.5, facing == 2 ? 0.5 : 0.0);
	vec3 stepMaxBounds = vec3(facing == 1 ? 0.5 : 1.0, isUpsideDown ? 0.5 : 1.0, facing == 3 ? 0.5 : 1.0);

	if (icIsStair) {
		int insideCornerDataValue = ExtractVoxelDataValue(insideCornerVoxel);
		bool icUpsideDown = insideCornerDataValue >= 4;
		int  icFacing     = insideCornerDataValue % 4;

		if (isUpsideDown == icUpsideDown && icIsStair) {
			if (facing == 0) {
				if (icFacing == 2) {
					stepMinBounds.z = 0.5;
				} else if (icFacing == 3) {
					stepMaxBounds.z = 0.5;
				}
			} else if (facing == 1) {
				if (icFacing == 2) {
					stepMinBounds.z = 0.5;
				} else if (icFacing == 3) {
					stepMaxBounds.z = 0.5;
				}
			} else if (facing == 2) {
				if (icFacing == 0) {
					stepMinBounds.x = 0.5;
				} else if (icFacing == 1) {
					stepMaxBounds.x = 0.5;
				}
			} else if (facing == 3) {
				if (icFacing == 0) {
					stepMinBounds.x = 0.5;
				} else if (icFacing == 1) {
					stepMaxBounds.x = 0.5;
				}
			}
		}
	}

	float stepDist;
	vec3 stepNormal;
	bool stepIntersected = IntersectAABB(origin - index, direction, stepMinBounds, stepMaxBounds, stepDist, stepNormal);

	// Outside corner check
	vec4[2] outsideCornerVoxel = ReadVoxel(index - offs[facing]);
	int outsideCornerId = ExtractVoxelId(outsideCornerVoxel);

	bool ocIsStair =
	outsideCornerId == 53 ||
	outsideCornerId == 67 ||
	outsideCornerId == 108 ||
	outsideCornerId == 109 ||
	outsideCornerId == 114 ||
	outsideCornerId == 128 ||
	outsideCornerId == 134 ||
	outsideCornerId == 135 ||
	outsideCornerId == 136 ||
	outsideCornerId == 156 ||
	outsideCornerId == 163 ||
	outsideCornerId == 164 ||
	outsideCornerId == 180 ||
	outsideCornerId == 203;

	vec3 cornerMinBounds = vec3(0.0, isUpsideDown ? 0.0 : 0.5, 0.0);
	vec3 cornerMaxBounds = vec3(0.0, isUpsideDown ? 0.5 : 1.0, 0.0);

	if (ocIsStair) {
		int outsideCornerDataValue = ExtractVoxelDataValue(outsideCornerVoxel);
		bool ocUpsideDown = outsideCornerDataValue >= 4;
		int  ocFacing     = outsideCornerDataValue % 4;

		if (isUpsideDown == ocUpsideDown) {
			if (facing == 0) {
				if (ocFacing == 2) {
					cornerMinBounds.xz = vec2(0.0, 0.5);
					cornerMaxBounds.xz = vec2(0.5, 1.0);
				} else if (ocFacing == 3) {
					cornerMinBounds.xz = vec2(0.0, 0.0);
					cornerMaxBounds.xz = vec2(0.5, 0.5);
				}
			} else if (facing == 1) {
				if (ocFacing == 2) {
					cornerMinBounds.xz = vec2(0.5, 0.5);
					cornerMaxBounds.xz = vec2(1.0, 1.0);
				} else if (ocFacing == 3) {
					cornerMinBounds.xz = vec2(0.5, 0.0);
					cornerMaxBounds.xz = vec2(1.0, 0.5);
				}
			} else if (facing == 2) {
				if (ocFacing == 0) {
					cornerMinBounds.xz = vec2(0.5, 0.0);
					cornerMaxBounds.xz = vec2(1.0, 0.5);
				} else if (ocFacing == 1) {
					cornerMinBounds.xz = vec2(0.0, 0.0);
					cornerMaxBounds.xz = vec2(0.5, 0.5);
				}
			} else if (facing == 3) {
				if (ocFacing == 0) {
					cornerMinBounds.xz = vec2(0.5, 0.5);
					cornerMaxBounds.xz = vec2(1.0, 1.0);
				} else if (ocFacing == 1) {
					cornerMinBounds.xz = vec2(0.0, 0.5);
					cornerMaxBounds.xz = vec2(0.5, 1.0);
				}
			}
		}
	}

	float cornerDist;
	vec3 cornerNormal;
	bool cornerIntersected = false;
	if (ocIsStair) {
		cornerIntersected = IntersectAABB(origin - index, direction, cornerMinBounds, cornerMaxBounds, cornerDist, cornerNormal);
	}

	if (slabIntersected) {
		if (stepIntersected && stepDist < slabDist) {
			if (cornerIntersected && cornerDist < stepDist) {
				hitPos = cornerDist * direction + origin;
				hitNormal = cornerNormal;
			} else {
				hitPos = stepDist * direction + origin;
				hitNormal = stepNormal;
			}
		} else if (cornerIntersected && cornerDist < slabDist) {
			hitPos = cornerDist * direction + origin;
			hitNormal = cornerNormal;
		} else {
			hitPos = slabDist * direction + origin;
			hitNormal = slabNormal;
		}

		return true;
	} else if (stepIntersected) {
		if (cornerIntersected && cornerDist < stepDist) {
			hitPos = cornerDist * direction + origin;
			hitNormal = cornerNormal;
		} else {
			hitPos = stepDist * direction + origin;
			hitNormal = stepNormal;
		}

		return true;
	} else if (cornerIntersected) {
		hitPos = cornerDist * direction + origin;
		hitNormal = cornerNormal;

		return true;
	}

	return false;
}
bool IntersectDoor(vec3 origin, ivec3 index, vec3 direction, int dataValue, out vec3 hitPos, inout vec3 hitNormal) {
	bool topHalf = dataValue >= 8;

	bool hingeRight;
	bool open;
	int  facing;

	if (topHalf) {
		hingeRight = dataValue % 2 == 1;

		int dv = ExtractVoxelDataValue(ReadVoxel(index - ivec3(0,1,0)));

		open = dv % 8 >= 4;
		facing = dv % 4;
	} else {
		open = dataValue % 8 >= 4;
		facing = dataValue % 4;

		hingeRight = ExtractVoxelDataValue(ReadVoxel(index + ivec3(0,1,0))) % 2 == 1;
	}

	facing = open ? (facing + (hingeRight ? -1 : 1)) % 4 : facing;

	vec3 minBounds = vec3(facing == 2 ? 0.8125 : 0.0, 0.0, facing == 3 ? 0.8125 : 0.0);
	vec3 maxBounds = vec3(facing == 0 ? 0.1875 : 1.0, 1.0, facing == 1 ? 0.1875 : 1.0);

	float dist;
	if (IntersectAABB(origin - index, direction, minBounds, maxBounds, dist, hitNormal)) {
		hitPos = dist * direction + origin;
		return true;
	}

	return false;
}
bool IntersectPressurePlate(vec3 origin, ivec3 index, vec3 direction, int dataValue, out vec3 hitPos, inout vec3 hitNormal) {
	bool isPresssed = dataValue >= 1;

	vec3 maxBounds = isPresssed ? vec3(0.9375, 0.03125, 0.9375) : vec3(0.9375, 0.0625, 0.9375);

	float dist;
	if (IntersectAABB(origin - index, direction, vec3(0.0625, 0, 0.0625), maxBounds, dist, hitNormal)) {
		hitPos = dist * direction + origin;
		return true;
	}

	return false;
}
bool IntersectButton(vec3 origin, ivec3 index, vec3 direction, int dataValue, out vec3 hitPos, inout vec3 hitNormal) {
	bool isPressed = dataValue >= 8;
	int  side      = dataValue % 8;

	vec3 minBounds, maxBounds;
	     if (side == 0) { minBounds = isPressed ? vec3(0.3125, 0.9375, 0.3750) : vec3(0.3125, 0.875, 0.3750); maxBounds = isPressed ? vec3(0.6875, 1.0000, 0.6250) : vec3(0.6875, 1.000, 0.6250); }
	else if (side == 1) { minBounds = isPressed ? vec3(0.0000, 0.3750, 0.3125) : vec3(0.0000, 0.375, 0.3125); maxBounds = isPressed ? vec3(0.0625, 0.6250, 0.6875) : vec3(0.1250, 0.625, 0.6875); }
	else if (side == 2) { minBounds = isPressed ? vec3(0.9375, 0.3750, 0.3125) : vec3(0.8750, 0.375, 0.3125); maxBounds = isPressed ? vec3(1.0000, 0.6250, 0.6875) : vec3(1.0000, 0.625, 0.6875); }
	else if (side == 3) { minBounds = isPressed ? vec3(0.3125, 0.3750, 0.0000) : vec3(0.3125, 0.375, 0.0000); maxBounds = isPressed ? vec3(0.6875, 0.6250, 0.0625) : vec3(0.6875, 0.625, 0.1250); }
	else if (side == 4) { minBounds = isPressed ? vec3(0.3125, 0.3750, 0.9375) : vec3(0.3125, 0.375, 0.8750); maxBounds = isPressed ? vec3(0.6875, 0.6250, 1.0000) : vec3(0.6875, 0.625, 1.0000); }
	else                { minBounds = isPressed ? vec3(0.3125, 0.0000, 0.3750) : vec3(0.3125, 0.000, 0.3750); maxBounds = isPressed ? vec3(0.6875, 0.0625, 0.6250) : vec3(0.6875, 0.125, 0.6250); }

	float dist;
	if (IntersectAABB(origin - index, direction, minBounds, maxBounds, dist, hitNormal)) {
		hitPos = dist * direction + origin;
		return true;
	}

	return false;
}
bool IntersectSnowLayer(vec3 origin, ivec3 index, vec3 direction, int dataValue, out vec3 hitPos, inout vec3 hitNormal) {
	vec3 minBounds = vec3(0, 0, 0) + index;
	vec3 maxBounds = vec3(1, dataValue * 0.125 + 0.125, 1) + index;

	float dist;
	if (IntersectAABB(origin, direction, minBounds, maxBounds, dist, hitNormal)) {
		hitPos = dist * direction + origin;
		return true;
	}

	return false;
}
bool IntersectFence(vec3 origin, ivec3 index, vec3 direction, int id, out vec3 hitPos, inout vec3 hitNormal) {
	bool intersected;
	float intersectDist;
	vec3 intersectNormal;

	// Post
	intersected = IntersectAABB(origin - index, direction, vec3(0.375,0,0.375), vec3(0.625,1,0.625), intersectDist, intersectNormal);

	// Check connected directions
	int idEast  = ExtractVoxelId(ReadVoxel(index + ivec3(1,0,0)));
	int idWest  = ExtractVoxelId(ReadVoxel(index - ivec3(1,0,0)));
	int idSouth = ExtractVoxelId(ReadVoxel(index + ivec3(0,0,1)));
	int idNorth = ExtractVoxelId(ReadVoxel(index - ivec3(0,0,1)));

	bool east  = idEast  != 0 && idEast  != 44 && idEast  != 53 && idEast  != 64 && idEast  != 70 && idEast  != 78 && idEast  != (id == 85 ? 113 : 85) && idEast  != 96 && idEast  != 118 && idEast  != 139 && idEast  != 145 && idEast  != 151 && idEast  != 171;
	bool west  = idWest  != 0 && idWest  != 44 && idWest  != 53 && idWest  != 64 && idWest  != 70 && idWest  != 78 && idWest  != (id == 85 ? 113 : 85) && idWest  != 96 && idWest  != 118 && idWest  != 139 && idWest  != 145 && idWest  != 151 && idWest  != 171;
	bool south = idSouth != 0 && idSouth != 44 && idSouth != 53 && idSouth != 64 && idSouth != 70 && idSouth != 78 && idSouth != (id == 85 ? 113 : 85) && idSouth != 96 && idSouth != 118 && idSouth != 139 && idSouth != 145 && idSouth != 151 && idSouth != 171;
	bool north = idNorth != 0 && idNorth != 44 && idNorth != 53 && idNorth != 64 && idNorth != 70 && idNorth != 78 && idNorth != (id == 85 ? 113 : 85) && idNorth != 96 && idNorth != 118 && idNorth != 139 && idNorth != 145 && idNorth != 151 && idNorth != 171;

	// temp holders
	float tDist;
	vec3 tNormal;

	// East-west connection
	if (east || west) {
		// Upper bar
		vec3 xUpperMin = vec3(west ? 0.0 : 0.5, 0.75,   0.4375);
		vec3 xUpperMax = vec3(east ? 1.0 : 0.5, 0.9375, 0.5625);
		if (IntersectAABB(origin - index, direction, xUpperMin, xUpperMax, tDist, tNormal)) {
			if (!intersected || tDist < intersectDist) {
				intersectDist = tDist;
				intersectNormal = tNormal;
			}
			intersected = true;
		}

		// Lower bar
		vec3 xLowerMin = vec3(west ? 0.0 : 0.5, 0.375,  0.4375);
		vec3 xLowerMax = vec3(east ? 1.0 : 0.5, 0.5625, 0.5625);
		if (IntersectAABB(origin - index, direction, xLowerMin, xLowerMax, tDist, tNormal)) {
			if (!intersected || tDist < intersectDist) {
				intersectDist = tDist;
				intersectNormal = tNormal;
			}
			intersected = true;
		}
	}

	// North-south connection
	if (south || north) {
		// Upper bar
		vec3 zUpperMin = vec3(0.4375, 0.75,   north ? 0.0 : 0.5);
		vec3 zUpperMax = vec3(0.5625, 0.9375, south ? 1.0 : 0.5);
		if (IntersectAABB(origin - index, direction, zUpperMin, zUpperMax, tDist, tNormal)) {
			if (!intersected || tDist < intersectDist) {
				intersectDist = tDist;
				intersectNormal = tNormal;
			}
			intersected = true;
		}

		// Lower bar
		vec3 zLowerMin = vec3(0.4375, 0.375,  north ? 0.0 : 0.5);
		vec3 zLowerMax = vec3(0.5625, 0.5625, south ? 1.0 : 0.5);
		if (IntersectAABB(origin - index, direction, zLowerMin, zLowerMax, tDist, tNormal)) {
			if (!intersected || tDist < intersectDist) {
				intersectDist = tDist;
				intersectNormal = tNormal;
			}
			intersected = true;
		}
	}

	if (intersected) {
		hitPos = intersectDist * direction + origin;
		hitNormal = intersectNormal;
	}

	return intersected;
}
bool IntersectTrapdoor(vec3 origin, ivec3 index, vec3 direction, int dataValue, out vec3 hitPos, inout vec3 hitNormal) {
	bool topHalf = dataValue >= 8;
	bool open = dataValue % 8 >= 4;
	int  side = dataValue % 4;

	vec3 minBounds = open ? vec3(side == 2 ? 0.8125 : 0.0, 0.0, side == 0 ? 0.8125 : 0.0) : vec3(0.0, topHalf ? 0.8125 : 0.0, 0.0);
	vec3 maxBounds = open ? vec3(side == 3 ? 0.1875 : 1.0, 1.0, side == 1 ? 0.1875 : 1.0) : vec3(1.0, topHalf ? 1.0 : 0.1875, 1.0);

	float dist;
	if (IntersectAABB(origin - index, direction, minBounds, maxBounds, dist, hitNormal)) {
		hitPos = dist * direction + origin;
		return true;
	}

	return false;
}
bool IntersectWall(vec3 origin, ivec3 index, vec3 direction, out vec3 hitPos, inout vec3 hitNormal) {
	bool intersected = false;
	float intersectDist;
	vec3 intersectNormal;

	// Check connected directions
	int idEast  = ExtractVoxelId(ReadVoxel(index + ivec3(1,0,0)));
	int idWest  = ExtractVoxelId(ReadVoxel(index - ivec3(1,0,0)));
	int idSouth = ExtractVoxelId(ReadVoxel(index + ivec3(0,0,1)));
	int idNorth = ExtractVoxelId(ReadVoxel(index - ivec3(0,0,1)));
	int idUp    = ExtractVoxelId(ReadVoxel(index + ivec3(0,1,0)));

	bool east  = idEast  != 0 && idEast  != 44 && idEast  != 53 && idEast  != 64 && idEast  != 70 && idEast  != 78 && idEast  != 85 && idEast  != 96 && idEast  != 113 && idEast  != 118 && idEast  != 145 && idEast  != 151 && idEast  != 171;
	bool west  = idWest  != 0 && idWest  != 44 && idWest  != 53 && idWest  != 64 && idWest  != 70 && idWest  != 78 && idWest  != 85 && idWest  != 96 && idWest  != 113 && idWest  != 118 && idWest  != 145 && idWest  != 151 && idWest  != 171;
	bool south = idSouth != 0 && idSouth != 44 && idSouth != 53 && idSouth != 64 && idSouth != 70 && idSouth != 78 && idSouth != 85 && idSouth != 96 && idSouth != 113 && idSouth != 118 && idSouth != 145 && idSouth != 151 && idSouth != 171;
	bool north = idNorth != 0 && idNorth != 44 && idNorth != 53 && idNorth != 64 && idNorth != 70 && idNorth != 78 && idNorth != 85 && idNorth != 96 && idNorth != 113 && idNorth != 118 && idNorth != 145 && idNorth != 151 && idNorth != 171;
	bool up    = idUp    != 0 && idUp    != 44 && idUp    != 53 && idUp    != 64 && idUp    != 70 && idUp    != 78 && idUp    != 85 && idUp    != 96 && idUp    != 113 && idUp    != 118 && idUp    != 145 && idUp    != 151 && idUp    != 171;

	// Post
	if (!((east && west && !south && !north) || (!east && !west && south && north)) || up) {
		intersected = IntersectAABB(origin - index, direction, vec3(0.25,0,0.25), vec3(0.75,1,0.75), intersectDist, intersectNormal);
	}

	// temp holders
	float tDist;
	vec3 tNormal;

	// East-west connection
	if (east || west) {
		vec3 minBounds = vec3(west ? 0.0 : 0.5, 0.0,   0.3125);
		vec3 maxBounds = vec3(east ? 1.0 : 0.5, 0.875, 0.6875);
		if (IntersectAABB(origin - index, direction, minBounds, maxBounds, tDist, tNormal)) {
			if (!intersected || tDist < intersectDist) {
				intersectDist = tDist;
				intersectNormal = tNormal;
				intersected = true;
			}
		}
	}

	// North-south connection
	if (south || north) {
		vec3 minBounds = vec3(0.3125, 0.0,   north ? 0.0 : 0.5);
		vec3 maxBounds = vec3(0.6875, 0.875, south ? 1.0 : 0.5);
		if (IntersectAABB(origin - index, direction, minBounds, maxBounds, tDist, tNormal)) {
			if (!intersected || tDist < intersectDist) {
				intersectDist = tDist;
				intersectNormal = tNormal;
				intersected = true;
			}
		}
	}

	if (intersected) {
		hitPos = intersectDist * direction + origin;
		hitNormal = intersectNormal;
	}

	return intersected;
}
bool IntersectAnvil(vec3 origin, ivec3 index, vec3 direction, int dataValue, out vec3 hitPos, inout vec3 hitNormal) {
	bool intersected = false;
	float intersectDist;
	vec3 intersectNormal;

	int facing = dataValue % 2;

	// Base
	intersected = IntersectAABB(origin - index, direction, vec3(0.125,0,0.125), vec3(0.875,0.25,0.875), intersectDist, intersectNormal);

	// temp holders
	float tDist;
	vec3 tNormal;

	vec3 minBounds = facing == 0 ? vec3(0.25, 0.25,   0.1875) : vec3(0.1875, 0.25,   0.25);
	vec3 maxBounds = facing == 0 ? vec3(0.75, 0.3125, 0.8125) : vec3(0.8125, 0.3125, 0.75);
	if (IntersectAABB(origin - index, direction, minBounds, maxBounds, tDist, tNormal)) {
		if (!intersected || tDist < intersectDist) {
			intersectDist = tDist;
			intersectNormal = tNormal;
			intersected = true;
		}
	}

	minBounds = facing == 0 ? vec3(0.375, 0.3125, 0.25) : vec3(0.25, 0.3125, 0.375);
	maxBounds = facing == 0 ? vec3(0.625, 0.625,  0.75) : vec3(0.75, 0.625,  0.625);
	if (IntersectAABB(origin - index, direction, minBounds, maxBounds, tDist, tNormal)) {
		if (!intersected || tDist < intersectDist) {
			intersectDist = tDist;
			intersectNormal = tNormal;
			intersected = true;
		}
	}

	minBounds = facing == 0 ? vec3(0.1875, 0.625, 0.0) : vec3(0.0, 0.625, 0.1875);
	maxBounds = facing == 0 ? vec3(0.8125, 1.0,   1.0) : vec3(1.0, 1.0,   0.8125);
	if (IntersectAABB(origin - index, direction, minBounds, maxBounds, tDist, tNormal)) {
		if (!intersected || tDist < intersectDist) {
			intersectDist = tDist;
			intersectNormal = tNormal;
			intersected = true;
		}
	}

	if (intersected) {
		hitPos = intersectDist * direction + origin;
		hitNormal = intersectNormal;
	}

	return intersected;
}
bool IntersectDaylightSensor(vec3 origin, ivec3 index, vec3 direction, out vec3 hitPos, inout vec3 hitNormal) {
	float dist;
	if (IntersectAABB(origin - index, direction, vec3(0,0,0), vec3(1, 0.375, 1), dist, hitNormal)) {
		hitPos = dist * direction + origin;
		return true;
	}

	return false;
}
bool IntersectCarpet(vec3 origin, ivec3 index, vec3 direction, out vec3 hitPos, inout vec3 hitNormal) {
	float dist;
	if (IntersectAABB(origin - index, direction, vec3(0,0,0), vec3(1, 0.0625, 1), dist, hitNormal)) {
		hitPos = dist * direction + origin;
		return true;
	}

	return false;
}
bool IntersectGrassPath(vec3 origin, ivec3 index, vec3 direction, out vec3 hitPos, inout vec3 hitNormal) {
	// TODO: Rename this function
	float dist;
	if (IntersectAABB(origin - index, direction, vec3(0,0,0), vec3(1, 0.9375, 1), dist, hitNormal)) {
		hitPos = dist * direction + origin;
		return true;
	}

	return false;
}
bool IntersectBlock(vec3 origin, ivec3 index, vec3 direction, out vec3 hitPos, inout vec3 hitNormal) {
	vec3 minBoundsDist = (      index - origin) / direction;
	vec3 maxBoundsDist = (1.0 + index - origin) / direction;

	vec3 positiveDir = step(0.0, direction);
	vec3 dists       = mix(maxBoundsDist, minBoundsDist, positiveDir);

	if (dists.x > dists.y) {
		if (dists.x > dists.z) {
			hitPos = dists.x * direction + origin;
			hitNormal = vec3(-positiveDir.x * 2.0 + 1.0, 0.0, 0.0);
		} else {
			hitPos = dists.z * direction + origin;
			hitNormal = vec3(0.0, 0.0, -positiveDir.z * 2.0 + 1.0);
		}
	} else if (dists.y > dists.z) {
		hitPos = dists.y * direction + origin;
		hitNormal = vec3(0.0, -positiveDir.y * 2.0 + 1.0, 0.0);
	} else {
		hitPos = dists.z * direction + origin;
		hitNormal = vec3(0.0, 0.0, -positiveDir.z * 2.0 + 1.0);
	}

	return true;
}

bool IntersectVoxel(vec3 origin, ivec3 index, vec3 direction, int id, inout vec3 hitPos, inout vec3 hitNormal) {
	// default value
	hitPos = origin;

    if(id ==   2
    || id ==   3
    || id ==   4
    || id ==   5
    || id ==   6
    || id ==   7
    || id ==   8
    || id ==  44
    || id ==  53
    || id ==  60
    || id ==  64
    || id ==  70
    || id ==  77
    || id ==  78
    || id ==  85
    || id ==  96
    || id == 113
    || id == 139
    || id == 145
    || id == 151
    || id == 171
    || id == 208
    ) { return false; }

	// Full blocks are always intersected
	return IntersectBlock(origin, index, direction, hitPos, hitNormal);
    return true;
}

bool RaytraceVoxel(vec3 origin, ivec3 originIndex, vec3 direction, bool transmit, const int maxSteps, out vec4[2] voxel, out vec3 hitPos, out vec3 hitNormal) {
    
	voxel = ReadVoxel(originIndex);

	int pid = ExtractVoxelId(voxel);
	if (pid > 0 && !transmit) {
		if (IntersectVoxel(origin, originIndex, direction, pid, hitPos, hitNormal)) {
			return true;
		}
	}
    
	ivec3 voxelIndex = originIndex;
	vec3 deltaDist;
	vec3 next;
	ivec3 deltaSign;
	for (int axis = 0; axis < 3; ++axis) {
		deltaDist[axis] = length(direction / direction[axis]);
		if (direction[axis] < 0.0) {
			deltaSign[axis] = -1;
			next[axis] = (origin[axis] - voxelIndex[axis]) * deltaDist[axis];
		} else {
			deltaSign[axis] = 1;
			next[axis] = (voxelIndex[axis] + 1.0 - origin[axis]) * deltaDist[axis];
		}
	}

	for (int i = 0; i < maxSteps; ++i) {
		if (next.x > next.y) {
			if (next.y > next.z) {
				next.z       += deltaDist.z;
				voxelIndex.z += deltaSign.z;
				hitNormal     = vec3(0, 0, -deltaSign.z);
			} else {
				next.y       += deltaDist.y;
				voxelIndex.y += deltaSign.y;
				hitNormal     = vec3(0, -deltaSign.y, 0);
			}
		} else if (next.x > next.z) {
			next.z       += deltaDist.z;
			voxelIndex.z += deltaSign.z;
			hitNormal     = vec3(0, 0, -deltaSign.z);
		} else {
			next.x       += deltaDist.x;
			voxelIndex.x += deltaSign.x;
			hitNormal     = vec3(-deltaSign.x, 0, 0);
		}

		if (!IsInVoxelizationVolume(voxelIndex)) { break; }

		voxel  = ReadVoxel(voxelIndex);
		int id = ExtractVoxelId(voxel);
		if(id ==   0
        || id ==   4
        || id ==   5
        || id ==   6
        || id ==   7
        || id ==   8
        || id ==  44
        || id ==  53
        || id ==  60
        || id ==  64
        || id ==  70
        || id ==  77
        || id ==  78
        || id ==  85
        || id ==  96
        || id == 113
        || id == 139
        || id == 145
        || id == 151
        || id == 171
        || id == 208
        ) {
            continue;
        } else {
			hitPos = origin + direction * maxof(next - deltaDist);
            return true;
		}
	}

	return false;
}
