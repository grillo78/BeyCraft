mat3 calculateTBN() {
	vec3 normal   = gl_NormalMatrix * gl_Normal;
	vec3 tangent  = gl_NormalMatrix * (at_tangent.xyz / at_tangent.w);
    return mat3(tangent, cross(tangent, normal), normal);
}