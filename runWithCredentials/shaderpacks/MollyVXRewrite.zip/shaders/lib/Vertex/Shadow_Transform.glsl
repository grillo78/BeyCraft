mat4 calculateShadowViewMatrix() {
    mat4 shadowViewMatrix = shadowModelView;

    #ifndef Telefocal_Shadows
        return shadowViewMatrix;
    #endif

    vec3 position = vec3(0.0, 0.0, 0.9998 * 2.0 - 1.0);
         position = projMAD(gbufferProjectionInverse, position) / (position.z * gbufferProjectionInverse[2].w + gbufferProjectionInverse[3].w);
         position = mat3(gbufferModelViewInverse) * position;

    shadowViewMatrix[3].xyz -= mat3(shadowViewMatrix) * position;

    return shadowViewMatrix;
}