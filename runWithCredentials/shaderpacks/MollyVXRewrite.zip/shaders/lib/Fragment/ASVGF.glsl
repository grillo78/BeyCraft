bool isReprojValid(vec2 coordPrevious, vec3 normal, vec3 normal_Previous, float depthtex, float depthtex_Previous) {
    if (clamp01(coordPrevious) != coordPrevious) return false;

    if (dot(normal, normal_Previous) < 0.06125) return false;

    if (abs(depthtex_Previous - depthtex) / abs(depthtex) > 0.1) return false;

    return true;
}

float ComputeWeight(
    float depthCenter, float depthP, float phiDepth,
    vec3 normalCenter, vec3 normalP, float normPower,
    float lumCenter, float lumP, float phiLum
) {
    float wNormal = pow(clamp01(dot(normalCenter, normalP)), normPower);
    float wDepth  = (phiDepth == 0) ? 0.0 : abs(depthCenter - depthP) / phiDepth;
    float wLum    = abs(lumCenter - lumP) / phiLum;

    return exp(-max0(wLum) - max0(wDepth)) * wNormal;
}

float filterVariance() {
    ivec2 coord = ivec2((texcoord + vec2(0.0, 1.0)) * resolution) / 2;

    float sum_Luma   = 0.0;
    float sum_Weight = 0.0;

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            ivec2 offset = ivec2(x, y);
            float weight = 1.0;
            sum_Luma   += texelFetch(colortex3, coord + offset, 0).a * weight;
            sum_Weight += weight;
        }
    }
    sum_Luma = sum_Luma / sum_Weight;

	return sum_Luma;
}