float volumetricFogFBM(vec3 position) {
    #ifndef Volumetric_Fog
        return 0.0;
    #endif

    position = position * 0.025;

    float coverage = 0.0;

    float noise = 0.0;
    float a = 1.0;
    float weight = a;

    mat2  rotMat   = mat2(2.2, 1.2, -3.2, 2.2);
    float movement = frameTimeCounter * 0.113 * Volumetric_Fog_Speed;

    for (int i = 0; i < 3; i ++) {
        noise    += Get3DNoise(position + movement) * a;
        position *= 4.5;
        a        *= 0.32;
        weight   += a;
    }

    noise /= weight;
    noise  = pow(max0(noise - coverage) / (1.0 - coverage), 5.0);

    return noise;
}

float calculatePollenNoise(vec3 position) {
    const float freq = 0.01;
    const float res  = 4.0;
    
    vec3 m  = vec3(windDirection.x, (sin(frameTimeCounter) * 0.5 + frameTimeCounter * 0.5) * 0.0005, windDirection.y) * frameTimeCounter;
    vec3 p  = position * res + m;
    vec3 id = floor(p);
    vec3 fp = fract(p) - 0.5;

    float rp     = hash13(id);
    float pollen = max0(0.25 - length(fp));

    return pollen * step(rp, freq);
}

vec2 calculateFogOpticalDensity(vec3 position) {
    float fogNoise    = volumetricFogFBM(position);
    float densityGrad = exp(-(position.y + Volumetric_Clouds_Altitude) / Volumetric_Clouds_Altitude);

    if (isEyeInWater > 0) return vec2(
        1.0,
        fogNoise
    );

    vec2 opticalDensity    = vec2(densityGrad);
         opticalDensity.y += pow(fogNoise, (1.0 - densityGrad) * 2.0) * 5.0;
         opticalDensity.y *= 500.0;
    
    return opticalDensity;
}

vec4 calculateVolumetricLight(gbuffer info, material mat, scene spaces, vec2 pattern) {
    #ifndef Volumetric_Light
        return vec4(0.0, 0.0, 0.0, 1.0);
    #endif

    if (isEyeInWater > 0) return vec4(0.0, 0.0, 0.0, 1.0);

    // Offset dither pattern to prevent overlap with other dither related volumetrics
    float ditherOffset = fract((pattern.x * 128 + frameCounter * 7) / 128);

    mat2x3 scatterCoeff    = isEyeInWater < 1 ?
        mat2x3(rayleighCoefficient, mieCoefficient) :
        mat2x3(vec3(0.0), waterScatterCoeff);
    mat2x3 extinctionCoeff = isEyeInWater < 1 ?
        mat2x3(rayleighCoefficient, mieExtinction) :
        mat2x3(waterAbsorbCoeff, waterScatterCoeff);

    // Setup scattering / extinction integral
	const mat2x3 a = mat2x3(-extinctionCoeff[0] * RCPLOG2, -extinctionCoeff[1] * RCPLOG2);
	const mat2x3 b = mat2x3(-1.0 / extinctionCoeff[0], -1.0 / extinctionCoeff[1]);
	const mat2x3 c = mat2x3( 1.0 / extinctionCoeff[0],  1.0 / extinctionCoeff[1]);

    float vlRenderDistance = mix(Volumetric_Light_Distance, Volumetric_Light_Distance_Rain, rainStrength);

    vec3  planeBottom = spaces.world[0] * (-cameraPosition.y) / spaces.world[0].y;
          planeBottom = spaces.world[2] * min(length(planeBottom), vlRenderDistance);
    vec3  planeTop    = spaces.world[0] * (Volumetric_Clouds_Altitude - cameraPosition.y) / spaces.world[0].y;
          planeTop    = spaces.world[2] * min(length(planeTop), vlRenderDistance);

    vec3 rayStart  = vec3(0.0);
    vec3 rayEnd    = vec3(0.0);

    if (cameraPosition.y < -Volumetric_Clouds_Altitude) {
        rayStart = planeBottom;
        rayEnd   = planeTop;
    } else if (cameraPosition.y > -Volumetric_Clouds_Altitude && cameraPosition.y < Volumetric_Clouds_Altitude) {
        rayStart = vec3(0.0);
        rayEnd   = spaces.world[2].y < 0.0 ? planeBottom : planeTop;
    } else if (cameraPosition.y > Volumetric_Clouds_Altitude) {
        if (spaces.world[2].y > 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
        rayStart = planeTop;
        rayEnd   = planeBottom;
    }

    rayEnd = info.depthtex.x < 1.0 ? spaces.world[0] : rayEnd;

    vec3  rayIncrement = (rayEnd - rayStart) / Volumetric_Light_Quality;
    vec3  rayPosition  = rayIncrement * ditherOffset + rayStart;
    float stepSize     = length(rayIncrement);
    
    float VoL     = dot(spaces.world[2], lightVec[1]);
    vec2  phase   = sky_phase(VoL, 0.5);
    float indoors = pow2(eyeBrightnessSmooth.y / 240.0);

    vec4 volumetricLight = vec4(0.0, 0.0, 0.0, 1.0);
    vec3 transmission    = vec3(1.0);

    for (int i = 0; i < Volumetric_Light_Quality; i++, rayPosition += rayIncrement) {
        vec2  opticalDensity = calculateFogOpticalDensity(rayPosition + cameraPosition) * stepSize;
        float cloudShadow    = calculateCloudShadows(rayPosition + cameraPosition);
        float landShadow     = calculateShadow(shadowtex0, distortShadowSpace(calculateShadowSpace(rayPosition)));

        vec3 lightingSun     = landShadow * cloudShadow * lightColors[2];
        vec3 lightingAmbient = indoors * RCPPI * lightColors[3];

        mat2x3 scatteringScale = mat2x3(
            scatterCoeff[0] * (exp2(a[0] * opticalDensity.x) * b[0] + c[0]),
            scatterCoeff[1] * (exp2(a[1] * opticalDensity.y) * b[1] + c[1])
        );
        
        volumetricLight.rgb += (scatteringScale * phase) * lightingSun * transmission * vec3(pow2(VL_Red), pow2(VL_Green), pow2(VL_Blue));
        volumetricLight.rgb += (scatteringScale * vec2(0.25)) * lightingAmbient * transmission;
        transmission        *= exp(-extinctionCoeff * opticalDensity * RCPLOG2);
        //volumetricLight.a   *= exp(-extinctionCoeff.x * opticalDensity * RCPLOG2);
    }

    volumetricLight.a = length(transmission);

    return volumetricLight;
}

vec4 calculatePollen(gbuffer info, material mat, scene spaces, vec2 pattern) {
    #ifndef Pollen
        return vec4(0.0, 0.0, 0.0, 1.0);
    #endif

    float indoors = pow2(eyeBrightnessSmooth.y / 240.0);

    if (indoors <= 0.0) return vec4(0.0, 0.0, 0.0, 1.0);

    // Precalculate integral variables
	const float a = -mieCoefficient.x / log(2.0);
	const float b = -1.0 / mieCoefficient.x;
	const float c =  1.0 / mieCoefficient.x;

    float worldLength  = length(spaces.world[0]);

    vec3  rayOrigin    = vec3(0.0);
    vec3  rayIncrement = spaces.world[2] * min(worldLength, Pollen_Distance) / Pollen_Quality;
    float stepSize     = length(rayIncrement);

    vec3 ray           = rayOrigin + rayIncrement * pattern.x;

    vec4 light         = vec4(0.0, 0.0, 0.0, 1.0);

    for (int i = 0; i < Pollen_Quality; i++, ray += rayIncrement) {
        float opticalDepth  = calculatePollenNoise(ray + cameraPosition) * 30.0 * stepSize;

        light.rgb += (opticalDepth * lightColors[2]) * (exp2(a * opticalDepth) * b + c) * light.a * 1.5 * indoors;
        light.a   *= exp(-mieCoefficient.x * opticalDepth);
    }

    return light;
}