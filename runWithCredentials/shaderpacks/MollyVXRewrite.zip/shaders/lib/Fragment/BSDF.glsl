float schlick(float F0, float LoH) {
	return F0 + (1.0 - F0) * pow(1.0 - LoH, 5.0);
}

float GGX(float NoH, float alpha2) {
	float p = NoH == 1.0 ? alpha2 : (NoH * alpha2 - NoH) * NoH + 1.0;
	return alpha2 / (PI * p * p);
}

float G2_GGX(float NoL, float NoV, float alpha2) {
	float x = 2.0 * NoL * NoV;
    float y = (1.0 - alpha2);

    return x / (NoV * sqrt(alpha2 + y * pow2(NoL)) + NoL * sqrt(alpha2 + y * pow2(NoV)));
}

float BRDF_GGX(float NoH, float NoL, float NoV, float alpha2) {
	float d  = GGX(NoH, alpha2);
	float g2 = G2_GGX(NoL, NoV, alpha2);

	return max0(d * g2 / (TAU * 4.0 * NoL * NoV)) * NoL;
}

vec3 diffuse_burley(vec3 diffuseColor, vec3 V, vec3 L, vec3 N, float r) {
	vec3  H   = normalize(V + L);
	float NoH = abs(dot(N, H));
    float NoV = abs(dot(V, N));
    float NoL = clamp01(dot(L, N));
    float LoV = abs(dot(L, V));

    float facing  = LoV * 0.5 + 0.5;
    float rough   = facing * (0.9 - 0.4 * facing) * ((0.5 + NoH) / NoH);
    float smooths = 1.05 * (1.0 - pow(1.0 - NoL, 5.0)) * (1.0 - pow(1.0 - NoV, 5.0));
    float single  = mix(smooths, rough, r);
    float multi   = 0.1159 * r;
    
    return clamp01(single + diffuseColor * multi) * NoL;
}

vec3 diffuse_hammon(vec3 albedo, vec3 view, vec3 light, vec3 normal, float roughness) {
	// Diffuse approximation for GGX + Smith microsurfaces.
	// http://gdcvault.com/play/1024478/PBR-Diffuse-Lighting-for-GGX

	float NoL = clamp01(dot(normal, light));
	float NoV = clamp01(dot(normal, view));
	float LoV = dot(light, view);
	float facing = 0.5 * LoV + 0.5;
	float NoH = (NoL + NoV) * inversesqrt(4.0 * facing);

	float single_rough  = facing * (-0.4 * facing + 0.9) * ((0.5 + NoH) / NoH);
	float single_smooth = 1.05 * (1.0 - pow5((1.0 - NoL))) * (1.0 - pow5((1.0 - NoV)));

	float single = clamp01(mix(single_smooth, single_rough, roughness) * RCPPI);
	float multi  = 0.1159 * roughness;

	return NoL * (albedo * multi + single);
}

vec3 subsurface(vec3 albedo, inout vec3 diffuse, vec3 viewVector, vec3 lightVector, vec3 normal, float alpha) {
    const float g = 0.1;
    const float a = 0.0;

    float NoL = dot(lightVector, normalize(normal));
    float VoL = dot(viewVector, lightVector);

    float SSS_N = (1.0 / (4.0 * PI)) * ((1.0 - pow2(g)) / pow(1.0 + pow2(g) - 2.0 * g * -NoL, 1.5)) * alpha;
    float SSS_V = (1.0 / (4.0 * PI)) * ((1.0 - pow2(g)) / pow(1.0 + pow2(g) - 2.0 * g *  VoL, 1.5));
    vec3  coeff = 1.0 / powf(albedo, 0.25);

    diffuse *= 1.0 - SSS_N;

    return exp(-coeff * a) * SSS_N * SSS_V * PI * 10 * SSS_Brightness;
}

vec3 diffuse(material mat, vec3 albedo, vec3 viewVector, vec3 lightVector, vec3 normal, vec3 lightColor, vec3 lightAtt) {
    vec3 diffuse = diffuse_hammon(albedo, viewVector, lightVector, normal, mat.roughness.x);
    vec3 SSS     = subsurface(albedo, diffuse, viewVector, lightVector, normal, mat.translucent);

    vec3 shade   = diffuse;
    shade += subsurface * 2.5;

    return shade * lightAtt * lightColor;
}

float f_dielectric(float NoH, float eta) { // H = N when no roughness
	// Assumes non-polarized
	float p = 1.0 - (eta * eta * (1.0 - NoH * NoH));
	if (p <= 0.0) return 1.0; p = sqrt(p);

	vec2 r = vec2(NoH, p);
	r = (eta * r - r.yx) / (eta * r + r.yx);
	return dot(r, r) * 0.5;
}

float f_dielectric(vec3 viewVector, vec3 normal, float F0) {
    vec3  V   = normalize(-viewVector);
    vec3  R   = reflect(viewVector, normal);
    vec3  H   = normalize(R + V);
    float LoH = dot(R, H);

    return schlick(F0, LoH);
}

vec3 BSDF(vec3 albedo, scene spaces, vec3 lightDir, vec3 lightColor, vec3 lightAtt, gbuffer info, material mat) {
    vec3 diffuse = diffuse_hammon(albedo, -spaces.world[2], lightDir, info.normal[0], mat.roughness.x);
    return diffuse * lightAtt * lightColor;
}


vec3 distributeMicrofacets(vec3 normal, vec4 noise, float alpha2) {
	noise.xyz = normalize(cross(normal, noise.xyz * 2.0 - 1.0));
	return normalize(noise.xyz * sqrt(alpha2 * noise.w / (1.0 - noise.w)) + normal);
}

float calculateGGXMipLevel(vec3 position, vec3 hitPosition, float roughness) {
	float rsScale = resolution.y * inversesqrt(Specular_Rays); // resolution and sample count
	float positionalScale = distance(position, hitPosition) / -hitPosition.z; // ray length and perspective divide

	return log2(roughness * rsScale * positionalScale);
}
