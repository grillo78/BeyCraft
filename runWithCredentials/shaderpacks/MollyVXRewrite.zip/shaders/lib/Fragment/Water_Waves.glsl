float gernsterWaves(vec2 coord, float time, float waveSteepness, float waveAmplitude, float waveLength, vec2 waveDirection){
	const float g = 19.6;
    
	float k = TAU / waveLength;
	float w = sqrt(g * k);

	float x = w * time - k * dot(waveDirection, coord);
	float wave = sin(x) * 0.5 + 0.5;

	float h = waveAmplitude * pow(wave, waveSteepness);

	return h;
}

float getWaves(vec2 coord) {
    const int octaves   = 6;

    float movement      = frameTimeCounter * 0.1 * float(materialIDs != 4) * pow2(Water_Speed);

    float waveSteepness = 0.9;
	float waveAmplitude = 0.02;
	float waveLength    = 1.5;
    float weight        = 1.0;
	vec2  waveDirection = -windDirection;
    vec2  noiseMovement = movement * waveDirection * 0.2;
    vec2  noise;

    float waves = 0.0;

    {
        noise          = pow2(noiseSmooth(coord * 0.01 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 0.8;
        waveDirection  = sincos(windDirectionRad + 0.9);

        noise          = pow2(noiseSmooth(coord * 0.01 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 0.8;
        waveDirection  = sincos(windDirectionRad - 1.8);

        noise          = pow2(noiseSmooth(coord * 0.01 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 0.8;
        waveDirection  = sincos(windDirectionRad + 2.7);

        noise          = pow2(noiseSmooth(coord * 0.01 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 0.8;
        waveDirection  = sincos(windDirectionRad - 3.6);

        noise          = pow2(noiseSmooth(coord * 0.01 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 0.8;
        waveDirection  = sincos(windDirectionRad + 4.5);

        noise          = pow2(noiseSmooth(coord * 0.01 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 0.8;
        waveDirection  = sincos(windDirectionRad - 5.4);
    }

    return waves;
}

vec3 calculateProceduralNormalsFlat(vec3 worldSpace) {
    vec2 coord = worldSpace.xz - worldSpace.y;

	const float delta  = 0.01;
	const float iDelta = 1.0 / delta;
    
    float sampleC = getWaves(coord                   );
	float sampleX = getWaves(coord + vec2(delta, 0.0));
	float sampleY = getWaves(coord + vec2(0.0, delta));

    vec3 waveNormals = normalize(vec3(
	    (sampleC - sampleX) * iDelta,
        (sampleC - sampleY) * iDelta,
        1.0
    ));

    return waveNormals;
}

#if !defined GBUFFERS_SHADOW && !defined COMPOSITE

vec3 water_calculateParallax(vec3 position, vec3 direction) {
    #ifndef Water_Parallax
        return position;
    #endif

    const int   iterations  = Water_Parallax_Samples;
    const float rIterations = 1.0 / iterations;

    const float depth = 6.0;
	float dist = inversesqrt(dot(direction, direction));

    vec2 offset = (direction.xy * rIterations) * (dist * depth);

    for(int i = 0; i < iterations; ++i) {
        position.xz = getWaves(position.xz) * offset - position.xz;
    }

    return position;
}

void calculateProceduralNormals(inout vec3 normal) {
    if (materialIDs != 1 && materialIDs != 4) return;

    #ifndef Procedural_Ice
        if (materialIDs == 4) return;
    #endif

    vec3 parallaxDirection   = normalize(tangentViewSpace);
    vec3 worldSpaceCorrected = worldSpace + gbufferModelViewInverse[3].xyz;
         worldSpaceCorrected = water_calculateParallax(worldSpaceCorrected, parallaxDirection);

    vec2 coord = worldSpaceCorrected.xz - worldSpaceCorrected.y;

	const float delta  = 0.01;
	const float iDelta = 1.0 / delta;

    float sampleC = getWaves(coord                   );
	float sampleX = getWaves(coord + vec2(delta, 0.0));
	float sampleY = getWaves(coord + vec2(0.0, delta));

    vec3 waveNormals = normalize(vec3(
	    (sampleC - sampleX) * iDelta,
        (sampleC - sampleY) * iDelta,
        1.0
    ));

    normal = waveNormals;
    normal = mix(vec3(0.0, 0.0, 1.0), normal, clamp(-tangentViewSpace.z, 0.0, 1.0));
}
#endif