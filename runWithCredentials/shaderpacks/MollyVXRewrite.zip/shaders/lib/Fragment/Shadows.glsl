float calculateShadowBias(vec3 shadowClip, vec3 normal, float sampleDiameterUV) {
	normal = abs(normal); // only actually needed for xy components, but if not done on z a plane can cast shadows on itself (which in this case is not wanted)

	vec2 temp = normalize(normal.xy) / vec2(shadowProjection[0].x, shadowProjection[1].y);

	return (temp.x + temp.y) * sampleDiameterUV * shadowProjection[2].z * min(sqrt(1.0 - normal.z * normal.z) / normal.z, 9.0);
}

float calculateShadow(sampler2D shadow, vec3 shadowSpace, float bias) {
    shadowSpace.xy = shadowSpace.xy * 0.5 + 0.5;
    if (floor(shadowSpace.xy) != vec2(0.0) || shadowSpace.z >= 1.0) return 1.0;
    return step(shadowSpace.z - bias, texture2DLod(shadow, shadowSpace.xy, 0.0).x);
}

float correctShadowDepth(float shadowDepth) {
    shadowDepth = shadowDepth * 2.0 - 1.0;
    shadowDepth = shadowDepth * Shadow_Z_Stretch;
    shadowDepth = shadowDepth * 0.5 + 0.5;
    return shadowDepth;
}