vec2 fermatsSpiralGoldenN(float index, float total) {
	float theta = index * GOLDEN_ANGLE;
	return vec2(sin(theta), cos(theta)) * sqrt(index / total);
}

vec2 fermatsSpiralGoldenS(float index, float total) {
	float theta = index * GOLDEN_ANGLE;
	return vec2(sin(theta), cos(theta)) * pow2(index / total);
}

vec2 hammersley(int i, int N) {
    return vec2(float(i) / float(N), float(bitfieldReverse(i)) * 2.3283064365386963e-10);
}

vec2 circlemap(float i, float n){
    return sincos( i * n * GOLDEN_ANGLE ) * sqrt(i);
}

vec2 circlemap(vec2 p) {
    p.y *= TAU;
    return vec2(cos(p.y), sin(p.y)) * sqrt(p.x);
}

vec3 GenUnitVector(vec2 p) {
    p.x *= TAU; p.y = p.y * 2.0 - 1.0;
    return vec3(sincos(p.x) * sqrt(1.0 - p.y * p.y), p.y);
}

vec3 GenCosineVector(vec3 vector, vec3 xyz) {
	vec3 dir = GenUnitVector(xyz.xy);
	float VoD = dot(vector, dir);

	return sqrt(xyz.z) * (dir - vector * VoD) * inversesqrt(1.0 - VoD * VoD) + sqrt(1.0 - xyz.z) * vector;
}

vec3 GenerateCosineVectorSafe(vec3 vector, vec2 xy) {
	// Apparently this is actually this simple.
	// http://www.amietia.com/lambertnotangent.html
	// (cosine lobe around vector = lambertian BRDF)
	// This one deals with ther rare case where cosineVector == (0,0,0)
	// Can just normalize it instead if you are sure that won't be a problem
	vec3 cosineVector = vector + GenUnitVector(xy);
	float lenSq = dot(cosineVector, cosineVector);
	return lenSq > 0.0 ? cosineVector * inversesqrt(lenSq) : vector;
}

vec3 sphereMap(vec2 a) {
    float phi = a.y * 2.0 * PI;
    float cosTheta = 1.0 - a.x;
    float sinTheta = sqrt(1.0 - cosTheta * cosTheta);

    return vec3(cos(phi) * sinTheta, sin(phi) * sinTheta, cosTheta * 2.0 - 1.0);
}

vec3 hemisphere(vec3 L, vec3 n) {
    vec3 tangentX = normalize(cross(vec3(0.0, 0.0, 1.0), n));
    vec3 tangentY = cross(n, tangentX);

    return tangentX * L.x + tangentY * L.y + n * L.z;
}

vec2 Halton23(int n) {
	float halton2 = float(bitfieldReverse(n) >> 9u) / (exp2(23.0) - 1.0);

	float i = float(n);
	float f = 1.0, r = 0.0;
	while (i > 0.0) {
		f /= 3.0;
		r += f * mod(i, 3);
		i  = floor(i / 3);
	}

	return vec2(halton2, r);
}