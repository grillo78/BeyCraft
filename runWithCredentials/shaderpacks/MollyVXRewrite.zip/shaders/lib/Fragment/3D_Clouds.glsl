const float maxCloudsAltitude = Volumetric_Clouds_Altitude + Volumetric_Clouds_Height;

#if Volumetric_Clouds_FBM == 1

float calculateCloudNoise(vec3 position, bool doDetailNoise) {
    const vec3 offsetDirection = vec3(windDirection.x, 0.0, windDirection.y);
    vec3  movement = offsetDirection * frameTimeCounter * 0.002 * pow2(VCloud_Speed);

    //position *= 0.007;
    position    *= 1.0 / Volumetric_Clouds_Altitude;
    position.xz  = rotateNoMat(position.xz, windDirection);
    position    *= vec3(1.0, 1.0, 1.0);

    vec3 offset = (position.y - Volumetric_Clouds_Altitude) / vec3(1.0, Volumetric_Clouds_Height, Volumetric_Clouds_Height);
    
    //float coverage = mix(Volumetric_Cloud_Coverage, 0.35, rainStrength);
    float coverage = max0(texture2D(noisetex, (position.xz + movement.xz) * 0.012).z * 2.0 - 1.0);
          coverage = (coverage + Volumetric_Cloud_Coverage) / (1.0 + Volumetric_Cloud_Coverage) * Volumetric_Cloud_Coverage;
          coverage = mix(coverage, 0.35, rainStrength);
    
    if (coverage <= 0.0) return 0.0;

    float samples    = 0.0;
    vec2  samples2   = vec2(0.0);
    float noise      = 0.0;
    float amplitutde = 1.0;
    float weight     = 0.0;

    const float res  = 0.5;
    const float freq = 0.3;

    vec3 p  = position * res;
    vec3 id = floor(p);
    vec3 fp = fract(p) - 0.5;

    float rp     = hash13(id);
    float points = 1.0 - smoothstep(0.0, 0.5, length(fp));

    float cells = points * step(rp, freq);

    { // Large noise calculation
        samples     = worley12((position + movement + offset).xz);
        noise      += samples * amplitutde;
        weight     += amplitutde;
        position    = position * 1.5 - samples * offsetDirection * 0.5 * VCloud_Distortion_Amount;
        amplitutde *= 0.8;

        samples     = Get3DNoise(position + movement + offset);
        noise      += samples * amplitutde;
        weight     += amplitutde;
        position    = position * 3.5 - samples * offsetDirection * 2.5 * VCloud_Distortion_Amount;
        amplitutde *= 0.4;

        samples     = Get3DNoise(position + movement + offset);
        noise      += samples * amplitutde;
        weight     += amplitutde;
        position    = position * 2.5 - samples * offsetDirection * 5.0 * VCloud_Distortion_Amount;
        amplitutde *= 0.7;
        
        samples     = Get3DNoise(position + movement + offset);
        noise      += samples * amplitutde;
        weight     += amplitutde;
        position    = position * 5.0 - samples * offsetDirection * 6.0 * VCloud_Distortion_Amount;
        amplitutde *= 0.5;
    }

    if (doDetailNoise) { // Small noise calculation
        samples     = Get3DNoise(position + movement);
        noise      += samples * amplitutde;
        weight     += amplitutde;
        position    = position * 1.5 - samples * offsetDirection * 15.0;
        amplitutde *= 0.0;

        samples     = Get3DNoise(position + movement);
        noise      += samples * amplitutde;
        weight     += amplitutde;
        position    = position * 1.5 - samples * offsetDirection * 15.0;

    }

    return max0(noise / weight - coverage);
}

#elif Volumetric_Clouds_FBM == 2

float calculateCloudNoise(vec3 position, bool doDetailNoise) {
    float time     = frameTimeCounter * 0.03;
    const vec3 offsetDirection = vec3(windDirection.x, 0.0, windDirection.y);
    float coverage = mix(Volumetric_Cloud_Coverage, 0.35, rainStrength);

    position    *= 1.0 / Volumetric_Clouds_Altitude;
    position.xz  = rotateNoMat(position.xz, windDirection);
    position    *= vec3(1.0, 1.0, 1.0);

	const mat4x3 cloudMul = mat4x3(vec3(0.6),
	                         vec3(3.0) * offsetDirection,
	                         vec3(3.0) * offsetDirection,
	                         vec3(8.0));

	mat4x3 CloudAdd = mat4x3(vec3(time * 0.5),
	                         vec3(0.0, 0.0, time * 2.0),
	                         vec3(time * -0.5),
	                         vec3(0.0, -time, 0.0));

	vec2 cloudNoise = vec2(Get3DNoise(position * cloudMul[0] + CloudAdd[0]), Get3DNoise(position * cloudMul[1] + CloudAdd[1]));
	cloudNoise.x += Get3DNoise(position * cloudMul[2] + CloudAdd[2]) * 0.25;
	cloudNoise.x += Get3DNoise(position * cloudMul[3] + CloudAdd[3]) * 0.1;
    position.xz  += -cloudNoise * windDirection * 0.5;
		cloudNoise.x += Get3DNoise(position * 5.0) * 0.05;
		cloudNoise.x -= Get3DNoise(position * 20.0) * 0.05;
	cloudNoise.x += cloudNoise.y * 0.03;
	cloudNoise.x += abs(cloudNoise.y * 2.0 - 1.0) * 0.04;

	return max0(cloudNoise.x - coverage);
}

#endif

float getCloudVolume(vec3 ray, float distance, bool doDetailNoise) {
	
	if (ray.y < Volumetric_Clouds_Altitude || ray.y > maxCloudsAltitude) return 0.0;

    const float density = Volumetric_Cloud_Density * 0.5;

    float altitudeLayer = (ray.y - Volumetric_Clouds_Altitude) / Volumetric_Clouds_Height;
    float gradientLayer = 1.0 - pow(remap(altitudeLayer, 0.0, 0.4, 0.0, 1.0) * remap(altitudeLayer, 0.6, 1.0, 1.0, 0.0) * 0.6, 0.25);
    float opticalDepth  = max0(calculateCloudNoise(ray, doDetailNoise) - distance - gradientLayer) * (1.0 - gradientLayer);

    return opticalDepth * density;
}

float calculateCloudShadows(vec3 worldSpace) {
    #if !defined Cloud_Shadows || !defined Volumetric_Clouds
        return mix(1.0, 0.0, rainStrength);
    #endif

    float horizon = smoothstep(0.2, 0.5, lightVec[1].y);

    const float midCloudAltitude = Volumetric_Clouds_Altitude + Volumetric_Clouds_Height * 0.5;

    const float shadowSteps = Cloud_Shadow_Steps;

    float stepSize     = Volumetric_Clouds_Height / shadowSteps;
    float stepLength   = stepSize / lightVec[1].y;
    vec3  rayPosition  = worldSpace + lightVec[1] * ((Volumetric_Clouds_Altitude - worldSpace.y) / lightVec[1].y);
    vec3  rayIncrement = lightVec[1] * stepSize;
          rayPosition += rayIncrement * 1.0;

    float opticalDepth = 0.0;

    for (int i = 0; i < shadowSteps; i++, rayPosition += rayIncrement) {
        opticalDepth += getCloudVolume(rayPosition, 0.0, true) * stepSize;
    }

    return exp2(-opticalDepth * 1.11);
}

float beerLambert(float sampleDensity, float precipitation) {
	return exp(-sampleDensity * precipitation);
}

float powder(float sampleDensity, float lightDotEye) {
	float powd = 1.0f - exp(-sampleDensity * 2.0f);
	return mix(
		1.0f,
		powd,
		clamp01((-lightDotEye * 0.5) + 0.5) // [-1,1]->[0,1]
	);
}

float calculateOutOpticalDensity(vec3 rayPosition, vec3 direction) {
    int   samples  = VC_Direct_Light_Quality;
    float stepSize = Volumetric_Clouds_Height / samples;
    
	vec3 rayDirection = direction * stepSize;
	     rayPosition += rayDirection * 0.1;

	float opticalDepth = 0.0;
	for (float i = 0.0; i < samples; i++, rayPosition += rayDirection)
		opticalDepth  += getCloudVolume(rayPosition, 0.0, true);

	return opticalDepth * stepSize;
}

vec4 calculateVolumetricClouds(gbuffer info, material mat, scene spaces, vec2 pattern, out vec3 projection) {
    #ifndef Volumetric_Clouds
        return vec4(0.0, 0.0, 0.0, 1.0);
    #endif

    if (info.depthtex.x < 1.0) return vec4(0.0, 0.0, 0.0, 1.0);

    const float heightFraction    = Volumetric_Clouds_Height / Volumetric_Clouds_Quality;
    const float multiscatterCoeff = 0.25 * RCPPI;
    const float transmissionCoeff = 1.11 * RCPLOG2;

    vec3  planeBottom = spaces.world[1] * (Volumetric_Clouds_Altitude - cameraPosition.y) / spaces.world[1].y;
          planeBottom = spaces.world[2] * min(length(planeBottom), Volumetric_Cloud_Distance);
    vec3  planeTop    = spaces.world[1] * (maxCloudsAltitude - cameraPosition.y) / spaces.world[1].y;
          planeTop    = spaces.world[2] * min(length(planeTop), Volumetric_Cloud_Distance);

    vec3 rayStart  = vec3(0.0);
    vec3 rayEnd    = vec3(0.0);

    if (cameraPosition.y < Volumetric_Clouds_Altitude) {
        rayStart = planeBottom;
        rayEnd   = planeTop;
    } else if (cameraPosition.y > Volumetric_Clouds_Altitude && cameraPosition.y < maxCloudsAltitude) {
        rayStart = vec3(0.0);
        rayEnd   = spaces.world[2].y < 0.0 ? planeBottom : planeTop;
    } else if (cameraPosition.y > maxCloudsAltitude) {
        rayStart = planeTop;
        rayEnd   = planeBottom;
    }

    projection = rayEnd;

    if (length(rayStart) >= Volumetric_Cloud_Distance) return vec4(0.0, 0.0, 0.0, 1.0);

    vec3  rayIncrement = (rayEnd - rayStart) / Volumetric_Clouds_Quality;
    vec3  rayPosition  = rayIncrement * pattern.x + rayStart;
    float stepSize     = length(rayIncrement);
    
    vec3  lightCol    = lightColors[0] + lightColors[1];
    vec3  lightBounce = lightColors[3];

    float VoL      = dot(spaces.world[2], lightVec[1]);
    float phase    = mix(hgPhase(VoL, -0.3), hgPhase(VoL, 0.8), 0.5) * PI;
    float phaseG0  = 0.25;

    vec4 clouds = vec4(0.0, 0.0, 0.0, 1.0);

    for (int i = 0; i < Volumetric_Clouds_Quality; i++, rayPosition += rayIncrement) {
        vec3  rayWorldPos      = rayPosition + cameraPosition;
        float inOpticalDensity = getCloudVolume(rayWorldPos, 0.0, true);

        if (inOpticalDensity <= 0.0) continue;

        float outOpticalDensitySun     = calculateOutOpticalDensity(rayWorldPos, lightVec[1]);
        float outOpticalDensityAmbient = inOpticalDensity * heightFraction * 0.5;

        vec3 lighting  = lightBounce * 0.00;
             lighting += exp(-outOpticalDensitySun     * transmissionCoeff) * phase * lightCol * Cloud_Direct_Brightness;
             lighting += exp(-outOpticalDensitySun     * transmissionCoeff * 0.25) * phaseG0 * lightCol;
             lighting += exp(-outOpticalDensityAmbient * transmissionCoeff) * phaseG0 * lightBounce * Cloud_Indirect_Brightness;
             //lighting *= mix(1.0, 1.0 - exp(-inOpticalDensity * 2.0), -VoL * 0.5 + 0.5);

        clouds.rgb += inOpticalDensity * heightFraction * lighting * clouds.a;
        clouds.a   *= exp(-inOpticalDensity * stepSize * transmissionCoeff);
    }

    return clouds;
}