float distortionFactor(vec2 shadowSpace) {
    float dist = length(abs(shadowSpace * 1.165));
    float distortion = ((1.0 - Shadow_Bias) + dist * Shadow_Bias) * 0.97;
    
    return distortion;
}

vec3 distortShadowSpace(vec3 shadowSpace) {
    shadowSpace = shadowSpace * 2.0 - 1.0;
    shadowSpace = shadowSpace / vec3(vec2(distortionFactor(shadowSpace.xy)), Shadow_Z_Stretch);
    shadowSpace = shadowSpace * 0.5 + 0.5;

    return shadowSpace;
}