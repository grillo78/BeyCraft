float cirrusCloudFBM(vec2 position) {
    vec2  movement   = windDirection * frameTimeCounter * 0.0001 * Cirrus_Speed;

    const vec2 stretch = vec2(0.5, 1.5);
    position *= 0.00012;
    position  = rotateNoMat(position, windDirection) * stretch;// + noiseSmooth(position * 0.01 + movement).xy * 0.1;

    
    float coverage = max0(noiseSmooth((position + movement) * 0.015).z * 2.0 - 1.0);
          coverage = (coverage + Cirrus_Clouds_Coverage) / (1.0 + Cirrus_Clouds_Coverage) * Cirrus_Clouds_Coverage;
          coverage = mix(coverage, 0.35, rainStrength);

    float samples    = 0.0;
    float noise      = 0.0;
    float amplitutde = 1.0;
    float weight     = 0.0;

    {
        samples     = noiseSmooth(position + movement).z;
        noise      += samples * amplitutde;
        weight     += amplitutde;
        position    = position * 1.0 - samples * windDirection * 0.05;
        amplitutde *= 0.8;

        samples     = noiseSmooth(position + movement).z;
        noise      += samples * amplitutde;
        weight     += amplitutde;
        position    = position * 2.0 - samples * windDirection * 0.1;
        amplitutde *= 0.5;

        samples     = noiseSmooth(position + movement).z;
        noise      += samples * amplitutde;
        weight     += amplitutde;
        position    = position * 3.0 - samples * windDirection * 0.1;
        amplitutde *= 0.4;
        
        samples     = noiseSmooth(position + movement).z;
        noise      += samples * amplitutde;
        weight     += amplitutde;
    }
    
    return smoothstep(coverage, 1.0, noise / weight);
}

void calculateCirrusClouds(inout vec3 color, in vec3 worldSpace, in vec3 worldSpaceNormalized, in float visibility) {
    #ifndef Cirrus_Clouds
        return;
    #endif

    float horizon = smoothstep(0.05, 0.1, worldSpaceNormalized.y);

    if (horizon <= 0.0 || visibility > 0.5) return;

    const float thickness  = 1.0;

    vec3  lightCol = lightColors[0] + lightColors[1];


    vec3  ray = worldSpace * (Cirrus_Clouds_Altitude - cameraPosition.y) / worldSpace.y + cameraPosition;

    float VoL = dot(worldSpaceNormalized, lightVec[1]);

    float opticalDepth    = cirrusCloudFBM(ray.xz) * thickness;

    if (opticalDepth <= 0.0) return;

    float lightVisibility = exp2(-cirrusCloudFBM(ray.xz + lightVec[1].xz * 50.0) * thickness) * opticalDepth;
    float phase           = hgPhase(VoL, 0.7) * PI;

    vec3 sunlight = lightVisibility * lightCol * phase;
    vec3 ambient  = opticalDepth * lightColors[3] * 0.25;

    vec3 lighting = sunlight + ambient;

    vec4  clouds = vec4(lighting, exp2(-opticalDepth));

    clouds = mix(vec4(0.0, 0.0, 0.0, 1.0),
             clouds,
             horizon);

    color = color * clouds.a + clouds.rgb;
}