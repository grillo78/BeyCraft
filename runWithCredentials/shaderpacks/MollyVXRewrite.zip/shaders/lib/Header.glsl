#extension GL_EXT_gpu_shader4 : require
#extension GL_ARB_shader_texture_lod : require
#extension GL_ARB_texture_gather : require

#include "/lib/Syntax.glsl"
#include "/lib/Settings.glsl"
#include "/lib/Utility.glsl"