const float Values_16Bit = exp2(16) - 1.0;
const float Values_8Bit  = exp2(8)  - 1.0;
const uvec4 RGB_16_Bits  = uvec4(5, 6, 5, 0);

float Pack2x4(vec2 x) {
	return dot(floor(15.0 * x + 0.5), vec2(1.0 / 255.0, 16.0 / 255.0));
}

vec2 Unpack2x4(float pack) {
	pack *= 255.0 / 16.0;
	vec2 xy; xy.y = floor(pack); xy.x = pack - xy.y;
	return vec2(16.0 / 15.0, 1.0 / 15.0) * xy;
}

float Pack2x8(vec2 x) {
	return dot(floor(255.0 * x + 0.5), vec2(1.0 / Values_16Bit, 256.0 / Values_16Bit));
}

vec2 Unpack2x8(float pack) {
	pack *= Values_16Bit / 256.0;
	vec2 xy; xy.y = floor(pack); xy.x = pack - xy.y;
	return vec2(256.0 / 255.0, 1.0 / 255.0) * xy;
}

uint EncodeArbitrary(vec4 x, uvec4 bitCount) {
    // Clamp between 0 and 1 to prevent overflowing into a neighboring value
    x = clamp(x, 0.0, 1.0);

    // Scale to give the correct range once converted into uints
    x *= exp2(bitCount) - 1.0;

    // Convert to uints
    uvec4 ix = uvec4(x);

    // Bitshift to position bitfields to not overlap
    // 00000001 << 5 == 00100000
    ix = ix << uvec4(0u, bitCount.x, bitCount.x + bitCount.y, bitCount.x + bitCount.y + bitCount.z);

    // Merge with logical or operations.
    // Output bit is 1 if either input bit is 1. 01010000 | 00001101 == 01011101
    return ix.x | ix.y | ix.z | ix.w;

    // Side note: Addition is equivalent to a logical or provided that the bitfields of the inputs don't overlap
    // return ix.x + ix.y + ix.z + ix.w;
}

vec4 DecodeArbitrary(uint x, uvec4 bitCount) {
    // Initial component separation, undo bit shift
    uvec4 ix = uvec4(x) >> uvec4(0u, bitCount.x, bitCount.x + bitCount.y, bitCount.x + bitCount.y + bitCount.z);

    // Finish separating components using logical and operations
    // `(1 << bitCount) - 1` sets the first bitCount bits to 1
    ix = ix & ((uvec4(1u) << bitCount) - uvec4(1u));

    // Convert to floats
    vec4 fx = vec4(ix);

    // Scale back to 0-1 range
    return fx / (exp2(bitCount) - 1.0);
}


float EncodeNormal(vec3 normal){
    // Scale down to octahedron, project onto XY plane
	normal.xy /= abs(normal.x) + abs(normal.y) + abs(normal.z);
	// Reflect -Z hemisphere folds over the diagonals
	vec2 encoded = (normal.z <= 0.0 ? (1.0 - abs(normal.yx)) * vec2(normal.x >= 0.0 ? 1.0 : -1.0, normal.y >= 0.0 ? 1.0 : -1.0) : normal.xy) * 0.5 + 0.5;
    return Pack2x8(encoded);
}

vec3 DecodeNormal(float a){
    vec2 encoded = Unpack2x8(a) * 2.0 - 1.0;
	// Exctract Z component
	vec3 normal = vec3(encoded, 1.0 - abs(encoded.x) - abs(encoded.y));
	// Reflect -Z hemisphere folds over the diagonals
	float t = max(-normal.z, 0.0);
	normal.xy += vec2(normal.x >= 0.0 ? -t : t, normal.y >= 0.0 ? -t : t);
	// Normalize and return
	return normalize(normal);
}

vec4 EncodeRGBE8(vec3 rgb) {
	float exponentPart = floor(log2(max(max(rgb.r, rgb.g), max(rgb.b, exp2(-127.0))))); // can remove the clamp to above exp2(-127) if you're sure you're not going to input any values below that
	vec3  mantissaPart = clamp((128.0 / 255.0) * exp2(-exponentPart) * rgb, 0.0, 1.0);
	      exponentPart = clamp(exponentPart / 255.0 + (127.0 / 255.0), 0.0, 1.0);

	return vec4(mantissaPart, exponentPart);
}

vec3 DecodeRGBE8(vec4 rgbe) {
	const float add = log2(510.0 / 256.0) - 127.0;
	return exp2(rgbe.a * 255.0 + add) * rgbe.rgb;
}


float encodeMaterialIDs(int IDs) {
    return float(IDs) / 31.0;
}

int decodeMaterialIDs(float IDs) {
    return int(floor(IDs * 31.0));
}

float getMaterialID(int IDs, int mask) {
    return float(IDs == mask);
}


float BitsToValues(int bits) {
    return exp2(bits) - 1.0;
}