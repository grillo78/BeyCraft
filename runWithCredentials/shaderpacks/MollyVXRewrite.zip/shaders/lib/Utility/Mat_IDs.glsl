

bool IsEmissiveId(int id) {
	return
	   id ==  10  // Lava
	|| id ==  50  // Torch
	|| id ==  51  // Fire
	|| id ==  76  // Redstone Torch
	|| id ==  89  // Glowstone
	|| id ==  90  // Nether Portal
	|| id ==  91  // Jack O' Lantern
	|| id == 124  // Redstone Lamp
	|| id == 138  // Beacon
	|| id == 169  // Sea Lantern
	|| id == 198  // End Rod
	|| id == 213 // Magma
    || id == 220 //campfire
    || id == 221 //lantern
    || id == 239;
}