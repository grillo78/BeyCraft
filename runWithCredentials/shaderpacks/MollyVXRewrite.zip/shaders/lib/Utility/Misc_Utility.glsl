vec2 sincos(float x){
    return vec2(sin(x), cos(x));
}

mat2 rotate(float rad) {
	return mat2(
	vec2(cos(rad), -sin(rad)),
	vec2(sin(rad),  cos(rad))
	);
}

vec2 rotateNoMat(vec2 coord, vec2 x) {
    float ns = x.y * coord.y + x.x * coord.x;
    float nc = x.x * coord.y - x.y * coord.x;
    return vec2(ns, nc);
}

vec3 Rotate(vec3 vector, vec3 axis, float angle) {
	// https://en.wikipedia.org/wiki/Rodrigues%27_rotation_formula
	vec2 sc = sincos(angle);
	return sc.y * vector + sc.x * cross(axis, vector) + (1.0 - sc.y) * dot(axis, vector) * axis;
}

vec3 Rotate(vec3 vector, vec3 from, vec3 to) {
	// where "from" and "to" are two unit vectors determining how far to rotate
	// adapted version of https://en.wikipedia.org/wiki/Rodrigues%27_rotation_formula

	float cosTheta = dot(from, to);
	vec3 axis = normalize(cross(from, to));

	vec2 sc = vec2(sqrt(1.0 - cosTheta * cosTheta), cosTheta);
	return sc.y * vector + sc.x * cross(axis, vector) + (1.0 - sc.y) * dot(axis, vector) * axis;
}

#define diagonal2(mat) vec2((mat)[0].x, (mat)[1].y)
#define diagonal3(mat) vec3((mat)[0].x, (mat)[1].y, mat[2].z)

#define transMAD(mat, v) (     mat3(mat) * (v) + (mat)[3].xyz)
#define  projMAD(mat, v) (diagonal3(mat) * (v) + (mat)[3].xyz)


#define log2(x)  log(x) / log(2.0)
#define log10(x) log(x) / log(10.0)

#define cubicSmooth(x) (x * x) * (3.0 - 2.0 * x)

#define coneAngleToSolidAngle(x) (TAU * (1.0 - cos(x)))
#define solidAngleToConeAngle(x) acos(1.0 - (x) / TAU)

float almostIdentity(float x, float m, float n) {
	if (x > m) return x;

	float a = 2.0 * n - m;
	float b = 2.0 * m - 3.0 * n;
	float t = x / m;

	return (a * t + b) * t * t + n;
}

float remap(float value, const float originalMin, const float originalMax, const float newMin, const float newMax) {
	return (((value - originalMin) / (originalMax - originalMin)) * (newMax - newMin)) + newMin;
}

void decodeColor(inout vec4 color) {
    color *= colorEncodeConstant;
}

float AddUvMargin(float uv, int resolution) {
	return uv * (1.0 - 1.0 / resolution) + (0.5 / resolution);
}
float RemoveUvMargin(float uv, int resolution) {
	return (uv - 0.5 / resolution) / (1.0 - 1.0 / resolution);
}
vec2 AddUvMargin(vec2 uv, ivec2 resolution) {
	return uv * (1.0 - 1.0 / resolution) + (0.5 / resolution);
}
vec2 RemoveUvMargin(vec2 uv, ivec2 resolution) {
	return (uv - (0.5 / resolution)) / (1.0 - (1.0 / resolution));
}
vec3 AddUvMargin(vec3 uv, ivec3 resolution) {
	return uv * (1.0 - 1.0 / resolution) + (0.5 / resolution);
}
vec3 RemoveUvMargin(vec3 uv, ivec3 resolution) {
	return (uv - 0.5 / resolution) / (1.0 - 1.0 / resolution);
}
vec4 AddUvMargin(vec4 uv, ivec4 resolution) {
	return uv * (1.0 - 1.0 / resolution) + (0.5 / resolution);
}
vec4 RemoveUvMargin(vec4 uv, ivec4 resolution) {
	return (uv - 0.5 / resolution) / (1.0 - 1.0 / resolution);
}