vec3 calculateViewSpace(vec3 screenSpace, mat4 projectionMatInverse) {
	screenSpace = screenSpace * 2.0 - 1.0;
	return projMAD(projectionMatInverse, screenSpace) / (screenSpace.z * projectionMatInverse[2].w + projectionMatInverse[3].w);
}

vec3 calculateScreenSpace(vec3 viewSpace, mat4 projectionMat) {
	return (diagonal3(projectionMat) * viewSpace + projectionMat[3].xyz) / -viewSpace.z * 0.5 + 0.5;
}

float linearizeDepth(float depth, mat4 projectionMatInverse) {
	return -1.0 / ((depth * 2.0 - 1.0) * projectionMatInverse[2].w + projectionMatInverse[3].w);
}

float delinearizeDepth(float depth, mat4 projectionMat) {
	return ((depth * projectionMat[2].z + projectionMat[3].z) / depth) * -0.5 + 0.5;
}

vec4 projectViewSpace(vec3 viewSpace, mat4 projectionMat) {
    //vec3 viewSpace = mat3(gbufferModelView) * (worldSpace - cameraPosition);
	vec4 projection    = vec4(projMAD(projectionMat, viewSpace), viewSpace.z * projectionMat[2].w);
    return projection;
}

#if defined COMPOSITE || defined DEFERRED

vec3 projectPrevious(vec3 space_Screen) {
    vec4 reproj  = gbufferModelViewInverse * gbufferProjectionInverse * vec4(space_Screen * 2.0 - 1.0, 1.0);
         reproj /= reproj.w;

    reproj.xyz += cameraPosition - previousCameraPosition;

    reproj  = gbufferPreviousProjection * gbufferPreviousModelView * reproj;
    reproj /= reproj.w;

    return reproj.xyz * 0.5 + 0.5;
}

#endif