bool raySphereIntersect(vec3 rayDirection, vec3 sphere, float radius, out vec2 hit) {
		hit = vec2(0.0);
	float b = dot(sphere, rayDirection);
	float c = dot(sphere, sphere) - radius * radius;
	
	float d = b * b - c;

    //if (dot(rayDirection, normalize(sphere)) > 1.0) return false;

	if (d < 0.0) {
        return false;
	}
    
	d = sqrt(d);
	
	hit = vec2(-b - d, -b + d);
    return true;
}

float raySphereDepth(vec3 rayDirection, const vec3 sphere, const float radius) {
    float b = dot(rayDirection, sphere);
    float t = pow2(b) - pow2(sphere.y);

    float depth = b + sqrt(pow2(radius) + t);

    if (-sphere.y > radius) depth += sphere.y + radius;

    return max0(depth);
}

// No intersection if returned y component is < 0.0
vec2 RSI(vec3 position, vec3 direction, float radius) {
	float PoD = dot(position, direction);
	float radiusSquared = radius * radius;

	float delta = PoD * PoD + radiusSquared - dot(position, position);
	if (delta < 0.0) return vec2(-1.0);
	      delta = sqrt(delta);

	return -PoD + vec2(-delta, delta);
}