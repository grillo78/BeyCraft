vec4 powf(vec4 a, float b) { return pow(a, vec4(b)); }
vec3 powf(vec3 a, float b) { return pow(a, vec3(b)); }
vec2 powf(vec2 a, float b) { return pow(a, vec2(b)); }

#define pow2(x) (x * x)
#define pow3(x) pow2(x) * x
#define pow4(x) pow2(pow2(x))
#define pow5(x) pow2(pow2(x)) * x
#define pow6(x) pow2(pow2(pow2(x)))
#define pow7(x) pow2(pow2(pow2(x))) * x
#define pow8(x) pow2(pow2(pow2(pow2(x))))