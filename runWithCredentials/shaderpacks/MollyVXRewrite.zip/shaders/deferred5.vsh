#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT vsh
#define DEFERRED 5


#include "/program/deferred/D3_D8_FilterSpatial.glsl"