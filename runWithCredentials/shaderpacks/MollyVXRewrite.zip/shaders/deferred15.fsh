#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT fsh
#define DEFERRED 15


#include "/program/deferred/D15_Last.glsl"