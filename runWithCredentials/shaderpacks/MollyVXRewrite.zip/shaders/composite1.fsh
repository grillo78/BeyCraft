#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT fsh
#define COMPOSITE 15


#include "/program/composite/C15_Last.glsl"