#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT vsh
#define DEFERRED 9


#include "/program/deferred/D9_ApplyLight.glsl"