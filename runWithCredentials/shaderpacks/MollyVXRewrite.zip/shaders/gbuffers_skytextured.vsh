#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT vsh
#define GBUFFERS_SKYTEXTURED


#if   PROG_SKYTEXTURED == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.glsl"
#elif PROG_SKYTEXTURED == G_OPAQUE
#include "/program/gbuffers/gbuffers_opaque.glsl"
#elif PROG_SKYTEXTURED == G_TRANSPARENT
#include "/program/gbuffers/gbuffers_transparent.glsl"
#endif