// Global varyings

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec2 taaOffset;
uniform vec2 resolution;
uniform vec2 pixel;


#include "/lib/Utility/Space_Transformations.glsl"


#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;
    
    gl_Position    = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position    = gl_in[i].gl_Position;
        gl_Position.xy = gl_Position.xy;
        texcoord = vertexTexcoord[i];
        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:3 */

layout (location = 0) out vec4 colortex3Write;

in vec2 texcoord;

uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex1;
uniform sampler2D noisetex;
uniform float near, far;
uniform int frameCounter;

const bool colortex1MipmapEnabled = true;
const bool colortex3MipmapEnabled = true;


#include "/lib/Fragment/ASVGF.glsl"
#include "/lib/Fragment/Noise.glsl"

#include "/lib/Texturing/Smoothing.glsl"


float filterVariance(ivec2 fragCoord) {
    float sum = 0.0;

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            ivec2 offset   = ivec2(x, y);
            vec3  lighting = texelFetch(colortex3, fragCoord + offset, 0).rgb;
            sum += dot(lighting, lumaCoeff);
        }
    }
    sum = sum / 9.0;

	return sum;
}

vec4 filterTemporal(vec3 normal_Opaque, float depthtex, ivec2 fragCoord, ivec2 tileCoord, ivec2 tileLocation, uint randSeed) {
    const int stepSize = 1;

    ivec2 fragCoordOffset = ivec2((texcoord - tileLocation * 0.5) * resolution);

    const float epsilonVariance = 1e-10;

    ivec2 jitter = (ivec2(nextRand(randSeed) * stepSize, nextRand(randSeed) * stepSize) * 2 - 1) / 4;

    vec4  lightingCenter  = texelFetch(colortex3, fragCoordOffset, 0);
    float luminanceCenter = dot(lightingCenter.rgb, lumaCoeff);
    float history         = lightingCenter.a;

	float variance    = filterVariance(fragCoordOffset);
    float depthCenter = -linearizeDepth(depthtex, gbufferProjectionInverse);
    float phiLum      = sigmaL * pow(max0(variance + epsilonVariance), 0.5) + 2048.0 * (pow2(1.0 / history) / pow2(stepSize));
    float phiDepth    = stepSize * sigmaZ / depthCenter;
    float totalWeight = 1.0;

    vec3  totalLighting = lightingCenter.rgb;
    float totalVariance = luminanceCenter;

    for (int x = -1; x <= 1; ++x) {
		for (int y = -1; y <= 1; ++y) {
			if (x == 0 && y == 0) { continue; }

			ivec2 offset = ivec2(x, y) * stepSize + jitter;

			if (clamp(tileCoord + offset, ivec2(stepSize * 2 - 2), ivec2(resolution - stepSize * 2 + 2)) == tileCoord + offset) {
                float depthSample    = -linearizeDepth(texelFetch(depthtex1, (tileCoord + offset * 2), 0).x, gbufferProjectionInverse);
                vec4  gbuffersSample = texelFetch(colortex1, (tileCoord + offset * 2), 0);
                vec3  normalSample   = DecodeNormal(gbuffersSample.z);

                vec4  lightingSample = texelFetch(colortex3, fragCoordOffset + offset, 0);
                float lumSample      = dot(lightingSample.rgb, lumaCoeff);
                float weight = ComputeWeight(
                    depthCenter,     depthSample,  sigmaZ * length(offset * 2),
                    normal_Opaque,   normalSample, sigmaN,
                    luminanceCenter, lumSample,    phiLum
                );

                totalLighting += lightingSample.rgb * weight;
                totalVariance += lumSample * weight * weight;
                totalWeight   += weight;
            }
		}
	}
    totalLighting /= totalWeight;
    totalVariance /= totalWeight * totalWeight;

    if (tileLocation == ivec2(0, 0)) {
        return vec4(totalLighting, history);
    } else {
        return vec4(totalLighting, totalVariance);
    }
}

vec4 resolve(
    ivec2 tileCoord,
    ivec2 fragCoord,
    float depthtex,
    vec3  normal_Current,
    out float history_Out
) {
    vec3 motion = (projectPrevious(vec3(fract(texcoord * 2), depthtex))) * vec3(resolution * 0.5, 1.0);

    vec3  color_Current = textureSmooth(colortex3, fract(texcoord * 2) * 0.5, resolution * 0.5).rgb;
    float lum_Current   = dot(color_Current, lumaCoeff);
    float depth_Current = -linearizeDepth(motion.z, gbufferProjectionInverse);

    vec2 pos_Previous = motion.xy;

    vec4  color_Previous   = textureLod(colortex3, pos_Previous * pixel + vec2(0.0, 0.5), 0.0);
    float history_Previous = textureLod(colortex3, pos_Previous * pixel                 , 0.0).a;
    float weight_Sum = 1.0;

    vec4  gbuffers_Previous = textureLod(colortex2, pos_Previous * pixel * 2, 0.0);
    vec3  normal_Previous   = DecodeNormal(gbuffers_Previous.z);
    float depth_Previous    = -linearizeDepth(gbuffers_Previous.w, gbufferProjectionInverse);

    if (
        abs(depth_Previous - depth_Current) / abs(depth_Current) < 0.1 &&
        floor(pos_Previous * pixel * 2) == vec2(0.0) && 
        color_Previous.r == color_Previous.r && color_Previous.g == color_Previous.g && color_Previous.b == color_Previous.b &&
        history_Previous == history_Previous
    ) {
        color_Previous   /= weight_Sum;
        history_Previous /= weight_Sum;

        //#ifdef Spatial_Filter
        //int Maxframes = 42;
        //#else
        int Maxframes = maxAccumulatedFrames;
        //#endif

        float history     = min(history_Previous + 1.0, Maxframes);
        float color_Alpha = max(0.0, 1.0 / history);

        //if (color_Alpha <= 0.5) history = min(history_Previous + 1.0, Maxframes * 2);

        vec4 color_Variance;
             color_Variance.rgb = mix(color_Previous.rgb, color_Current, color_Alpha);
             color_Variance.a   = dot(color_Variance.rgb, lumaCoeff) * max(1.0, history / 15.0);
        
        history_Out = history;
        return color_Variance;
    } else { 
        const int r = 5; /* spatially compute variance in 5x5 window */

        depth_Current = -linearizeDepth(depthtex, gbufferProjectionInverse);

        vec3  color_Sum  = color_Current;
        float weight_Sum = 1.0;

        float lum_Max = lum_Current; 

        for(int y = -r; y <= r; y++) {
			for(int x = -r; x <= r; x++) {
				if(x == 0 && y == 0)
					continue;

				ivec2 pos = tileCoord + ivec2(x, y) * 2;

				float depth_Sample    = -linearizeDepth(texelFetch(depthtex1, pos, 0).x, gbufferProjectionInverse);
                vec4  gbuffers_Sample = texelFetch(colortex1, pos, 0);
                vec3  normal_Sample   = DecodeNormal(gbuffers_Sample.z);

				float dist_z = abs(depth_Sample - depth_Current) / abs(depth_Current);
				if(dist_z < 0.1) {
					vec4  color_Sample = texelFetch(colortex3, pos / 2, 0);
					float lum_Sample   = dot(color_Sample.rgb, lumaCoeff);

					float weight = pow(max(0.0, dot(normal_Sample, normal_Current)), 128.0);

					color_Sum  += color_Sample.rgb * weight;
					weight_Sum += weight;
                    
					lum_Max = max(lum_Max, lum_Sample);
				}
			}
		}
        if (weight_Sum > 0.001)
            color_Sum /= weight_Sum;

        history_Out = 1.0;
        return vec4(color_Sum, lum_Max);
    }

    return vec4(color_Current, lum_Current);
}


void main() {
    ivec2 tileLocation = ivec2(texcoord * 2);
    ivec2 tileCoord = ivec2(fract(texcoord * 2) * resolution);
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);

    float depthtex = texelFetch(depthtex1, tileCoord, 0).x;

    if (depthtex >= 1.0) {
        colortex3Write = vec4(0.0);
        return;
    }

    vec4 gbuffers_Opaque = texelFetch(colortex1, tileCoord, 0);
    vec3 normal_Opaque   = DecodeNormal(gbuffers_Opaque.z);

    uint randSeed = initRand(uint(gl_FragCoord.x + gl_FragCoord.y * resolution.x), uint(frameCounter), 16);
/*
    if (tileLocation == ivec2(0, 0) || tileLocation == ivec2(0, 1)) {
        colortex3Write = filterTemporal(normal_Opaque, depthtex, fragCoord, tileCoord, tileLocation, randSeed);
    }
*/
    if (tileLocation == ivec2(0, 0) || tileLocation == ivec2(0, 1)) {
        float history;
        vec4  lighting = resolve(tileCoord, fragCoord, depthtex, normal_Opaque, history);

        if (tileLocation == ivec2(0, 0)) {
            colortex3Write.rgb = texelFetch(colortex3, tileCoord / 2, 0).rgb;
            colortex3Write.a   = history;
        } else if (tileLocation == ivec2(0, 1)) {
            colortex3Write = lighting;
        }
    }
}

#endif