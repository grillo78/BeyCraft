// Global varyings

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec2 taaOffset;


#include "/lib/Utility/Space_Transformations.glsl"


#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;
    
    gl_Position = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position      = gl_in[i].gl_Position;
        texcoord         = vertexTexcoord[i];
        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:2 */

layout (location = 0) out vec4 colortex2Write;

in vec2 texcoord;

uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform vec2 resolution;
uniform vec2 pixel;
uniform int frameCounter;


void main() {
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);

    vec4 gbuffers_Opaque   = texelFetch(colortex1, fragCoord, 0);
    vec4 gbuffers_Previous = texelFetch(colortex2, fragCoord, 0);

    colortex2Write = vec4(gbuffers_Previous.x, gbuffers_Opaque.z, gbuffers_Previous.zw);
}

#endif