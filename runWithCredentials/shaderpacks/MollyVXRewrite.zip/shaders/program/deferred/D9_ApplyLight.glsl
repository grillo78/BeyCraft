// Global varyings

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec2 taaOffset;
uniform float worldTime;


#include "/lib/Utility/Space_Transformations.glsl"


#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;

out vec3 sunTransmission;
out vec3 moonTransmission;

uniform sampler2D colortex7;
uniform vec3 sunVector;


#include "/lib/Shared/Atmosphere_Compute.glsl"


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;

    vec3 viewPosition = vec3(0.0, atmosphere_planetRadius + cameraPosition.y, 0.0);
    sunTransmission   = AtmosphereTransmittance(colortex7, viewPosition,  sunVector);
    moonTransmission  = AtmosphereTransmittance(colortex7, viewPosition, -sunVector);

    gl_Position = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

in vec3[3] sunTransmission;
in vec3[3] moonTransmission;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;

out mat2x3 lightColors;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position      = gl_in[i].gl_Position;
        texcoord         = vertexTexcoord[i];

        lightColors[0] = sunTransmission[i];
        lightColors[1] = moonTransmission[i] * 0.05;

        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:0 */

layout (location = 0) out vec4 colortex0Write;

in vec2 texcoord;
in mat2x3 lightColors;

uniform sampler2D colortex1;
uniform sampler2D colortex3;
uniform sampler2D colortex6;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;
uniform sampler2D noisetex;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection, shadowProjectionInverse;
uniform vec3 sunVector;
uniform vec3 moonVector;
uniform vec3 shadowLightVector;
uniform vec2 resolution;
uniform vec2 pixel;
uniform int frameCounter;


#include "/lib/Fragment/ASVGF.glsl"
#include "/lib/Fragment/Noise.glsl"
#include "/lib/Fragment/Mapping.glsl"
#include "/lib/Fragment/Shadows.glsl"
#include "/lib/Shared/Voxelization.glsl"
#include "/lib/Shared/Voxel_Intersect.glsl"
#include "/lib/Shared/Shadow_Distortion.glsl"
#include "/lib/Shared/Atmosphere_Project.glsl"


float calculateBlockerDepth(vec3 space_Shadow, uint randSeed) {
    const float maxBlockerDist = 32.0;
    const int   searchSamples  = 10;

    float searchScale  = 0.5 * maxBlockerDist / abs(shadowProjectionInverse[2].z);
    float spread       = tan(sunAngularRadius) * abs(shadowProjectionInverse[2].z) * shadowProjection[0].x;
    float searchRadius = spread * searchScale;

    float lod = log2(shadowMapResolution * searchRadius);

    float blockerDepth = 0.0;

    for (int i = 0; i < searchSamples; i++) {
        vec2 offset = sincos(nextRand(randSeed) * TAU) * sqrt(nextRand(randSeed)) * searchRadius;
        vec3 shadowSpaceDistorted = distortShadowSpace(space_Shadow + vec3(offset, 0.0));

        float shadowDepth = shadowSpaceDistorted.z - texture2DLod(shadowtex1, shadowSpaceDistorted.xy * 0.5 + 0.5, lod).x;

        blockerDepth += shadowDepth;
    }

    return min(blockerDepth / searchSamples * Shadow_Z_Stretch, searchScale) * spread * shadowMapResolution;
}

vec3 calculateShadows(vec3 space_Shadow, vec3 space_Voxel, vec3 normal_Opaque, uint randSeed) {
    ivec3 originIndex = ivec3(floor(space_Voxel + normal_Opaque * 0.0625));
    float moonFade = clamp(0.75 * (0.9 * (smoothstep(13000.0, 12000.0, float(worldTime)) + smoothstep(23000.0, 25000.0, float(worldTime)))),0.01, 1.0);

    vec3 sunlight = vec3(0.0);

    #ifdef PCSS
        float blockerDepth = calculateBlockerDepth(space_Shadow, randSeed);
        float lod = log2(blockerDepth);

        for(int i = 0; i < PCSS_Rays; ++i) {
            vec3 randVector = vec3(nextRand(randSeed), nextRand(randSeed), nextRand(randSeed));

            #ifdef Contact_Shadows
                vec3 hitPosition;
                vec3 hitNormal;

                vec3  rayDirection = GenUnitVector(randVector.xy);
                float angle = acos(dot(rayDirection, shadowLightVector)) * (sunAngularRadius / PI);

                rayDirection = sin(angle) * normalize(cross(shadowLightVector, rayDirection)) + cos(angle) * shadowLightVector;

                vec4[2] voxel     = ReadVoxel(originIndex);
                int     voxelID   = ExtractVoxelId(voxel);

                bool transmit = (voxelID == 50 || voxelID == 51 || voxelID == 76 || voxelID == 138 || voxelID == 198);

                bool  intersect = RaytraceVoxel(space_Voxel, originIndex, rayDirection, transmit, Ray_Distance, voxel, hitPosition, hitNormal);
                int   hitID = ExtractVoxelId(voxel);
                float bias  = Ray_Distance * 0.0004;
            #else
                bool  intersect = false;
                int   hitID = 0;
                float bias  = 0.0003;
            #endif

            if (!intersect || !IsInVoxelizationVolume(originIndex) ||
                hitID == 50 || hitID == 51 || hitID == 76 || hitID == 138 || hitID == 198
            ) {

                vec2 offset = normalize(randVector.xy * 2.0 - 1.0) * sqrt(randVector.z) * blockerDepth * shadowMapResInverse;
                sunlight += calculateShadow(shadowtex1, distortShadowSpace(space_Shadow + vec3(offset, 0.0)), bias);
            }
        }
        sunlight /= PCSS_Rays;
    #else
        #ifdef Contact_Shadows
            vec3 hitPosition;
            vec3 hitNormal;

            vec3  rayDirection = shadowLightVector;

            vec4[2] voxel     = ReadVoxel(originIndex);
            int     voxelID   = ExtractVoxelId(voxel);

            bool transmit = (voxelID == 50 || voxelID == 51 || voxelID == 76 || voxelID == 138 || voxelID == 198);

            bool  intersect = RaytraceVoxel(space_Voxel, originIndex, rayDirection, transmit, Ray_Distance, voxel, hitPosition, hitNormal);
            int   hitID = ExtractVoxelId(voxel);
            float bias  = Ray_Distance * 0.0004;
        #else
            bool  intersect = false;
            int   hitID = 0;
            float bias  = 0.0003;
        #endif

        if (!intersect || !IsInVoxelizationVolume(originIndex) ||
            hitID == 50 || hitID == 51 || hitID == 76 || hitID == 138 || hitID == 198
        ) {
            sunlight += calculateShadow(shadowtex1, distortShadowSpace(space_Shadow), bias);
        }
    #endif

    sunlight *= max0(dot(shadowLightVector, normal_Opaque));
    sunlight *= lightColors[0] + (lightColors[1] * 0.15);

    return sunlight * (vec3(Sun_Red, Sun_Green, Sun_Blue) / 255) * Sunlight_Brightness * 25.0;
}

vec4 filterSpatial(vec3 normal_Opaque, float depthtex, ivec2 tileCoord, uint randSeed) {
    vec2 coord = texcoord + taaOffset + pixel;
    ivec2 fragCoordFull   = ivec2(coord * resolution) / 2;
    ivec2 fragCoordOffset = ivec2((coord + vec2(0.0, 1.0)) * resolution) / 2;
    ivec2 shift = ivec2(gl_FragCoord.xy) % 2;

    const int iteration = 4;
    const int stepSize  = 4;

    ivec2 jitter = (ivec2(nextRand(randSeed) * stepSize, nextRand(randSeed) * stepSize) * 2 - 1) / 2;

    float history = texelFetch(colortex3, fragCoordFull, 0).a;

    vec4  lightingCenter  = texelFetch(colortex3, fragCoordOffset, 0);
    float luminanceCenter = dot(lightingCenter.rgb, lumaCoeff);

	float variance    = max(epsilonVariance, lightingCenter.a);
    float depthCenter = -linearizeDepth(depthtex, gbufferProjectionInverse);
    float phiLum      = variance * 1.0;
    float phiDepth    = stepSize * sigmaZ / depthCenter;
    float totalWeight = 1.0;

    vec4 result = lightingCenter;

    //return result;

    for (int x = -1; x <= 1; ++x) {
		for (int y = -1; y <= 1; ++y) {
			if (x == 0 && y == 0) { continue; }

			ivec2 offset = ivec2(x, y) * stepSize + jitter;

			if (clamp(tileCoord + offset, ivec2(stepSize - 2), ivec2(resolution - stepSize + 2)) == tileCoord + offset) {
                float depthSample    = -linearizeDepth(texelFetch(depthtex1, (fragCoordFull + offset) * 2, 0).x, gbufferProjectionInverse);
                vec4  gbuffersSample = texelFetch(colortex1, (fragCoordFull + offset) * 2, 0);
                vec3  normalSample   = DecodeNormal(gbuffersSample.z);

                vec4  lightingSample = texelFetch(colortex3, fragCoordOffset + offset, 0);
                float lumSample      = dot(lightingSample.rgb, lumaCoeff);

                if(lightingSample != lightingSample) continue;

                float weight = ComputeWeight(
                    depthCenter,     depthSample,  sigmaZ * length(offset),
                    normal_Opaque,   normalSample, sigmaN,
                    luminanceCenter, lumSample,    phiLum
                ) * max0(1.0 - length(vec2(x, y) + jitter) / 1.5);

                result      += lightingSample * vec4(vec3(weight), weight * weight);
                totalWeight += weight;
            }
		}
	}
    result = result / vec4(vec3(totalWeight), totalWeight * totalWeight);

    //if (iteration == 0) result.a = variance;

    return result;
}


void main() {
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);

    float depthtex     = texelFetch(depthtex1, fragCoord, 0).x;
    vec3  space_Screen = vec3(texcoord - taaOffset * 0.5, depthtex);
    vec3  space_View   = calculateViewSpace(space_Screen, gbufferProjectionInverse);
    vec3  space_World  = mat3(gbufferModelViewInverse) * space_View + gbufferModelViewInverse[3].xyz;

    if (depthtex >= 1.0) {
        vec2 lookupUV = ProjectSky(space_World);
        colortex0Write.rgb = texture2D(colortex6, lookupUV).rgb * PI;
        return;
    }
    vec3 space_Shadow = projMAD(shadowProjection, transMAD(shadowModelView, space_World)) * 0.5 + 0.5;
    vec3 space_Voxel  = SceneSpaceToVoxelSpace(space_World);

    vec4  gbuffers_Opaque = texelFetch(colortex1, fragCoord, 0);
    vec3  albedo_Opaque   = toLinear(DecodeArbitrary(uint(gbuffers_Opaque.x * Values_16Bit), RGB_16_Bits).rgb);
    vec3  specular_Opaque = DecodeArbitrary(uint(gbuffers_Opaque.y * Values_16Bit), RGB_16_Bits).rgb;
    vec3  normal_Opaque   = DecodeNormal(gbuffers_Opaque.z);
    vec2  flags_Opaque    = Unpack2x8(gbuffers_Opaque.a);
    int   IDs_Opaque      = int(255 - flags_Opaque.x * 255);

	uint randSeed = initRand(uint(gl_FragCoord.x + gl_FragCoord.y * resolution.x), uint(frameCounter), 16);
    
    float emitter = pow2(length(albedo_Opaque)) * float(IsEmissiveId(int(floor(255.5 - 255.0 * flags_Opaque.x))));
    #ifdef Resource_Pack_Emitters
          emitter = specular_Opaque.b;
    #endif

    vec3 lighting  = vec3(0.0);
         lighting += calculateShadows(space_Shadow, space_Voxel, normal_Opaque, randSeed) * flags_Opaque.y;
         lighting += filterSpatial(normal_Opaque, depthtex, fragCoord, randSeed).rgb;
         //lighting  = lighting * max0(1.0 - float(IsEmissiveId(int(floor(255.5 - 255.0 * flags_Opaque.x)))) * length(albedo_Opaque));
         lighting += albedo_Opaque * emitter * 2.3 * Bloom_Brightness * 3;
    
    if (lighting != lighting) lighting = vec3(0.0);
    
    colortex0Write.rgb = albedo_Opaque * lighting;
}

#endif