// Global varyings

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition, previousCameraPosition;


#include "/lib/Utility/Space_Transformations.glsl"


#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;
    
    gl_Position = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position      = gl_in[i].gl_Position;
        texcoord         = vertexTexcoord[i];
        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:6 */

layout (location = 0) out vec4 colortex6Write;

in vec2 texcoord;

uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform sampler2D noisetex;
uniform vec3 sunVector;
uniform vec3 moonVector;
uniform vec2 resolution;
uniform vec2 pixel;
uniform int frameCounter;


#include "/lib/Fragment/Noise.glsl"
#include "/lib/Shared/Atmosphere_Project.glsl"
#include "/lib/Shared/Atmosphere_Compute.glsl"
#include "/lib/Shared/Spectrum.glsl"


vec3 CalculateStars(vec3 background, vec3 viewVector) {
    const float scale = 256.0;
    const float coverage = 0.01;
    const float maxLuminance = 0.7;
    const float minTemperature = 1500.0;
    const float maxTemperature = 9000.0;

    viewVector = Rotate(viewVector, sunVector, vec3(0, 0, 1));

    // TODO: Calculate for surrounding cells as well to allow uniform apparent size

    vec3  p = viewVector * scale;
    ivec3 i = ivec3(floor(p));
    vec3  f = p - i;
    float r = dot(f - 0.5, f - 0.5);

    vec2 hash = hash23(i);
    hash.y = 2.0 * hash.y - 4.0 * hash.y * hash.y + 3.0 * hash.y * hash.y * hash.y;

    vec3 luminance = pow2(linearstep(1.0 - coverage, 1.0, hash.x)) * planckianLocus(mix(minTemperature, maxTemperature, hash.y));
    return background + maxLuminance * linearstep(0.25, 0.0, r) * pow2(linearstep(1.0 - coverage, 1.0, hash.x)) * planckianLocus(mix(minTemperature, maxTemperature, hash.y));
}


void main() {
    float tileSize = min(floor(resolution.x * 0.5) / 1.5, floor(resolution.y * 0.5)) * exp2(-Sky_Image_LOD);
	vec2 cmp = tileSize * vec2(3.0, 2.0);
    if (gl_FragCoord.x < cmp.x && gl_FragCoord.y < cmp.y) {
        vec3 viewPosition  = vec3(0.0, atmosphere_planetRadius + cameraPosition.y, 0.0);
        vec3 viewDirection = UnprojectSky(texcoord);

        vec3 transmission = vec3(1.0);
        //mat3 skySample  = sampleScattering(viewPosition, viewDirection, sunVector, moonVector, ivec2(4, 2), transmission);
        //vec3 scattering = skySample[0] * sunTint + skySample[1] * moonTint;

        colortex6Write.rgb = AtmosphereScattering(colortex6, viewPosition, viewDirection, sunVector) * sunTint + 
                             AtmosphereScattering(colortex6, viewPosition, viewDirection, moonVector) * moonTint;
    } else {
        colortex6Write = vec4(0.0, 0.0, 0.0, 1.0);
    }
}

#endif