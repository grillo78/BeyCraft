// Global varyings
f
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec2 taaOffset;
uniform vec2 resolution;
uniform vec2 pixel;


#include "/lib/Utility/Space_Transformations.glsl"


#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;
    
    gl_Position    = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position    = gl_in[i].gl_Position;
        gl_Position.xy = gl_Position.xy * 0.5 - 0.5 + vec2(1.0, 1.0);
        texcoord = vertexTexcoord[i];
        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:3 */

layout (location = 0) out vec4 colortex3Write;

in vec2 texcoord;

uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex1;
uniform float near, far;
uniform int frameCounter;

const bool colortex1MipmapEnabled = true;
const bool colortex3MipmapEnabled = true;


bool reproject(vec3 space_Screen, vec3 space_World, vec3 normal, float depthtex, ivec2 tileCoord, out vec3 reprojected) {
    reprojected = projectPrevious(space_Screen);

    float linearDepth = -linearizeDepth(reprojected.z, gbufferProjectionInverse);

    vec4  gbuffers_Previous = texelFetch(colortex2, ivec2(reprojected.xy * resolution), 0);
    vec3  normal_Previous   = DecodeNormal(gbuffers_Previous.y);
    float depthtex_Previous = -linearizeDepth(gbuffers_Previous.w, gbufferProjectionInverse);
    
    return isReprojValid(reprojected.xy, normal, normal_Previous, linearDepth, depthtex_Previous);
}

vec4 accumulate_Moments(vec3 space_Screen, vec3 space_World, vec3 normal_Opaque, float depthtex, ivec2 tileCoord, ivec2 fragCoord) {
    vec4 informationPass = vec4(0.0);

    vec3 reprojected;
    bool success = reproject(space_Screen, space_World, normal_Opaque, depthtex, tileCoord, reprojected);

    vec2  previousMoments = texelFetch(colortex3, ivec2((reprojected.xy + vec2(1.0, 1.0)) * resolution) / 2, 0).xy;
    vec4  currentLighting = texelFetch(colortex3, ivec2((reprojected.xy + vec2(0.0, 1.0)) * resolution) / 2, 0);
    float history = currentLighting.a;
    
    float historyLength = success ? min(history + 1.0, maxAccumulatedFrames) : 1.0;
    float alpha = success ? 1.0 / historyLength : 1.0;

    vec2 currentMoments;
         currentMoments.x = dot(currentLighting.rgb, lumaCoeff);
         currentMoments.y = currentMoments.x * currentMoments.x;

    vec2 accumulatedMoments = mix(previousMoments, currentMoments, alpha);

    informationPass.xy = accumulatedMoments;

    return informationPass;
}


void main() {
    ivec2 tileCoord = ivec2(texcoord * resolution);
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);

    float depthtex     = texelFetch(depthtex1, ivec2(tileCoord * 0.5) * 2, 0).x;

    if (depthtex >= 1.0) {
        colortex3Write = vec4(0.0);
        return;
    }

    vec3  space_Screen = vec3(texcoord, depthtex);
    vec3  space_View   = calculateViewSpace(space_Screen, gbufferProjectionInverse);
    vec3  space_World  = mat3(gbufferModelViewInverse) * space_View;

    vec4 gbuffers_Opaque = texelFetch(colortex1, ivec2(tileCoord * 0.5) * 2, 0);
    vec3 normal_Opaque   = DecodeNormal(gbuffers_Opaque.z);

    colortex3Write = accumulate_Moments(space_Screen, space_World, normal_Opaque, depthtex, tileCoord, fragCoord);
}

#endif