// Global varyings

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec2 taaOffset;
uniform vec2 resolution;
uniform vec2 pixel;


#include "/lib/Utility/Space_Transformations.glsl"


#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;
    
    gl_Position    = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position    = gl_in[i].gl_Position;
        gl_Position.xy = gl_Position.xy * 0.5 - 0.5 + vec2(0.0, 1.0);
        texcoord = vertexTexcoord[i];
        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:3 */

layout (location = 0) out vec4 colortex3Write;

in vec2 texcoord;

uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex1;
uniform sampler2D noisetex;
uniform float near, far;
uniform int frameCounter;
uniform float viewWidth, viewHeight;

const bool colortex1MipmapEnabled = true;
const bool colortex3MipmapEnabled = true;


#include "/lib/Fragment/ASVGF.glsl"
#include "/lib/Fragment/Noise.glsl"

vec2 haltonSequence(vec2 i, vec2 b) {
	vec2 f = vec2(1.0), r = vec2(0.0);
	while (i.x > 0.0 || i.y > 0.0) {
		f /= b;
		r += f * mod(i, b);
		i  = floor(i / b);
	}
    return r;
}

vec2 temporalJitter() {
	vec2 scale = 2.0 / vec2(viewWidth, viewHeight);
	return haltonSequence(vec2(frameCounter % 16), vec2(2.0, 3.0)) * scale + (-0.5 * scale);
}

vec4 filterSpatial(vec3 normal_Opaque, float depthtex, ivec2 tileCoord, uint randSeed) {
    ivec2 fragCoordFull   = ivec2(texcoord * resolution) / 2;
    ivec2 fragCoordOffset = ivec2((texcoord + vec2(0.0, 1.0)) * resolution) / 2;
    ivec2 shift     = ivec2(gl_FragCoord.xy) % 2;

    const int i[4] = int[4](
        1, 1, 1, 1
    );

    //#ifdef Spatial_Filter
    //int Maxframes = 42;
    //#else
    int Maxframes = maxAccumulatedFrames;
    //#endif

    const int iteration = DEFERRED - 1;
    int stepSize  = int(Filter_StepSize);
    stepSize = iteration;

    ivec2 jitter = (ivec2(nextRand(randSeed), nextRand(randSeed)));

    float history = texelFetch(colortex3, ivec2(texcoord * resolution * 0.5), 0).a;

    vec4  lightingCenter  = texelFetch(colortex3, fragCoordOffset, 0);
    float luminanceCenter = dot(lightingCenter.rgb, lumaCoeff);

	float variance    = max(epsilonVariance, lightingCenter.a) / max0(1.0 + -linearizeDepth(depthtex, gbufferProjectionInverse) * 5.0);
    float depthCenter = -linearizeDepth(depthtex, gbufferProjectionInverse);
    float phiLum      = mix(sigmaL, 256.0, (1.0 / history - 1.0 / Maxframes) * (1.0 + 1.0 / Maxframes)) * max0(variance);
    float phiDepth    = stepSize * sigmaZ / depthCenter;
    float totalWeight = 1.0;

    vec4 result = lightingCenter;

    for (int x = -1; x <= 1; ++x) {

		for (int y = -1; y <= 1; ++y) {

			if (x == 0 && y == 0) { continue; }

			ivec2 offset = ivec2(x, y) * stepSize + jitter;

			if (clamp(tileCoord + offset, ivec2(stepSize * 2 - 2), ivec2(resolution - stepSize * 2 + 2)) == tileCoord + offset) {
                float depthSample    = -linearizeDepth(texelFetch(depthtex1, (fragCoordFull + offset) * 2, 0).x, gbufferProjectionInverse);
                vec4  gbuffersSample = texelFetch(colortex1, (fragCoordFull + offset) * 2, 0);
                vec3  normalSample   = DecodeNormal(gbuffersSample.z);

                vec4  lightingSample = texelFetch(colortex3, fragCoordOffset + offset, 0);
                float lumSample      = dot(lightingSample.rgb, lumaCoeff);

                if(lightingSample != lightingSample) continue;

                float weight = ComputeWeight(
                    depthCenter,     depthSample,  sigmaZ * length(offset),
                    normal_Opaque,   normalSample, sigmaN,
                    luminanceCenter, lumSample,    phiLum
                );

                result      += lightingSample * vec4(vec3(weight), weight * weight);
                totalWeight += weight;
            }
		}
	}
    result = result / vec4(vec3(totalWeight), totalWeight * totalWeight);

    float accuracyInv = maxAccumulatedFrames;
    float vMult = Variance_Multiplier;

    if (accuracyInv >= 6) vMult *= 1.3;


    #ifdef Additional_Variance_Application
    result.a += (variance * 0.35) * (1 / Rays);// * (vMult * 10) * totalWeight;
    result.a += (variance * 0.2) * (vMult * 10) * totalWeight * (1 / Rays) * 1.2;
    result.a += (variance * 0.6) * (vMult / 10) * totalWeight * (1 / Rays);
    #endif

    return result;
}


void main() {
    ivec2 tileCoord = ivec2(texcoord * resolution);
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);

    float depthtex = texelFetch(depthtex1, ivec2(tileCoord * 0.5) * 2, 0).x;

    if (depthtex >= 1.0) {
        colortex3Write = vec4(0.0);
        return;
    }

    vec4 gbuffers_Opaque = texelFetch(colortex1, ivec2(tileCoord * 0.5) * 2, 0);
    vec3 normal_Opaque   = DecodeNormal(gbuffers_Opaque.z);

    uint randSeed = initRand(uint(gl_FragCoord.x + gl_FragCoord.y * (resolution.x)), uint(frameCounter), 16);


    #ifdef Spatial_Filter
    colortex3Write = filterSpatial(normal_Opaque, depthtex, tileCoord, randSeed);
    #else
    colortex3Write = texelFetch(colortex3, fragCoord, 0);
    #endif
}

#endif