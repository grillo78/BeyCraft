// Global varyings
f
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec2 taaOffset;
uniform vec2 resolution;
uniform vec2 pixel;


#include "/lib/Utility/Space_Transformations.glsl"


#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;
    
    gl_Position    = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position      = gl_in[i].gl_Position;
        texcoord = vertexTexcoord[i];
        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:3 */

layout (location = 0) out vec4 colortex3Write;

in vec2 texcoord;

uniform sampler2D colortex3;

const bool colortex3MipmapEnabled = true;


float filterVariance() {
    ivec2 coord = ivec2((fract(texcoord * 2.0) + vec2(1.0, 1.0)) * resolution) / 2;

    float sum = 0.0;

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            ivec2 offset = ivec2(x, y);
            vec2 moments = texelFetch(colortex3, coord + offset, 0).xy;
            sum += max0(moments.y - moments.x * moments.x);
        }
    }
    sum = sum / 9.0;

	return sum;
}

vec4 bufferCopyFlip() {
    vec4 A2B = texelFetch(colortex3, ivec2(gl_FragCoord.xy), 0);
    if (floor(texcoord * 2) == vec2(1.0, 0.0)) {
        vec4 lighting = texelFetch(colortex3, ivec2((texcoord + vec2(-0.5, 0.5)) * resolution), 0);
        A2B.rgb = lighting.rgb;

        vec2 moments = texelFetch(colortex3, ivec2((fract(texcoord * 2.0) + vec2(1.0, 1.0)) * resolution) / 2, 0).xy;
        A2B.a = dot(lighting.rgb, lumaCoeff);
    }
    return A2B;
}


void main() {
    colortex3Write = bufferCopyFlip();
}

#endif