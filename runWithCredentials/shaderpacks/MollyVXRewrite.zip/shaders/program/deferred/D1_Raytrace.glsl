// Global varyings

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection, gbufferPreviousProjectionInverse;
uniform mat4 gbufferPreviousModelView, gbufferPreviousModelViewInverse;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec2 taaOffset;
uniform vec2 resolution;
uniform vec2 pixel;


#include "/lib/Utility/Space_Transformations.glsl"


#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;

out vec3 sunTransmission;
out vec3 moonTransmission;

uniform sampler2D colortex7;
uniform vec3 sunVector;


#include "/lib/Shared/Atmosphere_Compute.glsl"


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;

    vec3 viewPosition = vec3(0.0, atmosphere_planetRadius + cameraPosition.y, 0.0);
    sunTransmission   = AtmosphereTransmittance(colortex7, viewPosition,  sunVector);
    moonTransmission  = AtmosphereTransmittance(colortex7, viewPosition, -sunVector);

    gl_Position = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

in vec3[3] sunTransmission;
in vec3[3] moonTransmission;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;

out mat2x3 lightColors;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position    = gl_in[i].gl_Position;
        gl_Position.xy = gl_Position.xy;
        texcoord = vertexTexcoord[i];

        lightColors[0] = sunTransmission[i]  * sunTint * vec3(1.0, 0.9, 1.0);
        lightColors[1] = moonTransmission[i] * moonTint;

        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:34 */

layout (location = 0) out vec4 colortex3Write;
layout (location = 1) out vec4 colortex4Write;

in vec2 texcoord;
in mat2x3 lightColors;

uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex6;
uniform sampler2D depthtex1;
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;
uniform sampler2D noisetex;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightVector;
uniform float near, far;
uniform int frameCounter;

const bool colortex3MipmapEnabled = false;

const bool shadowcolor0Mipmap  = true;
const bool shadowcolor1Mipmap  = true;


#include "/lib/Fragment/Noise.glsl"
#include "/lib/Fragment/Mapping.glsl"
#include "/lib/Fragment/Shadows.glsl"
#include "/lib/Shared/Voxelization.glsl"
#include "/lib/Shared/Voxel_Intersect.glsl"
#include "/lib/Shared/Atmosphere_Project.glsl"
#include "/lib/Shared/Shadow_Distortion.glsl"


vec3 calculateFlatNormals(vec3 space_View) {
    vec2 deltaCoordPosX = texcoord + vec2(pixel.x, 0.0);
    vec2 deltaCoordPosY = texcoord + vec2(0.0, pixel.y);
    //vec2 deltaCoordNegX = texcoord - vec2(pixel.x, 0.0);
    //vec2 deltaCoordNegY = texcoord - vec2(0.0, pixel.y);

	vec3 samplePosX = calculateViewSpace(vec3(deltaCoordPosX, texture2D(depthtex1, deltaCoordPosX).x), gbufferProjectionInverse);
	vec3 samplePosY = calculateViewSpace(vec3(deltaCoordPosY, texture2D(depthtex1, deltaCoordPosY).x), gbufferProjectionInverse);
	//vec3 sampleNegX = calculateViewSpace(vec3(deltaCoordNegX, texture2D(depthtex1, deltaCoordNegX).x), gbufferProjectionInverse);
	//vec3 sampleNegY = calculateViewSpace(vec3(deltaCoordNegY, texture2D(depthtex1, deltaCoordNegY).x), gbufferProjectionInverse);

    vec3 deltaPosX = (samplePosX - space_View);// + (space_View - sampleNegX);
    vec3 deltaPosY = (samplePosY - space_View);// + (space_View - sampleNegY);

    return mat3(gbufferModelViewInverse) * normalize(cross(deltaPosX, deltaPosY));
}

mat2x3 raytrace(vec3 space_Voxel, vec3 normal, uint randSeed) {
    vec3 startPos   = SceneSpaceToVoxelSpace(gbufferModelViewInverse[3].xyz);
    vec3 viewVector = normalize(space_Voxel - startPos);

    vec3 diffuse = vec3(0.0);
    vec3 scatter = vec3(0.0);

    for (int i = 0; i < Rays; i++) {

        float volumeInteractionDistance = -log(nextRand(randSeed)) / Volume_Density;
		bool  volumeInteraction = volumeInteractionDistance < distance(space_Voxel, startPos);

        vec3 bounceNormal = normal;
        vec3 rayPosition  = volumeInteraction ? startPos + viewVector * volumeInteractionDistance : space_Voxel;
        vec3 rayDirection;
        vec3 previousRayDirection;

        bool hitSky;

        vec4[2] voxel;
        int voxelID = 0;
        int voxelIDPrevious = 0;

        vec3 contribution = vec3(1.0);

        for (int j = 0; j < Ray_Bounces; j++) {
            //bool transmit = (voxelID == 50 || voxelID == 51 || voxelID == 76 || voxelID == 138 || voxelID == 198);
            
            vec3 randVector = vec3(nextRand(randSeed), nextRand(randSeed), nextRand(randSeed));
            ivec3 originIndex;

            if (volumeInteraction) {
                rayDirection = GenUnitVector(randVector.xy);
                originIndex = ivec3(floor(rayPosition));
            } else {
                rayDirection = GenCosineVector(bounceNormal, randVector);
                originIndex = ivec3(floor(rayPosition + bounceNormal * 0.06125));
            }

            vec3 rayPrevious = rayPosition;
            
            if (!IsInVoxelizationVolume(originIndex)) {
                hitSky = true;
                break;
            }

            bool hit = RaytraceVoxel(rayPosition, originIndex, rayDirection, false, Ray_Distance, voxel, rayPosition, bounceNormal);

            volumeInteractionDistance = -log(nextRand(randSeed)) / Volume_Density;
			volumeInteraction = volumeInteractionDistance < distance(rayPosition, rayPrevious);
/*
            if (volumeInteraction) {
                voxelID = voxelIDPrevious;

                rayPosition = rayPrevious + rayDirection * volumeInteractionDistance;
                contribution *= 1.0; //volumeScatteringAlbedo;
                scatter += contribution;
            } else*/ if (hit) {
                if (distance(rayPrevious, rayPosition) <= 0.0) { break; } // Ray is stuck
                hitSky = false;

                voxelID = ExtractVoxelId(voxel);
                voxelIDPrevious = voxelID;

                contribution *= toLinear(ExtractVoxelTint(voxel));
                diffuse += contribution * float(IsEmissiveId(voxelID)) * 8.0 * Emitter_Luminance * 2.4;
                if (dot(bounceNormal, shadowLightVector) <= 0.0) continue;

                vec3 hitPosition;
                vec3 hitNormal;
                #ifdef Contact_Shadows
                    if (!RaytraceVoxel(rayPosition, ivec3(floor(rayPosition + bounceNormal * 0.06125)), shadowLightVector, false, 16, voxel, hitPosition, hitNormal)) {
                        vec3 space_Shadow = VoxelSpaceToSceneSpace(rayPosition);
                             space_Shadow = projMAD(shadowProjection, transMAD(shadowModelView, space_Shadow)) * 0.5 + 0.5;

                        contribution *= dot(bounceNormal, shadowLightVector);

                        diffuse += contribution * ((lightColors[0] * vec3(Sun_Red, Sun_Green, Sun_Blue) / 255 * Sunlight_Brightness) * 0.04 + lightColors[1]) * calculateShadow(shadowtex1, distortShadowSpace(space_Shadow), 0.0002);

                    }
                #else
                    vec3 space_Shadow = VoxelSpaceToSceneSpace(rayPosition);
                         space_Shadow = projMAD(shadowProjection, transMAD(shadowModelView, space_Shadow)) * 0.5 + 0.5;

                    contribution *= dot(bounceNormal, shadowLightVector);

                        diffuse += contribution * ((lightColors[0] * vec3(Sun_Red, Sun_Green, Sun_Blue) / 255 * Sunlight_Brightness) * 0.04 + lightColors[1]) * calculateShadow(shadowtex1, distortShadowSpace(space_Shadow), 0.0002);

                #endif
                //if (voxelID == 31) diffuse *= 15.0;
            } else {
                hitSky = true;
                break;
            }
        }

        if (hitSky) {
            vec2 lookupUV = ProjectSky(rayDirection);
            vec3 sky = texture2D(colortex6, lookupUV).rgb;
            contribution *= (sky * 4.0);
            diffuse += contribution;
            continue;
        }
    }

    return mat2x3(diffuse / Rays, scatter / Rays);
}
/*
bool reproject(vec3 space_Screen, vec3 space_World, vec3 normal, float currentLuminance, out vec3 reprojected, out vec3 previousLighting, out vec3 previousVolumetrics, out float history, out float weight) {
    reprojected = projectPrevious(space_Screen);

    float linearDepth = -linearizeDepth(reprojected.z, gbufferProjectionInverse);

    vec4  gbuffers_Previous = texture(colortex2, reprojected.xy, 0.0);
    vec3  normal_Previous   = DecodeNormal(gbuffers_Previous.y);
    float depthtex_Previous = -linearizeDepth(gbuffers_Previous.w, gbufferProjectionInverse);

    vec3  view_Previous  = calculateViewSpace(vec3(reprojected.xy, gbuffers_Previous.w), gbufferPreviousProjectionInverse);
    vec3  world_Previous = mat3(gbufferPreviousModelViewInverse) * view_Previous;

    float currentNormalWeight  = 1.0 / (clamp01(-dot(normal, normalize(space_World))) * 100.0 + 1.0);
    float PreviousNormalWeight = 1.0 / (clamp01(-dot(normal_Previous, normalize(world_Previous))) * 100.0 + 1.0);

    vec4  previous = textureLod(colortex3, reprojected.xy / 2.0, 0.0);
    previousLighting = previous.rgb;
    history = previous.a;

    previousVolumetrics = textureLod(colortex4,reprojected.xy / 2.0, 0.0).rgb;

    float previousLuminance = dot(previous.rgb, lumaCoeff);

    weight = ComputeWeight(
        linearDepth, depthtex_Previous, 8.0,
        normal,      normal_Previous,   1.0,
        1.0, 1.0, 1.0
    );

    if (clamp01(reprojected.xy) != reprojected.xy) return false;

    if (dot(normal, normal_Previous) < 0.06125) return false;

    if (abs(depthtex_Previous - linearDepth) / abs(linearDepth) > 0.1) return false;
    
    return true;
}

void accumulate(inout vec4 lightBuffer, inout vec4 volumeBuffer, vec3 space_Screen, vec3 space_World, vec3 space_Voxel, vec3 normal, uint randSeed) {
    mat2x3 currentLighting  = raytrace(space_Voxel, normal, randSeed);
    float  currentLuminance = dot(currentLighting[0], lumaCoeff);

    vec3  reprojected;
    vec3  previousLighting;
    vec3  previousVolumetrics;
    float history;
    float weight;
    bool  success = reproject(space_Screen, space_World, normal, currentLuminance, reprojected, previousLighting, previousVolumetrics, history, weight);
    
    float historyLength = success ? min(history + 1.0, maxAccumulatedFrames) : 1.0;
    float alpha = 1.0 / historyLength;
    //      alpha = exp2(-historyLength);

    vec3 accumulatedLighting = mix(previousLighting, currentLighting[0], alpha);
    if (accumulatedLighting != accumulatedLighting) accumulatedLighting = vec3(0.0);

    vec3 accumulatedVolumetrics = mix(previousVolumetrics, currentLighting[1], alpha);
    if (accumulatedVolumetrics != accumulatedVolumetrics) accumulatedVolumetrics = vec3(0.0);

    lightBuffer  = vec4(accumulatedLighting,    historyLength);
    volumeBuffer = vec4(accumulatedVolumetrics, historyLength);
}
*/

void main() {
    ivec2 tileLocation = ivec2(texcoord * 2);
    ivec2 tileCoord = ivec2(fract(texcoord * 2) * resolution);
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);

    float depthtex = texelFetch(depthtex1, tileCoord, 0).x;

    //if (depthtex >= 1.0) {
    //    colortex3Write = vec4(0.0);
    //    return;
    //}

    ivec2 nearestCoord = tileCoord;
    float nearestDepth = depthtex;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            if (x == 0 && y == 0) { continue; }
            ivec2 coord = tileCoord + ivec2(x, y) * 2;
            float depthSample = texelFetch(depthtex1, coord, 0).x;

            if (depthSample < depthtex) {
                nearestCoord = coord;
                nearestDepth = depthSample;
            }
        }
    }

    depthtex = texelFetch(depthtex1, nearestCoord, 0).x;

    vec3  space_Screen = vec3(fract(texcoord * 2), depthtex);
    vec3  space_View   = calculateViewSpace(space_Screen, gbufferProjectionInverse);
    vec3  space_World  = mat3(gbufferModelViewInverse) * space_View + gbufferModelViewInverse[3].xyz;
    vec3  space_Voxel  = SceneSpaceToVoxelSpace(space_World);

    vec4 gbuffers_Opaque = texelFetch(colortex1, tileCoord, 0);
    vec3 normal_Opaque   = DecodeNormal(gbuffers_Opaque.z);
    vec2 flags_Opaque    = Unpack2x8(gbuffers_Opaque.a);
    int  IDs_Opaque      = int(255 - flags_Opaque.x * 255);

	uint randSeed = initRand(uint(gl_FragCoord.x + gl_FragCoord.y * resolution.x), uint(frameCounter), 16);

    if (tileLocation == ivec2(0, 0)) {
        mat2x3 lighting = raytrace(space_Voxel, normal_Opaque, randSeed);
        colortex3Write.rgb = lighting[0];
        colortex3Write.a   = texelFetch(colortex3, fragCoord, 0).a;
        //colortex4Write.rgb = lighting[1];
        //colortex4Write.a   = texelFetch(colortex4, fragCoord, 0).a;
    } else if (tileLocation == ivec2(0, 1)) {
        colortex3Write = texelFetch(colortex3, fragCoord, 0);
    }
    
    //accumulate(colortex3Write, colortex4Write, space_Screen, space_World, space_Voxel, normal_Opaque, randSeed);
}

#endif
