// Global varyings

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec2 taaOffset;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform mat4 shadowProjectionInverse;
uniform sampler2D shadowtex1;
uniform vec3 shadowLightPosition;
uniform int isEyeInWater;



#include "/lib/Utility/Space_Transformations.glsl"

#define shadowZstretch 2.5
#define shadowBias 0.9




#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;

out vec3 sunTransmission;
out vec3 moonTransmission;

uniform sampler2D colortex7;
uniform vec3 sunVector;


#include "/lib/Shared/Atmosphere_Compute.glsl"


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;

    vec3 viewPosition = vec3(0.0, atmosphere_planetRadius + cameraPosition.y, 0.0);
    sunTransmission   = AtmosphereTransmittance(colortex7, viewPosition,  sunVector);
    moonTransmission  = AtmosphereTransmittance(colortex7, viewPosition, -sunVector);

    gl_Position = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

in vec3[3] sunTransmission;
in vec3[3] moonTransmission;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;

out mat2x3 lightColors;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position      = gl_in[i].gl_Position;
        texcoord         = vertexTexcoord[i];

        lightColors[0] = sunTransmission[i]  * sunTint;
        lightColors[1] = moonTransmission[i] * moonTint;

        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:0 */

layout (location = 0) out vec4 colortex0Write;

in vec2 texcoord;
in mat2x3 lightColors;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform vec2 resolution;
uniform vec2 pixel;
uniform int frameCounter;
uniform float viewWidth, viewHeight;
uniform float near, far;


uniform ivec2 eyeBrightnessSmooth;

float bayer2(vec2 a){
    a = floor(a);
    return fract(dot(a, vec2(0.5, a.y * 0.75)));
}

float bayer4(vec2 a)   { return bayer2( 0.5  *a) * 0.25     + bayer2(a); }
float bayer8(vec2 a)   { return bayer4( 0.5  *a) * 0.25     + bayer2(a); }
float bayer16(vec2 a)  { return bayer4( 0.25 *a) * 0.0625   + bayer4(a); }
float bayer32(vec2 a)  { return bayer8( 0.25 *a) * 0.0625   + bayer4(a); }
float bayer64(vec2 a)  { return bayer8( 0.125*a) * 0.015625 + bayer8(a); }
float bayer128(vec2 a) { return bayer16(0.125*a) * 0.015625 + bayer8(a); }


const bool colortex0MipmapEnabled = true;

float distortionfactor(vec2 shadowspace){
float dist = length(abs(shadowspace * 1.165));
float distortion = ((1.0 - shadowBias) + dist * shadowBias) * 0.97;
return distortion;
}

float ld(float depth) {
   return (2.0 * near) / (far + near - depth * (far - near));
}

vec3 AerialPerspective(float dist) {

    #ifndef Fog
        return vec3(0.0);
    #endif

    float indoors       = 1.0 - clamp01((-eyeBrightnessSmooth.y + 230) / 100.0);
    if (isEyeInWater > 0.0) indoors = 1.0;

    float factor  = pow(dist, 1.0) * 0.08 * 1.0 * (1.0 + isEyeInWater * 4);
    return pow(vec3(0.2, 0.3, 1.25), vec3(1.3 - clamp01(factor) * 0.4)) * factor * 5 * indoors;
}

void celshade(inout vec3 color) {

    #ifndef Outline
        return;
    #endif

	float size = 0.63 * Outline_Thickness;
	vec2 pixel = 1.0 / vec2(viewWidth, viewHeight) * size;
    vec2 coord = texcoord;
	
	float outline;
	outline  = ld(texture2D(depthtex0, coord).r) * far * 8.0;
	outline -= ld(texture2D(depthtex0, coord + vec2( pixel.x * 2.0, 0.0)).r) * far;
	outline -= ld(texture2D(depthtex0, coord + vec2(-pixel.x * 2.0, 0.0)).r) * far;
	outline -= ld(texture2D(depthtex0, coord + vec2(0.0,  pixel.y * 2.0)).r) * far;
	outline -= ld(texture2D(depthtex0, coord + vec2(0.0, -pixel.y * 2.0)).r) * far;
	outline -= ld(texture2D(depthtex0, coord + vec2( pixel.x * 1.4,  pixel.y * 1.4)).r) * far;
	outline -= ld(texture2D(depthtex0, coord + vec2(-pixel.x * 1.4,  pixel.y * 1.4)).r) * far;
	outline -= ld(texture2D(depthtex0, coord + vec2( pixel.x * 1.4, -pixel.y * 1.4)).r) * far;
	outline -= ld(texture2D(depthtex0, coord + vec2(-pixel.x * 1.4, -pixel.y * 1.4)).r) * far;
	
	outline = clamp(1.0 - outline * 0.5 , 0.0 , 1.0);
//	outline = saturate(1.0 - outline * 0.5);
	
	color *= outline;
}
/*
vec3 transmittedScatteringIntegral(float od, const vec3 coeff) {
	const vec3 a = -coeff / log(2.0);
	const vec3 b = -1.0 / coeff;
	const vec3 c =  1.0 / coeff;

	return exp2(a * od) * b + c; // = ∫{0,od} e^(-coeff*x) dx
}

void calculateUnderwaterShading(inout gbuffer info, material mat, scene spaces) {
    if (isEyeInWater < 0.5) return;

    vec3 totalCoeff   = waterAbsorbCoeff + waterScatterCoeff;

    float waterDepth  = length(space_World);

    vec3 finalShading = vec3(0.0, 0.85, 1.0);

    vec3 absorption   = exp(-totalCoeff * waterDepth);
    vec3 scatter      = transmittedScatteringIntegral(waterDepth, totalCoeff) / PI * LOG2 * finalShading * waterScatterCoeff;

    color = color * absorption + scatter;
    color = mix(color, scatter, 0.1);
}
*/


void main() {
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);

    vec4 gbuffers_Transparent = texelFetch(colortex1, fragCoord, 0);
    vec3 albedo_Transparent   = toLinear(DecodeArbitrary(uint(gbuffers_Transparent.x * Values_16Bit), RGB_16_Bits).rgb);

    vec2 depthtex     = vec2(texelFetch(depthtex0, fragCoord, 0).x, texelFetch(depthtex1, fragCoord, 0).x);
    vec3 space_Screen = vec3(texcoord, depthtex);
    vec3 space_View   = calculateViewSpace(space_Screen, gbufferProjectionInverse);
    vec3 space_World  = mat3(gbufferModelViewInverse) * space_View;

    vec3 viewvec  = normalize(space_View);
    vec3 lightvec = normalize(shadowLightPosition);

    vec4 color = texelFetch(colortex0, fragCoord, 0);

    if (depthtex.y > depthtex.x)
        color.rgb *= albedo_Transparent;

    colortex0Write = color;

    celshade(colortex0Write.rgb);
    colortex0Write.rgb += AerialPerspective(length(space_View));

}

#endif