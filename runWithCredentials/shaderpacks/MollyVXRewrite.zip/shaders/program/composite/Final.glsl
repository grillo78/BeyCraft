// Global varyings

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec2 taaOffset;
uniform vec3 sunPosition;
uniform float aspectRatio;
uniform sampler2D depthtex1;
uniform sampler2D depthtex2;
uniform sampler2D texture;
uniform sampler2D noisetex;
uniform float centerDepthSmooth;
uniform float near, far;

uniform float viewWidth, viewHeight;


#include "/lib/Utility/Space_Transformations.glsl"


#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;
    
    gl_Position = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position      = gl_in[i].gl_Position;
        texcoord         = vertexTexcoord[i];
        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:0 */

layout (location = 0) out vec4 colortex0Write;

in vec2 texcoord;

uniform sampler2D shadowcolor0;
uniform sampler2D colortex0;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform vec2 resolution;
uniform vec2 pixel;
uniform int frameCounter;
uniform float frameTime;

#define About 0 //[0]

#include "/lib/Texturing/Smoothing.glsl"
#include "/lib/Shared/ACES_Main.glsl"
#include "/lib/Fragment/Sampling_Patterns.glsl"
#include "/lib/Shared/Palette.glsl"



vec2 calculateBlurTileOffset(int id) {
	// offsets approximately follows a multiple of this: (1 - 4⁻ˣ) / 3

	vec2 idMult = floor(float(id) * 0.5 + vec2(0.0, 0.5));
	vec2 offset = vec2(1.0, 2.0) * (1.0 - exp2(-2.0 * idMult)) / 3.0;

	vec2 paddingPixels = vec2(2.0, 9.0); // Set as needed
	vec2 paddingAccum  = idMult * paddingPixels;

	return offset + paddingAccum * pixel;
}

void calculateBloom(inout vec3 color, in vec2 coord) {
    vec3 bloom = toLinear(bicubicTexture(colortex0, coord * exp2(-1.0) + calculateBlurTileOffset(0), 1.0).rgb);
    float totalWeight = 1.0;
    for (int i = 1; i < 6; ++i) {
        float tileWeight = 1.0 / (i + 1.0);
        bloom += toLinear(bicubicTexture(colortex0, coord * exp2(-i - 1.0) + calculateBlurTileOffset(i), 1.0).rgb) * tileWeight;
        totalWeight += tileWeight;
    }
    bloom /= totalWeight;

    color = mix(color, bloom, 0.1);
}

vec2 calculateFlareCoord(vec2 coord, float scale, float distortion, out float onTile) {
    vec2 flareCoord = coord * 2.0 - 1.0;

    // remap ghost position
    flareCoord = flareCoord * scale;
    
    // barrel distortion
    vec2  ratio = vec2(1.0, 1.0 / aspectRatio) * vec2(1.0 / 1.0, 1.0);
    float dist  = dot(flareCoord * ratio, flareCoord * ratio);
    flareCoord  = flareCoord * pow(dist, distortion);
    
    vec2 xyDist = abs(flareCoord);

         flareCoord = flareCoord * 0.5 + 0.5;

    onTile  = smoothstep(1.0, 0.85, xyDist.x) * smoothstep(1.0, 0.85, xyDist.y);

    return flareCoord * exp2(-4.0) + vec2(0.5 + pixel.x * 4.0, 0.0);
}


void calculateLensFlare(inout vec3 color, in vec2 coord, in vec2 pattern) {

    vec2 aspectCorrect = vec2(aspectRatio, 1.0);

    //vec3 sunScreen = calculateScreenSpace(sunPosition, mat4(sunPosition));
    
    float onTile;
    vec2  flareCoord;
    vec3  flare = vec3(0.0);
/*
    float sun = pow(inversesqrt((smoothCircleDist(sunScreen.xy, 1.0) * 10.0) + 0.1) * 2.5, 2.5);

    flare += getShine(normalize(texcoord - sunScreen.xy), 0.05, 1.0, 20.0) *
             getShine(normalize(texcoord - sunScreen.xy), 0.05, 1.0, 15.0) *
             sun * vec3(1.0, 0.6, 0.2) * 3.0 * (1.0 + sun) * 100.0;

    flare += pow(getShine(normalize(texcoord - sunScreen.xy), 0.05, 1.0, 20.0) *
             getShine(normalize(texcoord - sunScreen.xy), 0.05, 1.0, 15.0) * 100.0, 6.0) *
             sun * vec3(1.0, 1.0, 1.0) * 300.0 * (1.0 + sun) * 100.0;
*/
    flareCoord = calculateFlareCoord(coord, -1.000 + pattern.y * 0.015, 3.0, onTile);
    flare     += bicubicTexture(colortex0, flareCoord, 1.0).rgb * onTile * vec3(0.5, 0.0, 0.0);

    flareCoord = calculateFlareCoord(coord, -1.015 + pattern.y * 0.015, 3.0, onTile);
    flare     += bicubicTexture(colortex0, flareCoord, 1.0).rgb * onTile * vec3(0.0, 0.5, 0.0);

    flareCoord = calculateFlareCoord(coord, -1.030 + pattern.y * 0.015, 3.0, onTile);
    flare     += bicubicTexture(colortex0, flareCoord, 1.0).rgb * onTile * vec3(0.0, 0.0, 0.5);

    flareCoord = calculateFlareCoord(coord,  7.00, 0.5, onTile);
    flare     += bicubicTexture(colortex0, flareCoord, 1.0).rgb * onTile * vec3(0.5, 0.5, 0.5);

    flareCoord = calculateFlareCoord(coord, -2.0, 0.4, onTile);
    flare     += bicubicTexture(colortex0, flareCoord, 1.0).rgb * onTile * vec3(0.5, 0.5, 0.5);

    flareCoord = calculateFlareCoord(coord, -4.0, 0.4, onTile);
    flare     += bicubicTexture(colortex0, flareCoord, 1.0).rgb * onTile * vec3(0.5, 0.5, 0.5);

    color += flare * 1.0e-5;
}


float ld(float depth) {
   return (2.0 * near) / (far + near - depth * (far - near));
}

vec2 circlemap(vec2 p) {
	p.y *= TAU;
	return vec2(cos(p.y), sin(p.y)) * sqrt(p.x);
}

#define cubicSmooth(x) (x * x) * (3.0 - 2.0 * x)


float calculateViewSpaceZ(float depth) {
	depth = depth * 2.0 - 1.0;
	return -1.0 / (depth * gbufferProjectionInverse[2][3] + gbufferProjectionInverse[3][3]);
}

vec2 hammersley(int i, int N) {
	return vec2(float(i) / float(N), float(bitfieldReverse(i)) * 2.3283064365386963e-10);
}


vec3 tonemap(vec3 color) {
    const vec3 a = vec3(1.00, 1.00, 1.00);
    const vec3 b = vec3(1.00, 1.00, 1.00);
    const vec3 c = vec3(1.70, 1.70, 1.70);
    const vec3 d = vec3(0.90, 0.90, 0.90);

    vec3 cr = mix(vec3(dot(color, lumaCoeff)), color, d) + 1.0;

    color = pow(color, a);
    color = pow(color / (1.0 + color), b / a);
    color = pow(color * color * (-2.0 * color + 3.0), cr / c);

    return color;
}

vec3 Tonemap(vec3 color) {
	const float toeStrength    = TONEMAP_TOE_STRENGTH;
	const float toeLength      = TONEMAP_TOE_LENGTH * TONEMAP_TOE_LENGTH / 2;
	const float linearSlope    = TONEMAP_LINEAR_SLOPE;
	const float linearLength   = TONEMAP_LINEAR_LENGTH;
	const float shoulderCurve  = TONEMAP_SHOULDER_CURVE;
	const float shoulderLength = TONEMAP_SHOULDER_LENGTH;

    const mat3 coneOverlapMatrix2Deg = mat3(
        mix(vec3(1.0, 0.0, 0.0), vec3(0.5595088340965042, 0.39845359892109633, 0.04203756698239944), vec3(CONE_OVERLAP_SIMULATION)),
        mix(vec3(0.0, 1.0, 0.0), vec3(0.43585871315661756, 0.5003841413971261, 0.06375714544625634), vec3(CONE_OVERLAP_SIMULATION)),
        mix(vec3(0.0, 0.0, 1.0), vec3(0.10997368482498855, 0.15247972169325025, 0.7375465934817612), vec3(CONE_OVERLAP_SIMULATION))
    );

	const float toeX     = toeLength;
	const float toeY     = linearSlope * toeLength * (1.0 - toeStrength);
	const float toePower = 1.0 / (1.0 - toeStrength);

	const float tim = 1.0 / toeX;
	const float tom = toeY;

	const float lm = linearSlope;
	const float la = toeStrength == 1.0 ? -linearSlope * toeX : toeY - toeY * toePower;

	const float shoulderX = linearLength * (1.0 - toeY) / linearSlope + toeX;
	const float shoulderY = linearLength * (1.0 - toeY) + toeY;

	const float sim = linearSlope * shoulderLength / (1.0 - shoulderY);
	const float sia = -sim * shoulderX;
	const float som = (1.0 - shoulderY) / shoulderLength;
	const float soa = shoulderY;

    color *= coneOverlapMatrix2Deg;

	for (int i = 0; i < 3; ++i) {
		if (color[i] < toeX) {
			color[i] = tom * pow(tim * color[i], toePower);
		} else if (color[i] < shoulderX) {
			color[i] = lm * color[i] + la;
		} else {
			color[i]  = sim * color[i] + sia;
			color[i] /= pow(pow(color[i], 1.0 / shoulderCurve) + 1.0, shoulderCurve);
			color[i]  = som * color[i] + soa;
		}
	}

	return color * inverse(coneOverlapMatrix2Deg);
}

void calculateNightEye(inout vec3 color) {
    float luminance  = dot(color, lumaCoeff);
    float lows       = exp(-luminance * (Night_Eye_Threshold * 3));
    vec3  saturation = mix(vec3(1.0, 1.0, 1.0), vec3(0.1, 0.1, 0.1), lows);
    vec3  tint       = normalize(vec3(0.2, 0.7, 1.0));

    color = mix(luminance * tint, color, saturation);
}

void sharpenImage(inout vec3 color, in vec2 coord) {

#ifndef Sharpen
    return;
#endif
    const vec2 circlePoints[8] = vec2[8](
        vec2( 1.0,  0.0),
        vec2(-1.0,  0.0),
        vec2( 0.0,  1.0),
        vec2( 0.0, -1.0),
        vec2( 0.7,  0.7),
        vec2(-0.7,  0.7),
        vec2(-0.7, -0.7),
        vec2( 0.7, -0.7)
    );

    const float lod = 0.0;
    vec2  lodCorrect = exp2(lod) * pixel * 0.5;

    vec3 blur = toLinear(texture2DLod(colortex5, coord + lodCorrect, lod).rgb);

    for (int i = 0; i < 8; i++) {
        vec2 offset = circlePoints[i] * pixel + lodCorrect;
        blur += toLinear(texture2DLod(colortex5, coord + offset - pixel * 0.5, lod).rgb);
    }

    vec3 difference = 1.0 - clamp01(blur / 8.5 - color);

    color *= mix(length(difference), 1.0, 0.2);
}

void calculateFilmGrain(inout vec3 color) {

    #ifndef Film_Grain 
        return;
    #endif

    uint randSeed = initRand(uint(gl_FragCoord.x + gl_FragCoord.y * resolution.x), uint(frameCounter), 16);

    float noiseX = nextRand(randSeed);
	float noiseY = nextRand(randSeed);
	float noiseZ = nextRand(randSeed);

    vec3 noise = vec3(noiseX, noiseY, noiseZ);

	color += noise * exp(-color) * vec3(0.2, 0.8, 1.0) * 0.01;
    color *= mix(vec3(1.0), noise, Film_Grain_Strength * 0.2);
}

void calculateDepthOfField(inout vec3 color, in vec2 coord) {

    #ifndef Depth_Of_Field
    return;
    #endif

    float ditherSizeSq = pow(viewWidth, 2.0);
    float dither       = pow(noiseSmooth(gl_FragCoord.xy * noiseResInverse).b, 2.2) * ditherSizeSq;

    float focalLength  = Focal_Length / 1000.0;
    float aperture     = (Focal_Length / FStop) / 1500.0;

    float expDepth     = texture2D(depthtex1, coord).x;
    if (expDepth < texture2D(depthtex2, coord).x) return;
    float depth        = calculateViewSpaceZ(expDepth);
    float focus        = calculateViewSpaceZ(centerDepthSmooth);

    float CoC          = ((aperture) * ((focalLength) * (focus - depth)) / (focus * (depth - (focalLength)))) * 1000.0;

    #ifdef Distance_Blur
          CoC         += smoothstep(0.1, 1.8, ld(expDepth)) * 1.4;
    #endif

    #ifdef Tilt_Shift
          CoC          = (coord.y - 0.5) * 0.5;
    #endif
    
    vec2 segment = circlemap(
        hammersley(int(DepthOfFieldQuality * ditherSizeSq + dither), int(DepthOfFieldQuality * ditherSizeSq))
    ) * aperture * CoC;

    float f = TAU / DepthOfFieldQuality;
    float a = cos(f);
    float b = sin(f);

    vec3  depthOfField = vec3(0.0);

    for (int i = 0; i < DepthOfFieldQuality; i++) {
        vec2 offset = segment * vec2(1.0, aspectRatio);

        depthOfField += toLinear(texture2DLod(colortex5, segment * vec2(1.0, aspectRatio) + coord, 0.0).rgb);

        float ns = b * segment.y + a * segment.x;
        float nc = a * segment.y - b * segment.x;
        segment = vec2(ns,nc);
    }

    color = depthOfField / DepthOfFieldQuality;
}

vec3 ditherScreen(vec3 color) {
    vec3 lestynRGB = vec3(dot(vec2(171.0, 231.0), gl_FragCoord.xy));
         lestynRGB = fract(lestynRGB.rgb / vec3(103.0, 71.0, 97.0));

    return color + lestynRGB.rgb / 255.0;
}

float tubeBorder() {
	vec2 a = texcoord * (1.0 - texcoord) * (35.0 + texcoord);
    return mix(2.0 - pow(a.x * a.y, 0.25), 1.0, 0.9);
}

vec2 calculateDistortion() {
    vec2 coord = texcoord * 2.0 - 1.0;
    #ifdef Helmet_Distortion
	    coord *= tubeBorder();
    #endif

    return coord * 0.5 + 0.5;
}

void calculateBorder(inout vec3 color) {
    color *= smoothstep(1.0, 0.9, tubeBorder());
}

void matrix(inout vec3 color) {
    #ifndef Color_Matrix
        return;
    #endif

    mat3 sRGB_2_XYZ_MAT = mat3( // Linear sRGB to XYZ color space
        vec3(0.8, 0.1, 0.1),
        vec3(0.1, 0.8, 0.1),
        vec3(0.1, 0.1, 0.8)
    );

    #if (Preset == 4)
        sRGB_2_XYZ_MAT = mat3(
            vec3(0.55, 0.25, 0.20),
            vec3(0.21, 0.71, 0.09),
            vec3(0.32, 0.1, 0.88)
    );
    #endif
    #if (Preset == 2)
        sRGB_2_XYZ_MAT *= mat3(
            vec3(0.8, 0.1, 0.1),
            vec3(0.3, 0.2, 0.5),
            vec3(0.3, 0.3, 0.6)
    );
    color = (vec3(color.r, color.g, color.b));
    #endif

    #if (Preset == 3)
    sRGB_2_XYZ_MAT = mat3(
            vec3(0.5, 0.6, 0.0),
            vec3(0.0, 1.0, 0.0),
            vec3(0.0, 0.0, 1.0)
    );
    color = (vec3(color.r, color.g, color.b));
    #endif

    #if (Preset == 1)
    sRGB_2_XYZ_MAT = mat3(
            (vec3(0.0, 0.0, 0.0) + vec3(2.5, 0.4, 0.7) * vec3(0.76, 0.0, 0.0)),
            (vec3(0.0, 0.0, 0.0) + vec3(0.5, 3.0, 0.1) * vec3(0.0, 0.76, 0.0)),
            (vec3(0.0, 0.0, 0.0) + vec3(0.5, 0.1, 3.5) * vec3(0.0, 0.0, 0.76))
    );
    color = (vec3(color.r, color.g, color.b)) * 0.8;
    #endif

    #if (Preset == 5)
    sRGB_2_XYZ_MAT = mat3(
            (vec3(0.2, 0.0, 0.0) + vec3(1.5, 0.4, 0.1) * vec3(0.76, 0.3, 0.1)),
            (vec3(0.0, 1.1, 0.0) + vec3(0.5, 2.0, 0.1) * vec3(0.1, 0.76, 0.3)),
            (vec3(0.0, 0.0, 0.7) + vec3(0.5, 0.1, 2.5) * vec3(0.3, 0.1, 0.76))
    );
    color = (vec3(color.r, color.g, color.b));
    #endif


    color = (vec3(color.r, color.g, color.b) * sRGB_2_XYZ_MAT);
}

void lookup(inout vec3 color) {
    const vec2 inverseSize = vec2(1.0 / 512, 1.0 / 5120);
    const mat2 correctGrid = mat2(
        vec2(1.0, inverseSize.y * 512),
        vec2(0.0, Selected_LUT * inverseSize.y * 512)
    );
    #ifndef LUT
        return;
    #endif

    color = clamp01(color);

    float blueColor = color.b * 63.0;

    vec4 quad = vec4(0.0);
    quad.y = floor(floor(blueColor) * 0.125);
    quad.x = floor(blueColor) - (quad.y * 8.0);
    quad.w = floor(ceil(blueColor) * 0.125);
    quad.z = ceil(blueColor) - (quad.w * 8.0);

    vec4 texPos = (quad * 0.125) + (0.123046875 * color.rg).xyxy + 0.0009765625;

    vec3 newColor1 = texture2D(colortex4, texPos.xy * correctGrid[0] + correctGrid[1]).rgb;
    vec3 newColor2 = texture2D(colortex4, texPos.zw * correctGrid[0] + correctGrid[1]).rgb;
    
    color = mix(newColor1, newColor2, fract(blueColor));
}



void main() {
    #ifdef Pixelizer
    vec2 newTC = pixelize(texcoord, pixel_size);
    //newTC += 
    #else
    vec2 newTC = texcoord;
    #endif
    vec2 pattern           = calculateSamplingDistributors();

    colortex0Write = texture2D(colortex5, newTC);
    colortex0Write.rgb = toLinear(colortex0Write.rgb);
    calculateDepthOfField(colortex0Write.rgb, newTC);
    calculateBloom(colortex0Write.rgb, newTC);
    //calculateLensFlare(colortex0Write.rgb, newTC, pattern); //Needs fixing
    sharpenImage(colortex0Write.rgb, newTC);
    #ifdef Night_Eye
    //calculateNightEye(colortex0Write.rgb);
    #endif
    #ifdef CRT_Border
    calculateBorder(colortex0Write.rgb);
    #endif

    //calculateFilmGrain(colortex0Write.rgb);
    //matrix(colortex0Write.rgb);

    //colortex0Write.rgb = Tonemap(colortex0Write.rgb);
    #ifdef ACES_Tonemap
    //colortex0Write.rgb = (colortex0Write.rgb * sRGB_2_AP0) * 1.0;
    FilmToneMap(colortex0Write.rgb);
    

    colortex0Write.rgb = WhiteBalance(colortex0Write.rgb);
	colortex0Write.rgb = Vibrance(colortex0Write.rgb);
	colortex0Write.rgb = Saturation(colortex0Write.rgb);
    colortex0Write.rgb = Contrast(colortex0Write.rgb);
    colortex0Write.rgb = LiftGammaGain(colortex0Write.rgb);
    #endif

    #ifdef Big_Dither
	colortex0Write.rgb = dither8x8(newTC, colortex0Write.rgb, pixel_size);
    #endif
    #ifndef Color_Compression
    colortex0Write.rgb = toSRGB(colortex0Write.rgb);
    #ifdef AP1
    colortex0Write.rgb = (colortex0Write.rgb * sRGB_2_AP1);
    #endif
    #endif
    lookup(colortex0Write.rgb);

    colortex0Write.rgb = ditherScreen(colortex0Write.rgb);
    clamp01(colortex0Write.rgb);


    //colortex0Write.rgb = texture2DLod(colortex6, texcoord, 0.0).rgb * 0.005;
    //colortex0Write.rgb = texture2DLod(shadowcolor0, texcoord, 0.0).rgb;
}

#endif