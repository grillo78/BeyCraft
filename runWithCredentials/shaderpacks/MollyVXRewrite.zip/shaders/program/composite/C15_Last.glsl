// Global varyings

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec2 taaOffset;


#include "/lib/Utility/Space_Transformations.glsl"


#if   FORMAT == vsh  // VERTEX PASS

out vec2 vertexTexcoord;


void main() {
    vertexTexcoord = gl_MultiTexCoord0.st;
    
    gl_Position = ftransform();
}

#elif FORMAT == gsh

layout (triangles) in;
in vec2[3] vertexTexcoord;

layout (triangle_strip, max_vertices = 3) out;
out vec2 texcoord;


void main() {
    for (int i = 0; i < 3; ++i) {
        gl_Position      = gl_in[i].gl_Position;
        texcoord         = vertexTexcoord[i];
        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:502 */

layout (location = 0) out vec4 colortex5Write;
layout (location = 1) out vec4 colortex0Write;
layout (location = 2) out vec4 colortex2Write;

in vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex5;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform vec2 resolution;
uniform vec2 pixel;
uniform int frameCounter;

const bool colortex0MipmapEnabled = true;
const bool colortex5MipmapEnabled = true;


vec3 calculateTAA(vec3 space_Screen, vec3 normal_Opaque, float exposure) {
    vec3 reprojected = projectPrevious(space_Screen);

    float linearDepth = -linearizeDepth(reprojected.z, gbufferProjectionInverse);
    vec4  gbuffers_Previous = texelFetch(colortex1, ivec2(reprojected.xy * resolution), 0);
    vec3  normal_Previous   = DecodeNormal(gbuffers_Previous.z);
    float depthtex_Previous = -linearizeDepth(texelFetch(depthtex0, ivec2(reprojected.xy * resolution), 0).x, gbufferProjectionInverse);

    float rejection = 0.5; // Make option / constant

    vec2 pixelCenterDist = 1.0 - abs(2.0 * fract(reprojected.xy * resolution) - 1.0);
	float weight = floor(reprojected.xy) == vec2(0.0) ? sqrt(pixelCenterDist.x * pixelCenterDist.y) * rejection + (1.0 - rejection) : 0.0;
    //weight = floor(reprojected.xy) == vec2(0.0) ? dot(0.5 - abs(fract(reprojected.xy * resolution) - 0.5), vec2(1.0)) : 0.0;

    mat2x3 limits = mat2x3(0.0);

    for (int i = -1; i <= 1; ++i) {
        for (int j = -1; j <= 1; ++j) {
            if (ivec2(i, j) == ivec2(0, 0)) continue; 

            vec3 currentSample = texture2DLod(colortex0, ivec2(i, j) * pixel + texcoord, 0.0).rgb;
                 currentSample = toSRGB(currentSample / exposure);

            if (ivec2(i, j) == ivec2(-1, -1)) {
                limits = mat2x3(currentSample, currentSample);

                continue;
            }

            limits[0] = min(currentSample, limits[0]);
            limits[1] = max(currentSample, limits[1]);
        }
    }

    vec3 antiAliased = mix(
        toSRGB(texture2DLod(colortex0, texcoord, 0.0).rgb / exposure),
        clamp(texture2DLod(colortex5, reprojected.xy, 0.0).rgb, limits[0], limits[1]),
        weight * 0.99
    );
    return antiAliased;
}

float calculateAverageLuminance() {
    const float maxLumaRange  = 2.55;
    const float minLumaRange  = 0.05;
    const float exposureDecay = 0.05;

    float avglod = int(exp2(min(resolution.x, resolution.y))) - 1;

	float averagePrevious = texture2DLod(colortex5, vec2(0.0), 0.0).a;
    float averageCurrent  = clamp(sqrt(dot(texture2DLod(colortex0, vec2(0.5), avglod).rgb, lumaCoeff)), minLumaRange, maxLumaRange);

    return mix(averagePrevious, averageCurrent, exposureDecay);
}

vec2 calculateBlurTileOffset(int id) {
	// offsets approximately follows a multiple of this: (1 - 4⁻ˣ) / 3

	vec2 idMult = floor(float(id) * 0.5 + vec2(0.0, 0.5));
	vec2 offset = vec2(1.0, 2.0) * (1.0 - exp2(-2.0 * idMult)) / 3.0;

	vec2 paddingPixels = vec2(2.0, 9.0); // Set as needed
	vec2 paddingAccum  = idMult * paddingPixels;

	return offset + paddingAccum * pixel;
}

vec3 calculateBloomTile(vec2 coord, const float lod) {
	coord *= exp2(lod);

	if (clamp01(coord) != coord) return vec3(0.0);

    vec2 resolutionScale = pixel * exp2(lod);

    vec3  bloom       = vec3(0.0);
	float totalWeight = 0.0;
	
	for (int y = -3; y <= 3; y++) {
		for (int x = -3; x <= 3; x++) {
			float weight  = clamp01(1.0 - length(vec2(x, y)) / 3.0);
			
			bloom += texture2DLod(colortex0, coord + vec2(x, y) * resolutionScale, lod).rgb * weight;
			totalWeight += weight;
		}
	}
	
	return bloom / totalWeight;
}

vec3 calculateFlareTile(vec2 coord, const float lod, const float power, float exposure) {
	coord *= exp2(lod);

	if (clamp01(coord) != coord) return vec3(0.0);

    vec2 resolutionScale = pixel * exp2(lod);

    vec3  bloom       = vec3(0.0);
	float totalWeight = 0.0;
	
	for (int y = -3; y <= 3; y++) {
		for (int x = -3; x <= 3; x++) {
			float weight  = pow2(clamp01(1.0 - length(vec2(x, y)) / 3.0));
			
			bloom += powf(texture2DLod(colortex0, coord + vec2(x, y) * resolutionScale, lod).rgb / exposure, power) * weight;
			totalWeight += weight;
		}
	}
	
	return bloom / totalWeight;
}

vec3 calculateBloomTiles() {
    vec3 blurTiles = calculateBloomTile(texcoord - calculateBlurTileOffset(0), 1);
		for (int i = 1; i < 6; blurTiles += calculateBloomTile(texcoord - calculateBlurTileOffset(i), ++i));
    
    vec2 flareTileOffset = vec2(0.5 + pixel.x * 4.0, 0.0 );
    vec3 flareTile = calculateFlareTile(texcoord - flareTileOffset, 4, 2.0, texture2DLod(colortex0, vec2(0.0), 0.0).a);

    return blurTiles + flareTile;
}
 
void main() {
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);

    vec2 depthtex     = vec2(texelFetch(depthtex0, fragCoord, 0).x, texelFetch(depthtex1, fragCoord, 0).x);
    vec3 space_Screen = vec3(texcoord, depthtex.y);

    vec4 gbuffers_Opaque   = texelFetch(colortex1, fragCoord, 0);
    vec4 gbuffers_Previous = texelFetch(colortex2, fragCoord, 0);
    vec3 normal_Opaque = DecodeNormal(gbuffers_Opaque.z);

    //vec3 tonemap = tonemap(color);
    #ifdef Set_Exposure
        float exposure = -Set_Exposure_Amount * -150.5;
    #else
                float exposure = calculateAverageLuminance();   
    #endif


    

    colortex5Write = vec4(calculateTAA(space_Screen, normal_Opaque, exposure * 2.5), exposure);
    colortex0Write = vec4(toSRGB(calculateBloomTiles() / (exposure * 2)), 0.0);
    colortex2Write = vec4(gbuffers_Opaque.z, gbuffers_Previous.y, depthtex);
}

#endif