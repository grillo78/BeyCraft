// Global varyings

uniform sampler2D texture;
uniform mat4 shadowModelViewInverse;
uniform vec3 cameraPosition;


#if   FORMAT == vsh  // VERTEX PASS

attribute vec4 mc_Entity;
attribute vec2 mc_midTexCoord;

out vec3  vertexProj;
out vec3  vertexNormal;
out vec3  vertexTint;
out vec2  texcoord;
out vec2  midcoord;
out float isNotOpaque;
out int   blockID;
out int   blockDataValue;


#include "/lib/Shared/Shadow_Distortion.glsl"


void main() {
    gl_Position    = gl_ModelViewMatrix * gl_Vertex;
    
    vertexProj     = (shadowModelViewInverse * gl_Position).xyz;
    vertexNormal   = normalize(mat3(shadowModelViewInverse) * gl_NormalMatrix * gl_Normal);
    vertexTint     = gl_Color.rgb;
    texcoord       = gl_MultiTexCoord0.xy;
    midcoord       = mc_midTexCoord.xy;
    blockID        = int(mc_Entity.x);
	blockDataValue = int(mc_Entity.z);
    
    gl_Position     = gl_ProjectionMatrix * gl_Position;
    gl_Position.xyz = gl_Position.xyz / vec3(vec2(distortionFactor(gl_Position.xy)), Shadow_Z_Stretch);

    isNotOpaque = 0.0;
		if(mc_Entity.x ==   0.0 // Something that definitely is not a block
		|| mc_Entity.x ==   6.0 // Saplings
        || mc_Entity.x ==  18.0   // Leaves
        || mc_Entity.x ==  20.0
		|| mc_Entity.x ==  26.0 // Bed
		|| mc_Entity.x ==  27.0 // Powered Rail
		|| mc_Entity.x ==  28.0 // Detector Rail
		|| mc_Entity.x ==  30.0 // Cobweb
		|| mc_Entity.x ==  31.0 // Shrub (old dead bush), Grass, Fern
		|| mc_Entity.x ==  32.0 // Dead Bush
		|| mc_Entity.x ==  37.0 // Dandelion
		|| mc_Entity.x ==  38.0 // Most small flowers
		|| mc_Entity.x ==  39.0 // Brown Mushroom
		|| mc_Entity.x ==  40.0 // Red Mushroom
		|| mc_Entity.x ==  55.0 // Redstone Dust
		|| mc_Entity.x ==  59.0 // Wheat
		|| mc_Entity.x ==  63.0 // Standing Sign
		|| mc_Entity.x ==  65.0 // Ladder
		|| mc_Entity.x ==  66.0 // Rail
		|| mc_Entity.x ==  68.0 // Wall Sign
		|| mc_Entity.x ==  69.0 // Lever
		|| mc_Entity.x ==  83.0 // Sugar Canes
		|| mc_Entity.x ==  93.0 // Redstone Repeater (Inactive)
		|| mc_Entity.x ==  94.0 // Redstone Repeater (Active)
		|| mc_Entity.x == 101.0 // Iron Bars
		|| mc_Entity.x == 102.0 // Glass Pane
		|| mc_Entity.x == 106.0 // Vines
		|| mc_Entity.x == 107.0 // Oak Fence Gate
		|| mc_Entity.x == 111.0 // Lily Pad
		|| mc_Entity.x == 116.0 // Enchantment Table
		|| mc_Entity.x == 120.0 // End Portal
		|| mc_Entity.x == 122.0 // Dragon Egg
		|| mc_Entity.x == 131.0 // Tripwire Hook
		|| mc_Entity.x == 132.0 // String
		|| mc_Entity.x == 140.0 // Flower Pot
		|| mc_Entity.x == 141.0 // Carrots
		|| mc_Entity.x == 142.0 // Potatoes
		|| mc_Entity.x == 144.0 // Mob Heads
		|| mc_Entity.x == 149.0 // Comparator (Inactive)
		|| mc_Entity.x == 150.0 // Comparator (Active)
		|| mc_Entity.x == 154.0 // Hopper
		|| mc_Entity.x == 157.0 // Activator Rail
		|| mc_Entity.x == 160.0 // Stained Glass Pane
		|| mc_Entity.x == 175.0 // Double plants (two block tall plants)
		|| mc_Entity.x == 176.0 // Standing Banner
		|| mc_Entity.x == 177.0 // Wall Banner
		|| mc_Entity.x == 183.0 // Spruce Fence Gate
		|| mc_Entity.x == 184.0 // Birch Fence Gate
		|| mc_Entity.x == 185.0 // Jungle Fence Gate
		|| mc_Entity.x == 186.0 // Dark Oak Fence Gate
		|| mc_Entity.x == 187.0 // Acacia Fence Gate
		|| mc_Entity.x == 207.0 // Beetroots
		) isNotOpaque = 1.0;
}

#elif FORMAT == gsh  // GEOMETRY PASS

layout (triangles) in;
in vec3[3]  vertexProj;
in vec3[3]  vertexNormal;
in vec3[3]  vertexTint;
in vec2[3]  texcoord;
in vec2[3]  midcoord;
in float[3] isNotOpaque;
in int[3]   blockID;
in int[3]   blockDataValue;

layout (triangle_strip, max_vertices = 7) out;
// Voxel buffer outputs
out vec4  fData0;
out vec4  fData1;
out float isVoxel;
// Shadow buffer outputs
out vec3 tint;
out vec2 textureCoordinates;
// Texture buffer outputs
out vec2 uv;
flat out int quad;


#include "/lib/Shared/Voxelization.glsl"


void main() {
    // Normal shadow maps
    // NOTE: You will need to manually clip triangles that are outside the shadow map. This does not currently do that.
    // I have some basic code for that from when I tried CSM but it's inefficient and incomplete.
    for (int i = 0; i < 3; ++i) {
        isVoxel = 0.0;
        gl_Position     = gl_in[i].gl_Position;
        gl_Position.xy  = gl_Position.xy * 0.5 + 0.5;
        // Cull triangles that go outside the shadow map section of the voxel atlas.
        if (gl_in[i].gl_Position.x < -1.0 || gl_in[i].gl_Position.y < -1.0) return;
        tint = vertexTint[i];
        textureCoordinates = texcoord[i];
        EmitVertex();
    } EndPrimitive();

    // Voxelized geometry
    if (isNotOpaque[0] > 0.5) { return; }

    vec3 triCentroid = (vertexProj[0] + vertexProj[1] + vertexProj[2]) / 3.0;

    // voxel position in the 2d map
    vec3 voxelSpacePosition = SceneSpaceToVoxelSpace(triCentroid - vertexNormal[0] / 32.0);
    ivec3 voxelIndex = ivec3(floor(voxelSpacePosition));
    vec4 p2d = vec4(((GetVoxelStoragePos(voxelIndex) + 0.5) / float(shadowMapResolution)) * 2.0 - 1.0, vertexNormal[0].y * -0.25 + 0.5, 1.0);

    if (!IsInVoxelizationVolume(voxelIndex)) { return; }

    ivec2 atlasResolution = textureSize(texture, 0);
    vec2  atlasAspectCorrect = vec2(1.0, float(atlasResolution.x) / float(atlasResolution.y));
    float tileSize   = maxof(abs(texcoord[0] - midcoord[0]) / atlasAspectCorrect) / maxof(abs(vertexProj[0] - vertexProj[1]));
    vec2  tileOffset = round((midcoord[0] - tileSize * atlasAspectCorrect) * atlasResolution);
          tileSize   = round(2.0 * tileSize * atlasResolution.x);
          tileOffset = round(tileOffset / tileSize);
    
    vec3 voxelTint = vec3(0.0);
         if (blockID[0] ==  10) voxelTint = vec3(Lava_Color_R, Lava_Color_G, Lava_Color_B) / 255;
    else if (blockID[0] ==  50) voxelTint = vec3(Torch_Color_R, Torch_Color_G, Torch_Color_B) / 255;
    else if (blockID[0] ==  51) voxelTint = vec3(Fire_Color_R, Fire_Color_G, Fire_Color_B) / 255;
    else if (blockID[0] ==  76) voxelTint = vec3(Redstone_Torch_Color_R, Redstone_Torch_Color_G, Redstone_Torch_Color_B) / 255;
    else if (blockID[0] ==  89) voxelTint = vec3(Glowstone_Color_R, Glowstone_Color_G, Glowstone_Color_B) / 255;
    else if (blockID[0] ==  90) voxelTint = vec3(Nether_Portal_Color_R, Nether_Portal_Color_G, Nether_Portal_Color_B) / 255;
    else if (blockID[0] ==  91) voxelTint = vec3(Jack_Color_R, Jack_Color_G, Jack_Color_B) / 255;
    else if (blockID[0] == 124) voxelTint = vec3(Redstone_Lamp_Color_R, Redstone_Lamp_Color_G, Redstone_Lamp_Color_B) / 255;
    else if (blockID[0] == 138) voxelTint = vec3(Beacon_Color_R, Beacon_Color_G, Beacon_Color_B) / 255;
    else if (blockID[0] == 169) voxelTint = vec3(Sea_Lantern_Color_R, Sea_Lantern_Color_G, Sea_Lantern_Color_B) / 255;
    else if (blockID[0] == 198) voxelTint = vec3(End_Rod_Color_R, End_Rod_Color_G, End_Rod_Color_B) / 255;
    else if (blockID[0] == 213) voxelTint = vec3(Magma_Color_R, Magma_Color_G, Magma_Color_B) / 255;
    else if (blockID[0] == 220) voxelTint = vec3(CampFire_Color_R, CampFire_Color_G, CampFire_Color_B) / 255 * CampFire_Alpha;
    else if (blockID[0] == 221) voxelTint = vec3(Lantern_Color_R, Lantern_Color_G, Lantern_Color_B) / 255 * Lantern_Alpha; //lantern
    else if (blockID[0] == 239) voxelTint = vec3(Pickle_Color_R, Pickle_Color_G, Pickle_Color_B) / 255 * Pickle_Alpha; //pickle
    else voxelTint = texture2D(texture, textureCoordinates).rgb * vertexTint[0].rgb;

    // fill out data
    vec4[2] voxel = vec4[2](vec4(0.0), vec4(0.0));
    SetVoxelTint(voxel, voxelTint);
    SetVoxelId(voxel, blockID[0]);
    SetVoxelDataValue(voxel, blockDataValue[0]);
    SetVoxelTileSize(voxel, int(tileSize));
    SetVoxelTileIndex(voxel, ivec2(tileOffset));

    // Create the primitive
    const vec2[4] offs = vec2[4](vec2(-1,1),vec2(1,1),vec2(1,-1),vec2(-1,-1));
    for (int i = 0; i < 4; ++i) {
        isVoxel = 1.0;
        gl_Position = p2d; fData0 = voxel[0]; fData1 = voxel[1];
        gl_Position.xy += offs[i] / shadowMapResolution;
        EmitVertex();
    } EndPrimitive();
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:01 */

layout (location = 0) out vec4 shadowcolor0Write;
layout (location = 1) out vec4 shadowcolor1Write;

// Voxel buffer inputs
in vec4  fData0;
in vec4  fData1;
in float isVoxel;
// Shadow buffer inputs
in vec3 tint;
in vec2 textureCoordinates;
// Texture buffer outputs
in vec2 uv;
flat in int quad;


void main() {
    if (isVoxel > 0.5) { // Voxels
        shadowcolor0Write = fData0;
        shadowcolor1Write = fData1;
    } else {
        vec4 albedo = texture2D(texture, textureCoordinates);
        if (albedo.a < 0.5) discard;
        albedo.rgb *= tint;

        shadowcolor0Write = albedo;
        shadowcolor1Write = vec4(0.0);
    }
}

#endif