// Global varyings

uniform mat4 gbufferModelViewInverse;

#if   FORMAT == vsh  // VERTEX PASS

attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

out mat3   vertexTBN;
out mat2x3 vertexProj;
out mat3x2 atlasTileInfo;
out vec3   vertexTint;
out vec3   tangentViewSpace;
out vec2   texcoord;
out float  materialIDs;

uniform mat4 gbufferProjection;
uniform vec3 cameraPosition;
uniform vec2 taaOffset;
uniform sampler2D texture;

#define atlasTileOffset     atlasTileInfo[0]
#define atlasTileSize       atlasTileInfo[1]
#define atlasTileResolution atlasTileInfo[2]


#include "/lib/Utility/Space_Transformations.glsl"
#include "/lib/Vertex/TBN.glsl"

void calculateAtlasTileInfo(inout mat3x2 atlasTileInfo) {
    ivec2 textureResolution = textureSize2D(texture, 0);

    atlasTileSize       = abs(gl_MultiTexCoord0.st - mc_midTexCoord.xy);
    atlasTileOffset     = mc_midTexCoord.xy - atlasTileSize;
    atlasTileSize      *= 2.0;

    atlasTileResolution = round(atlasTileSize * textureResolution);
    atlasTileSize       = atlasTileResolution / textureResolution;
    atlasTileOffset     = round(atlasTileOffset * textureResolution) / textureResolution;
}


void main() {
    vertexTBN     = calculateTBN();
    vertexProj[0] = transMAD(gl_ModelViewMatrix, gl_Vertex.xyz);
    vertexProj[1] = mat3(gbufferModelViewInverse) * vertexProj[0] + cameraPosition;
    tangentViewSpace = vertexProj[0] * vertexTBN;
    vertexTint    = gl_Color.rgb;
    texcoord      = mat2(gl_TextureMatrix[0]) * gl_MultiTexCoord0.st + gl_TextureMatrix[0][3].xy;
    materialIDs   = 1.0 - mc_Entity.x / 255.0;

    calculateAtlasTileInfo(atlasTileInfo);
    
    #ifdef GBUFFERS_HAND
    gl_Position    = ftransform();
    #else
    gl_Position    = projectViewSpace(vertexProj[0], gbufferProjection);
    #endif
    gl_Position.xy = taaOffset * gl_Position.w + gl_Position.xy;
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:1 */

layout (location = 0) out vec4 colortex1Write;

in mat3   vertexTBN;
in mat2x3 vertexProj;
in mat3x2 atlasTileInfo;
in vec3   vertexTint;
in vec3   tangentViewSpace;
in vec2   texcoord;
in vec4   color;
in float  materialIDs;

uniform sampler2D texture;
uniform sampler2D specular;
uniform sampler2D normals;
uniform vec3 shadowLightPosition;

#define atlasTileOffset     atlasTileInfo[0]
#define atlasTileSize       atlasTileInfo[1]
#define atlasTileResolution atlasTileInfo[2]


#include "/lib/Fragment/Dither.glsl"

float parallax_calculateShadow(vec3 coord, mat2 tcd, vec3 dir) {
    if (dir.z <= 0.0) return 0.0;

    coord.xy = (coord.xy - atlasTileOffset) / atlasTileSize;

    float Parallax_Depth = 0.15 * POM_Depth;

    vec3 increment = vec3(Parallax_Depth, Parallax_Depth, 1.0) * (dir / dir.z) / 256;
    vec3 offset = vec3(0.0, 0.0, coord.z);

    for (int i = 0; i < 64 && offset.z < 1.0; i++) {
        offset += increment;

            float foundHeight = textureGrad(normals, fract(coord.xy + offset.xy) * atlasTileSize + atlasTileOffset, tcd[0], tcd[1]).a;

        if (offset.z < foundHeight - 4.0/256.0) return 0.0;
    }

    return 1.0;
}

vec2 parallax_calculateCoordinate(vec2 textureCoordinates, mat2 textureCoordinateDerivatives, vec3 tangentViewVector, inout float parallaxShadow) {
    #ifndef GBUFFERS_TERRAIN
        return textureCoordinates;
    #endif

    if (tangentViewVector.z > 0.0) return textureCoordinates;

    ivec2 textureResolution = textureSize2D(texture, 0);

    mat2 derivatives = textureCoordinateDerivatives; derivatives[0] *= textureResolution; derivatives[1] *= textureResolution;
    float d = max(max(dot(derivatives[0], derivatives[0]), dot(derivatives[1], derivatives[1])), 1.0);
    vec2 atlasTileResolutionLod = atlasTileResolution * exp2(ceil(-0.5 * log2(d)));

    tangentViewVector.xy *= 0.10 * (2.0 * POM_Depth);
    tangentViewVector.y  *= atlasTileResolution.x / atlasTileResolution.y; // Tile aspect ratio - fixes snow layer sides
    vec2 texelDelta = tangentViewVector.xy * atlasTileResolutionLod;

    vec3 position = vec3((textureCoordinates - atlasTileOffset) / atlasTileSize, 1.0);
    float height;

    float smp = (512 * POM_Quality);

    for (int i = 0; i < smp; ++i) {

        height = texture2DGrad(normals, fract(position.st) * atlasTileSize + atlasTileOffset, textureCoordinateDerivatives[0], textureCoordinateDerivatives[1]).a;

        // Calculate distance to the next two texels
        // xy = closest, zw = second closest
        vec4 texelCoordinates = fract(position.stst * atlasTileResolutionLod.stst);
        texelCoordinates = texelCoordinates * vec4(2.0, 2.0, 1.0, 1.0) + vec4(-1.0, -1.0, -0.5, -0.5);
        texelCoordinates = (texelCoordinates * sign(texelDelta).xyxy) * -0.5 + 0.5;

        vec4 distanceToNextTexelDirectional = texelCoordinates / abs(texelDelta).xyxy;
        float distanceToNextTexel = min(distanceToNextTexelDirectional.x, distanceToNextTexelDirectional.y);

        // Check for intersection
        if (tangentViewVector.z * distanceToNextTexel + position.z < height) break;

        // Distance to second closest texel
        float distanceToNextTexel2 = min(
            maxof(distanceToNextTexelDirectional.xy),
            minof(distanceToNextTexelDirectional.zw)
        );

        // Move to halfway trough next texel
        position += 0.5 * (distanceToNextTexel + distanceToNextTexel2) * tangentViewVector;
    }

    position.xy = clamp(fract(position.st), 1e-6, 1.0 - 1e-6) * atlasTileSize + atlasTileOffset;

    parallaxShadow = parallax_calculateShadow(position, textureCoordinateDerivatives, shadowLightPosition * vertexTBN);

    return position.xy;
}


void main() {
    float shadowed = 1.0;
    mat2  derivatives = mat2(dFdx(texcoord), dFdy(texcoord));
    #ifdef POM
    vec2  coord       = parallax_calculateCoordinate(texcoord, derivatives, tangentViewSpace, shadowed);
    #else
    vec2  coord       = texcoord;
    #endif

    vec4 albedo = texture2D(texture, coord);
    if (albedo.a < 0.5) discard;
    albedo.rgb  = clamp01(albedo.rgb * vertexTint);

    #ifdef White_World
        albedo.rgb = vec3(0.5);
    #endif

    vec4  specularTex = texture2D(specular, coord);
    vec4  normalTex   = texture2D(normals, coord);
    #ifdef GBUFFERS_ENTITIES
        normalTex.xyz = vec3(0.5, 0.5, 1.0);
    #endif

    vec3 tangentNormals = normalize(mat3(gbufferModelViewInverse) * vertexTBN * (normalTex.xyz * 2.0 - 1.0));

    vec4 dither = bayer8(gl_FragCoord.xy) / (exp2(RGB_16_Bits) - 1.0);
    
    colortex1Write = vec4(
        EncodeArbitrary(albedo + dither, RGB_16_Bits) / Values_16Bit,
        EncodeArbitrary(specularTex, RGB_16_Bits) / Values_16Bit,
        EncodeNormal(tangentNormals),
        Pack2x8(vec2(materialIDs, shadowed))
    );
}

#endif