// Global varyings

uniform mat4 gbufferModelViewInverse;

#if   FORMAT == vsh  // VERTEX PASS

attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

out mat3   vertexTBN;
out mat2x3 vertexProj;
out vec3   vertexTint;
out vec2   texcoord;
out float  materialIDs;

uniform mat4 gbufferProjection;
uniform vec3 cameraPosition;
uniform vec2 taaOffset;


#include "/lib/Utility/Space_Transformations.glsl"
#include "/lib/Vertex/TBN.glsl"


void main() {
    vertexTBN     = calculateTBN();
    vertexProj[0] = transMAD(gl_ModelViewMatrix, gl_Vertex.xyz);
    vertexProj[1] = mat3(gbufferModelViewInverse) * vertexProj[0] + cameraPosition;
    vertexTint    = gl_Color.rgb;
    texcoord      = mat2(gl_TextureMatrix[0]) * gl_MultiTexCoord0.st + gl_TextureMatrix[0][3].xy;
    materialIDs   = 1.0 - mc_Entity.x / 255.0;
    
    #ifdef GBUFFERS_HAND
    gl_Position    = ftransform();
    #else
    gl_Position    = projectViewSpace(vertexProj[0], gbufferProjection);
    #endif
    gl_Position.xy = taaOffset * gl_Position.w + gl_Position.xy;
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:1 */

layout (location = 0) out vec4 colortex1Write;

in mat3   vertexTBN;
in mat2x3 vertexProj;
in vec3   vertexTint;
in vec2   texcoord;
in float  materialIDs;

uniform sampler2D texture;
uniform sampler2D specular;
uniform sampler2D normals;


#include "/lib/Fragment/Dither.glsl"


void main() {
    float isShadowed = 1.0;
    vec2  parallaxCoord = texcoord;
    
    vec4 albedo = texture2D(texture, texcoord);
    if (albedo.a <= 0.0) discard;
    albedo.rgb = clamp01(mix(albedo.rgb, vec3(1.0), 1.0 - albedo.a) * vertexTint);

    #ifdef White_World
        albedo.rgb = vec3(0.5);
    #endif

    vec4  specularTex = texture2D(specular, texcoord);
    vec4  normalTex   = texture2D(normals, texcoord);

    vec3 tangentNormals = normalize(mat3(gbufferModelViewInverse) * vertexTBN * (normalTex.xyz * 2.0 - 1.0));

    vec4 dither = bayer8(gl_FragCoord.xy) / (exp2(RGB_16_Bits) - 1.0);
    
    colortex1Write = vec4(
        EncodeArbitrary(albedo + dither, RGB_16_Bits) / Values_16Bit,
        EncodeArbitrary(specularTex, RGB_16_Bits) / Values_16Bit,
        EncodeNormal(tangentNormals),
        Pack2x8(vec2(materialIDs, isShadowed))
    );
}

#endif