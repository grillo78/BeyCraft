// Global varyings


#if   FORMAT == vsh  // VERTEX PASS

void main() {
    return;
}

#elif FORMAT == fsh  // FRAGMENT PASS

/* DRAWBUFFERS:01 */

void main() {
    return;
}

#endif