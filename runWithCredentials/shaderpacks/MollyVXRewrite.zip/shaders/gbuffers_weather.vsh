#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT vsh
#define GBUFFERS_WEATHER


#if   PROG_WEATHER == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.glsl"
#elif PROG_WEATHER == G_OPAQUE
#include "/program/gbuffers/gbuffers_opaque.glsl"
#elif PROG_WEATHER == G_TRANSPARENT
#include "/program/gbuffers/gbuffers_transparent.glsl"
#endif