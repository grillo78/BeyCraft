#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT vsh
#define GBUFFERS_VOXEL_SHADOW


#include "/program/gbuffers/gbuffers_vspass.glsl"