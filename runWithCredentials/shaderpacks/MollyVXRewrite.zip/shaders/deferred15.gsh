#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT gsh
#define DEFERRED 15


#include "/program/deferred/D15_Last.glsl"