#include "/lib/Syntax.glsl"
// Global varyings


#if   FORMAT == vsh  // VERTEX PASS

void main() {

}

#elif FORMAT == gsh  // GEOMETRY PASS

void main() {
    
}

#elif FORMAT == fsh  // FRAGMENT PASS

void main() {
    
}

#endif