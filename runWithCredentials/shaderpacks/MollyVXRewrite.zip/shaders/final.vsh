#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT vsh
#define FINAL


#include "/program/composite/Final.glsl"