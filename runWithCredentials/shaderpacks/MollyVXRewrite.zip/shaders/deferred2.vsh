#version 410 compatibility
#include "/lib/Header.glsl"
#define WORLD  0
#define FORMAT vsh
#define DEFERRED 2


#include "/program/deferred/D2_Reproj_Lighting.glsl"