/*
vec3 GetExperimentalSkyColor(vec3 lightCol, float NdotU, vec3 nViewPos, bool doGround) {
    float absNdotU = abs(NdotU);
    float NdotU2 = NdotU * NdotU;
    float NdotU4 = NdotU2 * NdotU2;
    float NdotU8 = NdotU4 * NdotU4;
    float invAbsNdotU = 1.0 - absNdotU;
    float invAbsNdotU2 = invAbsNdotU * invAbsNdotU;
    float invAbsNdotU4 = invAbsNdotU2 * invAbsNdotU2;
    float invAbsNdotU8 = invAbsNdotU4 * invAbsNdotU4;

    vec3 mainColor = skyCol*skyCol;
    if (NdotU < 0.0) {
        mainColor = vec3(dot(vec3(0.2), mainColor)) * 0.5 + 0.25 * mainColor;
    }
    mainColor *= 1.25 - NdotU4 * 0.75;
    vec3 middleColor = sqrt(fogCol);

    vec3 finalSky = mix(middleColor, mainColor, max(1.0 - invAbsNdotU8, 0.0));

    return pow(finalSky, vec3(1.125)) * 0.5;
}
*/

vec3 GetSkyColor(vec3 lightCol, float NdotU, vec3 nViewPos, bool doGround) {
    float sunVisibility2 = sunVisibility * sunVisibility;
    float sunVisibility4 = sunVisibility2 * sunVisibility2;

    vec3 sky = skyCol;

    float NdotS = clamp(dot(nViewPos, sunVec) * 0.5 + 0.5, 0.001, 1.0);
    NdotS *= NdotS;
    NdotS *= NdotS;

    float absNdotU = abs(NdotU);
    float NdotUp = NdotU;
        //NdotU = 1.0 - pow(1.0 - absNdotU, 1.0 + float(NdotU < 0.0));
    float NdotU2 = min(1.0 - NdotU, 1.0);
    NdotU2 = 1.0 - NdotU2 * NdotU2;
    //NdotU = min(NdotU + 0.015, 1.0);
    NdotU = 1.0 - NdotU;
    NdotU = pow(NdotU, 2.0 - NdotUp);
    NdotU = max(1.0 - NdotU, 0.0);
    //NdotU2 = NdotU;
	
	float sunVisibilityTimeBrightness = timeBrightness * 0.2 + sunVisibility4 * 0.8;

    float horizonExponent = 1.5 * (1.0 - NdotS) * sunVisibility4 * (1.0 - rainStrength)
                            + HORIZON_DISTANCE * 2.5 * (1.5 - rainStrength*0.5);
    float horizon = pow(1.0 - NdotU*0.5, horizonExponent);
    horizon *= (0.5 * sunVisibilityTimeBrightness + 0.3) * (1.0 - rainStrength * 0.75);

    float timeBrightness4 = 1.0 - timeBrightness;
    timeBrightness4 *= timeBrightness4;
    timeBrightness4 = 1.0 - timeBrightness4 * timeBrightness4;
    
    float lightmix = NdotS * max(1.0 - absNdotU * 2.0, 0.0) * pow(1.0 - timeBrightness4, 3.0) * 0.5
                     + horizon * 0.15 * (6.0 - timeBrightness4*5.0) + 0.05 * (1.0 - timeBrightness4);
    lightmix *= sunVisibility * (1.0 - rainStrength);

    sky = mix(fogCol, sky * (1.5 + 0.5 * sunVisibility4 + timeBrightness4) * (1.5 - NdotU2), absNdotU);
	
	float ground = 0.0;

    #ifndef SKY_REF_FIX_2
        doGround = false;
    #endif
    //doGround = true;

	if (doGround == true) {
        float invNdotU = clamp(dot(nViewPos, -upVec), 0.0, 1.0);
        float groundFactor = 0.5 * (11.0 * rainStrength + 1.0) * (-5.0 * sunVisibility4 + 6.0);
        ground = exp(-groundFactor / (invNdotU * 6.0));
        ground = smoothstep(0.0, 1.0, ground);
    }
    
    float mult = (0.1 * (1.0 + rainStrength) + horizon * 0.75) * (1.0 - ground);
	
	float meFactor = 0.06;
	if (sunAngle > 0.5) {
		if (sunAngle >  0.75) meFactor = max(sunAngle - 0.925, 0.0);
		if (sunAngle <= 0.75) meFactor = max(0.575 - sunAngle, 0.0);
	}
    vec3 meSkyColor = vec3(0.0);
    float meNdotU = 1.0 - absNdotU;
    meFactor *= meNdotU * meNdotU * 15.0 * (1.0 - rainStrength);
    if (NdotS > 0.0) meSkyColor = pow(mix(lightMorning, lightEvening, mefade), vec3(4.0));
    meSkyColor *= meFactor * meFactor * NdotS;
	
    sky = mix(sky * pow(max(1.0 - lightmix, 0.0), sunVisibility), lightCol * sqrt(lightCol), lightmix) * sunVisibility4;
	if (sunVisibility4 < 1.0) sky+= (1.0 - sunVisibility4) * lightNight*lightNight*lightNight * 7.0 * (1.0 + 3.0 * nightVision);
    sky+= meSkyColor * 0.8;
    
    vec3 weatherSky = weatherCol * weatherCol;
    weatherSky *= GetLuminance(ambientCol / (weatherSky)) * 1.4;
    sky = mix(sky, weatherSky, rainStrength) * mult;

    #ifdef FOG_DESATURATION
        if (NdotUp < 0.0) {
            vec3 gray = vec3(0.299, 0.587, 0.114);
            gray = vec3(dot(gray, sky));
            sky = mix(sky, gray, min(0.0 - NdotUp*2, 0.5) * 0.5 * (1.0 - rainStrength) * (0.5 + (sunVisibility4*0.5 + timeBrightness)));
        }
    #endif

    

    return pow(sky, vec3(1.125));
}