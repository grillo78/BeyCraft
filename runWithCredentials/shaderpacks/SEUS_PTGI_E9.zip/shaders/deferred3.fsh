#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/






in vec4 texcoord;



#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBufferData.inc"




 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 x(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,y=d();
   ivec2 f=ivec2(v.x*m.x,v.y*m.y);
   float z=float(f.y/y),i=float(int(f.x+mod(m.x*z,y))/y);
   i+=floor(m.x*z/y);
   vec3 s=vec3(0.,0.,i);
   s.x=mod(f.x+mod(m.x*z,y),y);
   s.y=mod(f.y,y);
   s.xyz=floor(s.xyz);
   s/=y;
   s.xyz=s.xzy;
   return s;
 }
 vec2 n(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 f=v.xzy*x;
   f=floor(f+1e-05);
   float y=f.z;
   vec2 i;
   i.x=mod(f.x+y*x,m.x);
   float s=f.x+y*x;
   i.y=f.y+floor(s/m.x)*x;
   i+=.5;
   i/=m;
   return i;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 s=ivec2(i.x*m.x,i.y*m.y);
   float z=float(s.y/y),r=float(int(s.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 t=vec3(0.,0.,r);
   t.x=mod(s.x+mod(m.x*z,y),y);
   t.y=mod(s.y,y);
   t.xyz=floor(t.xyz);
   t/=y;
   t.xyz=t.xzy;
   return t;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 f=v.xzy*y;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 i;
   i.x=mod(f.x+x*y,m.x);
   float s=f.x+x*y;
   i.y=f.y+floor(s/m.x)*y;
   i+=.5;
   i/=m;
   i.xy*=.5;
   return i;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 n()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,x=floor(v-.0001),y=floor(f-.0001);
   return x-y;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 m,vec2 x,vec4 s,vec4 i,inout float y,out vec2 t)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!r||i.x==20.||i.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(i.x==50.||i.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(i.x==51)
     y=0.;
   if(i.x>255)
     y=0.;
   vec3 z,c;
   if(f.x>.5)
     z=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       z=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         z=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           z=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             z=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               z=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   t=clamp((m.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,o=.15;
   if(i.x==10.||i.x==11.)
     {
       if(abs(f.y)<.01&&r||f.y>.99)
         h=.1,o=.1,y=0.;
       else
          y=1.;
     }
   if(i.x==51)
     h=.5,o=.1;
   if(i.x==76)
     h=.2,o=.2;
   if(i.x-255.+39.>=102.&&i.x-255.+39.<=112.)
     o=.025,h=.025;
   z=normalize(s.xyz);
   c=normalize(cross(z,f.xyz)*sign(s.w));
   vec3 n=v.xyz+mix(z*h,-z*h,vec3(t.x));
   n.xyz+=mix(c*h,-c*h,vec3(t.y));
   n.xyz-=f.xyz*o;
   return n;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA e(Ray v)
 {
   DDA f;
   f.mapPos=floor(v.origin);
   f.mapPosOrigin=f.mapPos;
   f.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.rayStep=sign(v.direction);
   f.sideDist=(sign(v.direction)*(f.mapPos-v.origin)+sign(v.direction)*.5+.5)*f.deltaDist;
   f.mask=vec3(0.);
   return f;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float y)
 {
   float x,z,r,t;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),r);
   y=min(min(y,z),t);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,s=y-z,r=vec3(0.);
   r+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-i.x),x);
   r+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-i.y),x);
   r+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),s=min(x,y),t=max(x,y);
   vec2 r=max(s.xx,s.yz);
   float z=max(r.x,r.y);
   r=min(t.xx,t.yz);
   float c=min(r.x,r.y);
   i.x=z;
   i.y=c;
   return c>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float y,inout vec3 x)
 {
   vec3 z=m.inv_direction*(v-m.origin),i=m.inv_direction*(f-m.origin),s=min(i,z),t=max(i,z);
   vec2 r=max(s.xx,s.yz);
   float c=max(r.x,r.y);
   r=min(t.xx,t.yz);
   float G=min(r.x,r.y);
   bool n=G>max(c,0.)&&max(c,0.)<y;
   if(n)
     x=d(v,f,m.origin+m.direction*c),y=c;
   return n;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 t=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   t*=saturate(dot(f,y));
   {
     vec4 r=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float c=abs(r.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,c),o=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     t=mix(t,t*h,1.-o);
   }
   t=TintUnderwaterDepth(t);
   return t*(1.-rainStrength);
 }
 vec3 f(vec3 f,vec3 i,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(f),t=m(s+y*.99);
   float n=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(t.xy,t.z-.0006*n),3).x;
   r*=saturate(dot(i,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct SugChoyrig{float EPQCbdZJBL;float xVoNcOTeXw;float dEdWWLhdyo;float vDYzoMNpum;vec3 ounGyXgtzs;};
 vec4 h(SugChoyrig v)
 {
   vec4 f;
   v.ounGyXgtzs=max(vec3(0.),v.ounGyXgtzs);
   f.x=v.EPQCbdZJBL;
   v.ounGyXgtzs=pow(v.ounGyXgtzs,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.ounGyXgtzs.x,v.dEdWWLhdyo);
   f.z=PackTwo16BitTo32Bit(v.ounGyXgtzs.y,v.vDYzoMNpum);
   f.w=PackTwo16BitTo32Bit(v.ounGyXgtzs.z,v.xVoNcOTeXw);
   return f;
 }
 SugChoyrig i(vec4 v)
 {
   SugChoyrig f;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),i=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   f.EPQCbdZJBL=v.x;
   f.dEdWWLhdyo=m.y;
   f.vDYzoMNpum=i.y;
   f.xVoNcOTeXw=s.y;
   f.ounGyXgtzs=pow(vec3(m.x,i.x,s.x),vec3(8.));
   return f;
 }
 SugChoyrig G(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void G(inout float v,inout float f,float m,float y,vec3 i,float x)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,y);
   #else
   v*=mix(3.4,3.4,y);
   #endif
   float s=dot(i,vec3(1.));
   f*=1.-pow(y,.4);
   f/=m*.1+2e-06;
   f*=4.;
   f*=.6;
   float r=m/(s+1e-07)*.2+4e-08;
   r=min(r,1.);
   r=mix(r,1.,pow(y,.25));
   if(x<.12)
     f=0.;
 }
 float G(vec3 v,vec3 y,float m)
 {
   float f=dot(abs(v-y),vec3(.3333));
   f*=m;
   f*=.18;
   return f;
 }
 void e(inout vec3 v,vec2 f,vec3 y)
 {}
 float e(float v,float f)
 {
   return v/(f*20.01+1.);
 }
 bool d(vec3 v,float y,Ray f,bool x,inout float i,inout vec3 z)
 {
   bool m=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(x)
     return false;
   if(y>=66.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),f,i,z);
   m=r;
   #else
   if(y<40.)
     return r=d(v,v+vec3(1.,1.,1.),f,i,z),r;
   if(y==40.||y>=42.&&y<=53.)
     r=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),f,i,z),m=m||r;
   if(y==41.||y>=54.&&y<=65.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,z),m=m||r;
   if(y==42.||y==45.||y==46.||y==51.||y==52.||y==53.||y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
     {
       float s=.5;
       if(y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
         s=0.;
       r=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),f,i,z);
       m=m||r;
     }
   if(y==42.||y==44.||y==47.||y==50.||y==52.||y==53.||y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
     {
       float s=.5;
       if(y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
         s=0.;
       r=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),f,i,z);
       m=m||r;
     }
   if(y==43.||y==44.||y==48.||y==50.||y==51.||y==53.||y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
     {
       float s=.5;
       if(y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
         s=0.;
       r=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),f,i,z);
       m=m||r;
     }
   if(y==43.||y==45.||y==49.||y==50.||y==51.||y==52.||y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
     {
       float s=.5;
       if(y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
         s=0.;
       r=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),f,i,z);
       m=m||r;
     }
   if(y>=66.&&y<=81.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,z),m=m||r;
   if(y==67.||y==68.||y==69.||y==71.||y==72.||y==73.||y==75.||y==76.||y==77.||y==79.||y==80.||y==81.)
     {
       float s=8.,t=8.;
       if(y==67.||y==69.||y==71.||y==73.||y==75.||y==77.||y==79.||y==81.)
         s=0.;
       if(y==68.||y==69.||y==72.||y==73.||y==76.||y==77.||y==80.||y==81.)
         t=16.;
       r=d(v+vec3(s,6.,7.)/16.,v+vec3(t,9.,9.)/16.,f,i,z);
       m=m||r;
       r=d(v+vec3(s,12.,7.)/16.,v+vec3(t,15.,9.)/16.,f,i,z);
       m=m||r;
     }
   if(y>=70.&&y<=81.)
     {
       float s=8.,t=8.;
       if(y>=70.&&y<=73.||y>=78.&&y<=81.)
         t=16.;
       if(y>=74.&&y<=81.)
         s=0.;
       r=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,t)/16.,f,i,z);
       m=m||r;
       r=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,t)/16.,f,i,z);
       m=m||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=82.&&y<=85.)
     {
       vec3 s=vec3(0),t=vec3(0);
       if(y==82.)
         s=vec3(0,0,0),t=vec3(16,16,3);
       if(y==83.)
         s=vec3(0,0,13),t=vec3(16,16,16);
       if(y==85.)
         s=vec3(0,0,0),t=vec3(3,16,16);
       if(y==84.)
         s=vec3(13,0,0),t=vec3(16,16,16);
       r=d(v+s/16.,v+t/16.,f,i,z);
       m=m||r;
     }
   if(y>=86.&&y<=101.)
     {
       vec3 s=vec3(0.),t=vec3(1.);
       if(y>=86.&&y<=93.)
         {
           float c=0.;
           if(y>=90.&&y<=93.)
             c=13.;
           s=vec3(0.,c,0.)/16.;
           t=vec3(16.,c+3.,16.)/16.;
         }
       if(y>=94.&&y<=97.)
         {
           float c=13.;
           if(y==96.||y==97.)
             c=0.;
           s=vec3(0.,0.,c)/16.;
           t=vec3(16.,16.,c+3.)/16.;
         }
       if(y>=98.&&y<=101.)
         {
           float c=13.;
           if(y==98.||y==99.)
             c=0.;
           s=vec3(c,0.,0.)/16.;
           t=vec3(c+3.,16.,16.)/16.;
         }
       r=d(v+s,v+t,f,i,z);
       m=m||r;
     }
   if(y>=102.&&y<=112.)
     {
       vec3 s=vec3(0.),t=vec3(1.);
       if(y>=102.&&y<=109.)
         {
           float c=float(y)-float(102.)+1.;
           t.y=c*2./16.;
         }
       if(y==110.)
         t.y=.0625;
       if(y==111.)
         s=vec3(1.,0.,1.)/16.,t=vec3(15.,1.,15.)/16.;
       if(y==112.)
         s=vec3(1.,0.,1.)/16.,t=vec3(15.,.5,15.)/16.;
       r=d(v+s,v+t,f,i,z);
       m=m||r;
     }
   #endif
   #endif
   return m;
 }
 float h(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 float i(vec3 v,vec3 y)
 {
   return dot(abs(v-y),vec3(.3333));
 }
 void main()
 {
   SugChoyrig v=G(texcoord.xy);
   float y=v.vDYzoMNpum;
   int z=0;
   vec4 f=texture2DLod(colortex6,texcoord.xy,0);
   vec3 i=f.xyz;
   float s=Luminance(i.xyz),t=f.w;
   vec3 x=GetNormals(texcoord.xy);
   float r=GetDepth(texcoord.xy),m=ExpToLinearDepth(r);
   vec3 n=GetViewPosition(texcoord.xy,r).xyz;
   vec2 c=vec2(0.);
   #if GI_FILTER_QUALITY==1
   c=BlueNoiseTemporal(texcoord.xy).xy-.5;
   #endif
   float h=2.*1,o=2.;
   G(h,o,f.w,y,i,m);
   float w=6.*mix(1.,6.,y),Y=mix(20.,15.,y)/m,R=0.;
   vec4 d=vec4(0.);
   float a=0.;
   vec4 p=vec4(vec3(1.),1.);
   int D=0;
   for(int S=-1;S<=1;S++)
     {
       for(int b=-1;b<=1;b++)
         {
           vec2 k=(vec2(S,b)+c)/vec2(viewWidth,viewHeight)*h,g=texcoord.xy+k.xy;
           g=clamp(g,2./vec2(viewWidth,viewHeight),1.-2./vec2(viewWidth,viewHeight));
           vec4 l=texture2DLod(colortex6,g,z);
           vec3 L=GetNormals(g);
           float E=GetDepth(g),u=ExpToLinearDepth(E),T=pow(saturate(dot(x,L)),w),P=exp(-(abs(u-m)*Y)),A=0.;
           #if GI_FILTER_QUALITY==1
           vec3 F=GetViewPosition(g,E).xyz,B=normalize(F.xyz-n.xyz);
           float U=dot(-L,B);
           bool W=U>0.&&Luminance(l.xyz)<Luminance(i.xyz);
           T=W?2.:T;
           A=exp(-G(l.xyz,i,W?o:o));
           #else
           A=exp(-G(l.xyz,i,o));
           #endif
           float C=P*A*T;
           d+=pow(l,p)*C;
           a+=C;
           D++;
         }
     }
   d/=a+.0001;
   d=pow(d,vec4(1.)/p);
   vec3 l=d.xyz;
   if(a<.0001)
     l=i;
   e(l,texcoord.xy,rand(texcoord.xy+sin(frameTimeCounter)).xyz);
   vec4 g=texture2DLod(colortex4,texcoord.xy,0);
   g.xyz=mix(g.xyz,l.xyz,vec3(y));
   gl_FragData[0]=g;
   gl_FragData[1]=vec4(l,d.w);
 };




/* DRAWBUFFERS:46 */
