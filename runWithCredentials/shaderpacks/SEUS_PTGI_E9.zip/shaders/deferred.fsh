#version 330 compatibility



/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

/////////ADJUSTABLE VARIABLES//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////ADJUSTABLE VARIABLES//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



//#define HALF_RES_TRACE

/////////INTERNAL VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////INTERNAL VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Do not change the name of these variables or their type. The Shaders Mod reads these lines and determines values to send to the inner-workings
//of the shaders mod. The shaders mod only reads these lines and doesn't actually know the real value assigned to these variables in GLSL.
//Some of these variables are critical for proper operation. Change at your own risk.

const bool colortex4Clear = false;
const bool colortex5Clear = false;
//END OF INTERNAL VARIABLES//




in vec4 texcoord;

in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSkyUp;
in vec3 colorTorchlight;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;


in vec3 worldLightVector;
in vec3 worldSunVector;


in mat4 gbufferPreviousModelViewInverse;
in mat4 gbufferPreviousProjectionInverse;


#include "lib/Uniforms.inc"
#include "lib/Common.inc"

#include "lib/Materials.inc"


/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////






// vec4 GetViewPosition(in vec2 coord, in float depth) 
// {	
// 	vec2 tcoord = coord;
// 	TemporalJitterProjPosInv01(tcoord);

// 	vec4 fragposition = gbufferProjectionInverse * vec4(tcoord.s * 2.0f - 1.0f, tcoord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
// 		 fragposition /= fragposition.w;

	
// 	return fragposition;
// }




vec2 GetNearFragment(vec2 coord, float depth, out float minDepth)
{
	
	
	vec2 texel = 1.0 / vec2(viewWidth, viewHeight);
	vec4 depthSamples;
	depthSamples.x = texture2D(depthtex1, coord + texel * vec2(1.0, 1.0)).x;
	depthSamples.y = texture2D(depthtex1, coord + texel * vec2(1.0, -1.0)).x;
	depthSamples.z = texture2D(depthtex1, coord + texel * vec2(-1.0, 1.0)).x;
	depthSamples.w = texture2D(depthtex1, coord + texel * vec2(-1.0, -1.0)).x;

	vec2 targetFragment = vec2(0.0, 0.0);

	if (depthSamples.x < depth)
		targetFragment = vec2(1.0, 1.0);
	if (depthSamples.y < depth)
		targetFragment = vec2(1.0, -1.0);
	if (depthSamples.z < depth)
		targetFragment = vec2(-1.0, 1.0);
	if (depthSamples.w < depth)
		targetFragment = vec2(-1.0, -1.0);


	minDepth = min(min(min(depthSamples.x, depthSamples.y), depthSamples.z), depthSamples.w);

	return coord + texel * targetFragment;
}










#include "lib/GBufferData.inc"





 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int y=v.x*v.y;
   return t(f(floor(pow(float(y),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int y=v.x*v.y;
   return d(f(floor(pow(float(y),.333333))));
 }
 vec3 v(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=d();
   ivec2 s=ivec2(v.x*f.x,v.y*f.y);
   float z=float(s.y/y),i=float(int(s.x+mod(f.x*z,y))/y);
   i+=floor(f.x*z/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(s.x+mod(f.x*z,y),y);
   m.y=mod(s.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 s(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 r;
   r.x=mod(i.x+y*x,f.x);
   float s=i.x+y*x;
   r.y=i.y+floor(s/f.x)*x;
   r+=.5;
   r/=f;
   return r;
 }
 vec3 e(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 s=ivec2(2048,2048);
   int x=s.x*s.y,y=f();
   ivec2 m=ivec2(i.x*s.x,i.y*s.y);
   float z=float(m.y/y),r=float(int(m.x+mod(s.x*z,y))/y);
   r+=floor(s.x*z/y);
   vec3 n=vec3(0.,0.,r);
   n.x=mod(m.x+mod(s.x*z,y),y);
   n.y=mod(m.y,y);
   n.xyz=floor(n.xyz);
   n/=y;
   n.xyz=n.xzy;
   return n;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 f=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,f.x);
   float s=i.x+x*y;
   r.y=i.y+floor(s/f.x)*y;
   r+=.5;
   r/=f;
   r.xy*=.5;
   return r;
 }
 vec3 e(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 m(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 x(vec3 v)
 {
   int y=d();
   v*=1./y;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 n(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 e()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,y=floor(v-.0001),x=floor(i-.0001);
   return y-x;
 }
 vec3 r(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 s,vec2 y,vec4 i,vec4 m,inout float x,out vec2 r)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(m.x==8||m.x==9||m.x==79||m.x<1.||!z||m.x==20.||m.x==171.||min(abs(f.x),abs(f.z))>.2)
     x=1.;
   if(m.x==50.||m.x==76.)
     {
       x=0.;
       if(f.y<.5)
         x=1.;
     }
   if(m.x==51)
     x=0.;
   if(m.x>255)
     x=0.;
   vec3 c,t;
   if(f.x>.5)
     c=vec3(0.,0.,-1.),t=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       c=vec3(0.,0.,1.),t=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         c=vec3(1.,0.,0.),t=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           c=vec3(1.,0.,0.),t=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             c=vec3(1.,0.,0.),t=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               c=vec3(-1.,0.,0.),t=vec3(0.,-1.,0.);
   r=clamp((s.xy-y.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,w=.15;
   if(m.x==10.||m.x==11.)
     {
       if(abs(f.y)<.01&&z||f.y>.99)
         h=.1,w=.1,x=0.;
       else
          x=1.;
     }
   if(m.x==51)
     h=.5,w=.1;
   if(m.x==76)
     h=.2,w=.2;
   if(m.x-255.+39.>=102.&&m.x-255.+39.<=112.)
     w=.025,h=.025;
   c=normalize(i.xyz);
   t=normalize(cross(c,f.xyz)*sign(i.w));
   vec3 n=v.xyz+mix(c*h,-c*h,vec3(r.x));
   n.xyz+=mix(t*h,-t*h,vec3(r.y));
   n.xyz-=f.xyz*w;
   return n;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA p(Ray v)
 {
   DDA f;
   f.mapPos=floor(v.origin);
   f.mapPosOrigin=f.mapPos;
   f.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.rayStep=sign(v.direction);
   f.sideDist=(sign(v.direction)*(f.mapPos-v.origin)+sign(v.direction)*.5+.5)*f.deltaDist;
   f.mask=vec3(0.);
   return f;
 }
 void i(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float y)
 {
   float x,r,z,t;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),z);
   y=min(min(y,r),t);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,s=y-z,r=vec3(0.);
   r+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-i.x),x);
   r+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-i.y),x);
   r+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),s=min(x,y),t=max(x,y);
   vec2 r=max(s.xx,s.yz);
   float z=max(r.x,r.y);
   r=min(t.xx,t.yz);
   float n=min(r.x,r.y);
   i.x=z;
   i.y=n;
   return n>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float y,inout vec3 x)
 {
   vec3 t=m.inv_direction*(v-m.origin),i=m.inv_direction*(f-m.origin),s=min(i,t),c=max(i,t);
   vec2 r=max(s.xx,s.yz);
   float z=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float n=min(r.x,r.y);
   bool w=n>max(z,0.)&&max(z,0.)<y;
   if(w)
     x=d(v,f,m.origin+m.direction*z),y=z;
   return w;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=r(v);
   float t=.5;
   vec3 s=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*t),0).x;
   s*=saturate(dot(f,y));
   {
     vec4 m=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float w=abs(m.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,w),c=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     s=mix(s,s*h,1.-c);
   }
   s=TintUnderwaterDepth(s);
   return s*(1.-rainStrength);
 }
 vec3 f(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 i=m(v),s=r(i+y*.99);
   float t=.5;
   vec3 n=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*t),3).x;
   n*=saturate(dot(f,y));
   n=TintUnderwaterDepth(n);
   return n*(1.-rainStrength);
 }
 vec3 i(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=r(v);
   float t=.5;
   vec3 s=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*t),2).x;
   s*=saturate(dot(f,y));
   s=TintUnderwaterDepth(s);
   return s*(1.-rainStrength);
 }struct SugChoyrig{float EPQCbdZJBL;float xVoNcOTeXw;float dEdWWLhdyo;float vDYzoMNpum;vec3 ounGyXgtzs;};
 vec4 h(SugChoyrig v)
 {
   vec4 f;
   v.ounGyXgtzs=max(vec3(0.),v.ounGyXgtzs);
   f.x=v.EPQCbdZJBL;
   v.ounGyXgtzs=pow(v.ounGyXgtzs,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.ounGyXgtzs.x,v.dEdWWLhdyo);
   f.z=PackTwo16BitTo32Bit(v.ounGyXgtzs.y,v.vDYzoMNpum);
   f.w=PackTwo16BitTo32Bit(v.ounGyXgtzs.z,v.xVoNcOTeXw);
   return f;
 }
 SugChoyrig w(vec4 v)
 {
   SugChoyrig f;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),s=UnpackTwo16BitFrom32Bit(v.z),i=UnpackTwo16BitFrom32Bit(v.w);
   f.EPQCbdZJBL=v.x;
   f.dEdWWLhdyo=m.y;
   f.vDYzoMNpum=s.y;
   f.xVoNcOTeXw=i.y;
   f.ounGyXgtzs=pow(vec3(m.x,s.x,i.x),vec3(8.));
   return f;
 }
 SugChoyrig g(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return w(texture2DLod(colortex5,v,0));
 }
 float g(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void d(inout float v,inout float f,float y,float i,vec3 s,float t)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,i);
   #else
   v*=mix(3.4,3.4,i);
   #endif
   float x=dot(s,vec3(1.));
   f*=1.-pow(i,.4);
   f/=y*.1+2e-06;
   f*=4.;
   f*=.6;
   float r=y/(x+1e-07)*.2+4e-08;
   r=min(r,1.);
   r=mix(r,1.,pow(i,.25));
   if(t<.12)
     f=0.;
 }
 float e(vec3 v,vec3 y,float f)
 {
   float i=dot(abs(v-y),vec3(.3333));
   i*=f;
   i*=.18;
   return i;
 }
 void f(inout vec3 v,vec2 f,vec3 y)
 {}
 float h(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool e(vec3 v,float y,Ray f,bool z,inout float i,inout vec3 t)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(z)
     return false;
   if(y>=66.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),f,i,t);
   r=m;
   #else
   if(y<40.)
     return m=d(v,v+vec3(1.,1.,1.),f,i,t),m;
   if(y==40.||y>=42.&&y<=53.)
     m=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),f,i,t),r=r||m;
   if(y==41.||y>=54.&&y<=65.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,t),r=r||m;
   if(y==42.||y==45.||y==46.||y==51.||y==52.||y==53.||y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
     {
       float x=.5;
       if(y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
         x=0.;
       m=d(v+vec3(0.,x,0.),v+vec3(.5,.5+x,.5),f,i,t);
       r=r||m;
     }
   if(y==42.||y==44.||y==47.||y==50.||y==52.||y==53.||y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
     {
       float x=.5;
       if(y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
         x=0.;
       m=d(v+vec3(.5,x,0.),v+vec3(1.,.5+x,.5),f,i,t);
       r=r||m;
     }
   if(y==43.||y==44.||y==48.||y==50.||y==51.||y==53.||y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
     {
       float x=.5;
       if(y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
         x=0.;
       m=d(v+vec3(.5,x,.5),v+vec3(1.,.5+x,1.),f,i,t);
       r=r||m;
     }
   if(y==43.||y==45.||y==49.||y==50.||y==51.||y==52.||y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
     {
       float x=.5;
       if(y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
         x=0.;
       m=d(v+vec3(0.,x,.5),v+vec3(.5,.5+x,1.),f,i,t);
       r=r||m;
     }
   if(y>=66.&&y<=81.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,t),r=r||m;
   if(y==67.||y==68.||y==69.||y==71.||y==72.||y==73.||y==75.||y==76.||y==77.||y==79.||y==80.||y==81.)
     {
       float x=8.,s=8.;
       if(y==67.||y==69.||y==71.||y==73.||y==75.||y==77.||y==79.||y==81.)
         x=0.;
       if(y==68.||y==69.||y==72.||y==73.||y==76.||y==77.||y==80.||y==81.)
         s=16.;
       m=d(v+vec3(x,6.,7.)/16.,v+vec3(s,9.,9.)/16.,f,i,t);
       r=r||m;
       m=d(v+vec3(x,12.,7.)/16.,v+vec3(s,15.,9.)/16.,f,i,t);
       r=r||m;
     }
   if(y>=70.&&y<=81.)
     {
       float x=8.,s=8.;
       if(y>=70.&&y<=73.||y>=78.&&y<=81.)
         s=16.;
       if(y>=74.&&y<=81.)
         x=0.;
       m=d(v+vec3(7.,6.,x)/16.,v+vec3(9.,9.,s)/16.,f,i,t);
       r=r||m;
       m=d(v+vec3(7.,12.,x)/16.,v+vec3(9.,15.,s)/16.,f,i,t);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=82.&&y<=85.)
     {
       vec3 x=vec3(0),s=vec3(0);
       if(y==82.)
         x=vec3(0,0,0),s=vec3(16,16,3);
       if(y==83.)
         x=vec3(0,0,13),s=vec3(16,16,16);
       if(y==85.)
         x=vec3(0,0,0),s=vec3(3,16,16);
       if(y==84.)
         x=vec3(13,0,0),s=vec3(16,16,16);
       m=d(v+x/16.,v+s/16.,f,i,t);
       r=r||m;
     }
   if(y>=86.&&y<=101.)
     {
       vec3 x=vec3(0.),s=vec3(1.);
       if(y>=86.&&y<=93.)
         {
           float h=0.;
           if(y>=90.&&y<=93.)
             h=13.;
           x=vec3(0.,h,0.)/16.;
           s=vec3(16.,h+3.,16.)/16.;
         }
       if(y>=94.&&y<=97.)
         {
           float w=13.;
           if(y==96.||y==97.)
             w=0.;
           x=vec3(0.,0.,w)/16.;
           s=vec3(16.,16.,w+3.)/16.;
         }
       if(y>=98.&&y<=101.)
         {
           float c=13.;
           if(y==98.||y==99.)
             c=0.;
           x=vec3(c,0.,0.)/16.;
           s=vec3(c+3.,16.,16.)/16.;
         }
       m=d(v+x,v+s,f,i,t);
       r=r||m;
     }
   if(y>=102.&&y<=112.)
     {
       vec3 x=vec3(0.),s=vec3(1.);
       if(y>=102.&&y<=109.)
         {
           float n=float(y)-float(102.)+1.;
           s.y=n*2./16.;
         }
       if(y==110.)
         s.y=.0625;
       if(y==111.)
         x=vec3(1.,0.,1.)/16.,s=vec3(15.,1.,15.)/16.;
       if(y==112.)
         x=vec3(1.,0.,1.)/16.,s=vec3(15.,.5,15.)/16.;
       m=d(v+x,v+s,f,i,t);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 vec2 c(inout float v)
 {
   return fract(sin(vec2(v+=.1,v+=.1))*vec2(43758.5,22578.1));
 }
 float D(vec2 v)
 {
   v*=vec2(viewWidth,viewHeight);
   const float y=1.61803,x=1.32472;
   return fract(dot(v,1./vec2(y,x*x)));
 }
 vec3 G(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   else
      y+=f[int(mod(frameCounter,8.f))]*.5;
   y=(floor(y*64.)+.5)/64.;
   vec3 x=texture2D(noisetex,y).xyz;
   return x;
 }
 vec3 D(vec3 v,inout float f,int y)
 {
   vec2 i=G(texcoord.xy+vec2(0.,0.)).xy;
   i=i*.99+.005;
   #if GI_RESPONSIVENESS<1
   #endif
   float x=6.28319*i.x,s=sqrt(i.y);
   vec3 t=normalize(cross(v,vec3(0.,1.,1.))),r=cross(v,t),m=t*cos(x)*s+r*sin(x)*s+v.xyz*sqrt(1.-i.y);
   return m;
 }
 vec3 y(inout float v)
 {
   vec3 y=G(texcoord.xy).xyz;
   y=fract(y+vec3(c(v),c(v).x)*.1);
   y=y*2.-1.;
   y=normalize(y);
   return y;
 }
 vec3 D(vec3 v,vec3 y)
 {
   vec2 f=s(x(m(v)+y+1.+e()));
   vec3 r=g(f).ounGyXgtzs;
   return r;
 }
 vec3 D()
 {
   vec2 y=s(v(texcoord.xy)+e()/d());
   vec3 x=g(y).ounGyXgtzs;
   return x;
 }
 vec3 D(vec3 v,vec3 m,vec3 y,vec3 x,vec3 z,MaterialMask s,float r,vec2 n,float t,out float w)
 {
   float h=fract(frameCounter*.0123456),c=1.;
   #ifdef SUNLIGHT_LEAK_FIX
   if(isEyeInWater<1)
     c=saturate(r*100.);
   #endif
   float k=1.;
   #ifdef CAVE_GI_LEAK_FIX
   if(isEyeInWater<1)
     k=saturate(r*10.);
   #endif
   vec3 a=D(x,h,0);
   w=10000.;
   vec3 o=a;
   #ifdef GI_SCREEN_SPACE_TRACING
   bool g=false;
   {
     const int G=8;
     float T=.25*-m.z;
     T=mix(T,.8,.5);
     float l=.07*-m.z;
     l=mix(l,1.,.5);
     l=.4;
     vec2 R=texcoord.xy;
     vec3 L=m.xyz,Y=normalize((gbufferModelView*vec4(a.xyz,0.)).xyz);
     for(int S=0;S<G;S++)
       {
         float F=float(S),H=(F+.5)/float(G),b=T*H;
         vec3 C=m.xyz+Y*b,P=ProjectBack(C),M=GetViewPositionNoJitter(P.xy,GetDepth(P.xy)).xyz;
         float E=length(C)-length(M)-.02;
         if(E>0.&&E<l)
           {
             g=true;
             R=P.xy;
             L=M.xyz;
             break;
           }
       }
     vec3 S=(gbufferModelViewInverse*vec4(L,1.)).xyz;
     S+=Fract01(cameraPosition.xyz+.5)+.5;
     if(g)
       {
         vec3 F=pow(texture2DLod(colortex7,R.xy-n*.5,0).xyz,vec3(2.2));
         F*=1.-saturate(t*1.1);
         return F*100.;
       }
   }
   #endif
   int G=f();
   float F=1./float(G);
   vec3 S=v+y*(.0001*length(v));
   S+=Fract01(cameraPosition.xyz+.5);
   Ray l=MakeRay(e(S,G)*G-vec3(1.,1.,1.),a);
   DDA T=p(l);
   vec3 L=vec3(1.),R=vec3(0.);
   float E=0.;
   {
     vec4 P=vec4(0.);
     vec3 b=vec3(0.);
     float Y=.5;
     for(int C=0;C<DIFFUSE_TRACE_LENGTH;C++)
       {
         b=T.mapPos/float(G);
         vec2 M=d(b,G);
         P=texture2DLod(shadowcolor,M,0);
         E=P.w*255.;
         float H=1.-step(.5,abs(E-241.));
         vec3 U=P.xyz;
         R+=U*H*Y*.5;
         if(E<240.)
           {
             if(e(T.mapPos,E,l,C==0,w,o))
               {
                 break;
               }
           }
         i(T);
         Y=1.;
       }
     float C=0.;
     if(E<1.f||E>254.f)
       {
         vec3 M=l.direction;
         if(isEyeInWater>0)
           M=refract(M,vec3(0.,-1.,0.),1.3333);
         vec3 U=SkyShading(M,worldSunVector,rainStrength);
         U*=saturate(M.y*10.+1.);
         U=DoNightEyeAtNight(U*12.,timeMidnight)*.083333;
         U=TintUnderwaterDepth(U);
         if(length(M)<.1)
           C=300.;
         R+=U*.1*k;
       }
     else
       {
         if(abs(E-31.)<.1)
           R+=.09*L*P.xyz*GI_LIGHT_BLOCK_INTENSITY;
         if(E<240.)
           {
             vec3 U=saturate(P.xyz);
             L*=U;
             R+=D(b,o)*L;
             const float M=2.4;
             vec3 H=i(S+l.direction*w-1.,worldLightVector,o,a,G),I=DoNightEyeAtNight(H*L*M*colorSunlight*c*k*12.,timeMidnight)/12.;
             R+=I;
             C=w;
           }
       }
     UnderwaterFog(R,C,a,colorSkyUp,colorSunlight);
   }
   if(s.grass<.5)
     R/=saturate(dot(x,a))+.01,R*=saturate(dot(y,a));
   return R;
 }
 vec3 G()
 {
   int y=f();
   vec3 x=v(texcoord.xy),s=n(x),r=e(s-vec3(1.,1.,0.),y);
   vec2 m=d(r,y);
   float z=1.;
   #ifdef CAVE_GI_LEAK_FIX
   if(isEyeInWater<1)
     z*=saturate(eyeBrightnessSmooth.y/240.*20.);
   #endif
   float t=1000.;
   t=min(t,texture2DLod(shadowcolor,d(e(s-vec3(0.,0.,0.),y),y)+vec2(.5,.5)/float(4096),0).w);
   t=min(t,texture2DLod(shadowcolor,d(e(s-vec3(0.,0.,0.),y),y)+vec2(-.5,-.5)/float(4096),0).w);
   t=min(t,texture2DLod(shadowcolor,d(e(s-vec3(0.,1.,0.),y),y)+vec2(0.,0.)/float(4096),0).w);
   t=min(t,texture2DLod(shadowcolor,d(e(s-vec3(0.,-1.,0.),y),y)+vec2(0.,0.)/float(4096),0).w);
   float w=texture2DLod(shadowcolor,d(e(s-vec3(0.,0.,0.),y),y),0).w;
   if(t*255.>240.||w*255.<240.)
     return vec3(0.);
   vec3 c=vec3(0.);
   for(int R=0;R<GI_SECONDARY_SAMPLES;R++)
     {
       float h=sin(frameTimeCounter*1.1)+s.x*.11+s.y*.12+s.z*.13+R*.1;
       vec3 G=normalize(rand(vec2(h))*2.-1.);
       G.x+=G.x==G.y||G.x==G.z?.01:0.;
       G.y+=G.y==G.z?.01:0.;
       vec3 a=s+vec3(1.,1.,1.);
       Ray M=MakeRay(e(a,y)*y-vec3(1.,1.,1.),G);
       DDA P=p(M);
       vec3 L=vec3(1.);
       float g=1000.;
       for(int S=0;S<1;S++)
         {
           vec4 T=vec4(0.);
           float E=0.;
           vec3 l=vec3(0.);
           float U=.2;
           for(int C=0;C<DIFFUSE_TRACE_LENGTH;C++)
             {
               l=P.mapPos/float(y);
               vec2 o=d(l,y);
               T=texture2DLod(shadowcolor,o,0);
               E=T.w*255.;
               float F=1.-step(.5,abs(E-241.));
               vec3 k=T.xyz;
               c+=k*U*F*(C==0?.5:1.);
               if(E<240.)
                 {
                   break;
                 }
               i(P);
               U=saturate(U*1.3);
             }
           g=distance(P.mapPos.xyz,P.mapPosOrigin.xyz);
           float C=0.,o=1.;
           if(abs(P.mapPos.x-P.mapPosOrigin.x)<2||abs(P.mapPos.y-P.mapPosOrigin.y)<2||abs(P.mapPos.z-P.mapPosOrigin.z)<2)
             o=0.;
           if(E<1.f||E>254.f)
             {
               vec3 F=M.direction;
               if(isEyeInWater>0)
                 F=refract(F,vec3(0.,-1.,0.),1.3333);
               vec3 k=SkyShading(F,worldSunVector,rainStrength);
               k*=saturate(F.y*10.+1.);
               k=DoNightEyeAtNight(k*12.,timeMidnight)*.083333;
               k=TintUnderwaterDepth(k);
               if(isEyeInWater>0)
                 ;
               if(length(F)<.1)
                 C=300.;
               c+=k*.1*z;
             }
           if(abs(E-31.)<.1)
             c+=.09*T.xyz*GI_LIGHT_BLOCK_INTENSITY;
           if(E<240.)
             {
               vec3 F=saturate(T.xyz);
               L*=F;
               vec3 k=-(P.mask*P.rayStep);
               const float Y=2.4;
               vec3 H=f(l,worldLightVector,k,G,y),b=DoNightEyeAtNight(H*Y*colorSunlight*o*L*z*12.,timeMidnight)/12.;
               c+=b*2.;
               c+=D(l,k)*L;
               C=g;
             }
           {
             vec2 F=IntersectSphere(s,M.direction,vec3(0.,1.5,0.),.75);
             if(g>F.y&&F.y>-.5)
               ;
           }
           UnderwaterFog(c,C,G,colorSkyUp,colorSunlight);
         }
     }
   c/=float(GI_SECONDARY_SAMPLES);
   return saturate(c);
 }
 vec4 T(float v)
 {
   float y=v*v,x=y*v;
   vec4 f;
   f.x=-x+3*y-3*v+1;
   f.y=3*x-6*y+4;
   f.z=-3*x+3*y+3*v+1;
   f.w=x;
   return f/6.f;
 }
 vec4 G(in sampler2D v,in vec2 f)
 {
   vec2 y=vec2(viewWidth,viewHeight);
   f*=y;
   f-=.5;
   float x=fract(f.x),s=fract(f.y);
   f.x-=x;
   f.y-=s;
   vec4 i=T(x),m=T(s),t=vec4(f.x-.5,f.x+1.5,f.y-.5,f.y+1.5),r=vec4(i.x+i.y,i.z+i.w,m.x+m.y,m.z+m.w),c=t+vec4(i.y,i.w,m.y,m.w)/r,z=texture2DLod(v,vec2(c.x,c.z)/y,0),h=texture2DLod(v,vec2(c.y,c.z)/y,0),w=texture2DLod(v,vec2(c.x,c.w)/y,0),a=texture2DLod(v,vec2(c.y,c.w)/y,0);
   float n=r.x/(r.x+r.y),o=r.z/(r.z+r.w);
   return mix(mix(a,w,n),mix(h,z,n),o);
 }
 bool T(vec3 v,vec3 y)
 {
   vec3 x=normalize(cross(dFdx(v),dFdy(v))),t=normalize(y-v),s=normalize(t);
   float f=.02+length(v)*.04;
   return distance(v,y)<f;
 }
 vec3 F(vec2 v)
 {
   vec2 y=vec2(viewWidth,viewHeight),x=1./y,s=v*y,i=floor(s-.5)+.5,f=s-i,z=f*f,t=f*z;
   float m=.5;
   vec2 r=-m*t+2.*m*z-m*f,c=(2.-m)*t-(3.-m)*z+1.,h=-(2.-m)*t+(3.-2.*m)*z+m*f,n=m*t-m*z,w=c+h,P=x*(i+h/w);
   vec3 F=texture2DLod(colortex4,vec2(P.x,P.y),0).xyz;
   vec2 a=x*(i-1.),G=x*(i+2.);
   vec4 o=vec4(texture2DLod(colortex4,vec2(P.x,a.y),0).xyz,1.)*(w.x*r.y)+vec4(texture2DLod(colortex4,vec2(a.x,P.y),0).xyz,1.)*(r.x*w.y)+vec4(F,1.)*(w.x*w.y)+vec4(texture2DLod(colortex4,vec2(G.x,P.y),0).xyz,1.)*(n.x*w.y)+vec4(texture2DLod(colortex4,vec2(P.x,G.y),0).xyz,1.)*(w.x*n.y);
   return max(vec3(0.),o.xyz*(1./o.w));
 }
 vec2 D(float v,vec2 f,out float y,out vec2 i,out vec4 r)
 {
   float t;
   vec2 x=GetNearFragment(texcoord.xy,v,t);
   y=texture2D(depthtex1,x).x;
   vec4 m=vec4(texcoord.xy*2.-1.,y*2.-1.,1.),s=gbufferProjectionInverse*m;
   s.xyz/=s.w;
   vec4 z=gbufferModelViewInverse*vec4(s.xyz,1.);
   r=z;
   r.xyz+=cameraPosition-previousCameraPosition;
   vec4 c=gbufferPreviousModelView*vec4(r.xyz,1.),n=gbufferPreviousProjection*vec4(c.xyz,1.);
   n.xyz/=n.w;
   i=m.xy-n.xy;
   float w=length(i)*10.,o=clamp(w*500.,0.,1.);
   vec2 g=f.xy-i.xy*.5;
   if(y<.7)
     g=texcoord.xy;
   return g;
 }
 void main()
 {
   GBufferData v=GetGBufferData();
   MaterialMask y=CalculateMasks(v.materialID);
   vec4 f=GetViewPosition(texcoord.xy,v.depth),s=gbufferModelViewInverse*vec4(f.xyz,1.),i=gbufferModelViewInverse*vec4(f.xyz,0.);
   vec3 x=normalize(f.xyz),m=normalize(i.xyz),r=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz),t=normalize((gbufferModelViewInverse*vec4(v.geoNormal,0.)).xyz);
   float z=length(f.xyz),c=dot(v.mcLightmap.xy,vec2(.5));
   if(y.grass>.5)
     r=vec3(0.,1.,0.),t=vec3(0.,1.,0.);
   vec4 n=vec4(texcoord.xy,0.,0.);
   float w;
   vec2 o;
   vec4 P;
   vec2 a=D(v.depth,n.xy,w,o,P),E=a.xy;
   E-=(vec2(mod(frameCounter/2,2.f),mod(frameCounter,2.f))-.5)/vec2(viewWidth,viewHeight)*1.5;
   vec3 C=F(E.xy);
   SugChoyrig M=g(a.xy);
   float k=1./(saturate(-dot(v.geoNormal,x))*100.+1.);
   vec4 d=vec4(a.xy,0.,0.);
   TemporalJitterProjPosPrevInv(d);
   vec4 l=gbufferPreviousProjectionInverse*vec4(a.xy*2.-1.,texture2DLod(colortex7,d.xy,0).w*2.-1.,1.);
   l/=l.w;
   vec3 R=(gbufferPreviousModelViewInverse*vec4(l.xyz,1.)).xyz;
   M.EPQCbdZJBL+=1.;
   M.EPQCbdZJBL=min(M.EPQCbdZJBL,2.);
   vec2 L=1./vec2(viewWidth,viewHeight),Y=1.-L;
   float S=0.,U=1.-exp2(-M.EPQCbdZJBL);
   if(!T(P.xyz,R.xyz)||(a.x<L.x||a.x>Y.x||a.y<L.y||a.y>Y.y)||abs(k-M.dEdWWLhdyo)>.01)
     U=0.,S=.99,M.EPQCbdZJBL=0.;
   float H;
   vec3 b=D(s.xyz,f.xyz,r.xyz,t,m.xyz,y,v.mcLightmap.y,o,S,H);
   b=max(vec3(0.),b);
   b=mix(b,C,vec3(U));
   M.dEdWWLhdyo=k;
   M.vDYzoMNpum=mix(M.vDYzoMNpum,S,mix(.5,1.,S));
   M.xVoNcOTeXw=c;
   vec3 p=G();
   M.ounGyXgtzs=mix(D(),p,vec3(.015));
   vec4 e=h(M);
   gl_FragData[0]=vec4(b,saturate(w));
   gl_FragData[1]=vec4(e);
   gl_FragData[2]=vec4(b,1.);
 };




/* DRAWBUFFERS:456 */
