#version 330 compatibility


#include "lib/Uniforms.inc"
#include "lib/Common.inc"



attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

out vec4 texcoord;
out vec4 color;
out vec4 lmcoord;

out vec3 normal;
out vec4 viewPos;

out float materialIDs;
out float mcEntity;
out float isWater;
out float isStainedGlass;

out float StSXoVoNgz;		
out float aYFTnWlIrg;			
out float rEpeEscUGE;			
out vec2 sLAoKhsvSP;			
out vec4 fnFFDTUhFS;		
out vec4 CDSvqneOsV;		

const int countInstances = 2;
uniform int instanceId;


 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int x(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int f()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int t()
 {
   ivec2 v=ivec2(2048,2048);
   int s=v.x*v.y;
   return x(f(floor(pow(float(s),.333333))));
 }
 vec3 d(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,s=f();
   ivec2 y=ivec2(v.x*m.x,v.y*m.y);
   float z=float(y.y/s),i=float(int(y.x+mod(m.x*z,s))/s);
   i+=floor(m.x*z/s);
   vec3 n=vec3(0.,0.,i);
   n.x=mod(y.x+mod(m.x*z,s),s);
   n.y=mod(y.y,s);
   n.xyz=floor(n.xyz);
   n/=s;
   n.xyz=n.xzy;
   return n;
 }
 vec2 n(vec3 v)
 {
   ivec2 x=ivec2(viewWidth,viewHeight);
   int s=f();
   vec3 i=v.xzy*s;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 n;
   n.x=mod(i.x+y*s,x.x);
   float m=i.x+y*s;
   n.y=i.y+floor(m/x.x)*s;
   n+=.5;
   n/=x;
   return n;
 }
 vec3 v(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,s=t();
   ivec2 y=ivec2(i.x*m.x,i.y*m.y);
   float z=float(y.y/s),f=float(int(y.x+mod(m.x*z,s))/s);
   f+=floor(m.x*z/s);
   vec3 n=vec3(0.,0.,f);
   n.x=mod(y.x+mod(m.x*z,s),s);
   n.y=mod(y.y,s);
   n.xyz=floor(n.xyz);
   n/=s;
   n.xyz=n.xzy;
   return n;
 }
 vec2 d(vec3 v,int z)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 x=ivec2(2048,2048);
   vec3 i=v.xzy*z;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 n;
   n.x=mod(i.x+y*z,x.x);
   float m=i.x+y*z;
   n.y=i.y+floor(m/x.x)*z;
   n+=.5;
   n/=x;
   n.xy*=.5;
   return n;
 }
 vec3 f(vec3 v,int x)
 {
   return v*=1./x,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int x)
 {
   return v*=1./x,v=v+vec3(.5),v;
 }
 vec3 m(vec3 v)
 {
   int x=t();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 r(vec3 v)
 {
   int x=f();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=f();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,s=floor(v-.0001),i=floor(x-.0001);
   return s-i;
 }
 vec3 p(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),s=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/s;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 m,vec2 y,vec2 n,vec4 i,vec4 x,inout float s,out vec2 f)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(x.x==8||x.x==9||x.x==79||x.x<1.||!r||x.x==20.||x.x==171.||min(abs(m.x),abs(m.z))>.2)
     s=1.;
   if(x.x==50.||x.x==76.)
     {
       s=0.;
       if(m.y<.5)
         s=1.;
     }
   if(x.x==51)
     s=0.;
   if(x.x>255)
     s=0.;
   vec3 z,a;
   if(m.x>.5)
     z=vec3(0.,0.,-1.),a=vec3(0.,-1.,0.);
   else
      if(m.x<-.5)
       z=vec3(0.,0.,1.),a=vec3(0.,-1.,0.);
     else
        if(m.y>.5)
         z=vec3(1.,0.,0.),a=vec3(0.,0.,1.);
       else
          if(m.y<-.5)
           z=vec3(1.,0.,0.),a=vec3(0.,0.,-1.);
         else
            if(m.z>.5)
             z=vec3(1.,0.,0.),a=vec3(0.,-1.,0.);
           else
              if(m.z<-.5)
               z=vec3(-1.,0.,0.),a=vec3(0.,-1.,0.);
   f=clamp((y.xy-n.xy)*100000.,vec2(0.),vec2(1.));
   float g=.15,c=.15;
   if(x.x==10.||x.x==11.)
     {
       if(abs(m.y)<.01&&r||m.y>.99)
         g=.1,c=.1,s=0.;
       else
          s=1.;
     }
   if(x.x==51)
     g=.5,c=.1;
   if(x.x==76)
     g=.2,c=.2;
   if(x.x-255.+39.>=102.&&x.x-255.+39.<=112.)
     c=.025,g=.025;
   z=normalize(i.xyz);
   a=normalize(cross(z,m.xyz)*sign(i.w));
   vec3 t=v.xyz+mix(z*g,-z*g,vec3(f.x));
   t.xyz+=mix(a*g,-a*g,vec3(f.y));
   t.xyz-=m.xyz*c;
   return t;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA e(Ray v)
 {
   DDA i;
   i.mapPos=floor(v.origin);
   i.mapPosOrigin=i.mapPos;
   i.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.rayStep=sign(v.direction);
   i.sideDist=(sign(v.direction)*(i.mapPos-v.origin)+sign(v.direction)*.5+.5)*i.deltaDist;
   i.mask=vec3(0.);
   return i;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 m[2],out float i,out float x)
 {
   float s,z,y,f;
   i=(m[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(m[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   s=(m[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(m[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   y=(m[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   f=(m[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,s),y);
   x=min(min(x,z),f);
 }
 vec3 d(const vec3 v,const vec3 x,vec3 m)
 {
   const float s=1e-05;
   vec3 z=(x+v)*.5,i=(x-v)*.5,y=m-z,f=vec3(0.);
   f+=vec3(sign(y.x),0.,0.)*step(abs(abs(y.x)-i.x),s);
   f+=vec3(0.,sign(y.y),0.)*step(abs(abs(y.y)-i.y),s);
   f+=vec3(0.,0.,sign(y.z))*step(abs(abs(y.z)-i.z),s);
   return normalize(f);
 }
 bool e(const vec3 v,const vec3 m,Ray i,out vec2 n)
 {
   vec3 x=i.inv_direction*(v-i.origin),s=i.inv_direction*(m-i.origin),y=min(s,x),f=max(s,x);
   vec2 r=max(y.xx,y.yz);
   float z=max(r.x,r.y);
   r=min(f.xx,f.yz);
   float c=min(r.x,r.y);
   n.x=z;
   n.y=c;
   return c>max(z,0.);
 }
 bool d(const vec3 v,const vec3 m,Ray i,inout float x,inout vec3 s)
 {
   vec3 y=i.inv_direction*(v-i.origin),z=i.inv_direction*(m-i.origin),n=min(z,y),f=max(z,y);
   vec2 r=max(n.xx,n.yz);
   float g=max(r.x,r.y);
   r=min(f.xx,f.yz);
   float c=min(r.x,r.y);
   bool a=c>max(g,0.)&&max(g,0.)<x;
   if(a)
     s=d(v,m,i.origin+i.direction*g),x=g;
   return a;
 }
 vec3 e(vec3 v,vec3 m,vec3 x,vec3 z,int s)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=p(v);
   float y=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*y),0).x;
   f*=saturate(dot(m,x));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float a=abs(n.x*256.-(v.y+cameraPosition.y)),g=GetCausticsComposite(v,m,a),r=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     f=mix(f,f*g,1.-r);
   }
   f=TintUnderwaterDepth(f);
   return f*(1.-rainStrength);
 }
 vec3 f(vec3 v,vec3 x,vec3 y,vec3 z,int s)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 i=m(v),n=p(i+y*.99);
   float f=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*f),3).x;
   r*=saturate(dot(x,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 m,vec3 x,vec3 z,int s)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=p(v);
   float y=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*y),2).x;
   f*=saturate(dot(m,x));
   f=TintUnderwaterDepth(f);
   return f*(1.-rainStrength);
 }struct SugChoyrig{float EPQCbdZJBL;float xVoNcOTeXw;float dEdWWLhdyo;float vDYzoMNpum;vec3 ounGyXgtzs;};
 vec4 i(SugChoyrig v)
 {
   vec4 i;
   v.ounGyXgtzs=max(vec3(0.),v.ounGyXgtzs);
   i.x=v.EPQCbdZJBL;
   v.ounGyXgtzs=pow(v.ounGyXgtzs,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.ounGyXgtzs.x,v.dEdWWLhdyo);
   i.z=PackTwo16BitTo32Bit(v.ounGyXgtzs.y,v.vDYzoMNpum);
   i.w=PackTwo16BitTo32Bit(v.ounGyXgtzs.z,v.xVoNcOTeXw);
   return i;
 }
 SugChoyrig h(vec4 v)
 {
   SugChoyrig i;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),x=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   i.EPQCbdZJBL=v.x;
   i.dEdWWLhdyo=m.y;
   i.vDYzoMNpum=x.y;
   i.xVoNcOTeXw=s.y;
   i.ounGyXgtzs=pow(vec3(m.x,x.x,s.x),vec3(8.));
   return i;
 }
 SugChoyrig G(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),s=vec2(viewWidth,viewHeight);
   v=(floor(v*s)+.5)*x;
   return h(texture2DLod(colortex5,v,0));
 }
 float G(float v,float x)
 {
   float s=1.;
   #ifdef FULL_RT_REFLECTIONS
   s=clamp(pow(v,.125)+x,0.,1.);
   #else
   s=clamp(v*10.-7.,0.,1.);
   #endif
   return s;
 }
 void G(inout float v,inout float i,float x,float m,vec3 f,float y)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,m);
   #else
   v*=mix(3.4,3.4,m);
   #endif
   float s=dot(f,vec3(1.));
   i*=1.-pow(m,.4);
   i/=x*.1+2e-06;
   i*=4.;
   i*=.6;
   float z=x/(s+1e-07)*.2+4e-08;
   z=min(z,1.);
   z=mix(z,1.,pow(m,.25));
   if(y<.12)
     i=0.;
 }
 float G(vec3 v,vec3 x,float s)
 {
   float i=dot(abs(v-x),vec3(.3333));
   i*=s;
   i*=.18;
   return i;
 }
 void e(inout vec3 v,vec2 x,vec3 s)
 {}
 float e(float v,float x)
 {
   return v/(x*20.01+1.);
 }
 bool d(vec3 v,float x,Ray i,bool m,inout float s,inout vec3 f)
 {
   bool n=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(m)
     return false;
   if(x>=66.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),i,s,f);
   n=r;
   #else
   if(x<40.)
     return r=d(v,v+vec3(1.,1.,1.),i,s,f),r;
   if(x==40.||x>=42.&&x<=53.)
     r=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),i,s,f),n=n||r;
   if(x==41.||x>=54.&&x<=65.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,s,f),n=n||r;
   if(x==42.||x==45.||x==46.||x==51.||x==52.||x==53.||x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
     {
       float z=.5;
       if(x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
         z=0.;
       r=d(v+vec3(0.,z,0.),v+vec3(.5,.5+z,.5),i,s,f);
       n=n||r;
     }
   if(x==42.||x==44.||x==47.||x==50.||x==52.||x==53.||x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
     {
       float z=.5;
       if(x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
         z=0.;
       r=d(v+vec3(.5,z,0.),v+vec3(1.,.5+z,.5),i,s,f);
       n=n||r;
     }
   if(x==43.||x==44.||x==48.||x==50.||x==51.||x==53.||x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
     {
       float z=.5;
       if(x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
         z=0.;
       r=d(v+vec3(.5,z,.5),v+vec3(1.,.5+z,1.),i,s,f);
       n=n||r;
     }
   if(x==43.||x==45.||x==49.||x==50.||x==51.||x==52.||x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
     {
       float z=.5;
       if(x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
         z=0.;
       r=d(v+vec3(0.,z,.5),v+vec3(.5,.5+z,1.),i,s,f);
       n=n||r;
     }
   if(x>=66.&&x<=81.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,s,f),n=n||r;
   if(x==67.||x==68.||x==69.||x==71.||x==72.||x==73.||x==75.||x==76.||x==77.||x==79.||x==80.||x==81.)
     {
       float z=8.,y=8.;
       if(x==67.||x==69.||x==71.||x==73.||x==75.||x==77.||x==79.||x==81.)
         z=0.;
       if(x==68.||x==69.||x==72.||x==73.||x==76.||x==77.||x==80.||x==81.)
         y=16.;
       r=d(v+vec3(z,6.,7.)/16.,v+vec3(y,9.,9.)/16.,i,s,f);
       n=n||r;
       r=d(v+vec3(z,12.,7.)/16.,v+vec3(y,15.,9.)/16.,i,s,f);
       n=n||r;
     }
   if(x>=70.&&x<=81.)
     {
       float z=8.,y=8.;
       if(x>=70.&&x<=73.||x>=78.&&x<=81.)
         y=16.;
       if(x>=74.&&x<=81.)
         z=0.;
       r=d(v+vec3(7.,6.,z)/16.,v+vec3(9.,9.,y)/16.,i,s,f);
       n=n||r;
       r=d(v+vec3(7.,12.,z)/16.,v+vec3(9.,15.,y)/16.,i,s,f);
       n=n||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=82.&&x<=85.)
     {
       vec3 z=vec3(0),y=vec3(0);
       if(x==82.)
         z=vec3(0,0,0),y=vec3(16,16,3);
       if(x==83.)
         z=vec3(0,0,13),y=vec3(16,16,16);
       if(x==85.)
         z=vec3(0,0,0),y=vec3(3,16,16);
       if(x==84.)
         z=vec3(13,0,0),y=vec3(16,16,16);
       r=d(v+z/16.,v+y/16.,i,s,f);
       n=n||r;
     }
   if(x>=86.&&x<=101.)
     {
       vec3 z=vec3(0.),y=vec3(1.);
       if(x>=86.&&x<=93.)
         {
           float g=0.;
           if(x>=90.&&x<=93.)
             g=13.;
           z=vec3(0.,g,0.)/16.;
           y=vec3(16.,g+3.,16.)/16.;
         }
       if(x>=94.&&x<=97.)
         {
           float g=13.;
           if(x==96.||x==97.)
             g=0.;
           z=vec3(0.,0.,g)/16.;
           y=vec3(16.,16.,g+3.)/16.;
         }
       if(x>=98.&&x<=101.)
         {
           float g=13.;
           if(x==98.||x==99.)
             g=0.;
           z=vec3(g,0.,0.)/16.;
           y=vec3(g+3.,16.,16.)/16.;
         }
       r=d(v+z,v+y,i,s,f);
       n=n||r;
     }
   if(x>=102.&&x<=112.)
     {
       vec3 z=vec3(0.),y=vec3(1.);
       if(x>=102.&&x<=109.)
         {
           float g=float(x)-float(102.)+1.;
           y.y=g*2./16.;
         }
       if(x==110.)
         y.y=.0625;
       if(x==111.)
         z=vec3(1.,0.,1.)/16.,y=vec3(15.,1.,15.)/16.;
       if(x==112.)
         z=vec3(1.,0.,1.)/16.,y=vec3(15.,.5,15.)/16.;
       r=d(v+z,v+y,i,s,f);
       n=n||r;
     }
   #endif
   #endif
   return n;
 }
 vec4 G(vec3 x,vec2 v,out float i,inout float z)
 {
   vec3 s=x;
   int f=t();
   x=clamp(x,vec3(1./f),vec3(1.-1./f));
   if(distance(x,s)>.005/f)
     z=1.;
   float n=dot(abs(x-s),vec3(1.));
   #ifdef MC_GL_VENDOR_ATI
   x-=1./float(f)*vec3(0.,0.,1.);
   #endif
   vec2 m=d(x,f);
   m+=v.xy*(1./vec2(4096));
   m=m*2.-1.;
   i=n;
   return vec4(m,i,1.);
 }
 void main()
 {
   gl_Position=ftransform();
   lmcoord=gl_TextureMatrix[1]*gl_MultiTexCoord1;
   texcoord=gl_MultiTexCoord0;
   mcEntity=mc_Entity.x;
   viewPos=gl_ModelViewMatrix*gl_Vertex;
   vec4 v=gl_Position;
   v=shadowProjectionInverse*v;
   v=shadowModelViewInverse*v;
   v.xyz+=cameraPosition.xyz;
   vec3 x=v.xyz;
   materialIDs=30.;
   isWater=0.;
   float z=0.f;
   isStainedGlass=0.f;
   if(mc_Entity.x==8||mc_Entity.x==9)
     isWater=1.f;
   if(mc_Entity.x==95||mc_Entity.x==160||mc_Entity.x==90||mc_Entity.x==165||mc_Entity.x==79)
     isStainedGlass=1.f;
   if(mc_Entity.x==79)
     z=1.f;
   if(mc_Entity.x==18.||mc_Entity.x==161.f)
     materialIDs=32.;
   if(mc_Entity.x==79.f||mc_Entity.x==174.f)
     materialIDs=33.;
   if(mc_Entity.x==50)
     materialIDs=241.;
   if(mc_Entity.x==76)
     materialIDs=241.;
   if(mc_Entity.x==10||mc_Entity.x==11)
     materialIDs=241.;
   if(mc_Entity.x==89||mc_Entity.x==124||mc_Entity.x==10||mc_Entity.x==11||mc_Entity.x==169||mc_Entity.x==91)
     materialIDs=31.;
   if(mc_Entity.x==51)
     materialIDs=241.;
   #ifdef GLOWING_LAPIS_LAZULI_BLOCK
   if(mc_Entity.x==22)
     materialIDs=31.;
   #endif
   #ifdef GLOWING_REDSTONE_BLOCK
   if(mc_Entity.x==152)
     materialIDs=31.;
   #endif
   if(mc_Entity.x==95||mc_Entity.x==160)
     materialIDs=240.;
   vec3 i=gl_Normal,s=normalize(gl_NormalMatrix*i);
   if(abs(materialIDs-2.)<.1)
     i=vec3(0.,1.,0.);
   normal=i;
   sLAoKhsvSP=mc_midTexCoord.xy;
   color=gl_Color;
   if(materialIDs!=2.)
     {
       if(i.x>.85)
         color.xyz*=1./.6;
       if(i.x<-.85)
         color.xyz*=1./.6;
       if(i.z>.85)
         color.xyz*=1.25;
       if(i.z<-.85)
         color.xyz*=1.25;
       if(i.y<-.85)
         color.xyz*=2.;
     }
   StSXoVoNgz=0.;
   if(instanceId==1)
     {
       aYFTnWlIrg=1.;
       vec2 f;
       vec3 y=d(v.xyz,gl_Normal.xyz,texcoord.xy,mc_midTexCoord.xy,at_tangent,mc_Entity,StSXoVoNgz,f);
       if(mc_Entity.x>255)
         materialIDs=mc_Entity.x-255.+39.;
       y=floor(y);
       y-=cameraPosition.xyz;
       int r=t();
       y=n(y,r);
       float m;
       fnFFDTUhFS=G(y,f,m,StSXoVoNgz);
       if(mc_Entity.x==51)
         m+=.9;
       m=m;
       gl_Position=fnFFDTUhFS;
     }
   else
     {
       aYFTnWlIrg=0.;
       v.xyz-=cameraPosition.xyz;
       v=shadowModelView*v;
       v=shadowProjection*v;
       gl_Position=v;
       float y=sqrt(gl_Position.x*gl_Position.x+gl_Position.y*gl_Position.y),f=1.f-SHADOW_MAP_BIAS+y*SHADOW_MAP_BIAS;
       gl_Position.xy*=.95f/f;
       gl_Position.xy*=.5;
       gl_Position.xy+=.5;
       if(isWater>.5)
         gl_Position.y-=1.;
       if(isStainedGlass>.5)
         gl_Position.x-=1.;
       gl_Position.z=mix(gl_Position.z,.5,.8);
       CDSvqneOsV=gl_Position;
       gl_FrontColor=gl_Color;
     }
 };



