#version 330 compatibility
#extension GL_ARB_shading_language_packing : enable
#extension GL_ARB_shader_bit_encoding : enable


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBuffersCommon.inc"


in vec4 texcoord;
in vec4 color;
in vec4 lmcoord;

in vec3 normal;
in vec4 viewPos;

in float materialIDs;
in float mcEntity;
in float isWater;
in float isStainedGlass;


in float StSXoVoNgz;
in float aYFTnWlIrg;
in float rEpeEscUGE;

in vec2 sLAoKhsvSP;


 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int s(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int f()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int s()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return s(f(floor(pow(float(x),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,y=f();
   ivec2 n=ivec2(v.x*m.x,v.y*m.y);
   float z=float(n.y/y),i=float(int(n.x+mod(m.x*z,y))/y);
   i+=floor(m.x*z/y);
   vec3 r=vec3(0.,0.,i);
   r.x=mod(n.x+mod(m.x*z,y),y);
   r.y=mod(n.y,y);
   r.xyz=floor(r.xyz);
   r/=y;
   r.xyz=r.xzy;
   return r;
 }
 vec2 x(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=f();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 r;
   r.x=mod(i.x+y*x,m.x);
   float s=i.x+y*x;
   r.y=i.y+floor(s/m.x)*x;
   r+=.5;
   r/=m;
   return r;
 }
 vec3 d(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,f=s();
   ivec2 n=ivec2(i.x*m.x,i.y*m.y);
   float y=float(n.y/f),r=float(int(n.x+mod(m.x*y,f))/f);
   r+=floor(m.x*y/f);
   vec3 z=vec3(0.,0.,r);
   z.x=mod(n.x+mod(m.x*y,f),f);
   z.y=mod(n.y,f);
   z.xyz=floor(z.xyz);
   z/=f;
   z.xyz=z.xzy;
   return z;
 }
 vec2 d(vec3 v,int f)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 i=v.xzy*f;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*f,m.x);
   float s=i.x+x*f;
   r.y=i.y+floor(s/m.x)*f;
   r+=.5;
   r/=m;
   r.xy*=.5;
   return r;
 }
 vec3 f(vec3 v,int f)
 {
   return v*=1./f,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int f)
 {
   return v*=1./f,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int f=s();
   v=v-vec3(.5);
   v*=f;
   return v;
 }
 vec3 r(vec3 v)
 {
   int x=f();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,x=floor(v-.0001),f=floor(i-.0001);
   return x-f;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 n,vec2 x,vec4 m,vec4 i,inout float y,out vec2 r)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!z||i.x==20.||i.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(i.x==50.||i.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(i.x==51)
     y=0.;
   if(i.x>255)
     y=0.;
   vec3 s,c;
   if(f.x>.5)
     s=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       s=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         s=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           s=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             s=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               s=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   r=clamp((n.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float t=.15,o=.15;
   if(i.x==10.||i.x==11.)
     {
       if(abs(f.y)<.01&&z||f.y>.99)
         t=.1,o=.1,y=0.;
       else
          y=1.;
     }
   if(i.x==51)
     t=.5,o=.1;
   if(i.x==76)
     t=.2,o=.2;
   if(i.x-255.+39.>=102.&&i.x-255.+39.<=112.)
     o=.025,t=.025;
   s=normalize(m.xyz);
   c=normalize(cross(s,f.xyz)*sign(m.w));
   vec3 e=v.xyz+mix(s*t,-s*t,vec3(r.x));
   e.xyz+=mix(c*t,-c*t,vec3(r.y));
   e.xyz-=f.xyz*o;
   return e;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA e(Ray v)
 {
   DDA f;
   f.mapPos=floor(v.origin);
   f.mapPosOrigin=f.mapPos;
   f.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.rayStep=sign(v.direction);
   f.sideDist=(sign(v.direction)*(f.mapPos-v.origin)+sign(v.direction)*.5+.5)*f.deltaDist;
   f.mask=vec3(0.);
   return f;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float x)
 {
   float y,r,z,s;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   s=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,y),z);
   x=min(min(x,r),s);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 m)
 {
   const float x=1e-05;
   vec3 y=(f+v)*.5,i=(f-v)*.5,n=m-y,r=vec3(0.);
   r+=vec3(sign(n.x),0.,0.)*step(abs(abs(n.x)-i.x),x);
   r+=vec3(0.,sign(n.y),0.)*step(abs(abs(n.y)-i.y),x);
   r+=vec3(0.,0.,sign(n.z))*step(abs(abs(n.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 x=m.inv_direction*(v-m.origin),y=m.inv_direction*(f-m.origin),n=min(y,x),r=max(y,x);
   vec2 s=max(n.xx,n.yz);
   float z=max(s.x,s.y);
   s=min(r.xx,r.yz);
   float c=min(s.x,s.y);
   i.x=z;
   i.y=c;
   return c>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 y)
 {
   vec3 i=m.inv_direction*(v-m.origin),s=m.inv_direction*(f-m.origin),n=min(s,i),r=max(s,i);
   vec2 z=max(n.xx,n.yz);
   float c=max(z.x,z.y);
   z=min(r.xx,r.yz);
   float t=min(z.x,z.y);
   bool a=t>max(c,0.)&&max(c,0.)<x;
   if(a)
     y=d(v,f,m.origin+m.direction*c),x=c;
   return a;
 }
 vec3 e(vec3 v,vec3 f,vec3 x,vec3 y,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   r*=saturate(dot(f,x));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float c=abs(n.x*256.-(v.y+cameraPosition.y)),t=GetCausticsComposite(v,f,c),o=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*t,1.-o);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 f,vec3 i,vec3 x,vec3 y,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(f),n=m(s+x*.99);
   float r=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*r),3).x;
   c*=saturate(dot(i,x));
   c=TintUnderwaterDepth(c);
   return c*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 x,vec3 y,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,x));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct SugChoyrig{float EPQCbdZJBL;float xVoNcOTeXw;float dEdWWLhdyo;float vDYzoMNpum;vec3 ounGyXgtzs;};
 vec4 i(SugChoyrig v)
 {
   vec4 f;
   v.ounGyXgtzs=max(vec3(0.),v.ounGyXgtzs);
   f.x=v.EPQCbdZJBL;
   v.ounGyXgtzs=pow(v.ounGyXgtzs,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.ounGyXgtzs.x,v.dEdWWLhdyo);
   f.z=PackTwo16BitTo32Bit(v.ounGyXgtzs.y,v.vDYzoMNpum);
   f.w=PackTwo16BitTo32Bit(v.ounGyXgtzs.z,v.xVoNcOTeXw);
   return f;
 }
 SugChoyrig h(vec4 v)
 {
   SugChoyrig f;
   vec2 i=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),n=UnpackTwo16BitFrom32Bit(v.w);
   f.EPQCbdZJBL=v.x;
   f.dEdWWLhdyo=i.y;
   f.vDYzoMNpum=m.y;
   f.xVoNcOTeXw=n.y;
   f.ounGyXgtzs=pow(vec3(i.x,m.x,n.x),vec3(8.));
   return f;
 }
 SugChoyrig D(vec2 v)
 {
   vec2 f=1./vec2(viewWidth,viewHeight),x=vec2(viewWidth,viewHeight);
   v=(floor(v*x)+.5)*f;
   return h(texture2DLod(colortex5,v,0));
 }
 float D(float v,float f)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+f,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void D(inout float f,inout float v,float x,float i,vec3 s,float y)
 {
   #if GI_FILTER_QUALITY==0
   f*=mix(2.6,2.4,i);
   #else
   f*=mix(3.4,3.4,i);
   #endif
   float n=dot(s,vec3(1.));
   v*=1.-pow(i,.4);
   v/=x*.1+2e-06;
   v*=4.;
   v*=.6;
   float r=x/(n+1e-07)*.2+4e-08;
   r=min(r,1.);
   r=mix(r,1.,pow(i,.25));
   if(y<.12)
     v=0.;
 }
 float D(vec3 v,vec3 f,float x)
 {
   float r=dot(abs(v-f),vec3(.3333));
   r*=x;
   r*=.18;
   return r;
 }
 void e(inout vec3 v,vec2 f,vec3 x)
 {}
 float e(float v,float f)
 {
   return v/(f*20.01+1.);
 }
 bool d(vec3 v,float f,Ray x,bool i,inout float y,inout vec3 z)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(i)
     return false;
   if(f>=66.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),x,y,z);
   r=m;
   #else
   if(f<40.)
     return m=d(v,v+vec3(1.,1.,1.),x,y,z),m;
   if(f==40.||f>=42.&&f<=53.)
     m=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),x,y,z),r=r||m;
   if(f==41.||f>=54.&&f<=65.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),x,y,z),r=r||m;
   if(f==42.||f==45.||f==46.||f==51.||f==52.||f==53.||f==54.||f==57.||f==58.||f==63.||f==64.||f==65.)
     {
       float s=.5;
       if(f==54.||f==57.||f==58.||f==63.||f==64.||f==65.)
         s=0.;
       m=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),x,y,z);
       r=r||m;
     }
   if(f==42.||f==44.||f==47.||f==50.||f==52.||f==53.||f==54.||f==56.||f==59.||f==62.||f==64.||f==65.)
     {
       float s=.5;
       if(f==54.||f==56.||f==59.||f==62.||f==64.||f==65.)
         s=0.;
       m=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),x,y,z);
       r=r||m;
     }
   if(f==43.||f==44.||f==48.||f==50.||f==51.||f==53.||f==55.||f==56.||f==60.||f==62.||f==63.||f==65.)
     {
       float s=.5;
       if(f==55.||f==56.||f==60.||f==62.||f==63.||f==65.)
         s=0.;
       m=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),x,y,z);
       r=r||m;
     }
   if(f==43.||f==45.||f==49.||f==50.||f==51.||f==52.||f==55.||f==57.||f==61.||f==62.||f==63.||f==64.)
     {
       float s=.5;
       if(f==55.||f==57.||f==61.||f==62.||f==63.||f==64.)
         s=0.;
       m=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),x,y,z);
       r=r||m;
     }
   if(f>=66.&&f<=81.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,x,y,z),r=r||m;
   if(f==67.||f==68.||f==69.||f==71.||f==72.||f==73.||f==75.||f==76.||f==77.||f==79.||f==80.||f==81.)
     {
       float s=8.,n=8.;
       if(f==67.||f==69.||f==71.||f==73.||f==75.||f==77.||f==79.||f==81.)
         s=0.;
       if(f==68.||f==69.||f==72.||f==73.||f==76.||f==77.||f==80.||f==81.)
         n=16.;
       m=d(v+vec3(s,6.,7.)/16.,v+vec3(n,9.,9.)/16.,x,y,z);
       r=r||m;
       m=d(v+vec3(s,12.,7.)/16.,v+vec3(n,15.,9.)/16.,x,y,z);
       r=r||m;
     }
   if(f>=70.&&f<=81.)
     {
       float s=8.,n=8.;
       if(f>=70.&&f<=73.||f>=78.&&f<=81.)
         n=16.;
       if(f>=74.&&f<=81.)
         s=0.;
       m=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,n)/16.,x,y,z);
       r=r||m;
       m=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,n)/16.,x,y,z);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(f>=82.&&f<=85.)
     {
       vec3 s=vec3(0),n=vec3(0);
       if(f==82.)
         s=vec3(0,0,0),n=vec3(16,16,3);
       if(f==83.)
         s=vec3(0,0,13),n=vec3(16,16,16);
       if(f==85.)
         s=vec3(0,0,0),n=vec3(3,16,16);
       if(f==84.)
         s=vec3(13,0,0),n=vec3(16,16,16);
       m=d(v+s/16.,v+n/16.,x,y,z);
       r=r||m;
     }
   if(f>=86.&&f<=101.)
     {
       vec3 s=vec3(0.),n=vec3(1.);
       if(f>=86.&&f<=93.)
         {
           float c=0.;
           if(f>=90.&&f<=93.)
             c=13.;
           s=vec3(0.,c,0.)/16.;
           n=vec3(16.,c+3.,16.)/16.;
         }
       if(f>=94.&&f<=97.)
         {
           float c=13.;
           if(f==96.||f==97.)
             c=0.;
           s=vec3(0.,0.,c)/16.;
           n=vec3(16.,16.,c+3.)/16.;
         }
       if(f>=98.&&f<=101.)
         {
           float c=13.;
           if(f==98.||f==99.)
             c=0.;
           s=vec3(c,0.,0.)/16.;
           n=vec3(c+3.,16.,16.)/16.;
         }
       m=d(v+s,v+n,x,y,z);
       r=r||m;
     }
   if(f>=102.&&f<=112.)
     {
       vec3 s=vec3(0.),n=vec3(1.);
       if(f>=102.&&f<=109.)
         {
           float c=float(f)-float(102.)+1.;
           n.y=c*2./16.;
         }
       if(f==110.)
         n.y=.0625;
       if(f==111.)
         s=vec3(1.,0.,1.)/16.,n=vec3(15.,1.,15.)/16.;
       if(f==112.)
         s=vec3(1.,0.,1.)/16.,n=vec3(15.,.5,15.)/16.;
       m=d(v+s,v+n,x,y,z);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 vec4 h(in sampler2D v,in vec2 f)
 {
   vec2 m=vec2(64.f,64.f);
   f*=m;
   f+=.5f;
   vec2 x=floor(f),r=fract(f);
   r.x=r.x*r.x*(3.f-2.f*r.x);
   r.y=r.y*r.y*(3.f-2.f*r.y);
   f=x+r;
   f-=.5f;
   f/=m;
   return texture2D(v,f);
 }
 float f(in float v,in float f,in float x)
 {
   if(v>f)
     return v;
   float s=2.f*x-f,y=2.f*f-3.f*x,r=v/f;
   return(s*r+y)*r*r+x;
 }
 float R(vec3 v)
 {
   float x=.5f;
   vec2 r=v.xz/20.f;
   r.xy-=v.y/20.f;
   r.x=-r.x;
   r.x+=FRAME_TIME/40.f*x;
   r.y-=FRAME_TIME/40.f*x;
   float m=1.f,i=m,s=0.f,y=h(noisetex,r*vec2(2.f,1.2f)+vec2(0.f,r.x*2.1f)).x;
   r/=2.1f;
   r.y-=FRAME_TIME/20.f*x;
   r.x-=FRAME_TIME/30.f*x;
   s+=y*.5;
   m=2.1f;
   i+=m;
   y=h(noisetex,r*vec2(2.f,1.4f)+vec2(0.f,-r.x*2.1f)).x;
   r/=1.5f;
   r.x+=FRAME_TIME/20.f*x;
   y*=m;
   s+=y;
   m=17.25f;
   i+=m;
   y=h(noisetex,r*vec2(1.f,.75f)+vec2(0.f,r.x*1.1f)).x;
   r/=1.5f;
   r.x-=FRAME_TIME/55.f*x;
   y*=m;
   s+=y;
   m=15.25f;
   i+=m;
   y=h(noisetex,r*vec2(1.f,.75f)+vec2(0.f,-r.x*1.7f)).x;
   r/=1.9f;
   r.x+=FRAME_TIME/155.f*x;
   y*=m;
   s+=y;
   m=29.25f;
   i+=m;
   y=abs(h(noisetex,r*vec2(1.f,.8f)+vec2(0.f,-r.x*1.7f)).x*2.f-1.f);
   r/=2.f;
   r.x+=FRAME_TIME/155.f*x;
   y=1.f-f(y,.2f,.1f);
   y*=m;
   s+=y;
   m=15.25f;
   i+=m;
   y=abs(h(noisetex,r*vec2(1.f,.8f)+vec2(0.f,r.x*1.7f)).x*2.f-1.f);
   y=1.f-f(y,.2f,.1f);
   y*=m;
   s+=y;
   s/=i;
   return s;
 }
 void main()
 {
   vec4 f=texture2D(texture,texcoord.xy,0);
   vec3 v=f.xyz*color.xyz;
   float x=1.;
   if(aYFTnWlIrg<.5)
     {
       x=min(f.w*7.,1.);
       vec3 r=(shadowModelViewInverse*vec4(viewPos.xyz,1.)).xyz;
       r+=cameraPosition.xyz;
       gl_FragData[0]=vec4(v.xyz,x);
       gl_FragData[1]=vec4(r.y/256.,1.-isWater,0.,x);
     }
   else
     {
       if(StSXoVoNgz>.0001)
         {
           discard;
         }
       vec3 s=normal.xyz;
       v*=v;
       if(abs(mcEntity-50.)<.1)
         v.xyz=GetColorTorchlight()*.1*GI_LIGHT_TORCH_INTENSITY;
       if(abs(mcEntity-76.)<.1)
         v.xyz=vec3(1.,.02,.01)*.05*GI_LIGHT_TORCH_INTENSITY;
       if(abs(mcEntity-51.)<.1)
         v.xyz=vec3(1.,.35,.05)*.5;
       float y=clamp((abs(color.x-color.y)+abs(color.x-color.z)+abs(color.y-color.z))*500.,0.,1.);
       gl_FragData[0]=vec4(v.xyz,(materialIDs+.1)/255.*x);
       gl_FragData[1]=vec4(sLAoKhsvSP.xy,y,dot(f.xyz,vec3(.33333)));
     }
 };



