#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"


const bool colortex6MipmapEnabled = false;



in vec4 texcoord;
in vec3 lightVector;

in float timeSunriseSunset;
in float timeNoon;
in float timeMidnight;
in float timeSkyDark;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSunglow;
in vec3 colorBouncedSunlight;
in vec3 colorScatteredSunlight;
in vec3 colorTorchlight;
in vec3 colorWaterMurk;
in vec3 colorWaterBlue;
in vec3 colorSkyTint;



in vec3 upVector;



#include "lib/GBufferData.inc"


 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=d();
   ivec2 s=ivec2(v.x*f.x,v.y*f.y);
   float z=float(s.y/y),i=float(int(s.x+mod(f.x*z,y))/y);
   i+=floor(f.x*z/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(s.x+mod(f.x*z,y),y);
   m.y=mod(s.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 s(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 i=v.xzy*x;
   i=floor(i+1e-05);
   float y=i.z;
   vec2 r;
   r.x=mod(i.x+y*x,f.x);
   float s=i.x+y*x;
   r.y=i.y+floor(s/f.x)*x;
   r+=.5;
   r/=f;
   return r;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 s=ivec2(i.x*m.x,i.y*m.y);
   float z=float(s.y/y),r=float(int(s.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 n=vec3(0.,0.,r);
   n.x=mod(s.x+mod(m.x*z,y),y);
   n.y=mod(s.y,y);
   n.xyz=floor(n.xyz);
   n/=y;
   n.xyz=n.xzy;
   return n;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 f=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,f.x);
   float s=i.x+x*y;
   r.y=i.y+floor(s/f.x)*y;
   r+=.5;
   r/=f;
   r.xy*=.5;
   return r;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 x(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 e(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 e()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,x=floor(v-.0001),y=floor(f-.0001);
   return x-y;
 }
 vec3 m(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/y;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 i,vec2 x,vec4 s,vec4 m,inout float y,out vec2 r)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(m.x==8||m.x==9||m.x==79||m.x<1.||!z||m.x==20.||m.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(m.x==50.||m.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(m.x==51)
     y=0.;
   if(m.x>255)
     y=0.;
   vec3 n,c;
   if(f.x>.5)
     n=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       n=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         n=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           n=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             n=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               n=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   r=clamp((i.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,t=.15;
   if(m.x==10.||m.x==11.)
     {
       if(abs(f.y)<.01&&z||f.y>.99)
         h=.1,t=.1,y=0.;
       else
          y=1.;
     }
   if(m.x==51)
     h=.5,t=.1;
   if(m.x==76)
     h=.2,t=.2;
   if(m.x-255.+39.>=102.&&m.x-255.+39.<=112.)
     t=.025,h=.025;
   n=normalize(s.xyz);
   c=normalize(cross(n,f.xyz)*sign(s.w));
   vec3 e=v.xyz+mix(n*h,-n*h,vec3(r.x));
   e.xyz+=mix(c*h,-c*h,vec3(r.y));
   e.xyz-=f.xyz*t;
   return e;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA p(Ray v)
 {
   DDA i;
   i.mapPos=floor(v.origin);
   i.mapPosOrigin=i.mapPos;
   i.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   i.rayStep=sign(v.direction);
   i.sideDist=(sign(v.direction)*(i.mapPos-v.origin)+sign(v.direction)*.5+.5)*i.deltaDist;
   i.mask=vec3(0.);
   return i;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float y)
 {
   float x,z,r,t;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),r);
   y=min(min(y,z),t);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 i=(f+v)*.5,m=(f-v)*.5,s=y-i,r=vec3(0.);
   r+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-m.x),x);
   r+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-m.y),x);
   r+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-m.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),s=min(x,y),n=max(x,y);
   vec2 r=max(s.xx,s.yz);
   float z=max(r.x,r.y);
   r=min(n.xx,n.yz);
   float t=min(r.x,r.y);
   i.x=z;
   i.y=t;
   return t>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 y)
 {
   vec3 i=m.inv_direction*(v-m.origin),s=m.inv_direction*(f-m.origin),n=min(s,i),r=max(s,i);
   vec2 c=max(n.xx,n.yz);
   float z=max(c.x,c.y);
   c=min(r.xx,r.yz);
   float t=min(c.x,c.y);
   bool o=t>max(z,0.)&&max(z,0.)<x;
   if(o)
     y=d(v,f,m.origin+m.direction*z),x=z;
   return o;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float t=abs(n.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,t),c=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-c);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 y,vec3 f,vec3 x,vec3 i,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(y),n=m(s+x*.99);
   float t=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*t),3).x;
   r*=saturate(dot(f,x));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct SugChoyrig{float EPQCbdZJBL;float xVoNcOTeXw;float dEdWWLhdyo;float vDYzoMNpum;vec3 ounGyXgtzs;};
 vec4 h(SugChoyrig v)
 {
   vec4 i;
   v.ounGyXgtzs=max(vec3(0.),v.ounGyXgtzs);
   i.x=v.EPQCbdZJBL;
   v.ounGyXgtzs=pow(v.ounGyXgtzs,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.ounGyXgtzs.x,v.dEdWWLhdyo);
   i.z=PackTwo16BitTo32Bit(v.ounGyXgtzs.y,v.vDYzoMNpum);
   i.w=PackTwo16BitTo32Bit(v.ounGyXgtzs.z,v.xVoNcOTeXw);
   return i;
 }
 SugChoyrig i(vec4 v)
 {
   SugChoyrig i;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),f=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   i.EPQCbdZJBL=v.x;
   i.dEdWWLhdyo=m.y;
   i.vDYzoMNpum=f.y;
   i.xVoNcOTeXw=s.y;
   i.ounGyXgtzs=pow(vec3(m.x,f.x,s.x),vec3(8.));
   return i;
 }
 SugChoyrig D(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float D(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void D(inout float v,inout float i,float x,float f,vec3 s,float y)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,f);
   #else
   v*=mix(3.4,3.4,f);
   #endif
   float r=dot(s,vec3(1.));
   i*=1.-pow(f,.4);
   i/=x*.1+2e-06;
   i*=4.;
   i*=.6;
   float m=x/(r+1e-07)*.2+4e-08;
   m=min(m,1.);
   m=mix(m,1.,pow(f,.25));
   if(y<.12)
     i=0.;
 }
 float D(vec3 v,vec3 y,float m)
 {
   float i=dot(abs(v-y),vec3(.3333));
   i*=m;
   i*=.18;
   return i;
 }
 void e(inout vec3 v,vec2 x,vec3 y)
 {}
 float e(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool d(vec3 v,float y,Ray f,bool x,inout float i,inout vec3 z)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(x)
     return false;
   if(y>=66.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),f,i,z);
   r=m;
   #else
   if(y<40.)
     return m=d(v,v+vec3(1.,1.,1.),f,i,z),m;
   if(y==40.||y>=42.&&y<=53.)
     m=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),f,i,z),r=r||m;
   if(y==41.||y>=54.&&y<=65.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,z),r=r||m;
   if(y==42.||y==45.||y==46.||y==51.||y==52.||y==53.||y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
     {
       float s=.5;
       if(y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
         s=0.;
       m=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),f,i,z);
       r=r||m;
     }
   if(y==42.||y==44.||y==47.||y==50.||y==52.||y==53.||y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
     {
       float s=.5;
       if(y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
         s=0.;
       m=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),f,i,z);
       r=r||m;
     }
   if(y==43.||y==44.||y==48.||y==50.||y==51.||y==53.||y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
     {
       float s=.5;
       if(y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
         s=0.;
       m=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),f,i,z);
       r=r||m;
     }
   if(y==43.||y==45.||y==49.||y==50.||y==51.||y==52.||y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
     {
       float s=.5;
       if(y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
         s=0.;
       m=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),f,i,z);
       r=r||m;
     }
   if(y>=66.&&y<=81.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,z),r=r||m;
   if(y==67.||y==68.||y==69.||y==71.||y==72.||y==73.||y==75.||y==76.||y==77.||y==79.||y==80.||y==81.)
     {
       float s=8.,c=8.;
       if(y==67.||y==69.||y==71.||y==73.||y==75.||y==77.||y==79.||y==81.)
         s=0.;
       if(y==68.||y==69.||y==72.||y==73.||y==76.||y==77.||y==80.||y==81.)
         c=16.;
       m=d(v+vec3(s,6.,7.)/16.,v+vec3(c,9.,9.)/16.,f,i,z);
       r=r||m;
       m=d(v+vec3(s,12.,7.)/16.,v+vec3(c,15.,9.)/16.,f,i,z);
       r=r||m;
     }
   if(y>=70.&&y<=81.)
     {
       float s=8.,t=8.;
       if(y>=70.&&y<=73.||y>=78.&&y<=81.)
         t=16.;
       if(y>=74.&&y<=81.)
         s=0.;
       m=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,t)/16.,f,i,z);
       r=r||m;
       m=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,t)/16.,f,i,z);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=82.&&y<=85.)
     {
       vec3 s=vec3(0),c=vec3(0);
       if(y==82.)
         s=vec3(0,0,0),c=vec3(16,16,3);
       if(y==83.)
         s=vec3(0,0,13),c=vec3(16,16,16);
       if(y==85.)
         s=vec3(0,0,0),c=vec3(3,16,16);
       if(y==84.)
         s=vec3(13,0,0),c=vec3(16,16,16);
       m=d(v+s/16.,v+c/16.,f,i,z);
       r=r||m;
     }
   if(y>=86.&&y<=101.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(y>=86.&&y<=93.)
         {
           float t=0.;
           if(y>=90.&&y<=93.)
             t=13.;
           s=vec3(0.,t,0.)/16.;
           c=vec3(16.,t+3.,16.)/16.;
         }
       if(y>=94.&&y<=97.)
         {
           float t=13.;
           if(y==96.||y==97.)
             t=0.;
           s=vec3(0.,0.,t)/16.;
           c=vec3(16.,16.,t+3.)/16.;
         }
       if(y>=98.&&y<=101.)
         {
           float t=13.;
           if(y==98.||y==99.)
             t=0.;
           s=vec3(t,0.,0.)/16.;
           c=vec3(t+3.,16.,16.)/16.;
         }
       m=d(v+s,v+c,f,i,z);
       r=r||m;
     }
   if(y>=102.&&y<=112.)
     {
       vec3 s=vec3(0.),n=vec3(1.);
       if(y>=102.&&y<=109.)
         {
           float t=float(y)-float(102.)+1.;
           n.y=t*2./16.;
         }
       if(y==110.)
         n.y=.0625;
       if(y==111.)
         s=vec3(1.,0.,1.)/16.,n=vec3(15.,1.,15.)/16.;
       if(y==112.)
         s=vec3(1.,0.,1.)/16.,n=vec3(15.,.5,15.)/16.;
       m=d(v+s,v+n,f,i,z);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 float h(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 float i(vec3 v,vec3 y)
 {
   return dot(abs(v-y),vec3(.3333));
 }
 vec3 c(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   y=(floor(y*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,y).xyz,s=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+vec3(s)*mod(frameCounter,64.f),vec3(1.));
   return i;
 }
 vec3 D(float v,float m,float f,vec3 y)
 {
   vec3 i;
   i.x=f*cos(v);
   i.y=f*sin(v);
   i.z=m;
   vec3 s=abs(y.y)<.999?vec3(0,0,1):vec3(1,0,0),x=normalize(cross(y,vec3(0.,1.,1.))),r=cross(x,y);
   return x*i.x+r*i.y+y*i.z;
 }
 vec3 c(vec2 v,float y,vec3 i)
 {
   float s=2*3.14159*v.x,x=sqrt((1-v.y)/(1+(y*y-1)*v.y)),f=sqrt(1-x*x);
   return D(s,x,f,i);
 }
 float G(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 G(in vec2 v,in float y,in vec3 i)
 {
   float s=G(y),f=2*3.14159*v.x,x=pow(v.y,1.f/(s+1.f)),z=sqrt(1-x*x);
   return D(f,x,z,i);
 }
 float R(vec2 v)
 {
   return texture2DLod(colortex3,v,0).w;
 }
 vec4 D(sampler2D v,float f,bool y,float s,float x,float z,float t)
 {
   GBufferData m=GetGBufferData();
   GBufferDataTransparent r=GetGBufferDataTransparent();
   bool n=r.depth<m.depth;
   if(n)
     m.normal=r.normal,m.smoothness=r.smoothness,m.metalness=0.,m.mcLightmap=r.mcLightmap,m.depth=r.depth;
   vec4 d=GetViewPosition(texcoord.xy,m.depth),h=gbufferModelViewInverse*vec4(d.xyz,1.),a=gbufferModelViewInverse*vec4(d.xyz,0.);
   vec3 o=normalize(d.xyz),p=normalize(a.xyz),Y=normalize((gbufferModelViewInverse*vec4(m.normal,0.)).xyz);
   float w=GetDepthLinear(texcoord.xy),G=1.-m.smoothness,l=G*G,b=D(m.smoothness,m.metalness);
   int k=0;
   vec4 L=texture2DLod(colortex6,texcoord.xy,k);
   float S=Luminance(L.xyz);
   if(b<.001)
     return L;
   float g=f*.9;
   g*=min(l*15.,1.1);
   g*=mix(L.w,1.,t);
   vec2 E=vec2(0.);
   if(y)
     {
       vec2 T=c(texcoord.xy).xy*.99+.005;
       E=T-.5;
     }
   float T=0.,u=1.1,P=e(s,m.totalTexGrad)/(l+.0001),B=e(x,m.totalTexGrad);
   vec4 U=vec4(0.),W=vec4(0.);
   float F=0.;
   vec4 A=vec4(vec3(z),1.);
   A.xyz=vec3(.5);
   A.xyz*=L.w*.95+.05;
   float C=m.smoothness;
   int H=0;
   for(int X=-1;X<=1;X++)
     {
       for(int M=-1;M<=1;M++)
         {
           vec2 I=(vec2(X,M)+E)/vec2(viewWidth,viewHeight)*g,O=texcoord.xy+I.xy;
           float V=length(I*vec2(viewWidth,viewHeight));
           O=clamp(O,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
           vec4 N=texture2DLod(colortex6,O,k);
           vec3 Q=GetNormals(O);
           float q=GetDepthLinear(O),Z=pow(saturate(dot(m.normal,Q)),P),J=exp(-(abs(q-w)*u)),j=exp(-(i(N.xyz,L.xyz)*T)),K=exp(-abs(C-R(O))*B),ab=Z*J*j*K;
           U+=vec4(pow(length(N.xyz),A.x)*normalize(N.xyz+1e-05),N.w)*ab;
           F+=ab;
           W+=N;
           H++;
         }
     }
   U/=F+.0001;
   U.xyz=pow(length(U.xyz),1./A.x)*normalize(U.xyz+1e-06);
   vec4 N=U;
   if(F<.001)
     N=L;
   return N;
 }
 void main()
 {
   vec4 y=D(colortex6,30.,false,180.,40.,.1,0.);
   gl_FragData[0]=vec4(y);
 };




/* DRAWBUFFERS:6 */
