#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"


const bool colortex6MipmapEnabled = false;


in vec4 texcoord;

in vec3 lightVector;
in vec3 worldLightVector;
in vec3 worldSunVector;

in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSkyUp;
in vec3 colorTorchlight;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;

#include "lib/GBufferData.inc"


// vec4 GetViewPosition(in vec2 coord, in float depth) 
// {	
// 	vec4 tcoord = vec4(coord.xy, 0.0, 0.0);

// 	vec4 fragposition = gbufferProjectionInverse * vec4(tcoord.s * 2.0f - 1.0f, tcoord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
// 		 fragposition /= fragposition.w;

	
// 	return fragposition;
// }





#include "lib/Materials.inc"


 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int y=v.x*v.y;
   return t(f(floor(pow(float(y),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int y=v.x*v.y;
   return d(f(floor(pow(float(y),.333333))));
 }
 vec3 e(vec2 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=m.x*m.y,y=d();
   ivec2 f=ivec2(v.x*m.x,v.y*m.y);
   float z=float(f.y/y),i=float(int(f.x+mod(m.x*z,y))/y);
   i+=floor(m.x*z/y);
   vec3 s=vec3(0.,0.,i);
   s.x=mod(f.x+mod(m.x*z,y),y);
   s.y=mod(f.y,y);
   s.xyz=floor(s.xyz);
   s/=y;
   s.xyz=s.xzy;
   return s;
 }
 vec2 x(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 f=v.xzy*x;
   f=floor(f+1e-05);
   float y=f.z;
   vec2 i;
   i.x=mod(f.x+y*x,m.x);
   float s=f.x+y*x;
   i.y=f.y+floor(s/m.x)*x;
   i+=.5;
   i/=m;
   return i;
 }
 vec3 s(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 s=ivec2(i.x*m.x,i.y*m.y);
   float z=float(s.y/y),r=float(int(s.x+mod(m.x*z,y))/y);
   r+=floor(m.x*z/y);
   vec3 n=vec3(0.,0.,r);
   n.x=mod(s.x+mod(m.x*z,y),y);
   n.y=mod(s.y,y);
   n.xyz=floor(n.xyz);
   n/=y;
   n.xyz=n.xzy;
   return n;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 f=v.xzy*y;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 i;
   i.x=mod(f.x+x*y,m.x);
   float s=f.x+x*y;
   i.y=f.y+floor(s/m.x)*y;
   i+=.5;
   i/=m;
   i.xy*=.5;
   return i;
 }
 vec3 e(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 n(vec3 v)
 {
   int y=d();
   v*=1./y;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 r(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 e()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,y=floor(v-.0001),x=floor(f-.0001);
   return y-x;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 s,vec2 z,vec4 m,vec4 i,inout float y,out vec2 x)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!r||i.x==20.||i.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(i.x==50.||i.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(i.x==51)
     y=0.;
   if(i.x>255)
     y=0.;
   vec3 e,c;
   if(f.x>.5)
     e=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       e=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         e=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           e=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             e=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               e=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   x=clamp((s.xy-z.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,t=.15;
   if(i.x==10.||i.x==11.)
     {
       if(abs(f.y)<.01&&r||f.y>.99)
         h=.1,t=.1,y=0.;
       else
          y=1.;
     }
   if(i.x==51)
     h=.5,t=.1;
   if(i.x==76)
     h=.2,t=.2;
   if(i.x-255.+39.>=102.&&i.x-255.+39.<=112.)
     t=.025,h=.025;
   e=normalize(m.xyz);
   c=normalize(cross(e,f.xyz)*sign(m.w));
   vec3 n=v.xyz+mix(e*h,-e*h,vec3(x.x));
   n.xyz+=mix(c*h,-c*h,vec3(x.y));
   n.xyz-=f.xyz*t;
   return n;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA p(Ray v)
 {
   DDA f;
   f.mapPos=floor(v.origin);
   f.mapPosOrigin=f.mapPos;
   f.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.rayStep=sign(v.direction);
   f.sideDist=(sign(v.direction)*(f.mapPos-v.origin)+sign(v.direction)*.5+.5)*f.deltaDist;
   f.mask=vec3(0.);
   return f;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float y)
 {
   float x,z,r,s;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   s=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),r);
   y=min(min(y,z),s);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,s=y-z,r=vec3(0.);
   r+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-i.x),x);
   r+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-i.y),x);
   r+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),s=m.inv_direction*(f-m.origin),x=min(s,y),c=max(s,y);
   vec2 r=max(x.xx,x.yz);
   float z=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float n=min(r.x,r.y);
   i.x=z;
   i.y=n;
   return n>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float y,inout vec3 x)
 {
   vec3 z=m.inv_direction*(v-m.origin),s=m.inv_direction*(f-m.origin),i=min(s,z),c=max(s,z);
   vec2 r=max(i.xx,i.yz);
   float t=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float n=min(r.x,r.y);
   bool e=n>max(t,0.)&&max(t,0.)<y;
   if(e)
     x=d(v,f,m.origin+m.direction*t),y=t;
   return e;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 z,int x)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float t=abs(n.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,t),c=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-c);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 y,vec3 f,vec3 x,vec3 z,int t)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(y),i=m(s+x*.99);
   float n=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*n),3).x;
   r*=saturate(dot(f,x));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 z,int x)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct SugChoyrig{float EPQCbdZJBL;float xVoNcOTeXw;float dEdWWLhdyo;float vDYzoMNpum;vec3 ounGyXgtzs;};
 vec4 h(SugChoyrig v)
 {
   vec4 i;
   v.ounGyXgtzs=max(vec3(0.),v.ounGyXgtzs);
   i.x=v.EPQCbdZJBL;
   v.ounGyXgtzs=pow(v.ounGyXgtzs,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.ounGyXgtzs.x,v.dEdWWLhdyo);
   i.z=PackTwo16BitTo32Bit(v.ounGyXgtzs.y,v.vDYzoMNpum);
   i.w=PackTwo16BitTo32Bit(v.ounGyXgtzs.z,v.xVoNcOTeXw);
   return i;
 }
 SugChoyrig i(vec4 v)
 {
   SugChoyrig i;
   vec2 f=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   i.EPQCbdZJBL=v.x;
   i.dEdWWLhdyo=f.y;
   i.vDYzoMNpum=m.y;
   i.xVoNcOTeXw=s.y;
   i.ounGyXgtzs=pow(vec3(f.x,m.x,s.x),vec3(8.));
   return i;
 }
 SugChoyrig D(vec2 v)
 {
   vec2 y=1./vec2(viewWidth,viewHeight),x=vec2(viewWidth,viewHeight);
   v=(floor(v*x)+.5)*y;
   return i(texture2DLod(colortex5,v,0));
 }
 float D(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void D(inout float v,inout float i,float f,float y,vec3 s,float x)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,y);
   #else
   v*=mix(3.4,3.4,y);
   #endif
   float r=dot(s,vec3(1.));
   i*=1.-pow(y,.4);
   i/=f*.1+2e-06;
   i*=4.;
   i*=.6;
   float z=f/(r+1e-07)*.2+4e-08;
   z=min(z,1.);
   z=mix(z,1.,pow(y,.25));
   if(x<.12)
     i=0.;
 }
 float D(vec3 v,vec3 y,float m)
 {
   float i=dot(abs(v-y),vec3(.3333));
   i*=m;
   i*=.18;
   return i;
 }
 void e(inout vec3 v,vec2 y,vec3 x)
 {}
 float h(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool d(vec3 v,float y,Ray f,bool z,inout float i,inout vec3 x)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(z)
     return false;
   if(y>=66.)
     return false;
   m=d(v,v+vec3(1.,1.,1.),f,i,x);
   r=m;
   #else
   if(y<40.)
     return m=d(v,v+vec3(1.,1.,1.),f,i,x),m;
   if(y==40.||y>=42.&&y<=53.)
     m=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),f,i,x),r=r||m;
   if(y==41.||y>=54.&&y<=65.)
     m=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,x),r=r||m;
   if(y==42.||y==45.||y==46.||y==51.||y==52.||y==53.||y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
     {
       float s=.5;
       if(y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
         s=0.;
       m=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),f,i,x);
       r=r||m;
     }
   if(y==42.||y==44.||y==47.||y==50.||y==52.||y==53.||y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
     {
       float s=.5;
       if(y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
         s=0.;
       m=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),f,i,x);
       r=r||m;
     }
   if(y==43.||y==44.||y==48.||y==50.||y==51.||y==53.||y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
     {
       float s=.5;
       if(y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
         s=0.;
       m=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),f,i,x);
       r=r||m;
     }
   if(y==43.||y==45.||y==49.||y==50.||y==51.||y==52.||y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
     {
       float s=.5;
       if(y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
         s=0.;
       m=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),f,i,x);
       r=r||m;
     }
   if(y>=66.&&y<=81.)
     m=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,x),r=r||m;
   if(y==67.||y==68.||y==69.||y==71.||y==72.||y==73.||y==75.||y==76.||y==77.||y==79.||y==80.||y==81.)
     {
       float s=8.,c=8.;
       if(y==67.||y==69.||y==71.||y==73.||y==75.||y==77.||y==79.||y==81.)
         s=0.;
       if(y==68.||y==69.||y==72.||y==73.||y==76.||y==77.||y==80.||y==81.)
         c=16.;
       m=d(v+vec3(s,6.,7.)/16.,v+vec3(c,9.,9.)/16.,f,i,x);
       r=r||m;
       m=d(v+vec3(s,12.,7.)/16.,v+vec3(c,15.,9.)/16.,f,i,x);
       r=r||m;
     }
   if(y>=70.&&y<=81.)
     {
       float s=8.,t=8.;
       if(y>=70.&&y<=73.||y>=78.&&y<=81.)
         t=16.;
       if(y>=74.&&y<=81.)
         s=0.;
       m=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,t)/16.,f,i,x);
       r=r||m;
       m=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,t)/16.,f,i,x);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=82.&&y<=85.)
     {
       vec3 s=vec3(0),c=vec3(0);
       if(y==82.)
         s=vec3(0,0,0),c=vec3(16,16,3);
       if(y==83.)
         s=vec3(0,0,13),c=vec3(16,16,16);
       if(y==85.)
         s=vec3(0,0,0),c=vec3(3,16,16);
       if(y==84.)
         s=vec3(13,0,0),c=vec3(16,16,16);
       m=d(v+s/16.,v+c/16.,f,i,x);
       r=r||m;
     }
   if(y>=86.&&y<=101.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(y>=86.&&y<=93.)
         {
           float t=0.;
           if(y>=90.&&y<=93.)
             t=13.;
           s=vec3(0.,t,0.)/16.;
           c=vec3(16.,t+3.,16.)/16.;
         }
       if(y>=94.&&y<=97.)
         {
           float t=13.;
           if(y==96.||y==97.)
             t=0.;
           s=vec3(0.,0.,t)/16.;
           c=vec3(16.,16.,t+3.)/16.;
         }
       if(y>=98.&&y<=101.)
         {
           float t=13.;
           if(y==98.||y==99.)
             t=0.;
           s=vec3(t,0.,0.)/16.;
           c=vec3(t+3.,16.,16.)/16.;
         }
       m=d(v+s,v+c,f,i,x);
       r=r||m;
     }
   if(y>=102.&&y<=112.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(y>=102.&&y<=109.)
         {
           float n=float(y)-float(102.)+1.;
           c.y=n*2./16.;
         }
       if(y==110.)
         c.y=.0625;
       if(y==111.)
         s=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(y==112.)
         s=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       m=d(v+s,v+c,f,i,x);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 float i(float v,float y)
 {
   return 1./(v*(1.-y)+y);
 }
 void D(inout vec3 v,in vec3 y,in vec3 f,vec3 s,float x)
 {
   float i=length(y);
   i*=pow(eyeBrightnessSmooth.y/240.f,6.f);
   i*=rainStrength;
   float r=pow(exp(-i*3e-06),4.);
   vec3 z=vec3(dot(colorSkyUp,vec3(1.)));
   v=mix(z,v,vec3(r));
 }
 vec4 G(vec2 v)
 {
   vec2 y=vec2(v.x,(v.y-floor(mod(FRAME_TIME*60.f,60.f)))/60.f);
   return texture2DLod(colortex4,y.xy,0);
 }
 float G(vec3 v,float y)
 {
   vec3 i=v.xyz+cameraPosition.xyz,f=refract(worldLightVector,vec3(0.,1.,0.),.750188);
   i+=f*((v.y+cameraPosition.y)/f.y);
   vec4 s=G(mod(i.xz/4.,vec2(1.)))*13.;
   float x=pow(y/2.,.5),r=pow(s.x,saturate(x*.5+.5));
   r=mix(r,s.y,saturate(x-1.));
   r=mix(r,s.z,saturate(x-2.));
   r=mix(r,s.w,saturate(x-3.));
   return r;
 }
 float m(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 float n(vec3 v,vec3 y)
 {
   return dot(abs(v-y),vec3(.3333));
 }
 vec3 c(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   y=(floor(y*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,y).xyz,s=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+vec3(s)*mod(frameCounter,64.f),vec3(1.));
   return i;
 }
 vec3 D(float v,float f,float y,vec3 i)
 {
   vec3 m;
   m.x=y*cos(v);
   m.y=y*sin(v);
   m.z=f;
   vec3 s=abs(i.y)<.999?vec3(0,0,1):vec3(1,0,0),x=normalize(cross(i,vec3(0.,1.,1.))),c=cross(x,i);
   return x*m.x+c*m.y+i*m.z;
 }
 vec3 G(vec2 v,float y,vec3 x)
 {
   float s=2*3.14159*v.x,z=sqrt((1-v.y)/(1+(y*y-1)*v.y)),f=sqrt(1-z*z);
   return D(s,z,f,x);
 }
 float a(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 a(in vec2 v,in float y,in vec3 x)
 {
   float s=a(y),f=2*3.14159*v.x,z=pow(v.y,1.f/(s+1.f)),i=sqrt(1-z*z);
   return D(f,z,i,x);
 }
 float R(vec2 v)
 {
   return texture2DLod(colortex3,v,0).w;
 }
 vec4 D(sampler2D v,float f,bool y,float s,float i,float x,float z)
 {
   GBufferData m=GetGBufferData();
   GBufferDataTransparent r=GetGBufferDataTransparent();
   bool t=r.depth<m.depth;
   if(t)
     m.normal=r.normal,m.smoothness=r.smoothness,m.metalness=0.,m.mcLightmap=r.mcLightmap,m.depth=r.depth;
   vec4 d=GetViewPosition(texcoord.xy,m.depth),e=gbufferModelViewInverse*vec4(d.xyz,1.),a=gbufferModelViewInverse*vec4(d.xyz,0.);
   vec3 p=normalize(d.xyz),o=normalize(a.xyz),w=normalize((gbufferModelViewInverse*vec4(m.normal,0.)).xyz);
   float G=GetDepthLinear(texcoord.xy),l=1.-m.smoothness,k=l*l,g=D(m.smoothness,m.metalness);
   int Y=0;
   vec4 L=texture2DLod(colortex6,texcoord.xy,Y);
   float S=Luminance(L.xyz);
   if(g<.001)
     return L;
   float b=f*.9;
   b*=min(k*15.,1.1);
   b*=mix(L.w,1.,z);
   vec2 M=vec2(0.);
   if(y)
     {
       vec2 T=c(texcoord.xy).xy*.99+.005;
       M=T-.5;
     }
   float T=0.,u=1.1,P=h(s,m.totalTexGrad)/(k+.0001),W=h(i,m.totalTexGrad);
   vec4 U=vec4(0.),B=vec4(0.);
   float F=0.;
   vec4 E=vec4(vec3(x),1.);
   E.xyz=vec3(.5);
   E.xyz*=L.w*.95+.05;
   float I=m.smoothness;
   int A=0;
   for(int C=-1;C<=1;C++)
     {
       for(int V=-1;V<=1;V++)
         {
           vec2 H=(vec2(C,V)+M)/vec2(viewWidth,viewHeight)*b,X=texcoord.xy+H.xy;
           float O=length(H*vec2(viewWidth,viewHeight));
           X=clamp(X,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
           vec4 N=texture2DLod(colortex6,X,Y);
           vec3 Q=GetNormals(X);
           float q=GetDepthLinear(X),Z=pow(saturate(dot(m.normal,Q)),P),J=exp(-(abs(q-G)*u)),j=exp(-(n(N.xyz,L.xyz)*T)),K=exp(-abs(I-R(X))*W),ab=Z*J*j*K;
           U+=vec4(pow(length(N.xyz),E.x)*normalize(N.xyz+1e-05),N.w)*ab;
           F+=ab;
           B+=N;
           A++;
         }
     }
   U/=F+.0001;
   U.xyz=pow(length(U.xyz),1./E.x)*normalize(U.xyz+1e-06);
   vec4 N=U;
   if(F<.001)
     N=L;
   return N;
 }
 void main()
 {
   GBufferData v=GetGBufferData();
   GBufferDataTransparent y=GetGBufferDataTransparent();
   MaterialMask s=CalculateMasks(v.materialID),f=CalculateMasks(y.materialID);
   bool x=y.depth<v.depth;
   if(x)
     v.normal=y.normal,v.smoothness=y.smoothness,v.metalness=0.,v.mcLightmap=y.mcLightmap,v.depth=y.depth,f.sky=0.;
   vec4 m=GetViewPosition(texcoord.xy,v.depth),r=gbufferModelViewInverse*vec4(m.xyz,1.),c=gbufferModelViewInverse*vec4(m.xyz,0.);
   vec3 t=normalize(m.xyz),z=normalize(c.xyz),h=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz);
   float n=ExpToLinearDepth(v.depth),e=1.-v.smoothness,o=e*e,w=D(v.smoothness,v.metalness);
   int d=0;
   vec4 p=texture2DLod(colortex6,texcoord.xy,d),b=p;
   float G=1.-v.smoothness,a=G*G;
   vec3 l=h,X=-z,Y=normalize(reflect(-X,l)+l*a),P=normalize(X+Y);
   float N=saturate(dot(l,Y)),k=saturate(dot(l,X)),R=saturate(dot(l,P)),L=saturate(dot(Y,P)),T=v.metalness*.98+.02,u=pow(1.-L,5.),J=T+(1.-T)*u,W=a/2.,K=i(N,W)*i(k+.8,W),U=N*J*K;
   b.xyz*=mix(vec3(1.),v.albedo.xyz,vec3(v.metalness));
   U=mix(U,1.,v.metalness);
   if(v.depth>.99999)
     U=0.;
   if(f.water>.5&&isEyeInWater>0)
     {
       if(length(refract(X,l,1.3333))<.5)
         U=1.;
       else
          U=0.;
     }
   U*=D(v.smoothness,v.metalness);
   vec4 E=texture2DLod(colortex3,texcoord.xy,0);
   vec3 F=pow(E.xyz,vec3(2.2)),g=F;
   g*=120.;
   UnderwaterFog(g,length(c.xyz),z,colorSkyUp,colorSunlight);
   g=mix(g,b.xyz,vec3(U));
   g+=F*v.metalness*120.;
   if(f.sky<.5&&!x&&isEyeInWater<1)
     LandAtmosphericScattering(g,m.xyz,t.xyz,z.xyz,worldSunVector.xyz,1.);
   D(g,m.xyz,t.xyz,z.xyz,1.);
   {
     if(isEyeInWater>0)
       {
         float M=BlueNoiseTemporal(texcoord.xy).x,j=20.;
         vec3 C=vec3(0.),S=(gbufferModelViewInverse*vec4(0.,0.,0.,1.)).xyz;
         for(int V=0;V<10;V++)
           {
             float A=float(V+M)/float(10);
             vec3 I=z.xyz*j*A+S;
             if(length(c.xyz)<length(I-S))
               {
                 break;
               }
             float Q,B;
             vec3 H=WorldPosToShadowProjPos(I.xyz,Q,B);
             float Z=shadow2DLod(shadowtex0,vec3(H.xy,H.z+1e-06),3).x,O=abs(texture2DLod(shadowcolor1,H.xy-vec2(0.,.5),4).x*256.-(I.y+cameraPosition.y)),q=GetCausticsComposite(I,worldLightVector,O),ac=shadow2DLod(shadowtex0,vec3(H.xy-vec2(0.,.5),H.z+1e-06),4).x;
             Z=mix(Z,Z*q,1.-ac);
             C+=Z*exp(-GetWaterAbsorption()*(j*A))*exp(-GetWaterAbsorption()*O);
           }
         float Z=dot(refract(worldLightVector,vec3(0.,-1.,0.),.750019),z.xyz),O=Z*Z,B=PhaseMie(.8,Z,O);
         g+=TintUnderwaterDepth(C*colorSunlight*GetWaterFogColor()*.075*B);
       }
   }
   g/=120.;
   g*=exp(-n*blindness);
   g=pow(g.xyz,vec3(.454545));
   gl_FragData[0]=vec4(g,E.w);
 };





/* DRAWBUFFERS:3 */
