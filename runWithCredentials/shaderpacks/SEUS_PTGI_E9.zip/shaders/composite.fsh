#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/





in vec4 texcoord;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorTorchlight;
in vec3 colorSkyUp;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;

in vec3 worldLightVector;
in vec3 worldSunVector;

in float timeMidnight;

#include "lib/Uniforms.inc"
#include "lib/Common.inc"



/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////








vec2 GetNearFragment(vec2 coord, float depth, out float minDepth)
{
	
	
	vec2 texel = 1.0 / vec2(viewWidth, viewHeight);
	vec4 depthSamples;
	depthSamples.x = texture2D(depthtex1, coord + texel * vec2(1.0, 1.0)).x;
	depthSamples.y = texture2D(depthtex1, coord + texel * vec2(1.0, -1.0)).x;
	depthSamples.z = texture2D(depthtex1, coord + texel * vec2(-1.0, 1.0)).x;
	depthSamples.w = texture2D(depthtex1, coord + texel * vec2(-1.0, -1.0)).x;

	vec2 targetFragment = vec2(0.0, 0.0);

	if (depthSamples.x < depth)
		targetFragment = vec2(1.0, 1.0);
	if (depthSamples.y < depth)
		targetFragment = vec2(1.0, -1.0);
	if (depthSamples.z < depth)
		targetFragment = vec2(-1.0, 1.0);
	if (depthSamples.w < depth)
		targetFragment = vec2(-1.0, -1.0);


	minDepth = min(min(min(depthSamples.x, depthSamples.y), depthSamples.z), depthSamples.w);

	return coord + texel * targetFragment;
}






#include "lib/Materials.inc"
#include "lib/GBufferData.inc"




 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int e(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int e()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int y=v.x*v.y;
   return t(f(floor(pow(float(y),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int y=v.x*v.y;
   return e(f(floor(pow(float(y),.333333))));
 }
 vec3 v(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=e();
   ivec2 i=ivec2(v.x*f.x,v.y*f.y);
   float z=float(i.y/y),r=float(int(i.x+mod(f.x*z,y))/y);
   r+=floor(f.x*z/y);
   vec3 s=vec3(0.,0.,r);
   s.x=mod(i.x+mod(f.x*z,y),y);
   s.y=mod(i.y,y);
   s.xyz=floor(s.xyz);
   s/=y;
   s.xyz=s.xzy;
   return s;
 }
 vec2 s(vec3 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int y=e();
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,f.x);
   float s=i.x+x*y;
   r.y=i.y+floor(s/f.x)*y;
   r+=.5;
   r/=f;
   return r;
 }
 vec3 d(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 s=ivec2(2048,2048);
   int x=s.x*s.y,y=f();
   ivec2 d=ivec2(i.x*s.x,i.y*s.y);
   float z=float(d.y/y),r=float(int(d.x+mod(s.x*z,y))/y);
   r+=floor(s.x*z/y);
   vec3 m=vec3(0.,0.,r);
   m.x=mod(d.x+mod(s.x*z,y),y);
   m.y=mod(d.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 f=ivec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,f.x);
   float s=i.x+x*y;
   r.y=i.y+floor(s/f.x)*y;
   r+=.5;
   r/=f;
   r.xy*=.5;
   return r;
 }
 vec3 e(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 m(vec3 v)
 {
   int s=f();
   v=v-vec3(.5);
   v*=s;
   return v;
 }
 vec3 x(vec3 v)
 {
   int y=e();
   v*=1./y;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 n(vec3 v)
 {
   int f=e();
   v=v-vec3(.5);
   v*=f;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,f=floor(v-.0001),y=floor(i-.0001);
   return f-y;
 }
 vec3 p(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 i,vec2 y,vec4 s,vec4 d,inout float x,out vec2 r)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(d.x==8||d.x==9||d.x==79||d.x<1.||!z||d.x==20.||d.x==171.||min(abs(f.x),abs(f.z))>.2)
     x=1.;
   if(d.x==50.||d.x==76.)
     {
       x=0.;
       if(f.y<.5)
         x=1.;
     }
   if(d.x==51)
     x=0.;
   if(d.x>255)
     x=0.;
   vec3 c,t;
   if(f.x>.5)
     c=vec3(0.,0.,-1.),t=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       c=vec3(0.,0.,1.),t=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         c=vec3(1.,0.,0.),t=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           c=vec3(1.,0.,0.),t=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             c=vec3(1.,0.,0.),t=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               c=vec3(-1.,0.,0.),t=vec3(0.,-1.,0.);
   r=clamp((i.xy-y.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,w=.15;
   if(d.x==10.||d.x==11.)
     {
       if(abs(f.y)<.01&&z||f.y>.99)
         h=.1,w=.1,x=0.;
       else
          x=1.;
     }
   if(d.x==51)
     h=.5,w=.1;
   if(d.x==76)
     h=.2,w=.2;
   if(d.x-255.+39.>=102.&&d.x-255.+39.<=112.)
     w=.025,h=.025;
   c=normalize(s.xyz);
   t=normalize(cross(c,f.xyz)*sign(s.w));
   vec3 m=v.xyz+mix(c*h,-c*h,vec3(r.x));
   m.xyz+=mix(t*h,-t*h,vec3(r.y));
   m.xyz-=f.xyz*w;
   return m;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA r(Ray v)
 {
   DDA f;
   f.mapPos=floor(v.origin);
   f.mapPosOrigin=f.mapPos;
   f.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.rayStep=sign(v.direction);
   f.sideDist=(sign(v.direction)*(f.mapPos-v.origin)+sign(v.direction)*.5+.5)*f.deltaDist;
   f.mask=vec3(0.);
   return f;
 }
 void i(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float y)
 {
   float x,z,r,t;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),r);
   y=min(min(y,z),t);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,d=y-z,r=vec3(0.);
   r+=vec3(sign(d.x),0.,0.)*step(abs(abs(d.x)-i.x),x);
   r+=vec3(0.,sign(d.y),0.)*step(abs(abs(d.y)-i.y),x);
   r+=vec3(0.,0.,sign(d.z))*step(abs(abs(d.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray s,out vec2 i)
 {
   vec3 y=s.inv_direction*(v-s.origin),x=s.inv_direction*(f-s.origin),d=min(x,y),t=max(x,y);
   vec2 r=max(d.xx,d.yz);
   float z=max(r.x,r.y);
   r=min(t.xx,t.yz);
   float m=min(r.x,r.y);
   i.x=z;
   i.y=m;
   return m>max(z,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray s,inout float y,inout vec3 x)
 {
   vec3 z=s.inv_direction*(v-s.origin),i=s.inv_direction*(f-s.origin),t=min(i,z),c=max(i,z);
   vec2 r=max(t.xx,t.yz);
   float m=max(r.x,r.y);
   r=min(c.xx,c.yz);
   float n=min(r.x,r.y);
   bool w=n>max(m,0.)&&max(m,0.)<y;
   if(w)
     x=d(v,f,s.origin+s.direction*m),y=m;
   return w;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=p(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   r*=saturate(dot(f,y));
   {
     vec4 d=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float t=abs(d.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,t),w=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     r=mix(r,r*h,1.-w);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 f(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 i=m(v),d=p(i+y*.99);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(d.xy,d.z-.0006*s),3).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 i(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=p(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct SugChoyrig{float EPQCbdZJBL;float xVoNcOTeXw;float dEdWWLhdyo;float vDYzoMNpum;vec3 ounGyXgtzs;};
 vec4 h(SugChoyrig v)
 {
   vec4 f;
   v.ounGyXgtzs=max(vec3(0.),v.ounGyXgtzs);
   f.x=v.EPQCbdZJBL;
   v.ounGyXgtzs=pow(v.ounGyXgtzs,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.ounGyXgtzs.x,v.dEdWWLhdyo);
   f.z=PackTwo16BitTo32Bit(v.ounGyXgtzs.y,v.vDYzoMNpum);
   f.w=PackTwo16BitTo32Bit(v.ounGyXgtzs.z,v.xVoNcOTeXw);
   return f;
 }
 SugChoyrig w(vec4 v)
 {
   SugChoyrig f;
   vec2 i=UnpackTwo16BitFrom32Bit(v.y),s=UnpackTwo16BitFrom32Bit(v.z),d=UnpackTwo16BitFrom32Bit(v.w);
   f.EPQCbdZJBL=v.x;
   f.dEdWWLhdyo=i.y;
   f.vDYzoMNpum=s.y;
   f.xVoNcOTeXw=d.y;
   f.ounGyXgtzs=pow(vec3(i.x,s.x,d.x),vec3(8.));
   return f;
 }
 SugChoyrig G(vec2 v)
 {
   vec2 y=1./vec2(viewWidth,viewHeight),z=vec2(viewWidth,viewHeight);
   v=(floor(v*z)+.5)*y;
   return w(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float f=1.;
   #ifdef FULL_RT_REFLECTIONS
   f=clamp(pow(v,.125)+y,0.,1.);
   #else
   f=clamp(v*10.-7.,0.,1.);
   #endif
   return f;
 }
 void G(inout float v,inout float f,float y,float i,vec3 x,float z)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,i);
   #else
   v*=mix(3.4,3.4,i);
   #endif
   float s=dot(x,vec3(1.));
   f*=1.-pow(i,.4);
   f/=y*.1+2e-06;
   f*=4.;
   f*=.6;
   float r=y/(s+1e-07)*.2+4e-08;
   r=min(r,1.);
   r=mix(r,1.,pow(i,.25));
   if(z<.12)
     f=0.;
 }
 float G(vec3 v,vec3 y,float f)
 {
   float r=dot(abs(v-y),vec3(.3333));
   r*=f;
   r*=.18;
   return r;
 }
 void e(inout vec3 v,vec2 f,vec3 y)
 {}
 float h(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 bool d(vec3 v,float y,Ray f,bool z,inout float i,inout vec3 x)
 {
   bool r=false,s=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(z)
     return false;
   if(y>=66.)
     return false;
   s=d(v,v+vec3(1.,1.,1.),f,i,x);
   r=s;
   #else
   if(y<40.)
     return s=d(v,v+vec3(1.,1.,1.),f,i,x),s;
   if(y==40.||y>=42.&&y<=53.)
     s=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),f,i,x),r=r||s;
   if(y==41.||y>=54.&&y<=65.)
     s=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,x),r=r||s;
   if(y==42.||y==45.||y==46.||y==51.||y==52.||y==53.||y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
     {
       float t=.5;
       if(y==54.||y==57.||y==58.||y==63.||y==64.||y==65.)
         t=0.;
       s=d(v+vec3(0.,t,0.),v+vec3(.5,.5+t,.5),f,i,x);
       r=r||s;
     }
   if(y==42.||y==44.||y==47.||y==50.||y==52.||y==53.||y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
     {
       float t=.5;
       if(y==54.||y==56.||y==59.||y==62.||y==64.||y==65.)
         t=0.;
       s=d(v+vec3(.5,t,0.),v+vec3(1.,.5+t,.5),f,i,x);
       r=r||s;
     }
   if(y==43.||y==44.||y==48.||y==50.||y==51.||y==53.||y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
     {
       float t=.5;
       if(y==55.||y==56.||y==60.||y==62.||y==63.||y==65.)
         t=0.;
       s=d(v+vec3(.5,t,.5),v+vec3(1.,.5+t,1.),f,i,x);
       r=r||s;
     }
   if(y==43.||y==45.||y==49.||y==50.||y==51.||y==52.||y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
     {
       float t=.5;
       if(y==55.||y==57.||y==61.||y==62.||y==63.||y==64.)
         t=0.;
       s=d(v+vec3(0.,t,.5),v+vec3(.5,.5+t,1.),f,i,x);
       r=r||s;
     }
   if(y>=66.&&y<=81.)
     s=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,x),r=r||s;
   if(y==67.||y==68.||y==69.||y==71.||y==72.||y==73.||y==75.||y==76.||y==77.||y==79.||y==80.||y==81.)
     {
       float t=8.,c=8.;
       if(y==67.||y==69.||y==71.||y==73.||y==75.||y==77.||y==79.||y==81.)
         t=0.;
       if(y==68.||y==69.||y==72.||y==73.||y==76.||y==77.||y==80.||y==81.)
         c=16.;
       s=d(v+vec3(t,6.,7.)/16.,v+vec3(c,9.,9.)/16.,f,i,x);
       r=r||s;
       s=d(v+vec3(t,12.,7.)/16.,v+vec3(c,15.,9.)/16.,f,i,x);
       r=r||s;
     }
   if(y>=70.&&y<=81.)
     {
       float t=8.,w=8.;
       if(y>=70.&&y<=73.||y>=78.&&y<=81.)
         w=16.;
       if(y>=74.&&y<=81.)
         t=0.;
       s=d(v+vec3(7.,6.,t)/16.,v+vec3(9.,9.,w)/16.,f,i,x);
       r=r||s;
       s=d(v+vec3(7.,12.,t)/16.,v+vec3(9.,15.,w)/16.,f,i,x);
       r=r||s;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=82.&&y<=85.)
     {
       vec3 t=vec3(0),w=vec3(0);
       if(y==82.)
         t=vec3(0,0,0),w=vec3(16,16,3);
       if(y==83.)
         t=vec3(0,0,13),w=vec3(16,16,16);
       if(y==85.)
         t=vec3(0,0,0),w=vec3(3,16,16);
       if(y==84.)
         t=vec3(13,0,0),w=vec3(16,16,16);
       s=d(v+t/16.,v+w/16.,f,i,x);
       r=r||s;
     }
   if(y>=86.&&y<=101.)
     {
       vec3 t=vec3(0.),w=vec3(1.);
       if(y>=86.&&y<=93.)
         {
           float c=0.;
           if(y>=90.&&y<=93.)
             c=13.;
           t=vec3(0.,c,0.)/16.;
           w=vec3(16.,c+3.,16.)/16.;
         }
       if(y>=94.&&y<=97.)
         {
           float c=13.;
           if(y==96.||y==97.)
             c=0.;
           t=vec3(0.,0.,c)/16.;
           w=vec3(16.,16.,c+3.)/16.;
         }
       if(y>=98.&&y<=101.)
         {
           float c=13.;
           if(y==98.||y==99.)
             c=0.;
           t=vec3(c,0.,0.)/16.;
           w=vec3(c+3.,16.,16.)/16.;
         }
       s=d(v+t,v+w,f,i,x);
       r=r||s;
     }
   if(y>=102.&&y<=112.)
     {
       vec3 t=vec3(0.),c=vec3(1.);
       if(y>=102.&&y<=109.)
         {
           float m=float(y)-float(102.)+1.;
           c.y=m*2./16.;
         }
       if(y==110.)
         c.y=.0625;
       if(y==111.)
         t=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(y==112.)
         t=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       s=d(v+t,v+c,f,i,x);
       r=r||s;
     }
   #endif
   #endif
   return r;
 }
 vec2 g(inout float v)
 {
   return fract(sin(vec2(v+=.1,v+=.1))*vec2(43758.5,22578.1));
 }
 vec3 c(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<8./viewWidth||v.x>1.-8./viewWidth||v.y<8./viewHeight||v.y>1.-8./viewHeight)
     ;
   else
      y+=f[int(mod(float(frameCounter),4.))]*.5;
   y=(floor(y*64.)+.5)/64.;
   vec3 s=texture2D(noisetex,y).xyz;
   return s;
 }
 vec3 c(vec3 v,inout float y,int x)
 {
   vec2 f=c(texcoord.xy+vec2(y+=.1,y+=.1)).xy;
   f=fract(f+g(y)*.1);
   float t=6.28319*f.x,s=sqrt(f.y);
   vec3 r=normalize(cross(v,vec3(0.,1.,1.))),i=cross(v,r),z=r*cos(t)*s+i*sin(t)*s+v.xyz*sqrt(1.-f.y);
   return z;
 }
 vec3 c(vec3 v,vec3 y)
 {
   vec2 f=s(x(m(v)+y+1.));
   vec3 r=G(f).ounGyXgtzs;
   return r;
 }
 vec3 G()
 {
   vec2 y=s(v(texcoord.xy)+d()/e());
   vec3 f=G(y).ounGyXgtzs;
   return f;
 }
 vec3 G(float v,float f,float y,vec3 i)
 {
   vec3 r;
   r.x=y*cos(v);
   r.y=y*sin(v);
   r.z=f;
   vec3 s=abs(i.y)<.999?vec3(0,0,1):vec3(1,0,0),x=normalize(cross(i,vec3(0.,1.,1.))),t=cross(x,i);
   return x*r.x+t*r.y+i*r.z;
 }
 vec3 f(vec2 v,float f,vec3 y)
 {
   float i=2*3.14159*v.x,x=sqrt((1-v.y)/(1+(f*f-1)*v.y)),t=sqrt(1-x*x);
   return G(i,x,t,y);
 }
 float l(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 g(in vec2 v,in float y,in vec3 f)
 {
   float i=l(y),t=2*3.14159*v.x,x=pow(v.y,1.f/(i+1.f)),r=sqrt(1-x*x);
   return G(t,x,r,f);
 }
 float g(float v,float y)
 {
   return 1./(v*(1.-y)+y);
 }
 void i(inout vec3 v,in vec3 f)
 {
   vec3 y=normalize(f.xyz),i=v;
   float x=dot(i,y);
   i=normalize(v-y*saturate(x)*.5);
   v=i;
 }
 vec4 D(in vec2 v)
 {
   float y=GetDepth(v);
   vec4 f=gbufferProjectionInverse*vec4(v.x*2.f-1.f,v.y*2.f-1.f,2.f*y-1.f,1.f);
   f/=f.w;
   return f;
 }
 vec4 D(in vec2 v,in float y)
 {
   vec4 f=gbufferProjectionInverse*vec4(v.x*2.f-1.f,v.y*2.f-1.f,2.f*y-1.f,1.f);
   f/=f.w;
   return f;
 }
 void D(inout vec3 v,in vec3 y,in vec3 f,vec3 x,float z)
 {
   float r=length(y);
   r*=pow(eyeBrightnessSmooth.y/240.f,6.f);
   r*=rainStrength;
   float i=pow(exp(-r*1e-05),4.);
   i=max(i,.5);
   vec3 t=vec3(dot(colorSkyUp,vec3(1.)))*.05;
   v=mix(t,v,vec3(i));
 }
 vec4 D(float v,float y,vec3 s,vec3 t,vec3 x,vec3 z,vec3 m,float h,float n)
 {
   float w=1.;
   #ifdef SUNLIGHT_LEAK_FIX
   if(isEyeInWater<1)
     w=saturate(n*100.);
   #endif
   v=max(v-.05,0.);
   y=0.;
   float p=v*v,o=fract(frameCounter*.0123456);
   vec3 a=c(texcoord.xy).xyz*.99+.005,l=c(texcoord.xy+.1).xyz,R=reflect(m,g(a.xy,p,x)),G=normalize((gbufferModelView*vec4(R.xyz,0.)).xyz);
   if(dot(R,x)<0.)
     R=reflect(R,x);
   #ifdef REFLECTION_SCREEN_SPACE_TRACING
   bool b=false;
   {
     const int k=32;
     vec2 S=texcoord.xy;
     vec3 Y=t.xyz;
     float T=0.;
     vec3 U=t.xyz;
     float P=.05/saturate(dot(-m,x)+.001),F=P*2.,L=1.,M=0.;
     for(int N=0;N<k;N++)
       {
         float E=float(N),u=(E+.5)/float(k);
         vec3 C=G.xyz*P*(.1+length(U)*.1)*L;
         float I=F*(length(U)*.1);
         U+=C;
         vec2 W=ProjectBack(U).xy;
         vec3 A=GetViewPosition(W.xy,GetDepth(W.xy)).xyz;
         float B=length(U)-length(A)-.02;
         if(U.z>0.)
           {
             break;
           }
         if(B>0.&&B<I&&W.x>0.&&W.x<1.&&W.y>0.&&W.y<1.)
           {
             U-=C;
             L*=.5;
             M+=1.;
             if(M>2.)
               {
                 b=true;
                 S=W.xy;
                 Y=A.xyz;
                 T=distance(U,t.xyz)*.4;
                 break;
               }
           }
       }
     vec3 N=(gbufferModelViewInverse*vec4(Y,0.)).xyz;
     if(length(N)>far)
       b=false;
     if(b)
       {
         S.xy=floor(S.xy*vec2(viewWidth,viewHeight)+.5)/vec2(viewWidth,viewHeight);
         vec3 C=pow(texture2DLod(colortex3,S.xy,0).xyz,vec3(2.2)),W=C*100.;
         UnderwaterFog(W,length(N),R,colorSkyUp,colorSunlight);
         return vec4(W,saturate(T/4.));
       }
   }
   #endif
   int U=f(),Y=e();
   vec3 N=s+x*(.01+h*.1);
   N+=Fract01(cameraPosition.xyz+.5);
   Ray W=MakeRay(e(N,U)*U-vec3(1.),R);
   vec3 k=vec3(1.),S=vec3(0.);
   float T=0.;
   DDA C=r(W);
   float L=far;
   vec3 A=vec3(1.);
   for(int E=0;E<1;E++)
     {
       vec4 P=vec4(0.);
       vec3 B=vec3(0.);
       float M=.5;
       for(int F=0;F<REFLECTION_TRACE_LENGTH;F++)
         {
           B=C.mapPos/float(U);
           vec2 u=d(B,U);
           P=texture2DLod(shadowcolor,u,0);
           T=P.w*255.;
           float I=1.-step(.5,abs(T-241.));
           vec3 V=P.xyz;
           float O=dot(C.mapPos+.5-W.origin,C.mapPos+.5-W.origin),H=saturate(pow(saturate(dot(W.direction,normalize(C.mapPos+.5-W.origin))),56.*O)*5.-1.)*5.;
           S+=V*I*M*.5*H;
           if(T<240.)
             {
               if(d(C.mapPos,T,W,F==0,L,A))
                 {
                   break;
                 }
             }
           i(C);
           M=1.;
         }
       if(P.w*255.<1.f||P.w*255.>254.f)
         {
           vec3 F=SkyShading(W.direction,worldSunVector,rainStrength);
           F=DoNightEyeAtNight(F*12.,timeMidnight)*.083333;
           F=TintUnderwaterDepth(F);
           S+=F*.1;
           L=1000.;
           break;
         }
       vec3 F=mod(W.origin+W.direction*L,vec3(1.))-.5;
       vec2 I=vec2(0.);
       I+=vec2(F.z*-A.x,-F.y)*abs(A.x);
       I+=vec2(F.x,F.z*A.y)*abs(A.y);
       I+=vec2(F.x*A.z,-F.y)*abs(A.z);
       vec3 u=(W.origin+W.direction*L)/float(U);
       vec2 O=textureSize(colortex0,0);
       vec4 V=texture2DLod(shadowcolor1,d(B,U),0);
       vec2 H=V.xy;
       H=(floor(H*O/TEXTURE_RESOLUTION)+.5)/(O/TEXTURE_RESOLUTION);
       vec2 X=H+I.xy*(TEXTURE_RESOLUTION/O);
       vec3 Q=pow(texture2D(colortex0,X).xyz,vec3(2.2));
       Q*=mix(vec3(1.),P.xyz/(V.w+1e-05),vec3(V.z));
       if(T<240.)
         {
           vec3 q=saturate(P.xyz);
           k*=Q;
         }
       if(abs(T-31.)<.1)
         S+=.09*k*GI_LIGHT_BLOCK_INTENSITY;
       vec3 q=vec3(0.),j=vec3(0.);
       if(abs(A.x)>.5)
         q=vec3(0.,1.,0.),j=vec3(0.,0.,1.);
       if(abs(A.y)>.5)
         q=vec3(1.,0.,0.),j=vec3(0.,0.,1.);
       if(abs(A.z)>.5)
         q=vec3(1.,0.,0.),j=vec3(0.,1.,0.);
       q*=1.;
       j*=1.;
       vec3 Z=c(B,A),J=Z,K=saturate(Z*100000.),ab=c(B+q/float(U),A);
       J+=ab;
       K+=saturate(ab*100000.);
       vec3 ac=c(B-q/float(U),A);
       J+=ac;
       K+=saturate(ac*100000.);
       vec3 ad=c(B+j/float(U),A);
       J+=ad;
       K+=saturate(ad*100000.);
       vec3 ae=c(B-j/float(U),A);
       J+=ae;
       K+=saturate(ae*100000.);
       J/=K+vec3(.0001);
       S+=J*k;
       const float af=2.4;
       vec3 ag=e(N+W.direction*L-1.,worldLightVector,A,R,U)*k*af*colorSunlight*w;
       if(isEyeInWater>0)
         ;
       S+=ag;
     }
   vec3 F=t.xyz+G*L,B=(gbufferModelViewInverse*vec4(F.xyz,0.)).xyz;
   if(L<1000.)
     LandAtmosphericScattering(S,F,G,R,worldSunVector,1.);
   D(S,F,normalize(t.xyz),normalize(s.xyz),1.);
   UnderwaterFog(S,length(B),m,colorSkyUp,colorSunlight);
   L*=saturate(dot(-m,x))*2.;
   return vec4(S,saturate(L/4.));
 }
 vec4 T(float v)
 {
   float y=v*v,f=y*v;
   vec4 r;
   r.x=-f+3*y-3*v+1;
   r.y=3*f-6*y+4;
   r.z=-3*f+3*y+3*v+1;
   r.w=f;
   return r/6.f;
 }
 vec4 T(in sampler2D v,in vec2 f)
 {
   vec2 y=vec2(viewWidth,viewHeight);
   f*=y;
   f-=.5;
   float s=fract(f.x),i=fract(f.y);
   f.x-=s;
   f.y-=i;
   vec4 t=T(s),r=T(i),x=vec4(f.x-.5,f.x+1.5,f.y-.5,f.y+1.5),d=vec4(t.x+t.y,t.z+t.w,r.x+r.y,r.z+r.w),c=x+vec4(t.y,t.w,r.y,r.w)/d,z=texture2DLod(v,vec2(c.x,c.z)/y,0),w=texture2DLod(v,vec2(c.y,c.z)/y,0),h=texture2DLod(v,vec2(c.x,c.w)/y,0),a=texture2DLod(v,vec2(c.y,c.w)/y,0);
   float m=d.x/(d.x+d.y),U=d.z/(d.z+d.w);
   return mix(mix(a,h,m),mix(w,z,m),U);
 }
 bool l(vec3 v,vec3 y)
 {
   vec3 f=normalize(cross(dFdx(v),dFdy(v))),i=normalize(y-v),t=normalize(i);
   return distance(v,y)<.05;
 }
 vec3 R(vec2 v)
 {
   vec2 y=vec2(viewWidth,viewHeight),f=1./y,i=v*y,x=floor(i-.5)+.5,t=i-x,s=t*t,r=t*s;
   float z=.5;
   vec2 d=-z*r+2.*z*s-z*t,c=(2.-z)*r-(3.-z)*s+1.,w=-(2.-z)*r+(3.-2.*z)*s+z*t,a=z*r-z*s,U=c+w,m=f*(x+w/U);
   vec3 h=texture2DLod(colortex4,vec2(m.x,m.y),0).xyz;
   vec2 W=f*(x-1.),A=f*(x+2.);
   vec4 n=vec4(texture2DLod(colortex4,vec2(m.x,W.y),0).xyz,1.)*(U.x*d.y)+vec4(texture2DLod(colortex4,vec2(W.x,m.y),0).xyz,1.)*(d.x*U.y)+vec4(h,1.)*(U.x*U.y)+vec4(texture2DLod(colortex4,vec2(A.x,m.y),0).xyz,1.)*(a.x*U.y)+vec4(texture2DLod(colortex4,vec2(m.x,A.y),0).xyz,1.)*(U.x*a.y);
   return max(vec3(0.),n.xyz*(1./n.w));
 }
 void main()
 {
   GBufferData v=GetGBufferData();
   GBufferDataTransparent f=GetGBufferDataTransparent();
   MaterialMask y=CalculateMasks(v.materialID),i=CalculateMasks(f.materialID);
   bool x=f.depth<v.depth;
   if(x)
     v.depth=f.depth,v.normal=f.normal,v.smoothness=f.smoothness,v.metalness=0.,v.mcLightmap=f.mcLightmap,i.sky=0.;
   vec4 r=GetViewPosition(texcoord.xy,v.depth),t=gbufferModelViewInverse*vec4(r.xyz,1.),d=gbufferModelViewInverse*vec4(r.xyz,0.);
   vec3 s=normalize(r.xyz),c=normalize(d.xyz),w=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz),z=normalize((gbufferModelViewInverse*vec4(v.geoNormal,0.)).xyz);
   float m=length(r.xyz);
   vec4 a=vec4(0.);
   float U=G(v.smoothness,v.metalness);
   if(U>.0001&&i.sky<.5)
     a=D(1.-v.smoothness,v.metalness,t.xyz,r.xyz,w.xyz,z,c.xyz,y.leaves,v.mcLightmap.y);
   vec4 n=texture2DLod(colortex3,texcoord.xy,0);
   vec3 W=n.xyz;
   W.xyz=pow(W.xyz,vec3(2.2));
   if(x)
     {
       vec3 F=GetViewPosition(texcoord.xy,texture2DLod(depthtex1,texcoord.xy,0).x).xyz;
       float e=length(F.xyz),A=e-m;
       vec3 h=f.normal-f.geoNormal*1.05;
       float k=saturate(A*.5);
       vec2 R=texcoord.xy+h.xy/(m+1.5)*k;
       W.xyz=pow(texture2DLod(colortex3,R.xy,0).xyz,vec3(2.2));
       F=GetViewPosition(R.xy,texture2DLod(depthtex1,R.xy,0).x).xyz;
       r=GetViewPosition(R.xy,texture2DLod(depthtex0,R.xy,0).x);
       e=length(F.xyz);
       m=length(r.xyz);
       A=e-m;
       if(i.water>.5&&isEyeInWater<1)
         {
           W.xyz*=exp(GetWaterAbsorption()*-A);
           vec3 S=GetWaterFogColor()*.001;
           S*=exp(-GetWaterAbsorption()*((-c.y*.5+.5)*3.));
           S*=pow(curve(saturate(mix(c.y,1.,.5))),2.)*.6+.4;
           S*=(colorSkyUp+colorSunlight*2.)*1.4;
           S=TintUnderwaterDepth(S);
           float B=exp(-A*.03);
           S*=exp(-GetWaterAbsorption()*(1.-B)*20.);
           S*=eyeBrightnessSmooth.y/240.;
           W=mix(S,W,vec3(B));
         }
       if(i.stainedGlass>.5)
         {
           vec3 S=normalize(f.albedo.xyz+.0001)*pow(length(f.albedo.xyz),.5);
           W.xyz*=mix(vec3(1.),S,vec3(pow(f.albedo.w,.2)));
           W.xyz*=mix(vec3(1.),S,vec3(pow(f.albedo.w,.2)));
         }
     }
   W.xyz=pow(W.xyz,vec3(1./2.2));
   a.xyz=saturate(a.xyz);
   gl_FragData[0]=texture2DLod(colortex0,texcoord.xy,0);
   gl_FragData[1]=vec4(W.xyz,v.smoothness);
   gl_FragData[2]=a;
 };




/* DRAWBUFFERS:036 */
