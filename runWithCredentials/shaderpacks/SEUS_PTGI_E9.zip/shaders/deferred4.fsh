#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/





in vec4 texcoord;




#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBufferData.inc"





 int f(float v)
 {
   return int(floor(v));
 }
 int t(int v)
 {
   return v-f(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-f(mod(float(v),2.))-1;
 }
 int d()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return t(f(floor(pow(float(x),.333333))));
 }
 int f()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return d(f(floor(pow(float(x),.333333))));
 }
 vec3 n(vec2 v)
 {
   ivec2 f=ivec2(viewWidth,viewHeight);
   int x=f.x*f.y,y=d();
   ivec2 n=ivec2(v.x*f.x,v.y*f.y);
   float s=float(n.y/y),i=float(int(n.x+mod(f.x*s,y))/y);
   i+=floor(f.x*s/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(n.x+mod(f.x*s,y),y);
   m.y=mod(n.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 x(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int x=d();
   vec3 f=v.xzy*x;
   f=floor(f+1e-05);
   float y=f.z;
   vec2 i;
   i.x=mod(f.x+y*x,m.x);
   float s=f.x+y*x;
   i.y=f.y+floor(s/m.x)*x;
   i+=.5;
   i/=m;
   return i;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 m=ivec2(2048,2048);
   int x=m.x*m.y,y=f();
   ivec2 n=ivec2(i.x*m.x,i.y*m.y);
   float s=float(n.y/y),z=float(int(n.x+mod(m.x*s,y))/y);
   z+=floor(m.x*s/y);
   vec3 r=vec3(0.,0.,z);
   r.x=mod(n.x+mod(m.x*s,y),y);
   r.y=mod(n.y,y);
   r.xyz=floor(r.xyz);
   r/=y;
   r.xyz=r.xzy;
   return r;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   ivec2 m=ivec2(2048,2048);
   vec3 f=v.xzy*y;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 i;
   i.x=mod(f.x+x*y,m.x);
   float s=f.x+x*y;
   i.y=f.y+floor(s/m.x)*y;
   i+=.5;
   i/=m;
   i.xy*=.5;
   return i;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=d();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 p(vec3 v)
 {
   int m=d();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 n()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,x=floor(v-.0001),y=floor(f-.0001);
   return x-y;
 }
 vec3 m(vec3 v)
 {
   vec4 f=vec4(v,1.);
   f=shadowModelView*f;
   f=shadowProjection*f;
   f/=f.w;
   float x=sqrt(f.x*f.x+f.y*f.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   f.xy*=.95f/y;
   f.z=mix(f.z,.5,.8);
   f=f*.5f+.5f;
   f.xy*=.5;
   f.xy+=.5;
   return f.xyz;
 }
 vec3 d(vec3 v,vec3 f,vec2 m,vec2 n,vec4 i,vec4 x,inout float y,out vec2 r)
 {
   bool s=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   s=!s;
   if(x.x==8||x.x==9||x.x==79||x.x<1.||!s||x.x==20.||x.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(x.x==50.||x.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(x.x==51)
     y=0.;
   if(x.x>255)
     y=0.;
   vec3 z,t;
   if(f.x>.5)
     z=vec3(0.,0.,-1.),t=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       z=vec3(0.,0.,1.),t=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         z=vec3(1.,0.,0.),t=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           z=vec3(1.,0.,0.),t=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             z=vec3(1.,0.,0.),t=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               z=vec3(-1.,0.,0.),t=vec3(0.,-1.,0.);
   r=clamp((m.xy-n.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,o=.15;
   if(x.x==10.||x.x==11.)
     {
       if(abs(f.y)<.01&&s||f.y>.99)
         h=.1,o=.1,y=0.;
       else
          y=1.;
     }
   if(x.x==51)
     h=.5,o=.1;
   if(x.x==76)
     h=.2,o=.2;
   if(x.x-255.+39.>=102.&&x.x-255.+39.<=112.)
     o=.025,h=.025;
   z=normalize(i.xyz);
   t=normalize(cross(z,f.xyz)*sign(i.w));
   vec3 d=v.xyz+mix(z*h,-z*h,vec3(r.x));
   d.xyz+=mix(t*h,-t*h,vec3(r.y));
   d.xyz-=f.xyz*o;
   return d;
 }struct DDA{vec3 mapPos;vec3 mapPosOrigin;vec3 deltaDist;vec3 rayStep;vec3 sideDist;vec3 mask;};
 DDA e(Ray v)
 {
   DDA f;
   f.mapPos=floor(v.origin);
   f.mapPosOrigin=f.mapPos;
   f.deltaDist=abs(vec3(length(v.direction))/(v.direction+.0001));
   f.rayStep=sign(v.direction);
   f.sideDist=(sign(v.direction)*(f.mapPos-v.origin)+sign(v.direction)*.5+.5)*f.deltaDist;
   f.mask=vec3(0.);
   return f;
 }
 void w(inout DDA v)
 {
   v.mask=step(v.sideDist.xyz,v.sideDist.yzx)*step(v.sideDist.xyz,v.sideDist.zxy),v.sideDist+=v.mask*v.deltaDist,v.mapPos+=v.mask*v.rayStep;
 }
 void d(in Ray v,in vec3 f[2],out float i,out float y)
 {
   float x,z,r,t;
   i=(f[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(f[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   x=(f[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(f[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(f[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   t=(f[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   i=max(max(i,x),r);
   y=min(min(y,z),t);
 }
 vec3 d(const vec3 v,const vec3 f,vec3 y)
 {
   const float x=1e-05;
   vec3 z=(f+v)*.5,i=(f-v)*.5,m=y-z,r=vec3(0.);
   r+=vec3(sign(m.x),0.,0.)*step(abs(abs(m.x)-i.x),x);
   r+=vec3(0.,sign(m.y),0.)*step(abs(abs(m.y)-i.y),x);
   r+=vec3(0.,0.,sign(m.z))*step(abs(abs(m.z)-i.z),x);
   return normalize(r);
 }
 bool e(const vec3 v,const vec3 f,Ray m,out vec2 i)
 {
   vec3 y=m.inv_direction*(v-m.origin),x=m.inv_direction*(f-m.origin),n=min(x,y),t=max(x,y);
   vec2 r=max(n.xx,n.yz);
   float s=max(r.x,r.y);
   r=min(t.xx,t.yz);
   float z=min(r.x,r.y);
   i.x=s;
   i.y=z;
   return z>max(s,0.);
 }
 bool d(const vec3 v,const vec3 f,Ray m,inout float y,inout vec3 x)
 {
   vec3 z=m.inv_direction*(v-m.origin),i=m.inv_direction*(f-m.origin),n=min(i,z),t=max(i,z);
   vec2 r=max(n.xx,n.yz);
   float s=max(r.x,r.y);
   r=min(t.xx,t.yz);
   float G=min(r.x,r.y);
   bool a=G>max(s,0.)&&max(s,0.)<y;
   if(a)
     x=d(v,f,m.origin+m.direction*s),y=s;
   return a;
 }
 vec3 e(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 t=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),0).x;
   t*=saturate(dot(f,y));
   {
     vec4 n=texture2DLod(shadowcolor1,i.xy-vec2(0.,.5),4);
     float r=abs(n.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,f,r),o=shadow2DLod(shadowtex0,vec3(i.xy-vec2(0.,.5),i.z+1e-06),4).x;
     t=mix(t,t*h,1.-o);
   }
   t=TintUnderwaterDepth(t);
   return t*(1.-rainStrength);
 }
 vec3 f(vec3 f,vec3 x,vec3 y,vec3 i,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(f),t=m(s+y*.99);
   float n=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(t.xy,t.z-.0006*n),3).x;
   r*=saturate(dot(x,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 f,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 i=m(v);
   float s=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(i.xy,i.z-.0006*s),2).x;
   r*=saturate(dot(f,y));
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }struct SugChoyrig{float EPQCbdZJBL;float xVoNcOTeXw;float dEdWWLhdyo;float vDYzoMNpum;vec3 ounGyXgtzs;};
 vec4 h(SugChoyrig v)
 {
   vec4 f;
   v.ounGyXgtzs=max(vec3(0.),v.ounGyXgtzs);
   f.x=v.EPQCbdZJBL;
   v.ounGyXgtzs=pow(v.ounGyXgtzs,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.ounGyXgtzs.x,v.dEdWWLhdyo);
   f.z=PackTwo16BitTo32Bit(v.ounGyXgtzs.y,v.vDYzoMNpum);
   f.w=PackTwo16BitTo32Bit(v.ounGyXgtzs.z,v.xVoNcOTeXw);
   return f;
 }
 SugChoyrig i(vec4 v)
 {
   SugChoyrig f;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),i=UnpackTwo16BitFrom32Bit(v.z),x=UnpackTwo16BitFrom32Bit(v.w);
   f.EPQCbdZJBL=v.x;
   f.dEdWWLhdyo=m.y;
   f.vDYzoMNpum=i.y;
   f.xVoNcOTeXw=x.y;
   f.ounGyXgtzs=pow(vec3(m.x,i.x,x.x),vec3(8.));
   return f;
 }
 SugChoyrig G(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 void G(inout float v,inout float f,float x,float y,vec3 i,float z)
 {
   #if GI_FILTER_QUALITY==0
   v*=mix(2.6,2.4,y);
   #else
   v*=mix(3.4,3.4,y);
   #endif
   float s=dot(i,vec3(1.));
   f*=1.-pow(y,.4);
   f/=x*.1+2e-06;
   f*=4.;
   f*=.6;
   float r=x/(s+1e-07)*.2+4e-08;
   r=min(r,1.);
   r=mix(r,1.,pow(y,.25));
   if(z<.12)
     f=0.;
 }
 float G(vec3 v,vec3 y,float f)
 {
   float i=dot(abs(v-y),vec3(.3333));
   i*=f;
   i*=.18;
   return i;
 }
 void e(inout vec3 v,vec2 x,vec3 y)
 {}
 float e(float v,float f)
 {
   return v/(f*20.01+1.);
 }
 bool d(vec3 v,float x,Ray y,bool f,inout float i,inout vec3 z)
 {
   bool m=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(f)
     return false;
   if(x>=66.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),y,i,z);
   m=r;
   #else
   if(x<40.)
     return r=d(v,v+vec3(1.,1.,1.),y,i,z),r;
   if(x==40.||x>=42.&&x<=53.)
     r=d(v+vec3(0.,0.,0.),v+vec3(1.,.5,1.),y,i,z),m=m||r;
   if(x==41.||x>=54.&&x<=65.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),y,i,z),m=m||r;
   if(x==42.||x==45.||x==46.||x==51.||x==52.||x==53.||x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
     {
       float s=.5;
       if(x==54.||x==57.||x==58.||x==63.||x==64.||x==65.)
         s=0.;
       r=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),y,i,z);
       m=m||r;
     }
   if(x==42.||x==44.||x==47.||x==50.||x==52.||x==53.||x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
     {
       float s=.5;
       if(x==54.||x==56.||x==59.||x==62.||x==64.||x==65.)
         s=0.;
       r=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),y,i,z);
       m=m||r;
     }
   if(x==43.||x==44.||x==48.||x==50.||x==51.||x==53.||x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
     {
       float s=.5;
       if(x==55.||x==56.||x==60.||x==62.||x==63.||x==65.)
         s=0.;
       r=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),y,i,z);
       m=m||r;
     }
   if(x==43.||x==45.||x==49.||x==50.||x==51.||x==52.||x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
     {
       float s=.5;
       if(x==55.||x==57.||x==61.||x==62.||x==63.||x==64.)
         s=0.;
       r=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),y,i,z);
       m=m||r;
     }
   if(x>=66.&&x<=81.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,y,i,z),m=m||r;
   if(x==67.||x==68.||x==69.||x==71.||x==72.||x==73.||x==75.||x==76.||x==77.||x==79.||x==80.||x==81.)
     {
       float s=8.,t=8.;
       if(x==67.||x==69.||x==71.||x==73.||x==75.||x==77.||x==79.||x==81.)
         s=0.;
       if(x==68.||x==69.||x==72.||x==73.||x==76.||x==77.||x==80.||x==81.)
         t=16.;
       r=d(v+vec3(s,6.,7.)/16.,v+vec3(t,9.,9.)/16.,y,i,z);
       m=m||r;
       r=d(v+vec3(s,12.,7.)/16.,v+vec3(t,15.,9.)/16.,y,i,z);
       m=m||r;
     }
   if(x>=70.&&x<=81.)
     {
       float s=8.,t=8.;
       if(x>=70.&&x<=73.||x>=78.&&x<=81.)
         t=16.;
       if(x>=74.&&x<=81.)
         s=0.;
       r=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,t)/16.,y,i,z);
       m=m||r;
       r=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,t)/16.,y,i,z);
       m=m||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=82.&&x<=85.)
     {
       vec3 s=vec3(0),t=vec3(0);
       if(x==82.)
         s=vec3(0,0,0),t=vec3(16,16,3);
       if(x==83.)
         s=vec3(0,0,13),t=vec3(16,16,16);
       if(x==85.)
         s=vec3(0,0,0),t=vec3(3,16,16);
       if(x==84.)
         s=vec3(13,0,0),t=vec3(16,16,16);
       r=d(v+s/16.,v+t/16.,y,i,z);
       m=m||r;
     }
   if(x>=86.&&x<=101.)
     {
       vec3 s=vec3(0.),t=vec3(1.);
       if(x>=86.&&x<=93.)
         {
           float h=0.;
           if(x>=90.&&x<=93.)
             h=13.;
           s=vec3(0.,h,0.)/16.;
           t=vec3(16.,h+3.,16.)/16.;
         }
       if(x>=94.&&x<=97.)
         {
           float n=13.;
           if(x==96.||x==97.)
             n=0.;
           s=vec3(0.,0.,n)/16.;
           t=vec3(16.,16.,n+3.)/16.;
         }
       if(x>=98.&&x<=101.)
         {
           float n=13.;
           if(x==98.||x==99.)
             n=0.;
           s=vec3(n,0.,0.)/16.;
           t=vec3(n+3.,16.,16.)/16.;
         }
       r=d(v+s,v+t,y,i,z);
       m=m||r;
     }
   if(x>=102.&&x<=112.)
     {
       vec3 s=vec3(0.),t=vec3(1.);
       if(x>=102.&&x<=109.)
         {
           float n=float(x)-float(102.)+1.;
           t.y=n*2./16.;
         }
       if(x==110.)
         t.y=.0625;
       if(x==111.)
         s=vec3(1.,0.,1.)/16.,t=vec3(15.,1.,15.)/16.;
       if(x==112.)
         s=vec3(1.,0.,1.)/16.,t=vec3(15.,.5,15.)/16.;
       r=d(v+s,v+t,y,i,z);
       m=m||r;
     }
   #endif
   #endif
   return m;
 }
 float h(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 float i(vec3 v,vec3 y)
 {
   return dot(abs(v-y),vec3(.3333));
 }
 void main()
 {
   SugChoyrig v=G(texcoord.xy);
   float x=v.vDYzoMNpum;
   int y=0;
   vec4 f=texture2DLod(colortex6,texcoord.xy,0);
   vec3 m=f.xyz;
   float s=Luminance(m.xyz),t=f.w;
   vec3 i=GetNormals(texcoord.xy);
   float z=GetDepth(texcoord.xy),r=ExpToLinearDepth(z);
   vec3 n=GetViewPosition(texcoord.xy,z).xyz;
   vec2 h=vec2(0.);
   #if GI_FILTER_QUALITY==1
   h=BlueNoiseTemporal(texcoord.xy).xy-.5;
   #endif
   float a=4.*1,o=4.;
   G(a,o,f.w,x,m,r);
   float d=12.*mix(1.,6.,x),w=mix(20.,15.,x)/r,Y=0.;
   vec4 c=vec4(0.);
   float p=0.;
   vec4 R=vec4(vec3(1.),1.);
   int D=0;
   for(int S=-1;S<=1;S++)
     {
       for(int b=-1;b<=1;b++)
         {
           vec2 k=(vec2(S,b)+h)/vec2(viewWidth,viewHeight)*a,l=texcoord.xy+k.xy;
           l=clamp(l,2./vec2(viewWidth,viewHeight),1.-2./vec2(viewWidth,viewHeight));
           vec4 L=texture2DLod(colortex6,l,y);
           vec3 E=GetNormals(l);
           float F=GetDepth(l),u=ExpToLinearDepth(F),g=pow(saturate(dot(i,E)),d),T=exp(-(abs(u-r)*w)),P=0.;
           #if GI_FILTER_QUALITY==1
           vec3 A=GetViewPosition(l,F).xyz,B=normalize(A.xyz-n.xyz);
           float U=dot(-E,B);
           bool W=U>0.&&Luminance(L.xyz)<Luminance(m.xyz);
           g=W?2.:g;
           P=exp(-G(L.xyz,m,W?o:o));
           #else
           P=exp(-G(L.xyz,m,o));
           #endif
           float C=T*P*g;
           c+=pow(L,R)*C;
           p+=C;
           D++;
         }
     }
   c/=p+.0001;
   c=pow(c,vec4(1.)/R);
   vec3 l=c.xyz;
   if(p<.0001)
     l=m;
   e(l,texcoord.xy,rand(texcoord.xy+sin(frameTimeCounter)).xyz);
   gl_FragData[0]=vec4(l,c.w);
 };




/* DRAWBUFFERS:6 */
