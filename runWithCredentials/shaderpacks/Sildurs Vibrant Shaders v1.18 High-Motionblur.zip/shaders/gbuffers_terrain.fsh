#version 120
/* DRAWBUFFERS:01 */
//Specular buffer 012
/*
Sildur's vibrant shaders, before editing, remember the agreement you've accepted by downloading this shaderpack:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1291396-1-6-4-1-12-1-sildurs-shaders-pc-mac-intel

You are allowed to:
- Modify it for your own personal use only, so don't share it online.

You are not allowed to:
- Rename and/or modify this shaderpack and upload it with your own name on it.
- Provide mirrors by reuploading my shaderpack, if you want to link it, use the link to my thread found above.
- Copy and paste code or even whole files into your "own" shaderpack.
*/
/*--------------------
//ADJUSTABLE VARIABLES//
---------------------*/

//#define POM				//Parallax mapping, must also be enabled/disabled in gbuffers_terrain.vsh (vertex)
#define POM_RES 64			//Texture / Resourcepack resolution. [64 128 256 512]

/*---------------------------
//END OF ADJUSTABLE VARIABLES//
----------------------------*/

/* Don't remove me
const int compositeFormat = RGBA16;
const int gaux2Format = RGBA16;
const int gaux3Format = RGBA16;		
const int gaux4Format = RGBA16;	

const int gcolorFormat = RGBA8;
const int gdepthFormat = RGBA16;
const int gnormalFormat = RGBA16;
const int compositeFormat = R11F_G11F_B10F;
const int gaux1Format = RGBA16;
const int gaux2Format = R11F_G11F_B10F;
const int gaux3Format = R11F_G11F_B10F;		
const int gaux4Format = R11F_G11F_B10F;	
-----------------------------------------*/

varying vec4 color;
varying vec4 texcoord;
varying vec4 normal;

uniform sampler2D texture;
//uniform sampler2D specular;

//encode normal in two channel (xy),torch and material(z) and sky lightmap (w)
vec4 encode (vec3 n){
    float p = sqrt(n.z*8+8);
    return vec4(n.xy/p + 0.5,texcoord.z,texcoord.w);
}

vec3 RGB2YCoCg(vec3 c){
		return vec3( 0.25*c.r+0.5*c.g+0.25*c.b, 0.5*c.r-0.5*c.b +0.5, -0.25*c.r+0.5*c.g-0.25*c.b +0.5);
}
vec3 newnormal = normal.xyz;
#ifdef POM
#extension GL_ARB_shader_texture_lod : enable
#if POM_RES == 64
const vec3 pomDepth = vec3(0.015625, 0.015625, 0.10703125);
#endif
#if POM_RES == 128
const vec3 pomDepth = vec3(0.0078125, 0.0078125, 0.045703125);
#endif
#if POM_RES == 256
const vec3 pomDepth = vec3(0.00390625, 0.00390625, 0.0189453125);
#endif
#if POM_RES == 512
const vec3 pomDepth = vec3(0.001953125, 0.001953125, 0.00751953125);
#endif

uniform sampler2D normals;
varying float dist;
varying vec3 viewVector;
varying mat3 tbnMatrix;
varying vec4 vtexcoordam; // .st for add, .pq for mul
varying vec2 vtexcoord;

vec2 dcdx = dFdx(vtexcoord.xy*vtexcoordam.pq);
vec2 dcdy = dFdy(vtexcoord.xy*vtexcoordam.pq);

vec4 readNormal(in vec2 coord){
	return texture2DGradARB(normals,fract(coord)*vtexcoordam.pq+vtexcoordam.st,dcdx,dcdy);
}

vec4 calcPOM(vec4 albedo){
	vec2 newCoord = vtexcoord.xy*vtexcoordam.pq+vtexcoordam.st;
	vec3 normViewVector = normalize(viewVector);
	if (dist < 16.0 && viewVector.z < 0.0 && readNormal(vtexcoord.xy).a < 1.0){
		vec3 coord = vec3(vtexcoord.xy, 1.0);
		for (int i= 0; i < 50 && (readNormal(coord.xy).a < coord.z); ++i) coord = coord + normViewVector.xyz * pomDepth;
	
		newCoord = fract(coord.xy)*vtexcoordam.pq+vtexcoordam.st;
	}

	//vec4 specularity = texture2DGradARB(specular, newCoord, dcdx, dcdy);
	vec3 bumpMapping = texture2DGradARB(normals, newCoord, dcdx, dcdy).rgb*2.0-1.0;
	newnormal = normalize(bumpMapping * tbnMatrix);

return albedo = texture2DGradARB(texture, newCoord, dcdx, dcdy)*color;
}
#endif

void main() {

vec4 albedo = texture2D(texture,texcoord.xy)*color;
#ifdef POM
	 albedo = calcPOM(albedo);
#endif
vec4 cAlbedo = vec4(RGB2YCoCg(albedo.rgb),albedo.a);

bool pattern = (mod(gl_FragCoord.x,2.0)==mod(gl_FragCoord.y,2.0));
cAlbedo.g = (pattern)?cAlbedo.b: cAlbedo.g;
cAlbedo.b = normal.a;

	gl_FragData[0] = cAlbedo;
	gl_FragData[1] = encode(newnormal.xyz);
	//gl_FragData[2] = specularity;
}