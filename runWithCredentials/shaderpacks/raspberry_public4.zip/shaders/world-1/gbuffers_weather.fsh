#version 460 compatibility
#define GBUFFERS_WEATHER
#define fsh
#include "/lib/Header.glsl"


#if   PROG_WEATHER == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.fsh"
#elif PROG_WEATHER == G_SOLID
#include "/program/gbuffers/gbuffers_solid.fsh"
#elif PROG_WEATHER == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.fsh"
#endif