#version 460 compatibility
#define GBUFFERS_HAND
#define vsh
#include "/lib/Header.glsl"


#if   PROG_HAND == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.vsh"
#elif PROG_HAND == G_SOLID
#include "/program/gbuffers/gbuffers_solid.vsh"
#elif PROG_HAND == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.vsh"
#endif