#version 460 compatibility
#define GBUFFERS_SPIDEREYES
#define vsh
#include "/lib/Header.glsl"


#if   PROG_SPIDEREYES == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.vsh"
#elif PROG_SPIDEREYES == G_SOLID
#include "/program/gbuffers/gbuffers_solid.vsh"
#elif PROG_SPIDEREYES == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.vsh"
#endif