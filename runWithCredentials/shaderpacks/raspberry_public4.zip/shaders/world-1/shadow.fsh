#version 460 compatibility
#define GBUFFERS_SHADOW
#define fsh
#include "/lib/Header.glsl"


#include "/program/gbuffers/gbuffers_shadow.fsh"