#version 460 compatibility
#define COMPOSITE 2
#define vsh
#include "/lib/Header.glsl"


#include "/program/composite/shading_1.vsh"