#version 460 compatibility
#define GBUFFERS_SKYBASIC
#define fsh
#include "/lib/Header.glsl"
layout (location = 0) out vec4 outAlbedo;
varying vec2 texcoord;
uniform sampler2D texture;


void main(){
discard;
}