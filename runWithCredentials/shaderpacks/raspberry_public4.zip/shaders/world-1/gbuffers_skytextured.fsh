#version 460 compatibility
#define GBUFFERS_SKYTEXTURED
#define fsh
#include "/lib/Header.glsl"


void main(){
discard;

}