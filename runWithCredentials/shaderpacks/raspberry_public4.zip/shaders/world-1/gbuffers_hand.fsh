#version 460 compatibility
#define GBUFFERS_HAND
#define fsh
#include "/lib/Header.glsl"


#if   PROG_HAND == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.fsh"
#elif PROG_HAND == G_SOLID
#include "/program/gbuffers/gbuffers_solid.fsh"
#elif PROG_HAND == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.fsh"
#endif