#version 460 compatibility
#define GBUFFERS_BLOCK
#define fsh
#include "/lib/Header.glsl"


#if   PROG_BLOCK == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.fsh"
#elif PROG_BLOCK == G_SOLID
#include "/program/gbuffers/gbuffers_solid.fsh"
#elif PROG_BLOCK == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.fsh"
#endif