#version 460 compatibility
#define COMPOSITE 0
#define fsh
#include "/lib/Header.glsl"


#include "/program/composite/pre_shading_0.fsh"