#version 460 compatibility
#define GBUFFERS_TEXTURED_LIT
#define vsh
#include "/lib/Header.glsl"


#if   PROG_TEXTURED_LIT == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.vsh"
#elif PROG_TEXTURED_LIT == G_SOLID
#include "/program/gbuffers/gbuffers_solid.vsh"
#elif PROG_TEXTURED_LIT == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.vsh"
#endif