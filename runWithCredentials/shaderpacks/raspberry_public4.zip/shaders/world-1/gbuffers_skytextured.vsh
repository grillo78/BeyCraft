#version 460 compatibility
#define GBUFFERS_SKYTEXTURED
#define vsh
#include "/lib/Header.glsl"


void main(){
gl_Position = ftransform();
//gl_Color *= vec3(0.0);

}