#version 460 compatibility
#define GBUFFERS_SKYBASIC
#define vsh
#include "/lib/Header.glsl"

varying vec2 texcoord;

void main(){
gl_Position = ftransform();
//gl_Color *= vec3(0.0);

}