#version 460 compatibility
#define GBUFFERS_ENTITIES
#define vsh
#include "/lib/Header.glsl"


#if   PROG_ENTITIES == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.vsh"
#elif PROG_ENTITIES == G_SOLID
#include "/program/gbuffers/gbuffers_solid.vsh"
#elif PROG_ENTITIES == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.vsh"
#endif