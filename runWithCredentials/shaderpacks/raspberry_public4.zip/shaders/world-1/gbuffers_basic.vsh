#version 460 compatibility
#define GBUFFERS_BASIC
#define vsh
#include "/lib/Header.glsl"


#if   PROG_BASIC == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.vsh"
#elif PROG_BASIC == G_SOLID
#include "/program/gbuffers/gbuffers_solid.vsh"
#elif PROG_BASIC == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.vsh"
#endif