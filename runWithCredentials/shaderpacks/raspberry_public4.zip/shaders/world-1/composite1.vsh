#version 460 compatibility
#define COMPOSITE 1
#define vsh
#include "/lib/Header.glsl"


#include "/program/composite/shading_0.vsh"