#version 460 compatibility
#define GBUFFERS_ARMOR_GLINT
#define fsh
#include "/lib/Header.glsl"


#if   PROG_TERRAIN == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.fsh"
#elif PROG_TERRAIN == G_SOLID
#include "/program/gbuffers/gbuffers_solid.fsh"
#elif PROG_TERRAIN == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.fsh"
#endif