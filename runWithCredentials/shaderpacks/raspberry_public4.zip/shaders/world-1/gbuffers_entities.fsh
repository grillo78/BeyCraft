#version 460 compatibility
#define GBUFFERS_ENTITIES
#define fsh
#include "/lib/Header.glsl"


#if   PROG_ENTITIES == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.fsh"
#elif PROG_ENTITIES == G_SOLID
#include "/program/gbuffers/gbuffers_solid.fsh"
#elif PROG_ENTITIES == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.fsh"
#endif