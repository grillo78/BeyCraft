#version 460 compatibility
#define GBUFFERS_WATER
#define fsh
#include "/lib/Header.glsl"


#if   PROG_WATER == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.fsh"
#elif PROG_WATER == G_SOLID
#include "/program/gbuffers/gbuffers_solid.fsh"
#elif PROG_WATER == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.fsh"
#endif