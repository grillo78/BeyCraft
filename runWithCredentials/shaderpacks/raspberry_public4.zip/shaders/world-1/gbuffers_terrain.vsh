#version 460 compatibility
#define GBUFFERS_TERRAIN
#define vsh
#include "/lib/Header.glsl"


#if   PROG_TERRAIN == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.vsh"
#elif PROG_TERRAIN == G_SOLID
#include "/program/gbuffers/gbuffers_solid.vsh"
#elif PROG_TERRAIN == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.vsh"
#endif