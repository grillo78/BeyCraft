#version 460 compatibility
#define GBUFFERS_SHADOW
#define vsh
#include "/lib/Header.glsl"


#include "/program/gbuffers/gbuffers_shadow.vsh"