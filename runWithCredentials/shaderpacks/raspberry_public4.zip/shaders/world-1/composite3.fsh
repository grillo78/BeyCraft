#version 460 compatibility
#define COMPOSITE 3
#define fsh
#include "/lib/Header.glsl"


#include "/program/composite/pre_post_0.fsh"