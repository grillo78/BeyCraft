#version 460 compatibility
#define GBUFFERS_BASIC
#define fsh
#include "/lib/Header.glsl"


#if   PROG_BASIC == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.fsh"
#elif PROG_BASIC == G_SOLID
#include "/program/gbuffers/gbuffers_solid.fsh"
#elif PROG_BASIC == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.fsh"
#endif