#version 460 compatibility
#define COMPOSITE 0
#define vsh
#include "/lib/Header.glsl"


#include "/program/composite/pre_shading_0.vsh"