#version 460 compatibility
#define GBUFFERS_WEATHER
#define vsh
#include "/lib/Header.glsl"


#if   PROG_WEATHER == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.vsh"
#elif PROG_WEATHER == G_SOLID
#include "/program/gbuffers/gbuffers_solid.vsh"
#elif PROG_WEATHER == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.vsh"
#endif