#version 460 compatibility
#define COMPOSITE 2
#define fsh
#include "/lib/Header.glsl"


#include "/program/composite/shading_1.fsh"