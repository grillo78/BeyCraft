#version 460 compatibility
#define COMPOSITE 3
#define vsh
#include "/lib/Header.glsl"


#include "/program/composite/pre_post_0.vsh"