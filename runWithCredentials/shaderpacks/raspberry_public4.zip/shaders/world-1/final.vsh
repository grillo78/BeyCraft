#version 460 compatibility
#define FINAL
#define vsh
#include "/lib/Header.glsl"


#include "/program/composite/post.vsh"