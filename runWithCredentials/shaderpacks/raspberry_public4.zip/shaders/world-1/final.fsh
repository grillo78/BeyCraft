#version 460 compatibility
#define FINAL
#define fsh
#include "/lib/Header.glsl"


#include "/program/composite/post.fsh"