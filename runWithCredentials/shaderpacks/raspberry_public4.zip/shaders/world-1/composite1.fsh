#version 460 compatibility
#define COMPOSITE 1
#define fsh
#include "/lib/Header.glsl"


/* DRAWBUFFERS:0 */

layout (location = 0) out vec4 colortex0write;
layout (location = 1) out vec4 colortex5write;


in vec2 texcoord;

flat in mat4 shadowViewMatrix;
flat in mat3 lightColors;
flat in mat2x3 sunVec;
flat in mat2x3 lightVec;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowModelView;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler3D depthtex2;
uniform int worldTime;

uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D noisetex;
uniform ivec2 eyeBrightnessSmooth;
uniform float rainStrength;
uniform float far;
uniform float frameTimeCounter;
uniform vec3 shadowLightPosition;
uniform vec3 upPosition;
uniform vec2 taaOffset;


uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform mat4 shadowProjection, shadowProjectionInverse;
uniform vec3 cameraPosition;
uniform float viewWidth, viewHeight;
uniform float sunAngle;

uniform int frameCounter;
uniform int isEyeInWater;


uniform vec2 pixel;


#include "/lib/Global.glsl"

#include "/lib/Utility/Space_Transformations.glsl"

#include "/lib/Fragment/BSDF.glsl"
#include "/lib/Utility/Mapping.glsl"
#include "/lib/Utility/Sampling_Patterns.glsl"
#include "/lib/Fragment/Shadows.glsl"

#include "/lib/Shared/Atmosphere_Params.glsl"
#include "/lib/Shared/Atmosphere_Compute.glsl"

vec2 rsi(vec3 position, vec3 direction, const float radius) {
	float PoD = dot(position, direction);
	float radiusSquared = radius * radius;

	float delta = PoD * PoD + radiusSquared - dot(position, position);
	if (delta < 0.0) return vec2(-1.0);
	      delta = sqrt(delta);

	return -PoD + vec2(-delta, delta);
}

float cubesmooth(float x) { return (x * x) * (3.0 - 2.0 * x); }
vec2 cubesmooth(vec2 x) { return (x * x) * (3.0 - 2.0 * x); }

float GetNoise(vec2 coord) {
	const vec2 madd = vec2(0.5 * noiseResInverse);
	vec2 whole = floor(coord);
	coord = whole + cubesmooth(coord - whole);
	
	return texture2D(noisetex, coord * noiseResInverse + madd).x;
}


#include "/lib/Shared/VClouds.glsl"

//#if (VCloud_TYPE == 2)
//#include "/lib/Shared/VCloudsold.glsl"
//#endif

void setupSolidAlbedo(inout gbuffer info) {
         if (info.forwardSolidMask) info.color[0] = info.color[0];
    else if (info.depthtex.y >= 1.0) info.color[0] = vec4(0.0, 0.0, 0.0, 1.0);
}

vec2 calculateRefraction(vec2 coord) {
    vec2 depthtex = vec2(
        texture2D(depthtex0, coord).x,
        texture2D(depthtex1, coord).y
    );
    if (depthtex.x >= depthtex.y || texture2D(colortex3, coord).a >= 1.0) return coord;
    if (isEyeInWater > 0.5) return coord;

    mat2x3 viewSpace  = mat2x3(
        calculateViewSpace(vec3(coord, depthtex.x)),
        calculateViewSpace(vec3(coord, depthtex.y))
    );

    vec3 normalBump = decodeNormal3x16(texture2D(colortex2, coord).x);
    vec3 normalFlat = mat3(gbufferModelViewInverse) * normalize(cross(dFdx(viewSpace[0]), dFdy(viewSpace[0])));

    float refractionDepth = min(distance(viewSpace[0], viewSpace[1]), 0.23);

    vec2  refractedCoord = coord + (normalBump.xz - normalFlat.xz) * refractionDepth / viewSpace[0].z;
    float refractedDepth = texture2D(depthtex1, refractedCoord).x;

    return depthtex.x > refractedDepth ? coord : refractedCoord;
}

void calculateDispersion(inout gbuffer info, in vec2 coord, material mat) {
    if (info.depthtex.x > info.depthtex.y) return;
    vec2 refraction = coord - texcoord;

    mat3x2 dispersionCoord = mat3x2(
        texcoord + refraction * 1.5,
        texcoord + refraction * 1.25,
        texcoord + refraction * 1.0
    );

    info.color[0].r = texture2D(colortex0, dispersionCoord[0]).r;
    info.color[0].g = texture2D(colortex0, dispersionCoord[1]).g;
    info.color[0].b = texture2D(colortex0, dispersionCoord[2]).b;
    if (isEyeInWater > 0.5) info.color[0].r *= 0.8;
    if (isEyeInWater > 0.5 && mat.water > 0.5) return;
}

float calculateBlockerDepth(vec3 shadowSpace, const float ditherSize, float dither) {
    #ifndef PCSS
        return 0.3;
    #endif

    const float maxBlockerDist = 32.0;
    const int   searchSamples  = 5;

    float searchScale  = 0.5 * maxBlockerDist / abs(shadowProjectionInverse[2].z);
    float spread       = tan(sunAngularRadius) * abs(shadowProjectionInverse[2].z) * shadowProjection[0].x;
    float searchRadius = spread * searchScale;

    float lod = log2(2.0 * shadowMapResolution * searchRadius / sqrt(searchSamples));

    float blockerDepth = 0.02;

    for (int i = 0; i < searchSamples; i++) {
        vec2 offset = fermatsSpiralGoldenN(i * ditherSize + dither, searchSamples * ditherSize) * searchRadius;
        vec3 shadowSpaceDistorted = distortShadowSpace(shadowSpace + vec3(offset, 0.0));

        float shadowDepth = shadowSpaceDistorted.z - texture2DLod(shadowtex1, shadowSpaceDistorted.xy, lod).x;

        blockerDepth += shadowDepth;
    }

    return min(blockerDepth / searchSamples * Shadow_Z_Stretch, searchScale) * spread * shadowMapResolution;
}

vec3 toNDC(vec3 pos){
	vec4 iProjDiag = vec4(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y, gbufferProjectionInverse[2].zw);
    vec3 p3 = pos * 2. - 1.;
    vec4 fragpos = iProjDiag * p3.xyzz + gbufferProjectionInverse[3];
    return fragpos.xyz / fragpos.w;
}

vec3 calculateSunlightVisibility(gbuffer info, material mat, scene spaces, vec3 shadowSpace, vec2 pattern) {
    const float ditherSize = pow2(16.0);
    float dither = ditherSize * pattern.y + 0.0;
    float hand = float(texture2D(depthtex1,texcoord.xy).r < 0.56);
    if (hand >= 1.0) return vec3(0.2) * pow2(info.lightmap[0].y);
    int   shadowQuality        = ShadowFilter_Quality;
    float inverseShadowQuality = 1.0 / float(shadowQuality);
    float filterSize           = calculateBlockerDepth(shadowSpace, ditherSize, dither);
    #ifdef SSS
    if (mat.translucent > 0.5) filterSize *= 2.0;
    #endif

    float shadow0     = 0.0;
    float shadow1     = 0.0;
    vec3  shadowColor = vec3(0.0);

    for (int i = 0; i < shadowQuality; i++) {
        vec2 offset = fermatsSpiralGoldenN(i * ditherSize + dither, shadowQuality * ditherSize) * filterSize / float(shadowMapResolution);

        vec3 shadowSpaceDistorted = distortShadowSpace(shadowSpace + vec3(offset, 0.0));

        shadow0     += calculateShadow(shadowtex0, shadowSpaceDistorted);
        shadow1     += calculateShadow(shadowtex1, shadowSpaceDistorted);
        shadowColor += texture2D(shadowcolor0, shadowSpaceDistorted.xy).xyz;
        //if (mat.translucent > 0.5) shadowColor *= 1.1;

    }
    shadow0     *= inverseShadowQuality;
    shadow1     *= inverseShadowQuality;
    shadowColor *= inverseShadowQuality;

    vec3 shadow = shadow0 + (1.0 - shadow0) * shadow1 * shadowColor;

    return shadow;
}

#include "/lib/Fragment/Shading.glsl"

const vec3  sRGBApproxWavelengths = vec3( 610.0, 549.0, 468.0 );

float radiation(in float temperature, in float wavelength)
{
    float e = exp(1.4387752e+7 / (temperature * wavelength));
    return 3.74177e+29 / (pow(wavelength, 5.0) * (e - 1.0));
}

vec3 radiation(in float t, in vec3 w)
{
    return vec3(
        radiation(t, w.x), 
        radiation(t, w.y), 
        radiation(t, w.z)
    );
}

void generateStars(inout vec3 color, in vec3 worldVector, in float freq, in float visibility) {
    if (visibility >= 1.0) return;
    if (worldTime <= 13400) return;
    if (worldTime >= 23000) return;
	vec3 SSunColor = lightColors[0];
	vec3 SMoonColor = lightColors[1];
	vec3 SLightColor = SSunColor + SMoonColor;

    
    const float minTemp =  3500.0;
    const float maxTemp =  50500.0;
    const float tempRange = maxTemp - minTemp;
    float frequency = freq * 20;

    const float res = 256.0;

    vec3 p  = worldVector * res;
    vec3 id = floor(p);
    vec3 fp = fract(p) - 0.5;

    float rp    = hash13(id);
    float stars = pow(max0(0.75 - length(fp)) * 1.4, 20.0);

    float starTemp = (sin(rp / frequency * PI * 16.0) * 0.5 + 0.5) * tempRange + minTemp;
    vec3  starEmission = radiation(starTemp, sRGBApproxWavelengths) * 1.0e-15;

    color.rgb += vec3(stars) * step(rp, frequency) * pow2(1.0) * starEmission * ((SSunColor * 0.0) + (SMoonColor * 0.8));
    color.rgb += vec3(0.0, 0.00002, 0.00008);
}

float max_depth3x3(sampler2D depthtex, vec2 coord, vec2 px) {

    float tl    = texture(depthtex, coord + vec2(-px.x, -px.y)).x;
    float tc    = texture(depthtex, coord + vec2(0.0, -px.y)).x;
    float tr    = texture(depthtex, coord + vec2(px.x, -px.y)).x;
    float tmin  = max(tl, max(tc, tr));

    float ml    = texture(depthtex, coord + vec2(-px.x, 0.0)).x;
    float mc    = texture(depthtex, coord).x;
    float mr    = texture(depthtex, coord + vec2(px.x, 0.0)).x;
    float mmin  = max(ml, max(mc, mr));

    float bl    = texture(depthtex, coord + vec2(-px.x, px.y)).x;
    float bc    = texture(depthtex, coord + vec2(0.0, px.y)).x;
    float br    = texture(depthtex, coord + vec2(px.x, px.y)).x;
    float bmin  = max(bl, max(bc, br));

    return max(tmin, max(mmin, bmin));
}


#include "/lib/Fragment/Nebula.glsl"

#include "/lib/Fragment/2D_Fog.glsl"
#include "/lib/Fragment/Volumetric_Fog.glsl"

void main() {
    mat2 coord = mat2(
        texcoord,
        calculateRefraction(texcoord)
    );
    vec2 pattern = calculateJitteredSamplingDistributors();
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);

    float depthtex     = texelFetch(depthtex1, fragCoord, 0).x;
    bool  depthOrder  = cameraPosition.y < vc_altitude;

    gbuffer  info   = calculateGbufferInformation(coord);
    material mat    = calculateMaterialMasks(info.specular, info.depthtex, info.materialIDs);
    scene    spaces = calculateSpaces(coord, info.depthtex);
    param    sky    = calculateSkyParameters(spaces.world[2], vec3(0.0, 1.0, 0.0));
    float underWaterDepth  = length(spaces.world[0]);

    vec3  space_Screen = vec3(texcoord - taaOffset * 0.5, depthtex);
    vec3  space_View   = calculateViewSpace(space_Screen);
    vec3  space_World  = mat3(gbufferModelViewInverse) * space_View + gbufferModelViewInverse[3].xyz;

    vec3 lightvec = normalize(shadowLightPosition);
    vec3 viewvec = normalize(space_View);
    vec3 upvec = normalize(upPosition);
    
    float taaDither 	= bayer64(ivec2(gl_FragCoord.st));
	taaDither 		= fract(taaDither + frameCounter%4);

    vec4 cloud_data;

    vec3 UWmultiplier = vec3(1.0);
    if (isEyeInWater >= 0.5 && mat.water <= 0.5) UWmultiplier = vec3(0.6, 0.9, 1.2) * 0.4;
    if (isEyeInWater >= 0.5 && mat.water >= 0.5) UWmultiplier *= vec3(0.8, 0.9, 1.4) * 0.4;
    //if (mat.water >= 0.5  && isEyeInWater <= 0.5 ) UWmultiplier *= 0.6;
    if (worldTime >= 12500 && worldTime <= 23000) UWmultiplier *= 0.002;
    
    const float cLOD    = sqrt(CLOUD_RENDER_LOD);
    vec2 scalecoord  = (texcoord-vec2(1.0-rcp(cLOD), 0.0))*cLOD;
    float d     = max_depth3x3(depthtex1, scalecoord, pixel*cLOD);

        if (clamp(scalecoord, -0.003, 1.003) == scalecoord && d>=1.0) {
            scalecoord      = clamp(scalecoord, 0.0, 1.0);
            vec3 viewpos    = calculateViewSpace(vec3(scalecoord, 1.0));
            vec3 viewvec    = normalize(viewpos);
            vec3 scenepos   = mat3(gbufferModelViewInverse) * viewpos;
            vec3 svec       = normalize(scenepos);

            //vc_render(info.color[2].rgb, viewvec, upvec, lightvec, cameraPosition, dot(viewvec, lightvec), taaDither, svec, scalecoord);
        } else {
            cloud_data = vec4(0.0, 0.0, 0.0, 1.0);
        }

    calculateDispersion(info, coord[1], mat);

    setupSolidAlbedo(info);
    calculateWaterShading(info, mat, spaces);
    drawTransparents(info, mat, spaces);
    //calculateSSS(info, mat, spaces);
    if (depthtex >= 1.0) {
    //applyAtmosphere(sky, info.color[0].rgb, spaces.world[2], sunVec[1], sky.sphereDepths[1], mat.land);
    //generateStars(info.color[0].rgb, spaces.world[2], 0.001, mat.land);
    //renderNebula(info.color[0].rgb, pattern, mat.land, spaces);
	//vc_render(info.color[0].rgb, viewvec, upvec, lightvec, cameraPosition, dot(viewvec, lightvec), taaDither, space_World, scalecoord, pattern);
    //AerialPerspective(info, spaces, spaces.view[0], mat);

    //info.color[0].rgb += VL().x * hgPhase(dot(lightvec, viewvec), 0.5) * 1.3 * VL_Strength * ((lightColors[0] + (lightColors[1] * vec3(0.5, 0.8, 1.5)) * 1.4)) * UWmultiplier;
    }
    calculateUnderwaterShading(info, mat, spaces);
    
    calculateShading2(info, mat, spaces, pattern, spaces.view[0]);
    
    //AerialPerspective(info, spaces, spaces.view[0], mat);

    //info.color[0].rgb += foggytime(info, spaces, spaces.view[0], mat);
    vec4  vl = calculateVolumetricLight(info, mat, spaces, pattern);
    vec3  scatter      = vl.rgb;
    float transmission = vl.a;
    float VLmultiplier = 1.0;
    float VLmultiplier2 = 1.0;

    if (depthtex < 1.0) {
    //if (cameraPosition.y > 55) info.color[0] += vec4(scatter, transmission) * VLmultiplier;
    }
    if (depthtex >= 1.0) {
    //info.color[0] += vec4(scatter * (1.0 + (rainStrength * 2)), transmission) * VLmultiplier * VLmultiplier2;
    }
    //if (cameraPosition.y <= 55) info.color[0].rgb += VL(pattern).x * hgPhase(dot(lightvec, viewvec), 0.5) * 2.0 * 0.5 * VL_Strength * ((lightColors[0] + (lightColors[1] * vec3(0.5, 0.8, 1.5)) * 1.4)) * UWmultiplier  * vec3(0.5 * VL_Red, 0.6 * VL_Green, 1.1 * VL_Blue);
    //if (depthtex <= 0.9999) {
    //calculateVolumetricLight(info, mat, spaces, pattern);
    //if (isEyeInWater > 0.5) info.color[0].rgb += VL(pattern).x * hgPhase(dot(lightvec, viewvec), 0.5) * 2.0 * 0.5 * VL_Strength * ((lightColors[0] + (lightColors[1] * vec3(0.5, 0.8, 1.5)) * 1.4)) * UWmultiplier  * vec3(0.5 * VL_Red, 0.6 * VL_Green, 1.1 * VL_Blue);
    //}
    colortex0write = info.color[0];
    //colortex5write = info.color[2];

}