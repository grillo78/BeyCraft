#version 460 compatibility
#define GBUFFERS_TEXTURED
#define fsh
#include "/lib/Header.glsl"


#if   PROG_TEXTURED_LIT == G_DISCARD
#include "/program/gbuffers/gbuffers_discard.fsh"
#elif PROG_TEXTURED_LIT == G_SOLID
#include "/program/gbuffers/gbuffers_solid.fsh"
#elif PROG_TEXTURED_LIT == G_FORWARD
#include "/program/gbuffers/gbuffers_forward.fsh"
#endif