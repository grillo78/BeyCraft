/* DRAWBUFFERS:01 */

layout (location = 0) out vec4 outAlbedo;
layout (location = 1) out vec4 outPassthrough;


void main() {
    outAlbedo      = vec4(0.0, 0.0, 0.0, 1.0);
    outPassthrough = vec4(0.0, 0.0, 0.0, 1.0);
}