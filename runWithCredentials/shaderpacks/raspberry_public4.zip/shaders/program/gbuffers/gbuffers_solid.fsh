/* DRAWBUFFERS:01 */

layout (location = 0) out vec4 outAlbedo;
layout (location = 1) out vec4 outPassthrough;


in vec3 color;
in vec3 worldSpace;
in vec3 viewSpace;
in vec2 texcoord;
in vec2 vertexLightmaps;
varying vec4 lightmapCoord;
varying vec3 normalff;

flat in mat3 tbnMatrixWorld;
flat in mat3 tbnMatrixView;
flat in int materialIDs;

uniform sampler2D texture;
uniform sampler2D normals;
uniform sampler2D specular;
uniform sampler2D noisetex;
uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform float viewWidth, viewHeight;
uniform int frameCounter;
uniform vec2 pixel;
uniform vec4 entityColor;
uniform float rainStrength;
uniform int terrainIconSize;
varying vec3 viewPos;


//vec2 pixel = 1.0 / vec2(viewWidth, viewHeight);


#include "/lib/Utility/Temporal.glsl"

#include "/lib/Utility/Sampling_Patterns.glsl"

float iconsize = 2.*float(terrainIconSize);
vec2 u = floor(texcoord.st*iconsize);

vec4 textureWrap(sampler2D t, vec2 v){
	v = (u+fract(v*iconsize))/iconsize;
	return texture2D(t,v);
}

vec4 getAlbedo(vec2 coord) {
    vec4 albedo     = texture2D(texture, coord);
         albedo.rgb = toLinear(albedo.rgb * color);
    return albedo;
}

vec4 getTangentNormals(vec2 coord) {
    vec4 normal = texture2D(normals,  coord) * 2.0 - 1.0;
    return normal;
}

vec3 calculateSpecularMaps(vec2 coord) {
    #ifdef LabPBR_Emissive
    vec3 specular = texture2D(specular, coord).rga;
    #else
    vec3 specular = texture2D(specular, coord).rgb;
    #endif
 
    #ifdef LabPBR_Emissive
    specular *= vec3(glossy_reflectiveness, metalic_reflectiveness, specular.b * (specular.b == 1.0 ? 0.0: 1.0));
    #else
    specular *= vec3(glossy_reflectiveness, metalic_reflectiveness, specular.b);
    #endif
    //if (specular.r < 0.15 && specular.r > 0.01) specular.r *= 15.0;
    //if (specular.g <= 0.2) specular.g *= 15.0;
    return specular;
}

vec2 calculateLightmaps(vec3 normalTex, vec3 normal, vec2 pattern) {
    vec2 lightmaps   = 16.0 - min(vec2(15.0), (vertexLightmaps - 0.5 / 16.0) * 16.0 * 16.0 / 15.0);
	     lightmaps   = pow2(clamp01(1.0 - pow4(lightmaps / 16.0))) / (1.0 + pow(lightmaps, vec2(2.0, 1.5)));
         lightmaps.x = mix(lightmaps.x, 0.4, float(materialIDs == 3));

    return sqrt(lightmaps) + pattern.x / vec2(31,63);
}

	vec2 directLightmap(vec2 lightmap, vec3 screenGeometryNormal, vec3 screenTextureNormal, vec2 pattern) {
		vec3 xtan = dFdx(viewPos.xyz);
		vec3 ytan = dFdy(viewPos.xyz);
		float NdotL1 = clamp(dot(
		  normalize(xtan * dFdx(lightmap.x) + ytan * dFdy(lightmap.x)),
		  screenTextureNormal), 0.0, 1.0
		);
		if(isnan(NdotL1)) NdotL1 = 0.5;
		if (length(NdotL1) <= 0.5) NdotL1 *= 2.0; 
        
		float NdotL2 = clamp01(dot(
		  normalize(xtan * dFdx(lightmap.y) + ytan * dFdy(lightmap.y)),
		  screenTextureNormal)
		);
		if(isnan(NdotL2)) NdotL2 = 0.5;
		float dotN	 = clamp01(dot(
		  screenGeometryNormal,
		  screenTextureNormal)
		);
		if(isnan(dotN)) dotN = 0.5;
        
		vec2	direct = vec2(
			mix(NdotL1 * pattern.x, dotN, .35),
			mix(NdotL2, dotN, .5)
		);

		vec2 lighting = lightmap * direct;
		return mix(lighting, vec2(1.0 / lightmapCoeff), powf(lightmap, 6.0));
	}


void main() {
    float shadowed    = 1.0;
    vec2 coord     = texcoord;

    vec2 pattern   = calculateJitteredSamplingDistributors();

    vec4 albedo    = getAlbedo(coord);
    vec4 normalTex = getTangentNormals(coord);
    vec3 specular  = calculateSpecularMaps(coord);
    vec3 normal    = normalize((normalTex.xyz) * tbnMatrixWorld);
    vec2 lightmaps = calculateLightmaps(normalTex.xyz, normal, pattern);
	vec4 bump = textureWrap(normals, coord);
    albedo.rgb *= (color.rgb + (entityColor.rgb * vec3(1.0, 0.0, 0.0) * 15));
	vec3 normalTangentSpace = normalize((bump.xyz * 2.0 - 1.0) * tbnMatrixView);
	vec2 lightmapT = (lightmapCoord.xy - (lightmapCoeff - 1.0)) * lightmapCoeff;

    lightmaps = directLightmap(lightmapT, normalff, normalTangentSpace, pattern);
    lightmaps.x = pow(lightmaps.x + pattern.x / 11,1.5);
    lightmaps.y = pow(lightmaps.y + pattern.x / 63,1.5);

    #ifdef GBUFFERS_BASIC
    albedo.rgb = vec3(selectionBlockR, selectionBlockG, selectionBlockB) + vec3(0.01);
    albedo.a = selectionBlockA;
    /* DRAWBUFFERS:0 */
    #endif

    #ifdef GBUFFERS_ARMOR_GLINT
    //albedo.rgb = vec3(0.0);
    lightmaps = vec2(0.0);
    albedo.rgb *= 13.0;
    //discard;
    #endif
    if (materialIDs == 4) lightmaps = calculateLightmaps(normalTex.xyz, normal, pattern);
    lightmaps.x *= 0.7;

    #ifdef GBUFFERS_HAND
    //lightmaps = vec2(0.0);
    lightmaps = calculateLightmaps(normalTex.xyz, normal, pattern);
    #endif

    #ifdef GBUFFERS_ENTITIES
    lightmaps = calculateLightmaps(normalTex.xyz, normal, pattern);
    #endif
    #ifdef GBUFFERS_BLOCK
    lightmaps = calculateLightmaps(normalTex.xyz, normal, pattern);
    #endif
    #ifdef GBUFFERS_SPIDEREYES
    //albedo.rgb = vec3(1.0, 0.0, 0.0) * 1000;
    #endif

    #ifdef GBUFFERS_TEXTURED
    albedo.rgb *= 100;
    #endif


    outAlbedo      = albedo;
    outPassthrough = vec4(
        encodeNormal3x16(normal),
        encode3x16(vec3(lightmaps, encodeMaterialIDs(materialIDs))),
        encode3x16(specular),
        shadowed * 0.5 + 0.5
    );
}