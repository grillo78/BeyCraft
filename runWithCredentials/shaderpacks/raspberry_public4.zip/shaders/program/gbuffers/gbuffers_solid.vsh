attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

out vec3 color;
out vec3 worldSpace;
out vec3 viewSpace;
out vec2 texcoord;
out vec2 vertexLightmaps;
varying vec4 lightmapCoord;
varying vec3 normalff;

flat out mat3 tbnMatrixWorld;
flat out mat3 tbnMatrixView;
flat out int materialIDs;

uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform vec3 cameraPosition;
uniform float viewWidth, viewHeight;
uniform int frameCounter;
uniform float frameTimeCounter;
uniform float rainStrength;
varying vec3 viewPos;


#include "/lib/Utility/Mat_IDs.glsl"
#include "/lib/Utility/Space_Transformations.glsl"


void calculateVertexLightmaps(out vec2 vertexLightmaps) {
    vertexLightmaps = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
}

void calculateTBN(out mat3 viewTBN, out mat3 worldTBN) {
	vec3 normal   = normalize(gl_NormalMatrix * gl_Normal);
	vec3 tangent  = normalize(gl_NormalMatrix * (at_tangent.xyz));

         viewTBN  = transpose(mat3(tangent, normalize(cross(tangent, normal)), normal));

         normal   = mat3(gbufferModelViewInverse) * normal;
         tangent  = mat3(gbufferModelViewInverse) * tangent;

	vec3 binormal = normalize(cross(tangent, normal));

         worldTBN = transpose(mat3(tangent, binormal, normal));
}

void calculateMatIDs(out int materialIDs) {
    int IDs  = 0;
    float id = mc_Entity.x;

    // Water
    if (id == WATER_FLOWING || id == WATER_STILL) IDs = 1;

    // Translucent
    if (id == LEAVES || id == VINES || id == TALLGRASS || id == DANDELION || id == ROSE ||
        id == WHEAT || id == LILYPAD || id == LEAVES2 || id == NEWFLOWERS || id == NETHER_WART ||
        id == DEAD_BUSH || id == CARROT || id == POTATO || id == COBWEB || id == SUGAR_CANE ||
        id == BROWN_SHROOM || id == RED_SHROOM || id == TALLERGRASS) IDs = 2;

    // Emitters
    if (id == TORCH || id == FIRE || id == LAVAFLOWING || id == LAVASTILL || id == GLOWSTONE ||
        id == SEA_LANTERN || id == LAMP_ON || id == BEACON || id == END_ROD || id == Jack || id == CAMPFIRE || id == LANTERN) IDs = 3;

    if (id == DOOR) IDs = 4;

    materialIDs = IDs;
}

	vec3 calcWave(in vec3 pos, in float fm, in float mm, in float ma, in float f0, in float f1, in float f2, in float f3, in float f4, in float f5) {
		float pi2wt = PI * 2.0 * (frameTimeCounter * 36.0);

		vec3 ret;
		float magnitude, d0, d1, d2, d3;
		magnitude = sin(pi2wt*fm + pos.x*0.5 + pos.z*0.5 + pos.y*0.5) * mm + ma;

		d0 = sin(pi2wt*f0);
		d1 = sin(pi2wt*f1);
		d2 = sin(pi2wt*f2);

		ret.x = sin(pi2wt*f3 + d0 + d1 - pos.x + pos.z + pos.y) * magnitude;
		ret.z = sin(pi2wt*f4 + d1 + d2 + pos.x - pos.z + pos.y) * magnitude;
		ret.y = sin(pi2wt*f5 + d2 + d0 + pos.z + pos.y - pos.y) * magnitude;

		return ret;
	}

	vec3 calcMove(in vec3 pos, in float f0, in float f1, in float f2, in float f3, in float f4, in float f5, in vec3 amp1, in vec3 amp2) {
		vec3 move1 = calcWave(pos      , 0.0027, 0.0400, 0.0400, 0.0127, 0.0089, 0.0114, 0.0063, 0.0224, 0.0015) * amp1;
		vec3 move2 = calcWave(pos+move1, 0.0348, 0.0400, 0.0400, f0, f1, f2, f3, f4, f5) * amp2;

		return move1+move2;
	}

	void displaceVertex(inout vec4 position, in float lightmap) {
		bool istopv = gl_MultiTexCoord0.t < mc_midTexCoord.t;

		float underCover = clamp01(pow(lightmap, 15.0) * 2.0);

		float wavyMult  = 1.0;

		vec3 worldpos = position.xyz + cameraPosition;

		// Waving vines / cobwebs / plants
		vec3 waving = calcMove(worldpos.xyz, 0.0040, 0.0064, 0.0043, 0.0035, 0.0037, 0.0041,vec3(1.0,0.2,1.0), vec3(0.5,0.1,0.5)) * underCover * wavyMult;

		// Waving leaves / tall flowers
		if ( mc_Entity.x == LEAVES || mc_Entity.x == LEAVES2 || mc_Entity.x == NEWFLOWERS )
			position.xyz += waving * 0.5;

		// Waving plants
		if ( mc_Entity.x == VINES )
			position.xyz += waving * 0.1;

		// Waving cobwebs
		if ( mc_Entity.x == COBWEB )
			position.xyz += waving * 0.1;

		// Waving plants
		if (istopv) {
			if ( mc_Entity.x == TALLGRASS || mc_Entity.x == DANDELION || mc_Entity.x == ROSE || mc_Entity.x == WHEAT || mc_Entity.x == FIRE ||
					 mc_Entity.x == NETHER_WART || mc_Entity.x == DEAD_BUSH || mc_Entity.x == CARROT || mc_Entity.x == POTATO)
				position.xyz += waving * 0.0;
		}
	}

    const float Wind_Direction_Degrees = 45.0;

    const float windDirectionRad  = radians(Wind_Direction_Degrees);
    const vec2  windDirection     = vec2(sin(windDirectionRad), cos(windDirectionRad));

void calculateVertexDisplacement(inout vec3 viewSpace, in vec3 worldSpace, in vec2 lightmaps, in int matIDs) {

    bool  topVertex = gl_MultiTexCoord0.t < mc_midTexCoord.t;
    float ID = mc_Entity.x;
    float time = frameTimeCounter * 2.0;

    int waveType = 0;
    if (ID == TALLGRASS ||ID == ROSE || ID == WHEAT || ID == NETHER_WART || ID == CARROT ||
        ID == POTATO || ID == BROWN_SHROOM || ID == RED_SHROOM)
        waveType = 1;
	
    float pi2wt = PI * 2.0 * (frameTimeCounter * 36.0);

    vec3 waves  = vec3(0.0);
         waves += sin((dot(worldSpace.xz, windDirection) + time) * 1.0) * vec3(windDirection.x, 0.0, windDirection.y) * 0.2;
         waves += cos((dot(worldSpace.yz, windDirection) + time) * 1.5) * vec3(windDirection.x, 0.0, windDirection.y) * 0.15;
         waves += sin((dot(worldSpace.xz, windDirection) + time) * 1.2) * vec3(windDirection.x, 0.0, windDirection.y) * 0.1;
         waves += cos((dot(worldSpace.xy, windDirection) + time) * 1.2) * vec3(windDirection.x, 0.0, windDirection.y) * 0.05;
         waves += sin((dot(worldSpace.xz, windDirection) + time) * 1.2) * vec3(windDirection.x, 0.0, windDirection.y) * 0.02;
         waves *= lightmaps.y;

    if (waveType == 1)
        viewSpace = viewSpace - mat3(gbufferModelView) * (waves * float(topVertex)) * 0.35;
    else
        viewSpace = viewSpace - mat3(gbufferModelView) * (waves * 0.5) * 0.0;
}

void projectViewSpace(out vec4 gl_Position, vec3 viewSpace) {
    #ifdef GBUFFERS_HAND
    //gl_Position = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
    //gl_Position = vec4(projMAD(gbufferProjection, viewSpace), (viewSpace.z * 2) * (gbufferProjection[2].w * 0.5));
    //gl_Position.xy = temporalJitter() * gl_Position.w + gl_Position.xy;
    gl_Position = ftransform();
    gl_Position += vec4(Hand_Horizontal, Hand_Height, 0.0, 0.0);
    //gl_Position.xy = temporalJitter() * gl_Position.w + gl_Position.xy;

    return;
    #endif
    vec4 position = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
    lightmapCoord = gl_TextureMatrix[1] * gl_MultiTexCoord1;
    #ifdef Wind
    //displaceVertex(position, lightmapCoord.y);
    #endif

	gl_Position    = vec4(projMAD(gbufferProjection, viewSpace), viewSpace.z * gbufferProjection[2].w);
    
	//gl_Position    = vec4(projMAD(gbufferProjection, viewSpace), viewSpace.z * gbufferProjection[2].w);
    #ifdef TAA
    gl_Position.xy = temporalJitter() * gl_Position.w + gl_Position.xy;
    #endif
}


void main() {
    color     = gl_Color.rgb;
    texcoord   = gl_MultiTexCoord0.xy;
    viewSpace  = transMAD(gl_ModelViewMatrix, gl_Vertex.xyz);
    worldSpace = mat3(gbufferModelViewInverse) * viewSpace + cameraPosition;
	normalff = normalize(gl_NormalMatrix * gl_Normal);
  	lightmapCoord = gl_TextureMatrix[1] * gl_MultiTexCoord1;
	vec4 viewpos = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
	vec4 locposition = gl_ModelViewMatrix * gl_Vertex;
	viewPos = locposition.xyz;
    calculateVertexLightmaps(vertexLightmaps);
    calculateMatIDs(materialIDs);
    calculateTBN(tbnMatrixView, tbnMatrixWorld);

    #ifdef Wind
    calculateVertexDisplacement(viewSpace, worldSpace, vertexLightmaps, materialIDs);
    #endif

    projectViewSpace(gl_Position, viewSpace);
}