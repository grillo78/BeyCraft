attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;


out vec3 color;
out vec3 worldSpace;
out vec3 viewSpace;
out vec2 texcoord;
out vec2 vertexLightmaps;
varying vec4 lightmapCoord;
flat out mat4 shadowViewMatrix;

flat out vec3 normal;
flat out int materialIDs;
flat out mat3 tbnMatrixView;


uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView, shadowModelViewInverse;
uniform vec3 cameraPosition;

uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform float viewWidth, viewHeight;
uniform int frameCounter;
uniform float frameTimeCounter;
uniform float rainStrength;

#include "/lib/Utility/Space_Transformations.glsl" 

#include "/lib/Vertex/Shadow_Transform.glsl"

#include "/lib/Fragment/Shadows.glsl"
#include "/lib/Utility/Mat_IDs.glsl"




void calculateTBN(out mat3 viewTBN, out mat3 worldTBN) {
	vec3 normal   = normalize(gl_NormalMatrix * gl_Normal);
	vec3 tangent  = normalize(gl_NormalMatrix * at_tangent.xyz);

         viewTBN  = transpose(mat3(tangent, normalize(cross(tangent, normal)), normal));

         normal   = mat3(gbufferModelViewInverse) * normal;
         tangent  = mat3(gbufferModelViewInverse) * tangent;

	vec3 binormal = normalize(cross(tangent, normal));

         worldTBN = transpose(mat3(tangent, binormal, normal));
}

void calculateMatIDs(out int materialIDs) {
    int IDs  = 0;
    float id = mc_Entity.x;

    // Water
    if (id == WATER_FLOWING || id == WATER_STILL) IDs = 1;

    // Translucent
    if (id == LEAVES || id == VINES || id == TALLGRASS || id == DANDELION || id == ROSE ||
        id == WHEAT || id == LILYPAD || id == LEAVES2 || id == NEWFLOWERS || id == NETHER_WART ||
        id == DEAD_BUSH || id == CARROT || id == POTATO || id == COBWEB || id == SUGAR_CANE ||
        id == BROWN_SHROOM || id == RED_SHROOM || id == TALLERGRASS) IDs = 2;

    // Emitters
    if (id == TORCH || id == FIRE || id == LAVAFLOWING || id == LAVASTILL || id == GLOWSTONE ||
        id == SEA_LANTERN || id == LAMP_ON || id == BEACON || id == END_ROD || id == Jack || id == CAMPFIRE || id == LANTERN) IDs = 3;

    materialIDs = IDs;
}


	vec3 calcWave(in vec3 pos, in float fm, in float mm, in float ma, in float f0, in float f1, in float f2, in float f3, in float f4, in float f5) {
		float pi2wt = PI * 2.0 * (frameTimeCounter * 36.0);

		vec3 ret;
		float magnitude, d0, d1, d2, d3;
		magnitude = sin(pi2wt*fm + pos.x*0.5 + pos.z*0.5 + pos.y*0.5) * mm + ma;

		d0 = sin(pi2wt*f0);
		d1 = sin(pi2wt*f1);
		d2 = sin(pi2wt*f2);

		ret.x = sin(pi2wt*f3 + d0 + d1 - pos.x + pos.z + pos.y) * magnitude;
		ret.z = sin(pi2wt*f4 + d1 + d2 + pos.x - pos.z + pos.y) * magnitude;
		ret.y = sin(pi2wt*f5 + d2 + d0 + pos.z + pos.y - pos.y) * magnitude;

		return ret;
	}

	vec3 calcMove(in vec3 pos, in float f0, in float f1, in float f2, in float f3, in float f4, in float f5, in vec3 amp1, in vec3 amp2) {
		vec3 move1 = calcWave(pos      , 0.0027, 0.0400, 0.0400, 0.0127, 0.0089, 0.0114, 0.0063, 0.0224, 0.0015) * amp1;
		vec3 move2 = calcWave(pos+move1, 0.0348, 0.0400, 0.0400, f0, f1, f2, f3, f4, f5) * amp2;

		return move1+move2;
	}

    
    const float Wind_Direction_Degrees = 45.0;

    const float windDirectionRad  = radians(Wind_Direction_Degrees);
    const vec2  windDirection     = vec2(sin(windDirectionRad), cos(windDirectionRad));


void calculateVertexDisplacement(inout vec3 viewSpace, in vec3 worldSpace, in vec2 lightmaps, in int matIDs) {

    bool  topVertex = gl_MultiTexCoord0.t < mc_midTexCoord.t;
    float ID = mc_Entity.x;
    float time = frameTimeCounter * 2.0;

    int waveType = 0;
    if (ID == TALLGRASS ||ID == ROSE || ID == WHEAT || ID == NETHER_WART || ID == CARROT ||
        ID == POTATO || ID == BROWN_SHROOM || ID == RED_SHROOM)
        waveType = 1;
	
    float pi2wt = PI * 2.0 * (frameTimeCounter * 36.0);

    vec3 waves  = vec3(0.0);
         waves += sin((dot(worldSpace.xz, windDirection) + time) * 1.0) * vec3(windDirection.x, 0.0, windDirection.y) * 0.2;
         waves += cos((dot(worldSpace.yz, windDirection) + time) * 1.5) * vec3(windDirection.x, 0.0, windDirection.y) * 0.15;
         waves += sin((dot(worldSpace.xz, windDirection) + time) * 1.2) * vec3(windDirection.x, 0.0, windDirection.y) * 0.1;
         waves += cos((dot(worldSpace.xy, windDirection) + time) * 1.2) * vec3(windDirection.x, 0.0, windDirection.y) * 0.05;
         waves += sin((dot(worldSpace.xz, windDirection) + time) * 1.2) * vec3(windDirection.x, 0.0, windDirection.y) * 0.02;
         waves *= lightmaps.y;

    if (waveType == 1)
        viewSpace = viewSpace - mat3(gbufferModelView) * (waves * float(topVertex)) * 0.35;
    else
        viewSpace = viewSpace - mat3(gbufferModelView) * (waves * 0.5) * 0.0;
}

void projectShadowViewSpace(out vec4 gl_Position, vec3 worldSpace) {
    //vec4 position = (gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex) - (cameraPosition, 0.0);
    //lightmapCoord = gl_TextureMatrix[1] * gl_MultiTexCoord1;
    //displaceVertex(position, lightmapCoord.y);

	gl_Position = vec4(projMAD(shadowProjection, transMAD(calculateShadowViewMatrix(), worldSpace)), worldSpace.z * shadowProjection[2].w + shadowProjection[3].w);
    //gl_Position = shadowProjection * gbufferModelView * position;
    gl_Position.xyz = gl_Position.xyz / vec3(vec2(distortionFactor(gl_Position.xy)), Shadow_Z_Stretch);
    //gl_Position.xyz = gl_Position.xyz - cameraPosition;
    
}

void main() {
    #ifndef TallGrass_Shadows
	if (mc_Entity.x == 31.0 || mc_Entity.x == 175.0 ) { // Disable shadows for tall grass
		gl_Position = vec4(-1.0);
		return;
	}
    #endif
    color           = gl_Color.rgb;
    viewSpace  = transMAD(gl_ModelViewMatrix, gl_Vertex.xyz);
    worldSpace = transMAD(-shadowModelViewInverse, viewSpace) - cameraPosition;
    #ifdef MC_GL_VENDOR_ATI
    worldSpace = transMAD(-shadowModelViewInverse, viewSpace);
    #endif

    texcoord        = gl_MultiTexCoord0.xy;
    normal          = normalize(gl_NormalMatrix * gl_Normal);
    #ifdef Wind
    calculateVertexDisplacement(viewSpace, vec3(-worldSpace.x, -worldSpace.y, -worldSpace.z), vec2(1.0), materialIDs);
    #endif

    calculateMatIDs(materialIDs);
    projectShadowViewSpace(gl_Position, transMAD(shadowModelViewInverse, viewSpace));
}