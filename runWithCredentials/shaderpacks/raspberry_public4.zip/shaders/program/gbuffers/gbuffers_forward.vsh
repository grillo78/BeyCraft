attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

out vec3 color;
out vec3 worldSpace;
out vec3 viewSpace;
out vec2 texcoord;
out vec2 vertexLightmaps;

flat out mat3 tbnMatrixWorld;
flat out mat3 tbnMatrixView;
flat out int materialIDs;

uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform vec3 cameraPosition;
uniform float viewWidth, viewHeight;
uniform int frameCounter;
uniform float rainStrength;


#include "/lib/Utility/Mat_IDs.glsl"
#include "/lib/Utility/Space_Transformations.glsl"


void projectViewSpace(out vec4 gl_Position, vec3 viewSpace) {
	gl_Position    = vec4(projMAD(gbufferProjection, viewSpace), viewSpace.z * gbufferProjection[2].w);
    #ifdef TAA
    gl_Position.xy = gl_Position.xy;
    #endif
}

void calculateVertexLightmaps(out vec2 vertexLightmaps) {
    vertexLightmaps = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
}

void calculateTBN(out mat3 viewTBN, out mat3 worldTBN) {
	vec3 normal   = normalize(gl_NormalMatrix * gl_Normal);
	vec3 tangent  = normalize(gl_NormalMatrix * (at_tangent.xyz / at_tangent.w));

         viewTBN  = transpose(mat3(tangent, normalize(cross(tangent, normal)), normal));

         normal   = mat3(gbufferModelViewInverse) * normal;
         tangent  = mat3(gbufferModelViewInverse) * tangent;

	vec3 binormal = normalize(cross(tangent, normal));

         worldTBN = transpose(mat3(tangent, binormal, normal));
}

void calculateMatIDs(out int materialIDs) {
    int IDs  = 0;
    float id = mc_Entity.x;

    // Water
    if (id == WATER_FLOWING || id == WATER_STILL) IDs = 1;

    // Translucent
    if (id == LEAVES || id == VINES || id == TALLGRASS || id == DANDELION || id == ROSE ||
        id == WHEAT || id == LILYPAD || id == LEAVES2 || id == NEWFLOWERS || id == NETHER_WART ||
        id == DEAD_BUSH || id == CARROT || id == POTATO || id == COBWEB || id == SUGAR_CANE ||
        id == BROWN_SHROOM || id == RED_SHROOM || id == TALLERGRASS) IDs = 2;

    // Emitters
    if (id == TORCH || id == FIRE || id == LAVAFLOWING || id == LAVASTILL || id == GLOWSTONE ||
        id == SEA_LANTERN || id == LAMP_ON || id == BEACON || id == END_ROD || id == Jack || id == CAMPFIRE || id == LANTERN) IDs = 3;
    
    //Leaves

    materialIDs = IDs;
}



void main() {
    color      = gl_Color.rgb;
    texcoord   = gl_MultiTexCoord0.xy;
    viewSpace  = transMAD(gl_ModelViewMatrix, gl_Vertex.xyz);
    worldSpace = mat3(gbufferModelViewInverse) * viewSpace + cameraPosition;

    calculateVertexLightmaps(vertexLightmaps);
    calculateMatIDs(materialIDs);
    calculateTBN(tbnMatrixView, tbnMatrixWorld);

    projectViewSpace(gl_Position, viewSpace);
}