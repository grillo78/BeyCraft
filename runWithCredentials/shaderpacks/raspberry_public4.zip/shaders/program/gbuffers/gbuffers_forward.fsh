/* DRAWBUFFERS:32 */

layout (location = 0) out vec4 outAlbedo;
layout (location = 1) out vec4 outPassthrough;


in vec3 color;
in vec3 worldSpace;
in vec3 viewSpace;
in vec2 texcoord;
in vec2 vertexLightmaps;

flat in mat3 tbnMatrixWorld;
flat in mat3 tbnMatrixView;
flat in int materialIDs;

uniform sampler2D depthtex0;

uniform sampler2D texture;
uniform sampler2D normals;
uniform sampler2D specular;
uniform sampler2D noisetex;
uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform float viewWidth, viewHeight;
uniform float frameTimeCounter;
uniform int frameCounter;
uniform vec2 pixel;
uniform float rainStrength;

//const vec2 pixel = 1.0 / vec2(viewWidth, viewHeight);


#include "/lib/Utility/Temporal.glsl"

#include "/lib/Utility/Sampling_Patterns.glsl"
#include "/lib/Fragment/Water_Waves.glsl"


vec4 getAlbedo(vec2 coord) {
    if (materialIDs == 1) return vec4(1.0, 1.0, 1.0, 0.5);

    vec4 albedo     = texture2D(texture, coord);
         albedo.rgb = toLinear(albedo.rgb * color.rgb);
    
    return albedo;
}

vec3 clampNormal(const vec3 n, const vec3 v) {
    float NoV = clamp(dot(n, -v), 0.0, 1.0);
    return normalize(NoV * v + n);
}

vec4 getTangentNormals(vec2 coord) {
    vec4 normal = texture2D(normals,  coord) * 2.0 - 1.0;
    calculateProceduralNormals(normal);
    return normal;
}

vec3 calculateSpecularMaps(vec2 coord) {
    #ifdef LabPBR_Emissive
    vec3 specular = texture2D(specular, coord).rga;
    #else
    vec3 specular = texture2D(specular, coord).rgb;
    #endif
 
    #ifdef LabPBR_Emissive
    specular *= vec3(glossy_reflectiveness, metalic_reflectiveness, specular.b * (specular.b == 1.0 ? 0.0: 1.0));
    #else
    specular *= vec3(glossy_reflectiveness, metalic_reflectiveness, specular.b);
    #endif
    //if (specular.r < 0.15 && specular.r > 0.01) specular.r *= 15.0;
    //if (specular.g <= 0.2) specular.g *= 15.0;
    return specular;
}
vec2 calculateLightmaps(vec3 normalTex, vec3 normal, vec2 pattern) {
    vec2 lightmaps   = 16.0 - min(vec2(15.0), (vertexLightmaps - 0.5 / 16.0) * 16.0 * 16.0 / 15.0);
	     lightmaps   = pow2(clamp01(1.0 - pow4(lightmaps / 16.0))) / (1.0 + pow(lightmaps, vec2(2.0, 1.5)));
         lightmaps.x = mix(lightmaps.x, 0.4, float(materialIDs == 3));

    return sqrt(lightmaps) + pattern.x / vec2(31,63);
}


void main() {
    vec2 coord     = texcoord;

    vec2 pattern   = calculateJitteredSamplingDistributors();
    float depth    = texture2D(depthtex0, texcoord).x;
    vec4 albedo    = getAlbedo(coord);
    vec4 normalTex = getTangentNormals(coord);
    vec3 specular  = calculateSpecularMaps(coord);
    vec3 normal    = normalize((normalTex.xyz) * tbnMatrixWorld);
    vec2 lightmaps = calculateLightmaps(normalTex.xyz, normal, pattern);

    #ifdef GBUFFERS_TEXTURED
    albedo.rgb = texture2D(texture, texcoord).rgb * 0.2;
    albedo.rgb *= color.rgb;
    /* DRAWBUFFERS:01 */

    //if (depth < 0.5) albedo.rgb = 0.0;
    #endif



    #ifdef GBUFFERS_SPIDEREYES
    //albedo.rgb = vec3(1.0, 0.0, 0.0) * 1000;
    #endif



    outAlbedo      = albedo;
    outPassthrough = vec4(
        encodeNormal3x16(normal),
        encode3x16(vec3(lightmaps, encodeMaterialIDs(materialIDs))),
        encode3x16(specular),
        1.0
    );
}