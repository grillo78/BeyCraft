/* DRAWBUFFERS:01 */

layout (location = 0) out vec4 outAlbedo;
layout (location = 1) out vec4 outPassthrough;

in vec3 color;
in vec3 viewSpace;
in vec3 worldSpace;
in vec2 texcoord;
in vec2 vertexLightmaps;

flat in vec3 normal;
flat in int materialIDs;
flat in mat3 tbnMatrixView;
flat in mat4 shadowViewMatrix;


uniform sampler2D texture;
uniform sampler2D specular;
uniform sampler2D noisetex;
uniform mat4 gbufferModelView; 
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView, gbufferPreviousProjection;
uniform vec3 shadowLightPosition;
uniform vec3 cameraPosition, previousCameraPosition;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform int frameCounter;
uniform float frameTimeCounter;
uniform float viewWidth, viewHeight;
uniform float rainStrength;

#include "/lib/Utility/Noise.glsl"

#include "/lib/Utility/Space_Transformations.glsl" 
#include "/lib/Utility/Mapping.glsl"
#include "/lib/Fragment/Water_Waves.glsl"

vec2 computeCameraVelocity(in vec3 worldSpace) {
    vec3 projection =(cameraPosition - previousCameraPosition) + worldSpace;
         projection = mat3(gbufferPreviousModelView) * projection;
         projection = (diagonal3(gbufferPreviousProjection) * projection + gbufferPreviousProjection[3].xyz) / -projection.z * 0.5 + 0.5;

    return (texcoord - projection.xy);
}

vec4 getAlbedo(vec2 coord) {
    if (materialIDs == 1) return vec4(0.5);
    vec4 albedo     = texture2D(texture, coord);
         albedo.rgb = albedo.rgb * color;
    return albedo;
}

void main() {
    vec4 albedo   = getAlbedo(texcoord);

    #ifdef GBUFFERS_BASIC
    albedo.rgb = vec3(selectionBlockR, selectionBlockG, selectionBlockB);
    albedo.a = 1.0;
    #endif

    #ifdef GBUFFERS_SPIDEREYES
    //albedo.rgb = vec3(1.0, 0.0, 0.0) * 1000;
    #endif

    if (materialIDs == 1) {
        const float depth = 1.0;
        vec3 lightVec = mat3(gbufferModelViewInverse) * normalize(shadowLightPosition);
        //vec3 projection = (cameraPosition - previousCameraPosition) + worldSpace;

		vec3  flatRefractVector = refract(-lightVec, vec3(0.0, 1.0, 0.0), 0.75);
		float surfDistUp        = -depth * abs(lightVec.y);

		vec3 rc = flatRefractVector * (surfDistUp / flatRefractVector.y);

        vec3 samplePos     = worldSpace - rc;

        vec3 refractVector = refract(-lightVec, -calculateProceduralNormalsFlat(samplePos), 0.75);
             samplePos     = refractVector * (surfDistUp / refractVector.y) + samplePos;

        float result = distance(worldSpace, samplePos);

        result = pow(result / depth * 0.5, 5.0);

        albedo.rgb = vec3(result);
    }


    outAlbedo      = albedo;
    outPassthrough = vec4(normal * 0.5 + 0.5, 1.0);
}