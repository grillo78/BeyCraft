/* DRAWBUFFERS:0 */

layout (location = 0) out vec4 finalColorOut;


in vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D colortex4;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D noisetex;

uniform float centerDepthSmooth;
uniform float aspectRatio;
uniform int worldTime;
uniform vec2 resolution;

uniform float viewWidth, viewHeight;
uniform float near, far;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform int isEyeInWater;
uniform int frameCounter;


uniform vec2 pixel;

uniform mat4 gbufferProjection, gbufferProjectionInverse;


#include "/lib/Utility/Noise.glsl"

#include "/lib/Texturing/Smoothing.glsl"


float calculateViewSpaceZ(float depth) {
	depth = depth * 2.0 - 1.0;
	return -1.0 / (depth * gbufferProjectionInverse[2][3] + gbufferProjectionInverse[3][3]);
}

vec2 circlemap(vec2 p) {
	p.y *= TAU;
	return vec2(cos(p.y), sin(p.y)) * sqrt(p.x);
}

vec2 hammersley(int i, int N) {
	return vec2(float(i) / float(N), float(bitfieldReverse(i)) * 2.3283064365386963e-10);
}

void calculateExposure(inout vec3 color) {
    color = color / texture2D(colortex6, vec2(0.0)).a;
}


void tonemap(inout vec3 color) {
    float luma  = dot(color, lumaCoeff);
    vec3  curve = color / (color + 1.0);
          color = mix(color / (luma + 1.0), curve, clamp01(curve));
}

void ditherScreen(inout vec3 color) {
    vec3 lestynRGB = vec3(dot(vec2(171.0, 231.0), gl_FragCoord.xy));
         lestynRGB = fract(lestynRGB.rgb / vec3(103.0, 71.0, 97.0));

    color += lestynRGB.rgb / 255.0;
}


void tonemap_filmic(inout vec3 color) {

	const vec3 a = vec3(1.14, 1.14, 1.14);
	const vec3 b = vec3(0.62, 0.59, 0.62);
	const vec3 c = vec3(0.82, 0.82, 0.82);
	const vec3 d = vec3(0.50, 0.50, 0.50);

	vec3 cr = mix(vec3(dot(color, lumaCoeff)), color, d) + 1.0;

	color = pow(color, a);
	color = pow(color / (1.0 + color), b / a);
	color = pow(color * color * (-2.0 * color + 3.0), cr / c);
}

void calculateNightEye(inout vec3 color) {
    float luminance  = dot(color, lumaCoeff);
    float lows       = 1.0 / (1.0 + luminance * 10.0);
    vec3  saturation = mix(vec3(0.87, 0.9, 0.9), vec3(0.0), lows);

    color = mix(luminance * vec3(0.1, 0.3, 0.55), color, saturation);
}

float ld(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}

float tubeBorder() {
	vec2 a = texcoord * (1.0 - texcoord) * (55.0 + texcoord);
    return mix(2.0 - pow(a.x * a.y, 0.25), 1.0, 0.9);
}

vec2 calculateDistortion() {
    vec2 coord = texcoord * 2.0 - 1.0;
    #ifdef Tube_Distortion
	    coord *= tubeBorder();
    #endif

    return coord * 0.5 + 0.5;
}

void calculateBorder(inout vec3 color) {
    #ifndef Tube_Distortion
        return;
    #endif

    color *= smoothstep(1.0, 0.9, tubeBorder());
}

uint initRand(uint val0, uint val1, uint backoff)
{
    backoff = 16;
	uint v0 = val0, v1 = val1, s0 = 0;

	for (uint n = 0; n < backoff; n++)
	{
		s0 += 0x9e3779b9;
		v0 += ((v1 << 4) + 0xa341316c) ^ (v1 + s0) ^ ((v1 >> 5) + 0xc8013ea4);
		v1 += ((v0 << 4) + 0xad90777d) ^ (v0 + s0) ^ ((v0 >> 5) + 0x7e95761e);
	}
	return v0;
}

float nextRand(inout uint s)
{
	s = (1664525u * s + 1013904223u);
	return float(s & 0x00FFFFFF) / float(0x01000000);
}

void calculateFilmGrain(inout vec3 color) {
    #ifndef Film_Grain
        return;
    #endif
    uint randSeed = initRand(uint(gl_FragCoord.x + gl_FragCoord.y * resolution.x), uint(frameCounter), 16);

    float noiseX = hash13(vec3(gl_FragCoord.xy, -frameTimeCounter * 0.05));
	float noiseY = hash13(vec3(gl_FragCoord.xy,  frameTimeCounter * 0.03));
	float noiseZ = hash12(gl_FragCoord.xy);

    vec3 noise = vec3(noiseX, noiseY, noiseZ);

	color += noise * exp(-color) * vec3(1.0, 1.0, 1.1) * 0.05 * Film_Grain_Strength;
    color *= mix(vec3(1.0), noise, Film_Grain_Strength * 0.1);
}

mat3 colormat = mat3(1.40, 0.01, 0.00,
					0.15, 1.40, 0.15,
					0.10, 0.20, 1.70);

vec3 dispersionSample(sampler2D colortex, vec2 coord, float lod) {
    #ifndef Chromatic_Aberration
        return texture2DLod(colortex, coord, lod).rgb;
    #endif
    mat3x2 dispersionCoord = mat3x2(
        coord * 2.0 - 1.0,
        coord * 2.0 - 1.0,
        coord * 2.0 - 1.0
    );

    dispersionCoord[0] = dispersionCoord[0] * (0.996 * (Chromatic_Strength * 0.999)) * 0.5 + 0.5;
    dispersionCoord[1] = dispersionCoord[1] * (0.998) * 0.5 + 0.5;
    dispersionCoord[2] = dispersionCoord[2] * (1.000) * 0.5 + 0.5;
    
    return vec3(
        texture2DLod(colortex, dispersionCoord[0], lod).r,
        texture2DLod(colortex, dispersionCoord[1], lod).g,
        texture2DLod(colortex, dispersionCoord[2], lod).b
    );
}


void calculateDepthOfField(inout vec3 color, in vec2 coord, in vec2 pattern) {
    #ifndef DepthOfField
        return;
    #endif
    float depthh    = texture(depthtex0, texcoord).x;
    bool hand      = depthh<0.56;

    const float apertureRadiusMM = DOF_Aperture * 0.5;
    const float sensorHeightMM   = 24;
    const float apertureRadius   = apertureRadiusMM / 2200.0 / sqrt(DepthOfFieldQuality);
    const float sensorHeight     = sensorHeightMM / 1000.0;

    float focalLength  = 0.5 * sensorHeight * gbufferProjection[1].y;
    float expDepth     = texture2D(depthtex1, coord).x;
    float depth        = calculateViewSpaceZ(expDepth);
    float focus        = calculateViewSpaceZ(centerDepthSmooth);

    float CoC          = apertureRadius * focalLength * (depth - focus) / (depth * (focus - focalLength) * sensorHeight); // COC radius in units of the sensor height

    #ifdef Distance_Blur
          CoC         += apertureRadius * smoothstep(0.1, 1.8, ld(expDepth)) * 4.4;
    #endif

    #ifdef Rain_Blur
    if (rainStrength >= 0.1)      CoC         += apertureRadius * smoothstep(0.1, 1.8, ld(expDepth)) * (rainStrength * 5);
    #endif

    #ifdef Underwater_Blur
         if (isEyeInWater >= 0.5) CoC         += apertureRadius * smoothstep(0.1, 1.8, ld(expDepth)) * 1.4;
    #endif

    #ifdef Tilt_Shift
          CoC          = apertureRadius * (coord.y * 2.0 - 1.0);
    #endif
    
    vec2  CoCAspect    = CoC * vec2(1.0 / aspectRatio, 1.0) * vec2(1.0 / DOF_Anamorphic, DOF_Anamorphic);

	float lod = log2(abs(CoC) * pixel.y * pixel.x * (0.007 / DepthOfFieldQuality));
    
    const float error      = 1.0;
    const float errorRCP   = 1.0 / error;
    const float ditherSize = pow2(0.0);
    const float total      = DepthOfFieldQuality * ditherSize;
    float dither           = noiseSmooth(gl_FragCoord.xy * noiseResInverse).b * ditherSize;
    vec3  depthOfField     = vec3(0.0);
    vec2 bokehAngle = vec2(0.0, 1.0);
    float a = 2.4;
    mat2 rot = mat2(cos(a), -sin(a), sin(a), cos(a));
    vec2 centerdist = coord.xy - 0.5;
    vec3 prep = normalize(vec3(centerdist.y, -centerdist.x, 0.0));
    float angle = length(centerdist.xy) * 1.221 * 1.4;
    float sizeCorrect = sqrt(DepthOfFieldQuality);

    vec2 offset;

    for (int i = 0; i < DepthOfFieldQuality; i++) {
        bokehAngle = rot * bokehAngle;
        float index   = i * ditherSize + dither;
	    float theta   = index * GOLDEN_ANGLE;
        offset  = (sin(theta) + cos(theta)) * (error - pow(index / total, DOF_Bias)) * errorRCP * CoCAspect * bokehAngle;
        vec3 oldoffset = vec3(offset, 0.0);
        #ifdef Aperture_Rotation
        vec3 rotated = oldoffset * cos(angle) + cross(prep, oldoffset) * sin(angle) + prep * dot(prep, oldoffset) * (1.0 - cos(angle)) * sizeCorrect;
        #else
        vec3 rotated = oldoffset;
        #endif
        #ifdef MC_GL_RENDERER_RADEON
        rotated = oldoffset;
        #endif
        #ifdef MC_GL_RENDERER_MESA
        rotated = oldoffset;
        #endif
        #ifdef Distance_Blur
        rotated = oldoffset;
        #endif
        #ifdef Rain_Blur
        if (rainStrength >= 0.1) rotated = oldoffset;
        #endif
        depthOfField += dispersionSample(colortex6, rotated.xy + coord, lod);
        //depthOfField *= oldoffset
    }

    if(hand) color = color;
    else color = depthOfField / DepthOfFieldQuality;
}

vec2 calculateBlurTileOffset(const int id) {
	// offsets approximately follows a multiple of this: (1 - 4⁻ˣ) / 3

	const vec2 idMult = floor(id * 0.5 + vec2(0.0, 0.5));
	const vec2 offset = vec2(1.0, 2.0) * (1.0 - exp2(-2.0 * idMult)) / 3.0;

	const vec2 paddingPixels = vec2(2.0, 9.0); // Set as needed
	const vec2 paddingAccum  = idMult * paddingPixels;

	return offset + paddingAccum * pixel;
}

vec3 calculateBloomTile(vec2 coord, const float lod, vec2 offset) {
	return bicubicTexture(colortex0, coord / exp2(lod) + offset - pixel * 0.5).rgb;
}

void calculateBloom(inout vec3 color, in vec2 coord) {
	vec3 bloom = vec3(0.0);
	bloom += calculateBloomTile(coord, 2.0, vec2(0.0                     ,                    0.0));
	bloom += calculateBloomTile(coord, 3.0, vec2(0.0                     , 0.25   + pixel.y * 2.0));
	bloom += calculateBloomTile(coord, 4.0, vec2(0.125    + pixel.x * 2.0, 0.25   + pixel.y * 2.0));
	bloom += calculateBloomTile(coord, 5.0, vec2(0.1875   + pixel.x * 4.0, 0.25   + pixel.y * 2.0));
	bloom += calculateBloomTile(coord, 6.0, vec2(0.125    + pixel.x * 2.0, 0.3125 + pixel.y * 4.0));
	bloom += calculateBloomTile(coord, 7.0, vec2(0.140625 + pixel.x * 4.0, 0.3125 + pixel.y * 4.0));
	
	bloom /= 7.0;

    #ifdef Bloom
	color = mix(color, bloom, 0.04 * Bloom_Strength);
    #endif
}

vec3 lowlight_desaturate(inout vec3 color) {
    float multiplier = 1.0;
    float moonFade = clamp(0.75 * (0.9 * (smoothstep(13000.0, 12000.0, float(worldTime)) + smoothstep(23000.0, 24000.0, float(worldTime)))), 0.1, 1.0);

    const vec3 rod_response = vec3(0.15, 0.50, 0.35);

    float rod_color = dot(color * rod_response, vec3(0.1, 0.65, 0.6));
    float desaturated = dot(color, rod_response);
    color = mix(color, vec3(rod_color), exp2((-33.0) * desaturated));

    return color;
}


vec2 sincos(float x){
    return vec2(sin(x),cos(x));
}

void calculateDiffractionSpikes(inout vec3 color, in vec2 coord, in vec2 pattern) {

    #ifndef Lens_Streaks
    return;
    #endif

    const int   tileID     = 1;
    const vec2  tileOffset = calculateBlurTileOffset(tileID);
    const float tileScale  = exp2(-tileID - 1.0);

    float a = 2.4;
    #ifndef Streak_Rotation
    a = 0.0;
    #endif
    mat2 rot = mat2(cos(a), -sin(a), sin(a), cos(a));

    const float qualityRCP = 1.0 / Streak_Loops;
    const float falloff    = 10.0;

    float rotStep = radians(360.0 / Aperture_Blades);
    float rotDir = rotStep + radians(35.0);

    float radius   = (0.1 * Streak_Faloff) * qualityRCP;
    vec2  radScale = radius * vec2(1.0 / aspectRatio, 1.0);

    float totalWeight = 87.5;
    vec3  spikes = vec3(0.0);

    for (int x = 0; x < Aperture_Blades; x++, rotDir += rotStep) {
        vec2 offset = sincos(rotDir) * radScale;
        #ifdef Streak_Rotation
        offset *= rot;
        #endif
        //offset *= pattern.y;
        vec2 coord  = texcoord + offset;
        #ifdef Tube_Distortion
        coord *= -tubeBorder();
        #endif
        for (int y = 0; y < Streak_Loops; y++, coord += offset) {
            float weight = pow(1.0 - y * qualityRCP, falloff);
            bool  onTile = floor(coord) == vec2(0.0);

            if (!onTile) continue;

            spikes      += texture2DLod(colortex6, coord, 0.0).rgb * weight  * Streak_Brightness;
            totalWeight += weight;
        }
    }

    color += spikes / totalWeight * 0.3 * Streak_Brightness;
}

vec4 bicubicTexture(sampler2D tex, vec2 coord, float res) {
  vec2 resolutionScale = resolution * res;

  coord *= resolutionScale;

  float fx = fract(coord.x);
  float fy = fract(coord.y);
  coord.x -= fx;
  coord.y -= fy;

  vec4 xcubic = cubic(fx);
  vec4 ycubic = cubic(fy);

  vec4 c = vec4(coord.x - 0.5, coord.x + 1.5, coord.y - 0.5, coord.y + 1.5);
  vec4 s = vec4(xcubic.x + xcubic.y, xcubic.z + xcubic.w, ycubic.x + ycubic.y, ycubic.z + ycubic.w);
  vec4 offset = c + vec4(xcubic.y, xcubic.w, ycubic.y, ycubic.w) / s;

  vec4 sample0 = texture2DLod(tex, vec2(offset.x, offset.z) / resolutionScale, 0.0);
  vec4 sample1 = texture2DLod(tex, vec2(offset.y, offset.z) / resolutionScale, 0.0);
  vec4 sample2 = texture2DLod(tex, vec2(offset.x, offset.w) / resolutionScale, 0.0);
  vec4 sample3 = texture2DLod(tex, vec2(offset.y, offset.w) / resolutionScale, 0.0);

  float sx = s.x / (s.x + s.y);
  float sy = s.z / (s.z + s.w);

  return mix( mix(sample3, sample2, sx), mix(sample1, sample0, sx), sy);
}

void lookup(inout vec3 color) {
    const vec2 inverseSize = vec2(1.0 / 512, 1.0 / 5120);
    const mat2 correctGrid = mat2(
        vec2(1.0, inverseSize.y * 512),
        vec2(0.0, Selected_LUT * inverseSize.y * 512)
    );
    #ifndef LUT
        return;
    #endif
    #ifdef SHOW_LUT
        if (gl_FragCoord.x < 512.0 && gl_FragCoord.y < 512.0) {
            vec2 uv = gl_FragCoord.xy / 512.0;
            color = texture2D(colortex7, uv + correctGrid[1]).rgb;
            return;
        }
    #endif

    color = clamp01(color);

    float blueColor = color.b * 63.0;

    vec4 quad = vec4(0.0);
    quad.y = floor(floor(blueColor) * 0.125);
    quad.x = floor(blueColor) - (quad.y * 8.0);
    quad.w = floor(ceil(blueColor) * 0.125);
    quad.z = ceil(blueColor) - (quad.w * 8.0);

    vec4 texPos = (quad * 0.125) + (0.123046875 * color.rg).xyxy + 0.0009765625;

    vec3 newColor1 = texture2D(colortex7, texPos.xy * correctGrid[0] + correctGrid[1]).rgb;
    vec3 newColor2 = texture2D(colortex7, texPos.zw * correctGrid[0] + correctGrid[1]).rgb;
    
    color = mix(newColor1, newColor2, fract(blueColor));
}

float extractLuma(vec3 c)
{
    return clamp(c.r * 1.299 + c.g * 1.587 + c.b * 1.114, 0.0, 115.5) * 2;
}

#include "/lib/Fragment/Post/ACEST.glsl"
#include "/lib/Fragment/Post/ACESSPL.glsl"
#include "/lib/Fragment/Post/ACES.glsl"
#include "/lib/Fragment/Post/Palette.glsl"


void main() {
    vec2 pattern           = vec2(1.0);

        mat3 YUVFromRGB = mat3(
    vec3(0.299,-0.14713, 0.615),
    vec3(0.587,-0.28886,-0.51499),
    vec3(0.114,0.436,-0.10001));

        mat3 RGBFromYUV = mat3(
    vec3(1, 1, 1),
    vec3(0.0,-0.394,2.03211),
    vec3(1.13983,-0.580,0.0));

    vec3 color = texture2D(colortex6, texcoord).rgb;
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);

    float depthtex     = texelFetch(depthtex1, fragCoord, 0).x;
    #ifdef Pixelizer
    vec2 distortedTexcoord = pixelize(texcoord, pixel_size);
    #else
    vec2 distortedTexcoord = texcoord;
    #endif

	vec2 uv = fragCoord.xy / resolution.xy;
    vec3 yuv = YUVFromRGB * color.rgb;
    vec2 imgSize = resolution;

    float accumY = 0.0; 
    for(int i = -1; i <= 1; ++i) {
        for(int j = -1; j <= 1; ++j) {
            vec2 offset = vec2(i,j) / imgSize;
            
            float s = extractLuma(texture(colortex6,uv + offset).rgb);
            float notCentre = min(float(i*i + j*j),1.0);
            accumY += s * (9.0 - notCentre*10.1);
        }
    }
    accumY /= 9.0;
    
    float gain = 0.4;
    accumY = (accumY + yuv.x)*gain;
    #ifndef MC_GL_RENDERER_RADEON
    calculateDepthOfField(color, distortedTexcoord, pattern);
    #endif
    
    //if (depthtex < 1.0) {
	//color += vec3(RGBFromYUV * vec3(accumY,yuv.y,yuv.z)); // sharpened
    //}

    calculateBloom(color, distortedTexcoord);
    calculateDiffractionSpikes(color, distortedTexcoord, pattern);
    calculateExposure(color);
    calculateFilmGrain(color);
    //calculateBorder(color);

	ColorCorrection m;
	m.lum = vec3(0.2125, 0.7154, 0.0721);
	m.saturation = 0.95 + SAT_MOD;
	m.vibrance = VIB_MOD;
	m.contrast = 1.0 - CONT_MOD;
	m.contrastMidpoint = CONT_MIDPOINT;

	m.gain = vec3(1.0, 1.0, 1.0) + GAIN_MOD; //Tint Adjustment
	m.lift = vec3(0.0, 0.0, 0.0) + LIFT_MOD * 0.01; //Tint Adjustment
	m.InvGamma = vec3(1.0, 1.0, 1.0);



    color = FilmToneMap(color);
    //color = color * colormat;
    
    lowlight_desaturate(color);
    
	color = WhiteBalance(color);
	color = Vibrance(color, m);
	color = Saturation(color, m);
    color = Contrast(color, m);
    color = LiftGammaGain(color, m);

    #ifdef Big_Dither
    color = dither8x8(distortedTexcoord, color.rgb, pixel_size);
    #endif
    #ifndef Color_Compression
	color = linearToSrgb(color);
    #endif

    lookup(color);

	color = clamp01(color);

    ditherScreen(color);

    finalColorOut = vec4(color, 1.0);
}