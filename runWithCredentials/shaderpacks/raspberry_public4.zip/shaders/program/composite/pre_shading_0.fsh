/* DRAWBUFFERS:45 */

layout (location = 0) out vec4 accumulatedWrite; //colortex4
layout (location = 1) out vec4 cloudWrite;       //colortex5


in vec2 texcoord;

flat in mat4 shadowViewMatrix;
flat in mat3 lightColors;
flat in mat2x3 sunVec;
flat in mat2x3 lightVec;
uniform float sunAngle;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex7;
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler3D depthtex2;
uniform sampler2D noisetex;
uniform int worldTime;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView, gbufferPreviousProjection;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition, previousCameraPosition;
uniform vec3 upPosition;
uniform float viewWidth, viewHeight;
uniform float far;
uniform int frameCounter;
uniform ivec2 eyeBrightnessSmooth;
uniform vec2 taaOffset;
uniform vec3 shadowLightPosition;
uniform float screenBrightness;
uniform ivec2 eyeBrightness;

uniform vec2 pixel;
uniform int isEyeInWater;



#include "/lib/Global.glsl"

#include "/lib/Utility/Space_Transformations.glsl"

#include "/lib/Fragment/BSDF.glsl"
#include "/lib/Utility/Mapping.glsl"
#include "/lib/Utility/Sampling_Patterns.glsl"
#include "/lib/Fragment/Shadows.glsl"

#include "/lib/Shared/Atmosphere_Params.glsl"
#include "/lib/Shared/Atmosphere_Compute.glsl"

float cubesmooth(float x) { return (x * x) * (3.0 - 2.0 * x); }
vec2 cubesmooth(vec2 x) { return (x * x) * (3.0 - 2.0 * x); }

vec2 rsi(vec3 position, vec3 direction, const float radius) {
	float PoD = dot(position, direction);
	float radiusSquared = radius * radius;

	float delta = PoD * PoD + radiusSquared - dot(position, position);
	if (delta < 0.0) return vec2(-1.0);
	      delta = sqrt(delta);

	return -PoD + vec2(-delta, delta);
}

float GetNoise(vec2 coord) {
	const vec2 madd = vec2(0.5 * noiseResInverse);
	vec2 whole = floor(coord);
	coord = whole + cubesmooth(coord - whole);
	
	return texture2D(noisetex, coord * noiseResInverse + madd).x;
}

#include "/lib/Shared/VClouds.glsl"


vec3 getDiffuse(vec3 albedo, vec3 viewVector, vec3 direction, vec3 normal, float roughness) {
    #if   Indirect_Diffuse == NdotL
        return vec3(max0(sqrt(dot(normal, direction)))) * inversePI;
    #elif Indirect_Diffuse == Hammon_GGX
        return diffuse_hammon(albedo, viewVector, direction, normal, roughness);
    #endif
}

vec3 calculateGlobalIllumination(gbuffer info, material mat, scene spaces, vec2 pattern) {
    vec3 shadowSpace = calculateShadowSpace(spaces.world[1]);

    #ifndef Global_Illumination
    return vec3(0.0);
    #endif
    if (worldTime >= 12500) return vec3(0.0);
    float hand = float(texture2D(depthtex1,texcoord.xy).r < 0.56);
    if (hand >= 1.0) return vec3(-35.0);
    const float ditherSize = pow2(8.0);
    #ifdef GI_Bleeding_Fix
    if (eyeBrightness.y <= 30) return vec3(0.0);
    #endif
    float ditherOffset = fract((pattern.y * 128 + frameCounter * 7) / 128);

    float dither = (ditherSize * ditherOffset);
    int   RSMQuality = GI_Quality;
    float GIRadius   = GI_Radius;

    vec3  shadowNormal = normalize(mat3(shadowViewMatrix) * info.normal[0]);
    vec3  light  = vec3(0.0);
    float weight = 1.0;

    float step   = 0.0 / RSMQuality;
    float lod    = 0.0;
    
    float radius = GIRadius * shadowMapResInverse;
    float indoors  = 1.0 - clamp01((-eyeBrightnessSmooth.y + 230) / 100.0);
    vec4 stainedColor                    =  vec4(1.0);



    for (int i = 0; i < RSMQuality; i++) {
        vec2 offset = fermatsSpiralGoldenS(i * ditherSize + dither, RSMQuality * ditherSize) * radius;
        if (dot(shadowNormal.xy, offset) <= 0.0) offset = -offset;

        vec3 offsetPosition                  = shadowSpace + vec3(offset, 0.0);
        vec3 offsetPositionDistorted         = distortShadowSpace(offsetPosition);
        #ifdef Translucent_GI
        stainedColor = texture2D(shadowcolor0, offsetPositionDistorted.xy);
        #endif


        float shadowDepth = texture2DLod(shadowtex1, offsetPositionDistorted.xy, lod).x;
              shadowDepth = (((shadowDepth * 2.0 - 1.0) * Shadow_Z_Stretch) * 0.5 + 0.5);

        vec3  samplePosition = vec3(offsetPosition.xy, shadowDepth) - shadowSpace;
        float sampleLength   = length(samplePosition);

        vec3 samplePositionNormalized = normalize(samplePosition) * vec3(1.0, 1.0, -1.0);

        if (sampleLength > radius) continue;
        weight++;

        float falloff = 1.0 / (1.0 + pow2(sampleLength) * shadowMapResolution);

        vec3 diffuse = getDiffuse(info.color[0].rgb, -spaces.world[2], samplePositionNormalized, shadowNormal, mat.roughness.x) * PI;

        if (bool(lessThanEqual(diffuse, vec3(0.0)))) continue;

        vec3 normalSample = texture2DLod(shadowcolor1, offsetPositionDistorted.xy, lod).rgb * 2.0 - 1.0;
             normalSample = -normalSample;

        vec3 diffuse_bounce = getDiffuse(info.color[0].rgb, -spaces.world[2], samplePositionNormalized, normalSample, 1.0) * PI;

        if (bool(lessThanEqual(diffuse_bounce, vec3(0.2)))) continue;

        vec3 lightSample = (toLinear(texture2DLod(shadowcolor0, offsetPositionDistorted.xy, lod).rgb) * falloff * diffuse * diffuse_bounce * mat.land);
        if (lightSample != lightSample) lightSample = vec3(1.0);

        light += lightSample;

    }

    return light / weight * 134.0 * GI_Intensity  * (1.0 - (rainStrength * 0.96)) * stainedColor.rgb;
}

float calculateAO(gbuffer info, material mat, vec3 viewSpace, float dither) {
    if (mat.emitter > 0.5) return 1.0;

    #ifndef Ambient_Occlusion 
    return 1.0;
    #endif

    vec3 normal    = mat3(gbufferModelView) * info.normal[0];

    float radius   = 0.5;
    float power    = 1.0;
    float strength = AO_Strength * 111;

    #ifdef Stochastic_AO 
    radius = 1.1;
    strength = 13.0;
    #endif

    float AO       = 0.0;

    for (int i = 0; i < 25; i++) {

        float dx   = (radius / (-viewSpace.z)) * pow(dither, power);
        vec2  dir  = normalize(mix(circlemap(i, 25), circlemap(i + 1, 6), fract(dither + 0.25))) * (dx + pixel * 2.0);
        vec2  h    = texcoord + dir;

        vec3 nvpos = calculateViewSpace(vec3(h, texture2D(depthtex1, h).y)).xyz;

        float d    = length(nvpos - viewSpace);

        AO += max(0.0, dot(normal, nvpos - viewSpace) / d - 0.15)
            * max(0.0, - (d - radius))
            * float(d > 0.00001);
    }

    return pow(1.0 - clamp01(AO / 25), strength) * info.lightmap[0].x;
}

#include "/lib/Fragment/RTAO.glsl"

vec2 computeCameraVelocity(in vec3 worldSpace) {
    vec3 projection =(cameraPosition - previousCameraPosition) + worldSpace;
         projection = mat3(gbufferPreviousModelView) * projection;
         projection = (diagonal3(gbufferPreviousProjection) * projection + gbufferPreviousProjection[3].xyz) / -projection.z * 0.5 + 0.5;

    return (texcoord - projection.xy);
}

vec4 accumulateLighting(gbuffer info, material mat, scene spaces, param sky, vec2 pattern) {
    vec2  cameraVelocity    = computeCameraVelocity(spaces.world[1]);
    vec2  texcoordPrevoius  = -cameraVelocity + texcoord;
    vec4  previousFrameInfo = texture2DLod(colortex4, texcoordPrevoius, 0.0);
    float moonFade = 0.75 * (0.9 * (smoothstep(13000.0, 12000.0, float(worldTime)) + smoothstep(23000.0, 24000.0, float(worldTime))));
    vec3 ambientColor = lightColors[2] * 1.0;

    vec3  viewSpacePrevious = calculateViewSpace(vec3(texcoord, texture2D(depthtex1, texcoordPrevoius).x));
    float displacement      = length(viewSpacePrevious - spaces.view[1]);
    bool  fragmentMoving    = bool(displacement <= 1.0);

    vec3 fakeBounce = vec3(1.15, 1.145, 1.13) * (lightColors[0] * sunTint + lightColors[1] * moonTint) * (info.normal[0].y * 0.5 + 0.5);

    vec3  lighting  = vec3(0.0);
#if   Ambient_Occlusion == 0
          //lighting += (lightColors[2] + fakeBounce * 0.05) * info.lightmap[0].y * 1.1 * Skylight_Brightness * 0.03;
          lighting;
          const float ambientOcclusionLevel = 0.5;
//#elif Ambient_Occlusion == SSAO
          //lighting += calculateAO(info, mat, spaces.view[1], pattern.y) * info.lightmap[0].y * 0.4 * vec3(moonFade);
          //lighting;
#elif Ambient_Occlusion == 1
          //lighting += calculateAO(info, mat, spaces.view[1], pattern.x);
          const float ambientOcclusionLevel = 0.0;

#endif
#if defined GI_Bleeding_Fix
          lighting += calculateGlobalIllumination(info, mat, spaces, pattern) * info.lightmap[0].y;
#else
          lighting += calculateGlobalIllumination(info, mat, spaces, pattern);
#endif
    //if (lighting != lighting) lighting = vec3(0.0);

    float filterWeight   = Temporal_Filter_Weight;
    
    vec4  accumulated = mix(vec4(lighting, 1.0), previousFrameInfo, filterWeight);

    return accumulated;
}

#include "/lib/Fragment/Refraction.glsl"

float max_depth3x3(sampler2D depthtex, vec2 coord, vec2 px) {

    float tl    = texture(depthtex, coord + vec2(-px.x, -px.y)).x;
    float tc    = texture(depthtex, coord + vec2(0.0, -px.y)).x;
    float tr    = texture(depthtex, coord + vec2(px.x, -px.y)).x;
    float tmin  = max(tl, max(tc, tr));

    float ml    = texture(depthtex, coord + vec2(-px.x, 0.0)).x;
    float mc    = texture(depthtex, coord).x;
    float mr    = texture(depthtex, coord + vec2(px.x, 0.0)).x;
    float mmin  = max(ml, max(mc, mr));

    float bl    = texture(depthtex, coord + vec2(-px.x, px.y)).x;
    float bc    = texture(depthtex, coord + vec2(0.0, px.y)).x;
    float br    = texture(depthtex, coord + vec2(px.x, px.y)).x;
    float bmin  = max(bl, max(bc, br));

    return max(tmin, max(mmin, bmin));
}

//#include "/lib/Fragment/Nebula.glsl"


void main() {
    mat2 coord = mat2(
        texcoord,
        calculateRefraction(texcoord)
    );

    gbuffer  info   = calculateGbufferInformation(coord);
    material mat    = calculateMaterialMasks(info.specular, info.depthtex, info.materialIDs);
    scene    spaces = calculateSpaces(coord, info.depthtex);
    param    sky    = calculateSkyParameters(mat3(gbufferModelView) * info.normal[0], normalize(upPosition));

    vec2 pattern = calculateAlteredSamplingDistributors();
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);
    float depthtex     = texelFetch(depthtex1, fragCoord, 0).x;
    vec3  space_Screen = vec3(coord[0] - taaOffset * 0.5, depthtex);
    vec3  space_View   = calculateViewSpace(space_Screen);
    vec3  space_World  = mat3(gbufferModelViewInverse) * space_View + gbufferModelViewInverse[3].xyz;
    vec4 cloud_data;
    float taaDither 	= bayer64(ivec2(gl_FragCoord.st));
	taaDither 		= fract(taaDither + frameCounter%4);
    vec3 lightvec = normalize(shadowLightPosition);
    vec3 viewvec = normalize(space_View);
    vec3 upvec = normalize(upPosition);
    float solidBlue = fract((toLinear(noiseSmooth(gl_FragCoord.xy * noiseResInverse).rgb).b * 255) / 255) * 0.7;

    const float cLOD    = sqrt(CLOUD_RENDER_LOD);
    vec2 scalecoord  = (texcoord-vec2(1.0-rcp(cLOD), 0.0))*cLOD;
    float d     = max_depth3x3(depthtex1, scalecoord, pixel*cLOD);

        if (clamp(scalecoord, -0.003, 1.003) == scalecoord && d>=1.0) {
            scalecoord      = clamp(scalecoord, 0.0, 1.0);
            vec3 viewpos    = calculateViewSpace(vec3(scalecoord, 1.0));
            vec3 viewvec    = normalize(viewpos);
            vec3 scenepos   = mat3(gbufferModelViewInverse) * viewpos;
            vec3 svec       = normalize(scenepos);

            vc_render(info.color[2], viewvec, upvec, lightvec, cameraPosition, dot(viewvec, lightvec), taaDither, svec, scalecoord, pattern);
        } else {
            cloud_data = vec4(0.0, 0.0, 0.0, 1.0);
        }

    accumulatedWrite = clamp01(accumulateLighting(info, mat, spaces, sky, pattern));
    cloudWrite = info.color[2];
}