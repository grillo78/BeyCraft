/* DRAWBUFFERS:0 */

layout (location = 0) out vec4 colorWrite; //colortex0


in vec2 texcoord;

flat in mat4 shadowViewMatrix;
flat in mat3 lightColors;
flat in mat2x3 sunVec;
flat in mat2x3 lightVec;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowModelView;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler3D depthtex2;
uniform int worldTime;
uniform sampler2D normals;

uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D noisetex;
uniform ivec2 eyeBrightnessSmooth;
uniform float rainStrength;
uniform float far;
uniform float frameTimeCounter;
uniform vec3 shadowLightPosition;
uniform vec3 upPosition;
uniform vec2 taaOffset;


uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform mat4 shadowProjection, shadowProjectionInverse;
uniform vec3 cameraPosition;
uniform float viewWidth, viewHeight;
uniform float sunAngle;

uniform int frameCounter;
uniform int isEyeInWater;


uniform vec2 pixel;


#include "/lib/Global.glsl"

#include "/lib/Utility/Space_Transformations.glsl"

#include "/lib/Fragment/BSDF.glsl"
#include "/lib/Utility/Mapping.glsl"
#include "/lib/Utility/Sampling_Patterns.glsl"
#include "/lib/Fragment/Shadows.glsl"

#include "/lib/Shared/Atmosphere_Params.glsl"
#include "/lib/Shared/Atmosphere_Compute.glsl"

vec3 rand(vec2 coord)
{
	float noiseX = clamp01(fract(sin(dot(coord, vec2(12.9898, 78.223))) * 43758.5453));
	float noiseY = clamp01(fract(sin(dot(coord, vec2(12.9898, 78.223)*2.0)) * 43758.5453));
	float noiseZ = clamp01(fract(sin(dot(coord, vec2(12.9898, 78.223)*3.0)) * 43758.5453));

	return vec3(noiseX, noiseY, noiseZ);
}

vec2 rsi(vec3 position, vec3 direction, const float radius) {
	float PoD = dot(position, direction);
	float radiusSquared = radius * radius;

	float delta = PoD * PoD + radiusSquared - dot(position, position);
	if (delta < 0.0) return vec2(-1.0);
	      delta = sqrt(delta);

	return -PoD + vec2(-delta, delta);
}

float cubesmooth(float x) { return (x * x) * (3.0 - 2.0 * x); }
vec2 cubesmooth(vec2 x) { return (x * x) * (3.0 - 2.0 * x); }

float GetNoise(vec2 coord) {
	const vec2 madd = vec2(0.5 * noiseResInverse);
	vec2 whole = floor(coord);
	coord = whole + cubesmooth(coord - whole);
	
	return texture2D(noisetex, coord * noiseResInverse + madd).x;
}


#include "/lib/Shared/VClouds.glsl"

//#if (VCloud_TYPE == 2)
//#include "/lib/Shared/VCloudsold.glsl"
//#endif

void setupSolidAlbedo(inout gbuffer info) {
         if (info.forwardSolidMask) info.color[0] = info.color[0];
    else if (info.depthtex.y >= 1.0) info.color[0] = vec4(0.0, 0.0, 0.0, 1.0);
}

#include "/lib/Fragment/Refraction.glsl"

float calculateBlockerDepth(vec3 shadowSpace, const float ditherSize, float dither, material mat) {
    #ifndef PCSS
        return 0.3;
    #endif

    const float maxBlockerDist = 32.0;

    const int   searchSamples  = 2;

    float searchScale  = 1.0 * maxBlockerDist / abs(shadowProjectionInverse[2].z);
    float spread       = tan(sunAngularRadius) * abs(shadowProjectionInverse[2].z) * shadowProjection[0].x;
    if (mat.translucent >= 0.5) {
    #ifdef SSS
    spread = 0.1 * SSS_Scatter_Amount;
    #endif
    }

    float searchRadius = spread * searchScale;

    float lod = log2(2.0 * shadowMapResolution * searchRadius / sqrt(searchSamples));

    float blockerDepth = 0.02;

    for (int i = 0; i < searchSamples; i++) {
        vec2 offset = fermatsSpiralGoldenN(i * ditherSize + dither, searchSamples * ditherSize) * searchRadius;
        vec3 shadowSpaceDistorted = distortShadowSpace(shadowSpace + vec3(offset, 0.0));

        float shadowDepth = shadowSpaceDistorted.z - texture2DLod(shadowtex1, shadowSpaceDistorted.xy, lod).x;

        blockerDepth += shadowDepth;
    }

    return min(blockerDepth / searchSamples * Shadow_Z_Stretch, searchScale) * spread * shadowMapResolution;
}

vec3 toNDC(vec3 pos){
	vec4 iProjDiag = vec4(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y, gbufferProjectionInverse[2].zw);
    vec3 p3 = pos * 2. - 1.;
    vec4 fragpos = iProjDiag * p3.xyzz + gbufferProjectionInverse[3];
    return fragpos.xyz / fragpos.w;
}

vec3 calculateSunlightVisibility(gbuffer info, material mat, scene spaces, vec3 shadowSpace, vec2 pattern) {
    const float ditherSize = pow2(8.0);
    float dither = ditherSize;
    #ifdef TAA
    dither = ditherSize * pattern.y;
    #endif

    float SNdotL = dot(info.normal[0], lightVec[1]);
    if (SNdotL < 0.0 && mat.translucent < 0.5) return vec3(0.0);

    int   shadowQuality        = ShadowFilter_Quality;
    float inverseShadowQuality = 1.0 / float(shadowQuality);
    float filterSize           = calculateBlockerDepth(shadowSpace, ditherSize, dither, mat);

    vec3  shadow     = vec3(0.0);
    float dayFade = clamp(0.75 * (0.9 * (smoothstep(9000.0, 11000.0, float(worldTime)) + smoothstep(3000.0, 0000.0, float(worldTime)))), 0.08, 1.0);

    float shadowsBias = mix(0.0001, 0.00014, SNdotL * 0.5 + 0.5) / 1.5;
    float shadowsBias2 = mix(0.0001, 0.0019, SNdotL * 0.5 + 0.5) / 1.5;


    for (int i = 0; i < shadowQuality; i++) {
        vec2 offset = fermatsSpiralGoldenN(i * ditherSize + dither, shadowQuality * ditherSize) * filterSize * shadowMapResInverse;

        vec3 shadowSpaceDistorted = distortShadowSpace(shadowSpace + vec3(offset, 0.0));
        vec2 zStep = shadowSpaceDistorted.z - vec2(shadowsBias, shadowsBias);

        if (shadowSpaceDistorted.z >= 1.0) {
            shadow = vec3(shadowQuality);
            break;
        }

        float shadowDepth0 = texture2DLod(shadowtex0, shadowSpaceDistorted.xy, 0.0).x;
        float shadowDepth1 = texture2DLod(shadowtex1, shadowSpaceDistorted.xy, 0.0).x;
        vec4  shadowColor  = texture2DLod(shadowcolor0, floor(shadowSpaceDistorted.xy * shadowMapResolution) * shadowMapResInverse, 0.0);

        float shadow0 = step(zStep.x, shadowDepth0);
        float shadow1 = step(zStep.x, shadowDepth1);

        float transparent = (1.0 - step(zStep.y, shadowDepth0)) * step(zStep.y, shadowDepth1);
        float waterDepth  = (shadowDepth1 - shadowDepth0) * Shadow_Z_Stretch;
              waterDepth  = (waterDepth * shadowProjectionInverse[2].z + shadowProjection[3].z);
        
        vec3 shadowSample = shadow0 + (1.0 - shadow0) * shadow1 * shadowColor.rgb;



        shadow += shadowSample;
    }

    shadow *= inverseShadowQuality;

    return shadow.rgb;
    //return vec3(filterSize);
}

#include "/lib/Fragment/Shading.glsl"

const vec3  sRGBApproxWavelengths = vec3( 610.0, 549.0, 468.0 );

float radiation(in float temperature, in float wavelength)
{
    float e = exp(1.4387752e+7 / (temperature * wavelength));
    return 3.74177e+29 / (pow(wavelength, 5.0) * (e - 1.0));
}

vec3 radiation(in float t, in vec3 w)
{
    return vec3(
        radiation(t, w.x), 
        radiation(t, w.y), 
        radiation(t, w.z)
    );
}

void generateStars(inout vec3 color, in vec3 worldVector, in float freq, in float visibility) {
    if (visibility >= 1.0) return;
    if (worldTime <= 13400) return;
    if (worldTime >= 23000) return;
	vec3 SSunColor = lightColors[0];
	vec3 SMoonColor = lightColors[1];
	vec3 SLightColor = SSunColor + SMoonColor;

    
    const float minTemp =  3500.0;
    const float maxTemp =  50500.0;
    const float tempRange = maxTemp - minTemp;
    float frequency = freq * 20;

    const float res = 128.0;

    vec3 p  = worldVector * res;
    vec3 id = floor(p);
    vec3 fp = fract(p) - 0.5;

    float rp    = hash13(id);
    float stars = pow(max0(0.75 - length(fp)) * 1.2, 20.0);

    float starTemp = (sin(rp / frequency * PI * 16.0) * 0.5 + 0.5) * tempRange + minTemp;
    vec3  starEmission = radiation(starTemp, sRGBApproxWavelengths) * 1.0e-15;

    color.rgb += vec3(stars) * step(rp, frequency) * pow2(1.0) * starEmission * ((SSunColor * 0.0) + (SMoonColor * 18.8));
    //color.rgb += vec3(0.0, 0.00002, 0.00008);
}

float max_depth3x3(sampler2D depthtex, vec2 coord, vec2 px) {

    float tl    = texture(depthtex, coord + vec2(-px.x, -px.y)).x;
    float tc    = texture(depthtex, coord + vec2(0.0, -px.y)).x;
    float tr    = texture(depthtex, coord + vec2(px.x, -px.y)).x;
    float tmin  = max(tl, max(tc, tr));

    float ml    = texture(depthtex, coord + vec2(-px.x, 0.0)).x;
    float mc    = texture(depthtex, coord).x;
    float mr    = texture(depthtex, coord + vec2(px.x, 0.0)).x;
    float mmin  = max(ml, max(mc, mr));

    float bl    = texture(depthtex, coord + vec2(-px.x, px.y)).x;
    float bc    = texture(depthtex, coord + vec2(0.0, px.y)).x;
    float br    = texture(depthtex, coord + vec2(px.x, px.y)).x;
    float bmin  = max(bl, max(bc, br));

    return max(tmin, max(mmin, bmin));
}



#include "/lib/Fragment/Nebula.glsl"

#include "/lib/Fragment/2D_Fog.glsl"
#include "/lib/Fragment/Volumetric_Fog.glsl"
#include "/lib/Shared/2DClouds.glsl"

void main() {
    mat2 coord = mat2(
        texcoord,
        texcoord
    );
    vec2 texcoord2 = calculateRefraction(texcoord);

    vec2 pattern = calculateJitteredSamplingDistributors();
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);
    float cloudAlpha = 0.0;     

    float depthtex     = texelFetch(depthtex1, fragCoord, 0).x;
    bool  depthOrder  = cameraPosition.y < vc_altitude;

    gbuffer  info   = calculateGbufferInformation(coord);
    material mat    = calculateMaterialMasks(info.specular, info.depthtex, info.materialIDs);
    scene    spaces = calculateSpaces(coord, info.depthtex);
    param    sky    = calculateSkyParameters(spaces.world[2], vec3(0.0, 1.0, 0.0));
    float underWaterDepth  = length(spaces.world[0]);

    vec3  space_Screen = vec3(texcoord2 - taaOffset * 0.5, depthtex);
    vec3  space_View   = calculateViewSpace(space_Screen);
    vec3  space_World  = mat3(gbufferModelViewInverse) * space_View + gbufferModelViewInverse[3].xyz;

    vec3 lightvec = normalize(shadowLightPosition);
    vec3 viewvec = normalize(space_View);
    vec3 upvec = normalize(upPosition);
    
    float taaDither 	= bayer64(ivec2(gl_FragCoord.st));
	taaDither 		= fract(taaDither + frameCounter%4);
    vec3 shadowSpace = calculateShadowSpace(spaces.world[1]);
    vec3 shadowLightmap = calculateSunlightVisibility(info, mat, spaces, shadowSpace, pattern);
    vec4 cloud_data;

    vec3 UWmultiplier = vec3(1.0);
    if (isEyeInWater >= 0.5 && mat.water <= 0.5) UWmultiplier = vec3(0.6, 0.9, 1.2) * 0.4;
    if (isEyeInWater >= 0.5 && mat.water >= 0.5) UWmultiplier *= vec3(0.8, 0.9, 1.4) * 0.4;
    //if (mat.water >= 0.5  && isEyeInWater <= 0.5 ) UWmultiplier *= 0.6;
    if (worldTime >= 12500 && worldTime <= 23000) UWmultiplier *= 0.002;
    
    const float cLOD    = sqrt(CLOUD_RENDER_LOD);
    vec2 scalecoord  = (texcoord-vec2(1.0-rcp(cLOD), 0.0))*cLOD;
    float d     = max_depth3x3(depthtex1, scalecoord, pixel*cLOD);

        if (clamp(scalecoord, -0.003, 1.003) == scalecoord && d>=1.0) {
            scalecoord      = clamp(scalecoord, 0.0, 1.0);
            vec3 viewpos    = calculateViewSpace(vec3(scalecoord, 1.0));
            vec3 viewvec    = normalize(viewpos);
            vec3 scenepos   = mat3(gbufferModelViewInverse) * viewpos;
            vec3 svec       = normalize(scenepos);

            //vc_render(info.color[2].rgb, viewvec, upvec, lightvec, cameraPosition, dot(viewvec, lightvec), taaDither, svec, scalecoord);
        } else {
            cloud_data = vec4(0.0, 0.0, 0.0, 1.0);
        }

        calculateDispersion(info, coord[1], mat);

    setupSolidAlbedo(info);
    calculateWaterShading(info, mat, spaces);
    //calculateSSS(info, mat, spaces);

    if (depthtex >= 1.0) {
    applyAtmosphere(sky, info.color[0].rgb, spaces.world[2], sunVec[1], lightVec[0], sky.sphereDepths[1], mat.land);
    generateStars(info.color[0].rgb, spaces.world[2], 0.005, mat.land);
    #ifdef Test2DCloud
    Compute2DClouds(info.color[0].rgb, cloudAlpha, space_World, 0.0);
    #endif
    #ifdef VCloudLayer2
	//fc_render(info.color[0].rgb, viewvec, upvec, lightvec, cameraPosition, dot(viewvec, lightvec), taaDither, space_World, scalecoord, pattern);
    #endif
    #ifdef VolumeCloud
    const float cLOD    = sqrt(CLOUD_RENDER_LOD);
    vec2 cloudcoord = (texcoord) * rcp(cLOD) + vec2(1.0 - rcp(cLOD), 0.0);
    if (texture2D(depthtex1, texcoord).x >= 1.0) {
    vec4 tex5   = texture(colortex5, cloudcoord);
    #ifdef Cloud_Bicubic
    tex5 = bicubicTexture(colortex5, cloudcoord, 1.3, pattern);
    #endif
    info.color[0].rgb = info.color[0].rgb * (tex5.a) + tex5.rgb;
    }

	//vc_render(info.color[0].rgb, viewvec, upvec, lightvec, cameraPosition, dot(viewvec, lightvec), taaDither, space_World, scalecoord, pattern);
    #endif

    //AerialPerspective(info, spaces, spaces.view[0], mat);

    //info.color[0].rgb += VL().x * hgPhase(dot(lightvec, viewvec), 0.5) * 1.3 * VL_Strength * ((lightColors[0] + (lightColors[1] * vec3(0.5, 0.8, 1.5)) * 1.4)) * UWmultiplier;
    }

    calculateUnderwaterShading(info, mat, spaces);
    
    calculateShading(info, mat, spaces, pattern, spaces.view[0]);
    drawTransparents(info, mat, spaces);

    AerialPerspective(info, spaces, spaces.view[0], mat);

    //info.color[0].rgb += foggytime(info, spaces, spaces.view[0], mat);
    vec4  vl = calculateVolumetricLight(info, mat, spaces, pattern);
    vec3  scatter      = vl.rgb;
    float transmission = vl.a;
    float VLmultiplier = 1.0;
    float VLmultiplier2 = 1.0;

    info.color[0] += vec4(scatter, transmission) * VLmultiplier;

    //if (cameraPosition.y <= 55) info.color[0].rgb += VL(pattern).x * hgPhase(dot(lightvec, viewvec), 0.5) * 2.0 * 0.5 * VL_Strength * ((lightColors[0] + (lightColors[1] * vec3(0.5, 0.8, 1.5)) * 1.4)) * UWmultiplier  * vec3(0.5 * VL_Red, 0.6 * VL_Green, 1.1 * VL_Blue);
    //if (depthtex <= 0.9999) {
    //calculateVolumetricLight(info, mat, spaces, pattern);
    if (isEyeInWater > 0.5) info.color[0].rgb += VL(pattern).x * hgPhase(dot(lightvec, viewvec), 0.5) * 2.0 * 0.5 * VL_Strength * ((lightColors[0] + (lightColors[1] * vec3(0.5, 0.8, 1.5)) * 1.4)) * UWmultiplier  * vec3(0.5 * VL_Red, 0.6 * VL_Green, 1.1 * VL_Blue);
    //}
    
    #ifdef Accumulated_Debug
    colorWrite = denoise(colortex4, pattern);
    #ifdef Debug_Shadows
    colorWrite.rgb += diffuse(info.color[0].rgb, spaces, lightVec[1], lightColor, shadowLightmap, info, mat);
    #endif
    #else
    //colorWrite   = vec4(info.normal[0], 1.0);
    colorWrite = info.color[0];
    #endif
    //colortex5write = info.color[2];

}