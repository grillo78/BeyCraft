/* DRAWBUFFERS:0 */

layout (location = 0) out vec4 colortex0Write;


const bool colortex0MipmapEnabled = true;


in vec2 texcoord;

flat in mat4 shadowViewMatrix;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowModelView;
flat in mat3 lightColors;
flat in mat2x3 sunVec;
flat in mat2x3 lightVec;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D shadowtex0;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;
uniform sampler2D noisetex;
uniform int worldTime;
uniform sampler2D shadowtex1;
uniform vec2 taaOffset;
uniform vec3 shadowLightPosition;


uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView, gbufferPreviousProjection;
uniform mat4 shadowProjection, shadowProjectionInverse;

uniform vec3 cameraPosition, previousCameraPosition;
uniform vec3 upPosition;

uniform float viewWidth, viewHeight;
uniform float sunAngle;
uniform float rainStrength;
uniform float far;
uniform float frameTimeCounter;

uniform int frameCounter;
uniform int isEyeInWater;

uniform vec2 pixel;


#include "/lib/Global.glsl"

#include "/lib/Utility/Space_Transformations.glsl"
#include "/lib/Utility/Raytrace.glsl"
#include "/lib/Utility/Mapping.glsl"
#include "/lib/Utility/Sampling_Patterns.glsl"

#include "/lib/Shared/Atmosphere_Params.glsl"
#include "/lib/Shared/Atmosphere_Compute.glsl"

#include "/lib/Fragment/BSDF.glsl"
#include "/lib/Fragment/Shadows.glsl"
#include "/lib/Fragment/Nebula.glsl"


float distortionfactor(vec2 shadowspace){
float dist = length(abs(shadowspace * 1.165));
float distortion = ((1.0 - shadowBias) + dist * shadowBias) * 0.97;
return distortion;
}

vec4 VL() {
    #ifndef Volumetric_Light
    return vec4(0.0);
    #endif
    vec4 endPos = gbufferProjectionInverse * (vec4(texcoord.st, texture2D(depthtex0, texcoord.st).r, 1.0) * 2.0 - 1.0);
    endPos /= endPos.w;
    endPos = shadowProjection * shadowModelView * gbufferModelViewInverse * endPos;
    vec4 startPos = shadowProjection * shadowModelView * gbufferModelViewInverse * vec4(0.0, 0.0, 0.0, 1.0);
    vec4 dir = normalize(endPos - startPos);

    vec4 increment = dir * distance(endPos, startPos) / VL_Quality;
    startPos -= increment * bayer128(gl_FragCoord.xy);
    vec4 curPos = startPos;

    mat4 matrix = shadowModelViewInverse * shadowProjectionInverse;

    float lengthOfIncrement = length(increment);

    vec4 result = vec4(0.0);
    for (int j = 0; j < VL_Quality; j++) {
        curPos += increment;
        vec3 shadowPos = (curPos.xyz / vec3(vec2(distortionfactor(curPos.xy)), shadowZstretch)) * 0.5 + 0.5;
        float shadowTransparent = float(texture2D(shadowtex1, shadowPos.st).r > shadowPos.p - 0.00008);
        vec3 shadow = vec3(shadowTransparent);

        result += vec4(shadow * lengthOfIncrement, 1.0) * vec4(1.0);
    }

    return result / (1.0+result);
}

vec3 toNDC(vec3 pos){
	vec4 iProjDiag = vec4(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y, gbufferProjectionInverse[2].zw);
    vec3 p3 = pos * 2. - 1.;
    vec4 fragpos = iProjDiag * p3.xyzz + gbufferProjectionInverse[3];
    return fragpos.xyz / fragpos.w;
}

vec3 calculateSunlightVisibility(vec3 shadowSpace, vec2 pattern, material mat, gbuffer info) {
    const float ditherSize = pow2(16.0);
    float dither = ditherSize * pattern.y + 0.0;
    float hand = float(texture2D(depthtex1,texcoord.xy).r < 0.56);
    if (hand >= 1.0) return vec3(0.2) * pow2(info.lightmap[0].y);
    int   shadowQuality        = 1;
    float inverseShadowQuality = 1.0 / float(shadowQuality);
    float filterSize           = 0.1;

    float shadow0     = 0.0;
    float shadow1     = 0.0;
    vec3  shadowColor = vec3(0.0);

    for (int i = 0; i < shadowQuality; i++) {
        vec2 offset = fermatsSpiralGoldenN(i * ditherSize + dither, shadowQuality * ditherSize) * filterSize / float(shadowMapResolution);

        vec3 shadowSpaceDistorted = distortShadowSpace(shadowSpace + vec3(offset, 0.0));

        shadow0     += calculateShadow(shadowtex0, shadowSpaceDistorted);
        shadow1     += calculateShadow(shadowtex1, shadowSpaceDistorted);
        shadowColor += texture2D(shadowcolor0, shadowSpaceDistorted.xy).xyz;
        //if (mat.translucent > 0.5) shadowColor *= 1.1;

    }
    shadow0     *= inverseShadowQuality;
    shadow1     *= inverseShadowQuality;
    shadowColor *= inverseShadowQuality;

    vec3 shadow = shadow0 + (1.0 - shadow0) * shadow1 * shadowColor;

    return shadow;
}

const vec3  sRGBApproxWavelengths = vec3( 610.0, 549.0, 468.0 );

float radiation(in float temperature, in float wavelength)
{
    float e = exp(1.4387752e+7 / (temperature * wavelength));
    return 3.74177e+29 / (pow(wavelength, 5.0) * (e - 1.0));
}

vec3 radiation(in float t, in vec3 w)
{
    return vec3(
        radiation(t, w.x), 
        radiation(t, w.y), 
        radiation(t, w.z)
    );
}

void generateStars(inout vec3 color, in vec3 worldVector, in float freq, in float visibility) {
    if (visibility >= 1.0) return;
    if (worldTime <= 13400) return;
    if (worldTime >= 23000) return;
	vec3 SSunColor = lightColors[0];
	vec3 SMoonColor = lightColors[1];
	vec3 SLightColor = SSunColor + SMoonColor;

    
    const float minTemp =  3500.0;
    const float maxTemp =  50500.0;
    const float tempRange = maxTemp - minTemp;
    float frequency = freq * 20;

    const float res = 128.0;

    vec3 p  = worldVector * res;
    vec3 id = floor(p);
    vec3 fp = fract(p) - 0.5;

    float rp    = hash13(id);
    float stars = pow(max0(0.75 - length(fp)) * 1.4, 20.0);

    float starTemp = (sin(rp / frequency * PI * 16.0) * 0.5 + 0.5) * tempRange + minTemp;
    vec3  starEmission = radiation(starTemp, sRGBApproxWavelengths) * 1.0e-15;

    color.rgb += vec3(stars) * step(rp, frequency) * pow2(1.0) * starEmission * ((SSunColor * 0.0) + (SMoonColor * 0.3));
    //color.rgb += vec3(0.0, 0.00002, 0.00008);
}


void calculateSpecularLight(inout gbuffer info, material mat, scene spaces, param sky, vec2 pattern) {
    vec3 shadowSpace = calculateShadowSpace(spaces.world[0]);
    vec3 shadowLightmap = calculateSunlightVisibility(shadowSpace, pattern, mat, info);
    if (info.depthtex.x >= 1.0) return;
    float hand = float(texture2D(depthtex1,texcoord.xy).r < 0.56);
    if (hand >= 1.0) return;
    vec3 lightvec = normalize(shadowLightPosition);
    vec3 viewvec = normalize(spaces.view[2]);

    vec3 UWmultiplier = vec3(1.0);
    if (worldTime >= 12500 && worldTime <= 23000) UWmultiplier *= 0.002;


    const ivec2 atmosphereQuality = ivec2(1, 1);
    float compression = length(lightColors[0] + lightColors[1]) * 5.0;

    bool  importantPixels = mat.reflectiveness.y > 0.37; //exp(-1) = 0.3678

    vec3  normal    = mat3(gbufferModelView) * info.normal[1];
    vec3  up        = normalize(upPosition);
    vec3  rayOrigin = spaces.screen[0];

    vec3  H   = normalize(lightVec[0] - spaces.view[2]);
    float NoH = clamp01(dot(normal, H));
    float NoL = clamp01(dot(lightVec[0], normal));
    float NoV = abs(dot(-spaces.view[2], normal));

    vec3 reflectedSunlight = clamp01(BRDF_GGX(NoH, NoL, NoV, mat.roughness.y)) * vec3(1.0) * ((lightColors[0] * 393) + (lightColors[1] * 0.01)) * info.lightmap[1].y * shadowLightmap;
    if (mat.water > 0.5) reflectedSunlight *= 10;
    vec3 reflection = vec3(0.0);

    int rays = importantPixels ? Specular_Rays : 1;

    //if (mat.metalness.y >= 0.8) rays = 10;
    #ifndef Rough_Reflections
    rays = 1;
    #endif

    for (int i = 0; i < rays; i++) {
        vec3 ray;
        vec3 facetNormal = normal;
        bool intersect   = false;

        vec3 reflectionSample = vec3(0.0);

        if (importantPixels) {
                facetNormal  = distributeMicrofacets(normal, hash42(vec2(i, 1.0)), mat.roughness.y, pattern);
                #ifdef Rough_Reflections
                facetNormal  = distributeMicrofacets(normal, hash42(vec2(i + pattern.y, frameCounter)), mat.roughness.y, pattern);
                #endif

            vec3 rayDirection = reflect(spaces.view[2], facetNormal);

            intersect = raytraceIntersection(rayOrigin, rayDirection, ray, 2.0, (20.0 * Refinement_Quality), 4.0);
            if (intersect) {
                float LOD = 0.0;
                reflectionSample = texture2DLod(colortex0, ray.xy, LOD).rgb;
                
            } else if (isEyeInWater < 0.5) {
                param reflectedSky = calculateSkyParameters(rayDirection, up);
                applyAtmosphere2(sky, reflectionSample, rayDirection, sunVec[0], reflectedSky.sphereDepthsClipped, 0.0);
                generateStars(reflectionSample, vec3(spaces.world[2].x, spaces.world[2].y, spaces.world[2].z) + (facetNormal * 0.05), 0.003, 0.0);
                if (floor(ray.xy) == vec2(0.0)) {
                         reflectionSample     = reflectionSample;
                }
                if (mat.water > 0.5) reflectionSample *= 3.0;
                reflectionSample *= pow(info.lightmap[1].y, 3.0) * 1.0;
                reflectionSample += VL().x * hgPhase(dot(lightvec, viewvec), 0.5) * 10.0 * VL_Strength * ((lightColors[0] + (lightColors[1]) * 1.4)) * UWmultiplier * vec3(0.5 * VL_Red, 0.6 * VL_Green, 1.1 * VL_Blue);

            }
        }
        reflectionSample += reflectedSunlight * pow(info.lightmap[1].y, 3.0) * float(!intersect) * 3.5;
        reflection       += reflectionSample * f_dielectric(spaces.view[2], normal, mat.F0.y);
    }

    reflection /= rays;

    if (reflection != reflection) reflection = vec3(0.0, 0.0, 0.0);

    info.color[0].rgb += max0(reflection) * mat.reflectiveness.y;
}

#include "/lib/Fragment/Refraction.glsl"

void main() {
    mat2 coord = mat2(
        texcoord,
        calculateRefraction(texcoord)
    );

    const float cLOD    = sqrt(CLOUD_RENDER_LOD);
        
    vec2 cloudcoord = (texcoord) * rcp(cLOD)+vec2(1.0-rcp(cLOD), 0.0);

    gbuffer  info   = calculateGbufferInformation(coord);
    material mat    = calculateMaterialMasks(info.specular, info.depthtex, info.materialIDs);
    scene    spaces = calculateSpaces(coord, info.depthtex);
    param    sky    = calculateSkyParameters(spaces.view[2], normalize(upPosition));

    vec2 pattern = calculateJitteredSamplingDistributors();

    calculateSpecularLight(info, mat, spaces, sky, pattern);

    if (texture2D(depthtex1, texcoord).x>=1.0) {
    //vec4 tex5   = texture(colortex5, cloudcoord);
    //info.color[0].rgb = info.color[0].rgb * tex5.a + tex5.rgb;
    }

    if (info.color[0] != info.color[0]) info.color[0] = vec4(0.0, 0.0, 0.0, 1.0);
    //vec4 return5    = stex(colortex5);
    //info.color[0] = tex5;


    colortex0Write = make_drawbuffer(info.color[0]);
}