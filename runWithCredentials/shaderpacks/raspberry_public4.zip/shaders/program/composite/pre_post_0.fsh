/* DRAWBUFFERS:06 */

layout (location = 0) out vec4 bloomWrite; //colortex0
layout (location = 1) out vec4 TAAWrite;   //colortex6

const bool colortex0MipmapEnabled = true;
const bool colortex6MipmapEnabled = true;


in vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform sampler2D noisetex;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform int worldTime;

uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView, gbufferPreviousProjection;
uniform vec3 cameraPosition, previousCameraPosition;
uniform float viewWidth, viewHeight;
uniform int isEyeInWater;
uniform int frameCounter;

uniform vec2 pixel;


#include "/lib/Global.glsl"

#include "/lib/Utility/Space_Transformations.glsl"

#include "/lib/Utility/Sampling_Patterns.glsl"


vec2 computeCameraVelocity(in vec3 projection) {
    projection = (cameraPosition - previousCameraPosition) + projection;

    projection = mat3(gbufferPreviousModelView) * projection;
    projection = (diagonal3(gbufferPreviousProjection) * projection + gbufferPreviousProjection[3].xyz) / -projection.z * 0.5 + 0.5;

    return (texcoord.xy - projection.xy);
}


vec3 calculateBloomTile(const float lod, vec2 offset) {
	vec2 coord = (texcoord - offset) * exp2(lod);
	vec2 scale = pixel * exp2(lod);
	
	if (any(greaterThanEqual(abs(coord - 0.5), scale + 0.5)))
		return vec3(0.0);
	
	vec3  bloom       = vec3(0.0);
	float totalWeight = 0.0;
	
	for (int y = -3; y <= 3; y++) {
		for (int x = -3; x <= 3; x++) {
			float weight  = clamp01(1.0 - length(vec2(x, y)) / 4.0);
			      weight *= weight;
			
			bloom += texture2DLod(colortex0, coord + vec2(x, y) * scale, lod).rgb * weight;
			totalWeight += weight;
		}
	}
	
	return bloom / totalWeight;
}

vec3 calculateBloom(material mat) {
	vec3 bloom = vec3(0.0);
	bloom += calculateBloomTile(2.0, vec2(0.0                     ,                    0.0));
	bloom += calculateBloomTile(3.0, vec2(0.0                     , 0.25   + pixel.y * 2.0));
	bloom += calculateBloomTile(4.0, vec2(0.125    + pixel.x * 2.0, 0.25   + pixel.y * 2.0));
	bloom += calculateBloomTile(5.0, vec2(0.1875   + pixel.x * 4.0, 0.25   + pixel.y * 2.0));
	bloom += calculateBloomTile(6.0, vec2(0.125    + pixel.x * 2.0, 0.3125 + pixel.y * 4.0));
	bloom += calculateBloomTile(7.0, vec2(0.140625 + pixel.x * 4.0, 0.3125 + pixel.y * 4.0));

	return bloom * 1.3;
}

float calculateAverageLuminance() {
    const float maxLumaRange  = 2.55;
    const float minLumaRange  = 0.05;
    const float exposureDecay = Auto_Exposure_Decay;

    float avglod = int(exp2(min(viewWidth, viewHeight))) - 1;

	float averagePrevious = texture2DLod(colortex6, vec2(0.0), 0.0).a;
    float averageCurrent  = clamp(sqrt(dot(texture2DLod(colortex0, vec2(0.5), avglod).rgb, lumaCoeff)), minLumaRange, maxLumaRange);

    return mix(averagePrevious, averageCurrent, exposureDecay);
}

vec3 calculateMotionBlur(vec2 coord, vec2 velocity, vec2 pattern) {
    float depth    = texture(depthtex0, texcoord).x;
    bool hand      = depth<0.56;

    float tail          = Motion_Blur_Strength;

    const float sampleDensity = 0.95;
    int   maxSamples          = 2;

    vec2  direction = velocity * tail;
    int   steps     = min(1 + int(floor(length(direction / pixel) * sampleDensity)), maxSamples);

    vec2  increment = direction / steps * 0.5 * Motion_Blur_Strength;
    vec2  screenRay = coord + increment;
    if (depth < 0.56) increment *= 0.0;
    vec3  color     = vec3(0.0);

    for (int i = 0; i < steps; screenRay += increment, i++) {
        color += texture2DLod(colortex0, screenRay, 0.0).rgb;
    }
    return color / steps;
}

//Begin TAA from YMIR / Kappa
#define square(x) (x*x)

vec2 reproject(vec2 texcoord, float depth) {
    float hand  	= float(depth > 0.56);

    vec4 position	= vec4(texcoord, depth, 1.0)*2.0-1.0;
        position    = gbufferProjectionInverse*position;
        position   /= position.w;
        position    = gbufferModelViewInverse*position;

		position   += vec4(cameraPosition-previousCameraPosition, 0.0)*hand;
		position    = gbufferPreviousModelView*position;
		position    = gbufferPreviousProjection*position;

    return (position.xy/position.w)*0.5+0.5;
}

vec4 texture_catmullrom(sampler2D tex, vec2 uv) {
    vec2 res    = textureSize(tex, 0);
    vec2 viewPixelSize = vec2(1.0 / viewWidth, 1.0 / viewHeight);

    vec2 coord  = uv*res;
    vec2 coord1 = floor(coord - 0.5) + 0.5;

    vec2 f      = coord-coord1;

    vec2 w0     = f*(-0.5 + f*(1.0-0.5*f));
    vec2 w1     = 1.0 + square(f)*(-2.5+1.5*f);
    vec2 w2     = f*(0.5 + f*(2.0-1.5*f));
    vec2 w3     = square(f)*(-0.5+0.5*f);

    vec2 w12    = w1+w2;
    vec2 delta12 = w2/w12;

    vec2 uv0    = coord1 - vec2(1.0);
    vec2 uv3    = coord1 + vec2(1.0);
    vec2 uv12   = coord1 + delta12;

        uv0    *= viewPixelSize;
        uv3    *= viewPixelSize;
        uv12   *= viewPixelSize;

    vec4 col    = vec4(0.0);
        col    += textureLod(tex, vec2(uv0.x, uv0.y), 0)*w0.x*w0.y;
        col    += textureLod(tex, vec2(uv12.x, uv0.y), 0)*w12.x*w0.y;
        col    += textureLod(tex, vec2(uv3.x, uv0.y), 0)*w3.x*w0.y;

        col    += textureLod(tex, vec2(uv0.x, uv12.y), 0)*w0.x*w12.y;
        col    += textureLod(tex, vec2(uv12.x, uv12.y), 0)*w12.x*w12.y;
        col    += textureLod(tex, vec2(uv3.x, uv12.y), 0)*w3.x*w12.y;

        col    += textureLod(tex, vec2(uv0.x, uv3.y), 0)*w0.x*w3.y;
        col    += textureLod(tex, vec2(uv12.x, uv3.y), 0)*w12.x*w3.y;
        col    += textureLod(tex, vec2(uv3.x, uv3.y), 0)*w3.x*w3.y;

    return clamp(col, 0.0, 65535.0);
}

float get_luma(vec3 x) {
    return dot(x, vec3(0.2125, 0.7154, 0.0721));
}

#define taa_blend 0.5        //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.5 2.0]
#define taa_mreject 1.5      //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.5 2.0]
#define taa_antighost 15.0
#define taa_antiflicker 0.6

vec3 temporalAntiAliasing(vec3 scenecol, material mat) {
    vec2 coord = texcoord;
    vec3 returnColor 	= vec3(0.0);
	float depth 		= stex(depthtex1).r;
	vec2 reprojectedPos = reproject(texcoord, depth);
    vec2 viewPixelSize = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    vec2 viewSize = vec2(viewWidth, viewHeight);
	float blendWeight = 0.9;

	vec2 px_dist    = 0.5-abs(fract((reprojectedPos-texcoord)*viewSize)-0.5);

    float blend_weight	= dot(px_dist, px_dist);
        blend_weight    = pow(blend_weight, 1.5)*taa_mreject;

    if (clamp(reprojectedPos, 0.0, 1.0) != reprojectedPos) return scenecol;

	vec3 tl = textureLod(colortex0,texcoord+vec2(-viewPixelSize.x, -viewPixelSize.y),0).rgb;
	vec3 tc = textureLod(colortex0,texcoord+vec2( 0.0,         	-viewPixelSize.y),0).rgb;
	vec3 tr = textureLod(colortex0,texcoord+vec2( viewPixelSize.x, -viewPixelSize.y),0).rgb;
	vec3 ml = textureLod(colortex0,texcoord+vec2(-viewPixelSize.x, 0.0         	),0).rgb;
	vec3 mr = textureLod(colortex0,texcoord+vec2( viewPixelSize.x, 0.0         	),0).rgb;
	vec3 bl = textureLod(colortex0,texcoord+vec2(-viewPixelSize.x,  viewPixelSize.y),0).rgb;
	vec3 bm = textureLod(colortex0,texcoord+vec2( 0.0,          	 viewPixelSize.x),0).rgb;
	vec3 br = textureLod(colortex0,texcoord+vec2( viewPixelSize.x,  viewPixelSize.y),0).rgb;

	vec3 min_col = min(min(min(min(min(min(min(min(tl, tc), tr), ml), scenecol), mr), bl), bm), br);
	vec3 max_col = max(max(max(max(max(max(max(max(tl, tc), tr), ml), scenecol), mr), bl), bm), br);

	vec3 reprojection	= texture_catmullrom(colortex6, reprojectedPos).rgb;

	vec3 taa_color 		= clamp(reprojection, min_col, max_col);

	float clamped 		= distance(reprojection, taa_color)/get_luma(reprojection);

    //flicker reduction
    float lum_diff      = distance(reprojection, scenecol)/get_luma(reprojection);
        lum_diff        = 1.0-clamp01(square(lum_diff))*taa_antiflicker;

    vec2 velocity       = (texcoord-reprojectedPos)/viewPixelSize;

    float taa_weight 	= clamp01(1.0-sqrt(length(velocity))/2.0)*0.9;
    float stinkyWeight  = 0.982;
    if (mat.water >= 0.5) stinkyWeight = 0.7;

    if (mat.land < 0.5) taa_weight = max(taa_weight, 0.05);
    taa_weight = max(taa_weight, 0.35);

	taa_weight  = mix(taa_weight, stinkyWeight * TAA_Weight, 1.0-clamp01(lum_diff*taa_blend + blend_weight + clamped*taa_antighost));

	return mix(scenecol.rgb, taa_color.rgb, taa_weight);
}

#include "/lib/Fragment/Refraction.glsl"

void main() {
    mat2 coord = mat2(
        texcoord,
        calculateRefraction(texcoord)
    );

    vec2 texcoord2 = calculateRefraction(texcoord);

    gbuffer  info   = calculateGbufferInformation(coord);
    scene    spaces = calculateSpaces(coord, info.depthtex);

    vec2 pattern = calculateJitteredSamplingDistributors();

    vec3 color = texture2D(colortex0, texcoord2).rgb;

float depth0 = texture2D(depthtex0, texcoord2).x;

vec3 screenspace = vec3(texcoord2, depth0);
vec3 viewspace = calculateViewSpace(screenspace);

vec3 worldspace = mat3(gbufferModelViewInverse) * viewspace;

vec2 CameraVelocity = computeCameraVelocity(worldspace);
vec2 prevCoord = -CameraVelocity + texcoord2;

float weight = floor(prevCoord) == vec2(0.0) ? dot(0.5 - abs(fract(prevCoord / pixel) - 0.5), vec2(1.0)) : 0.0;

mat2x3 limits = mat2x3(0.0);
float exposure = calculateAverageLuminance();
#ifndef Auto_Exposure
exposure = Manual_Exposure;
#endif

ivec2 fragCoord = ivec2(gl_FragCoord.xy);
float depthtex     = texelFetch(depthtex0, fragCoord, 0).x;
vec3 antiAliased;
material mat    = calculateMaterialMasks(info.specular, info.depthtex, info.materialIDs);

vec4 scenecol   = texture2DLod(colortex0, texcoord2, 0.0);
if (mat.land <= 0.5) scenecol = texture2DLod(colortex0, texcoord2, 0.0);

vec3 taa = temporalAntiAliasing(scenecol.rgb, mat);


float hand = float(texture2D(depthtex1,texcoord.xy).r < 0.56);
if (hand >= 1.0) antiAliased = color;
    TAAWrite = vec4(scenecol.rgb, exposure);
    bloomWrite = vec4(calculateBloom(mat), 1.0);
    #ifdef TAA
    TAAWrite = vec4(taa, exposure);
    #endif
}