out vec2 texcoord;
out vec3 upVec;

flat out mat4 shadowViewMatrix;
flat out mat3 lightColors;
flat out mat2x3 sunVec;
flat out mat2x3 lightVec;

uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView, gbufferPreviousProjection;
uniform vec3 cameraPosition, previousCameraPosition;
uniform mat4 shadowModelView;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform float viewWidth, viewHeight;
uniform int frameCounter;


#include "/lib/Utility/Space_Transformations.glsl"

#include "/lib/Vertex/Shadow_Transform.glsl"

#include "/lib/Shared/Atmosphere_Params.glsl"
#include "/lib/Shared/Atmosphere_Lighting.glsl"


void main() {
	texcoord         = gl_MultiTexCoord0.st;
    
    sunVec[0]        = normalize(sunPosition);
    sunVec[1]        = mat3(gbufferModelViewInverse) * sunVec[0];
    lightVec[0]      = normalize(shadowLightPosition);
    lightVec[1]      = mat3(gbufferModelViewInverse) * lightVec[0];
    shadowViewMatrix = calculateShadowViewMatrix();
    lightColors      = calculateLightColors(sunVec[1]);

    gl_Position = ftransform();
}