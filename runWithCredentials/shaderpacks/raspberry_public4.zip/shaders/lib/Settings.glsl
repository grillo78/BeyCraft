/*                         */
/* START DEVELOPER OPTIONS */
/*                         */
#extension GL_EXT_gpu_shader4 : enable

/* Setup Programs */

// Gbuffer program types
#define G_DISCARD 0
#define G_SOLID   1
#define G_FORWARD 2
// PROG_SHADOW only
#define G_SHADOW  3
#define G_VOXEL   4

// Set gbuffers to use program
#define PROG_BASIC       G_SOLID
#define PROG_ENTITIES    G_SOLID
#define PROG_HAND        G_SOLID
#define PROG_SKYBASIC    G_DISCARD
#define PROG_SKYTEXTURED G_DISCARD
#define PROG_TERRAIN     G_SOLID
#define PROG_TEXTURED    G_FORWARD
#define PROG_WATER       G_FORWARD
#define PROG_WEATHER     G_FORWARD
#define PROG_SHADOW      G_SHADOW

/* Setup Buffers */
/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGB16;
const int colortex2Format = RGB16;
const int colortex3Format = RGBA8;
const int colortex4Format = RGB16;
const int colortex5Format = RGBA16F;
const int colortex6Format = RGBA16F;
const int colortex7Format = RGB10_A2;

const bool colortex0Clear = true;
const bool colortex1Clear = true;
const bool colortex2Clear = true;
const bool colortex3Clear = true;
const bool colortex4Clear = false;
const bool colortex5Clear = true;
const bool colortex6Clear = false;
const bool colortex7Clear = true;

const bool shadowtex0Mipmap   = false;
const bool shadowtex1Mipmap   = false;
const bool shadowcolor0Mipmap = false;
const bool shadowcolor1Mipmap = false;
*/

/* Initialize Shader */

const int   noiseTextureResolution  = 64;
const float noiseResInverse         = 1.0 / noiseTextureResolution;

const float sunPathRotation	        = -40;

#define Sun_Size 1.0 //[0.5 0.75 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 10.0]
const float sunAngularRadius  = radians(0.35) * Sun_Size;


/* Setup option toggles */

// General
#define Off        0
#define On         1

#define Performance_Impact_Key 0 //Shows which colors mean what[0 1 2 3 4 5]

// Ambient Occlusion
//#define SSAO      2
//#define RTAO      2

#define About 0 //[0 1]

// Diffuse
#define NdotL      0
#define Hammon_GGX 1

//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

/*                         */
/*        LIGHTING         */
/*                         */

//////////////////////////////////////////////////////////
/*         Shadows         *//////////////////////////////
//////////////////////////////////////////////////////////

#define PCSS
#define ShadowFilter_Quality         5           //[1 5 10 20 40 80]

#define Shadow_Bias                  0.9
#define Shadow_Z_Stretch             2.5
#define shadowBias                   0.9
#define shadowZstretch               2.5

#define SSS
#define SSS_Brightness               1.0          //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
#define SSS_Scatter_Amount           1.0          //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]

//Shadow Constants

const float shadowDistance         = 120.0;

const int   shadowMapResolution    = 2048;  //[512 1024 2048 4096 8192 16384]
const float shadowMapResInverse    = 1.0 / shadowMapResolution;
const float shadowIntervalSize     = 4.0;


//#define RTSM

//////////////////////////////////////////////////////////
/*   Global Illumination   *//////////////////////////////
//////////////////////////////////////////////////////////


//#define Global_Illumination
#define Fake_Bounce

#define GI_Radius                    75           //[10 20 30 40 50 60 75 80 90 100 110 120 130 140 150 160 200 250 300 350 400 450 500 1000 2000]
#define GI_Quality                   2            //[1 2 5 10 25 50]
#define GI_Intensity                 0.8          //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 3.0 4.0 5.0]
//#define Translucent_GI                          //GI on stained glass and foliage blocks

//Temporal weight effects AO as well
#define Temporal_Filter_Weight       0.6          //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 0.91 0.92 0.93 0.94 0.95 0.97 0.98 0.99 0.999]
#define Temporal_Filter_Forgiveness  0.001
//#define Spatial_Filter
#define GI_Bleeding_Fix                           //Disables GI in low skylight levels

//////////////////////////////////////////////////////////
/*    Ambient Occlusion    *//////////////////////////////
//////////////////////////////////////////////////////////

#define Ambient_Occlusion            0            //[0 0]
#define AO_Rays                      5            //[2 5 10 15 20 40]
#define AO_Steps                     10
#define AO_Radius                    1.0
#define AO_Strength                  1.0          //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
//#define Stochastic_AO
#define RTAO_Angle                   0.3          //[0.0 0.1 0.2 0.3 0.4 0.45 0.5]
#define RTAO_Trace_Length            1.0          //Distance a ray will travel before cancelling automatically, lower values can give greater shading on small details, and higher values the opposite.[0.3 0.5 1.0 1.5 2.0 4.0]

//////////////////////////////////////////////////////////
/*        Specular         *//////////////////////////////
//////////////////////////////////////////////////////////

#define Indirect_Diffuse            Hammon_GGX         //[NdotL Hammon_GGX]

#define Specular_Rays                2            //[1 2 4 8 16 32]
#define Refinement_Quality           0.75         //[0.25 0.5 0.75 1.0 2.0 4.0]

#define glossy_reflectiveness        1.0          //[0.0 0.25 0.5 0.75 0.9 0.95 1.0 1.05 1.15 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]
#define metalic_reflectiveness       1.0          //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]
#define Rough_Reflections

//#define Gray_Scale_Specular_Support
//#define Emissive_Mapping
//#define LabPBR_Emissive                         //Use LabPBR alpha emissive instead of blue channel


//////////////////////////////////////////////////////////
/*    Lighting Colors      *//////////////////////////////
//////////////////////////////////////////////////////////

//Emitter
#define Emitter_Red                  1.0         //[0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define Emitter_Green                0.35         //[0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define Emitter_Blue                 0.1         //[0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

#define Emitter_Luminance            1.0         //[0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

const vec3  torchColor = vec3(Emitter_Red, Emitter_Green, Emitter_Blue) * Emitter_Luminance;

//Skylight
#define Skylight

#define Skylight_Brightness          1.0         //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 3.0 4.0]
#define Skylight_Red                 1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]
#define Skylight_Green               1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]
#define Skylight_Blue                1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]

//Sun & Moon
#define Sunlight_Brightness          1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0]

#define Sunlight_Red                 1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]
#define Sunlight_Green               1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]
#define Sunlight_Blue                1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]

#define Moonlight_Brightness         1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0]

#define Moonlight_Red                1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]
#define Moonlight_Green              1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]
#define Moonlight_Blue               1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0 10.0]

const vec3  sunTint    = vec3(1.35, 1.5, 1.5) * 1.0 * vec3(Sunlight_Red, Sunlight_Green, Sunlight_Blue);
const vec3  moonTint   = vec3(0.0015, 0.003, 0.013) * vec3(Moonlight_Red, Moonlight_Green, Moonlight_Blue) * Moonlight_Brightness * 2;

//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

/*                         */
/*         POST            */
/*                         */

//////////////////////////////////////////////////////////
/*         ACES            *//////////////////////////////
//////////////////////////////////////////////////////////

#define SAT_MOD                      0.1         // [-1.0 -0.95 -0.9 -0.85 -0.8 -0.75 -0.7 -0.65 -0.6 -0.55 -0.5 -0.45 -0.4 -0.35 -0.3 -0.25 -0.2 -0.15 -0.1 -0.05 0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define VIB_MOD                     -0.1         // [-0.45 -0.4 -0.35 -0.3 -0.25 -0.2 -0.15 -0.1 -0.05 0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CONT_MOD                     0.2         // [-1.0 -0.95 -0.9 -0.85 -0.8 -0.75 -0.7 -0.65 -0.6 -0.55 -0.5 -0.45 -0.4 -0.35 -0.3 -0.25 -0.2 -0.15 -0.1 -0.05 0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CONT_MIDPOINT                0.0         // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define GAIN_MOD                     0.0         // [-1.0 -0.9 -0.8 -0.7 -0.6 -0.5 -0.4 -0.3 -0.2 -0.1 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define LIFT_MOD                     0.0         // [-10.0 -9.0 -8.0 -7.0 -6.0 -5.0 -4.0 -3.0 -2.0 -1.0 0.0 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0]
#define WHITE_BALANCE                7200        // [4000 4100 4200 4300 4400 4500 4600 4700 4800 4900 5000 5100 5200 5300 5400 5500 5600 5700 5800 5900 6000 6100 6200 6300 6400 6500 6600 6700 6800 6900 7000 7100 7200 7300 7400 7500 7600 7700 7800 7900 8000 8100 8200 8300 8400 8500 8600 8700 8800 8900 9000 9100 9200 9300 9400 9500 9600 9700 9800 9900 10000 10100 10200 10300 10400 10500 10600 10700 10800 10900 11000 11100 11200 11300 11400 11500 11600 11700 11800 11900 12000]     

#define Film_Slope                   0.30        //[0.0 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]
#define Film_Toe                     0.55        //[0.00 0.05 0.15 0.25 0.35 0.45 0.55 0.65 0.75 0.85 0.95 1.05]
#define Film_Shoulder                0.7         //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.6 0.7 0.8 0.9 1.0]
#define Black_Clip                   0.0         //[0.005 0.010 0.015 0.020 0.025 0.030 0.035 0.040 0.045 0.050 0.06 0.07 0.08 0.09 0.1]
#define White_Clip                   0.025       //[0.005 0.010 0.015 0.020 0.025 0.030 0.035 0.040 0.045 0.050 0.06 0.07 0.08 0.09 1.0]
#define Blue_Correction              1.0         //[1.0 0.9 0.8 0.7 0.6 0.5 0.4 0.3 0.2 0.1 0.0 -0.1 -0.2 -0.3 -0.4 -0.5 -0.6 -0.7 -0.8 -0.9 -1.0]
#define Gamut_Expansion              1.0         //[0.0 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0]      

#define in_Match                     0.14        //[0.0 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.40]
#define Out_Match                    0.14        //[0.0 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.40]       


//////////////////////////////////////////////////////////
/*     Bloom & Streaks     *//////////////////////////////
//////////////////////////////////////////////////////////

#define Bloom
#define Bloom_Strength               1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0]

//#define Lens_Streaks
#define Streak_Loops                 30          //[20 30 50 75 100]
#define Streak_Faloff                0.85        //[0.0 0.25 0.5 0.75 0.85 1.0 1.25 1.5 1.75 2.0 2.5]
#define Streak_Brightness            1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5]
//#define Streak_Rotation
//#define Lens_Flare
#define Flare_Strength               1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5]
#define Lens_Shape                   1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5]

//////////////////////////////////////////////////////////
/*          DOF            *//////////////////////////////
//////////////////////////////////////////////////////////

#define DepthOfField

#define DepthOfFieldQuality          16          // [8 16 24 32 40 48 56 64 72 80 88 96 104 112 120 128 256 512]
#define DOF_Bias                     1.0         // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0]
#define DOF_Anamorphic               1.0         // [0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define DOF_Aperture                 15          // [10 15 20 25 30 35 40 45 50 55 60 65 70 75 100 150 300 400]
#define Focal_Length                 35.0        // [0.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0]
#define Aperture_Blades              4           // [2 3 4 5 6 7 8 9 10]
#define Aperture_Rotation

//#define Tilt_Shift
//#define Distance_Blur
#define Underwater_Blur
#define Rain_Blur


//////////////////////////////////////////////////////////
/*        MISC Post        *//////////////////////////////
//////////////////////////////////////////////////////////


//#define Chromatic_Aberration
#define Chromatic_Strength           1.0         //[1.01 1.0 0.999 0.995 0.991]

#define Default_Exposure             0.25        //[0.0 0.15 0.25 0.35 0.45 0.55 0.65 0.75 0.85 0.95 1.05]

//#define Film_Grain
#define Film_Grain_Strength          1.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 2.0 3.0]

#define LUT
#define Selected_LUT                 5           //[0 1 2 3 4 5 6 7 8 9]
//#define SHOW_LUT

#define Motion_Blur
#define Motion_Blur_Strength         1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0]

//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

/*                         */
/*      VOLUMETRICS        */
/*                         */

//////////////////////////////////////////////////////////
/*    Volumetric Clouds    *//////////////////////////////
//////////////////////////////////////////////////////////

#define VolumeCloud

#define CLOUD_RENDER_LOD             6.0         //[128.0 64.0 32.0 16.0 8.0 6.0 4.0 2.0 1.0]
#define LOD_Multiplier               1.0         //[1.0 1.5 2.0 2.5 3.0]

#define Cloud_LOD
#define VCloud_TYPE 1
//#define Cloud_Bicubic                          //Assists with dithering patterns caused by low res clouds, can cause overblurring.


//////////////////////////////////////////////////////////
/*     Volumetric Fog      *//////////////////////////////
//////////////////////////////////////////////////////////

#define Volumetric_Fog

#define VFOG_Strength                2.5         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0 4.0 5.0 6.0]
#define Volume_Fog_Octaves           3           //[1 2 3]
#define Volume_Fog_MaxHeight         128.0
#define VFOG_Speed                   1.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]

#define VFOG_Red                     1.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]
#define VFOG_Green                   1.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]
#define VFOG_Blue                    1.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]


//////////////////////////////////////////////////////////
/*    Volumetric Light     *//////////////////////////////
//////////////////////////////////////////////////////////

#define Volumetric_Light

#define VL_Quality                   1           //[1 3 5 10 15 25]
#define VL_Strength                  1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0 5.0]

#define VL_Red                       1.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]
#define VL_Green                     1.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]
#define VL_Blue                      1.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]

#define rainFog_Strength             1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5]
//#define Day_Fog


//////////////////////////////////////////////////////////
/*    Volumetric Nebula    *//////////////////////////////
//////////////////////////////////////////////////////////

//#define Nebula

#define Nebula_Seed                  5.2         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0 3.1 3.2 3.3 3.4 3.5 3.6 3.7 3.8 3.9 4.0 4.1 4.2 4.3 4.4 4.5 4.6 4.7 4.8 4.9 5.0 5.1 5.2 5.3 5.4 5.5 5.6 5.7 5.8 5.9 6.0 6.1 6.2 6.3 6.4 6.5 6.6 6.7 6.8 6.9 7.0 7.1 7.2 7.3 7.4 7.5 7.6 7.7 7.8 7.9 8.0]
#define Nebula_Loops                 15          //[5 10 15 20 40 80]
#define Nebula_Octaves               4           //[3 4 5 6 7]
#define Nebula_Movement              0.0         //[0.0 0.5 1.0 1.5 2.0]

#define Star_Red                     0.9         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]
#define Star_Green                   0.6         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]
#define Star_Blue                    0.3         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]
#define Star_Brightness              1.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 2.0 2.5 3.0]

//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

/*                         */
/*     MISCELLANEOUS       */
/*                         */

//////////////////////////////////////////////////////////
/*          Water          *//////////////////////////////
//////////////////////////////////////////////////////////

#define Water_thickness              1.0         //[0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0]
//#define Water_Parallax
#define WaveOctaves                  5           //[1 2 3 4 5 6]
#define WaveHeight                   1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0]
#define WaveSpeed                    1.0         //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0]
#define Wind_Intensity               1.0         //[0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3.0]
#define Drag_Intensity               1.0         //[0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5]
#define Cell_Size                    0.0         //Only for new water pattern[-0.25 0.0 0.25 0.5 0.75]

#define Water_Type                   0           //[0 0]
#define Refraction_Depth             1.0         //[0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5]


//////////////////////////////////////////////////////////
/*      Selection Box      *//////////////////////////////
//////////////////////////////////////////////////////////

#define selectionBlockR              0.7         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define selectionBlockG              0.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define selectionBlockB              0.6         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define selectionBlockA              1.0         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]


//////////////////////////////////////////////////////////
/*       Really MISC       *//////////////////////////////
//////////////////////////////////////////////////////////

#define horizonAltitude             1500.0

#define Wind

#define Hand_Height                  0.0         //[-0.7 -0.6 -0.5 -0.4 -0.3 -0.2 -0.1 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9]
#define Hand_Horizontal              0.2         //[-1.0 -0.9 -0.8 -0.7 -0.6 -0.5 -0.4 -0.3 -0.2 -0.1 0.0 0.1 0.2 0.3 0.4 0.5]

#define TallGrass_Shadows

//#define Accumulated_Debug
#define AO_Skylight_Influence
//#define Test2DCloud
#define Parallax_Depth               0.2          //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
//#define POM
#define TAA
#define TAA_Weight                   1.0          //[0.25 0.5 0.75 0.8 0.85 0.9 0.95 1.0 1.04]
#define Auto_Exposure
#define Manual_Exposure              1.25         //[0.01 0.1 0.15 0.2 0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]

#define Auto_Exposure_Decay          0.005        //[0.001 0.005 0.01 0.05 0.1]

//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

#define pixel_size 6 //[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30]
#define pixelX 4 //[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30]
#define pixelY 4 //[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30]
//#define Big_Dither //Original screen dither function by http://maple.pet/
//#define Pixelizer //Original pixelize function by http://maple.pet/

#define Pattern_Red 254 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define Pattern_Green 254 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define Pattern_Blue 254 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define Pattern_Brightness 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0 4.0 5.0 10.0 20.0 30.0]

//#define Color_Compression //Requires Dither!!

#define Preset 1 //[1 2 3 4 5]

#define GBPreset 18 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32]

#define Palette_Brightness 0.3 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.2 2.4 2.6 2.8 3.0]
#define Palette_Contrast 1.6 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.2 2.4 2.6 2.8 3.0]
#define Palette_Gamma 0.4 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.2 2.4 2.6 2.8 3.0]


//#define Debug_Shadows


