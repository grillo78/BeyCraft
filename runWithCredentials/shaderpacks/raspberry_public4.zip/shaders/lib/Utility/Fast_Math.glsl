float flength(vec2 x) {
	return sqrt(dot(x, x));
}

float flength(vec3 x) {
	return sqrt(dot(x, x));
}

float flength(vec4 x) {
	return sqrt(dot(x, x));
}