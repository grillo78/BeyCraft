#include "/lib/Utility/Dither.glsl"
#include "/lib/Utility/Noise.glsl"

vec2 calculateSamplingDistributors() {
    return vec2(
        bayer128(gl_FragCoord.xy),
        toLinear(noiseSmooth(gl_FragCoord.xy * noiseResInverse).rgb).b
    );
}

vec2 calculateJitteredSamplingDistributors() {
    return vec2(
        bayer128(gl_FragCoord.xy + temporalJitter() / pixel * 2.0),
        toLinear(noiseSmooth(gl_FragCoord.xy * noiseResInverse + temporalJitter() / pixel * 2.0).rgb).b
    );
}

vec2 calculateAlteredSamplingDistributors() {
    float prime = frameCounter * 7;
    return vec2(
        fract((bayer128(gl_FragCoord.xy) * 128 + prime) / 128),
        fract((toLinear(noiseSmooth(gl_FragCoord.xy * noiseResInverse).rgb).b * 255 + prime) / 255)
    );
}