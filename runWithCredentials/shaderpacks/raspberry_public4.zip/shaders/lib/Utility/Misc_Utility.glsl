mat2 rotate(float rad) {
	return mat2(
	vec2(cos(rad), -sin(rad)),
	vec2(sin(rad),  cos(rad))
	);
}

vec2 rotateNoMat(vec2 coord, float a, float b) {
    float ns = b * coord.y + a * coord.x;
    float nc = a * coord.y - b * coord.x;
    return vec2(ns, nc);
}

float smin( float a, float b, float k )
{
    float h = clamp( 0.5+0.5*(b-a)/k, 0.0, 1.0 );
    return mix( b, a, h ) - k*h*(1.0-h);
}

#define cubicSmooth(x) (x * x) * (3.0 - 2.0 * x)


float almostIdentity(float x, float m, float n) {
	if (x > m) return x;

	float a = 2.0 * n - m;
	float b = 2.0 * m - 3.0 * n;
	float t = x / m;

	return (a * t + b) * t * t + n;
}

float raySphereDepth(vec3 rayDirection, const vec3 sphere, const float radius) {
    float b = dot(rayDirection, sphere);
    float t = pow2(b) - pow2(sphere.y);

    float depth = b + sqrt(pow2(radius) + t);

    if (-sphere.y > radius) depth += sphere.y + radius;

    return max0(depth);
}

bool raySphereIntersect(vec3 rayDirection, vec3 sphere, float radius, out vec2 hit) {
		hit = vec2(0.0);
	float b = dot(sphere, rayDirection);
	float c = dot(sphere, sphere) - radius * radius;
	
	float d = b * b - c;

    //if (dot(rayDirection, normalize(sphere)) > 1.0) return false;

	if (d < 0.0) {
        return false;
	}
    
	d = sqrt(d);
	
	hit = vec2(-b - d, -b + d);
    return true;
}

vec3 transmittedScatteringIntegral(float od, const vec3 coeff) {
	const vec3 a = -coeff / log(2.0);
	const vec3 b = -1.0 / coeff;
	const vec3 c =  1.0 / coeff;

	return exp2(a * od) * b + c; // = ∫{0,od} e^(-coeff*x) dx
}

#define rcp(x) (1.0/x)

#define stex(x) texture(x, coord)
