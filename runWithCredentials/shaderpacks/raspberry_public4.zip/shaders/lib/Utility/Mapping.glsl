vec2 fermatsSpiralGoldenN(float index, float total) {
	float theta = index * GOLDEN_ANGLE;
	return vec2(sin(theta), cos(theta)) * sqrt(index / total);
}

vec2 fermatsSpiralGoldenS(float index, float total) {
	float theta = index * GOLDEN_ANGLE;
	return vec2(sin(theta), cos(theta)) * pow2(index / total);
}

vec2 sincos(float x) {
    return vec2(sin(x),cos(x));
}

vec2 circlemap(float i, float n) {
    return sincos(i * n * GOLDEN_ANGLE) * sqrt(i);
}

vec3 sphereMap(vec2 a) {
    float phi = a.y * 2.0 * PI;
    float cosTheta = 1.0 - a.x;
    float sinTheta = sqrt(1.0 - cosTheta * cosTheta);

    return vec3(cos(phi) * sinTheta, sin(phi) * sinTheta, cosTheta);
}

vec3 hemisphere(vec3 L, vec3 n) {
    vec3 tangentX = normalize(cross(vec3(0.0, 0.0, 1.0), n));
    vec3 tangentY = cross(n, tangentX);

    return tangentX * L.x + tangentY * L.y + n * L.z;
}