#define PI  radians(180.0)
#define RCPPI 1.0 / PI
#define RCPLOG2 1.0 / LOG2

#define TAU PI * 2.0
#define inversePI 1.0 / PI
#define PHI sqrt(5.0) * 0.5 + 0.5
#define GOLDEN_ANGLE TAU / PHI / PHI

#define lightmapCoeff 1.0323886276

#define lumaCoeff vec3(0.2125, 0.7154, 0.0721)

#define RGB_Wavelengths vec3(750.0, 570.0, 495.0)

#define air_IOR   1.0002
#define water_IOR 1.3333
#define BK7_IOR   1.5176

#define IORtoF0(IOR) pow2(abs((1.0 - IOR) / (1.0 + IOR)))

#define waterRoughness       0.1

#define waterCoefficient     vec3(0.4510, 0.0867, 0.0476) / log(2.0)
#define waterScatterCoeff    vec3(6.9, 7.2, 7.1) * 0.0008 / log(2.0)

#define rayleighCoefficient  vec3(4.847e-6, 1.149e-5, 2.87e-5 ) * 1.0
#define ozoneCoefficient     vec3(3.426, 8.298, 0.356) * 6e-5 / 100.0
#define mieCoefficient       3e-6

#define cloudCoeffScatter    0.02
#define cloudCoeffTransmit   cloudCoeffScatter * 1.11

#define mieScatteringAngle   0.86


#define nebulaCoeff rayleighCoefficient


const float sinSunAngle       = sin(sunAngularRadius);
const float cosSunAngle       = cos(sunAngularRadius);
const float sunSolidAngle     = radians(360.0) * (1.0 - cosSunAngle);