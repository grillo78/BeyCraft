#include "/lib/Utility/Temporal.glsl"

#define diagonal2(mat) vec2((mat)[0].x, (mat)[1].y)
#define diagonal3(mat) vec3((mat)[0].x, (mat)[1].y, mat[2].z)

#define transMAD(mat, v) (     mat3(mat) * (v) + (mat)[3].xyz)
#define  projMAD(mat, v) (diagonal3(mat) * (v) + (mat)[3].xyz)


vec3 calculateViewSpace(vec3 screenSpace) {
	screenSpace = screenSpace * 2.0 - 1.0;
	return projMAD(gbufferProjectionInverse, screenSpace) / (screenSpace.z * gbufferProjectionInverse[2].w + gbufferProjectionInverse[3].w);
}

vec3 calculateScreenSpace(vec3 viewSpace) {
	return (diagonal3(gbufferProjection) * viewSpace + gbufferProjection[3].xyz) / -viewSpace.z * 0.5 + 0.5;
}

float linearizeDepth(float depth) {
	return -1.0 / ((depth * 2.0 - 1.0) * gbufferProjectionInverse[2].w + gbufferProjectionInverse[3].w);
}

float delinearizeDepth(float depth) {
	return ((depth * gbufferProjection[2].z + gbufferProjection[3].z) / depth) * -0.5 + 0.5;
}

#ifdef COMPOSITE

struct scene {
    mat2x3 screen;
    mat3x3 view;
    mat3x3 world;
};

scene calculateSpaces(mat2 coord, vec2 depthtex) {
    scene spaces;
    vec2 jitter = vec2(0.0);
    #if COMPOSITE == 0
    jitter = vec2(0.0);
    #else
    #ifdef TAA
    jitter = temporalJitter() * 0.5;
    #endif
    #endif

    spaces.screen[0] = vec3(coord[0] - jitter, depthtex.x);
    spaces.screen[1] = vec3(coord[1] - jitter, depthtex.y);

    spaces.view[0]   = calculateViewSpace(spaces.screen[0]);
    spaces.view[1]   = calculateViewSpace(spaces.screen[1]);
    spaces.view[2]   = normalize(spaces.view[1]);

    spaces.world[0]  = mat3(gbufferModelViewInverse) * spaces.view[0];
    spaces.world[1]  = mat3(gbufferModelViewInverse) * spaces.view[1];
    spaces.world[2]  = normalize(spaces.world[1]);

    return spaces;
}

#endif