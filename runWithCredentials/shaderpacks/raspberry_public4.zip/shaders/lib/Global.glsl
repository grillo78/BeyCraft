
struct gbuffer {
    mat3x4 color;
    mat2x3 normal;
    mat2x3 specular;
    mat2   lightmap;
    vec2   depthtex;
    float  shadowed;
    ivec2  materialIDs;
    bool   forwardSolidMask;
    bool   gbufferForward;
};

struct material {
    vec2 roughness;
    vec2 reflectiveness;
    vec2 F0;
    vec2 metalness;
    vec2 emissiveness;

    float land;

    float water;
    float translucent;
    float emitter;
    float nonSolid;
};

gbuffer calculateGbufferInformation(mat2 coord) {
    gbuffer info;

    info.color[0]         = texture2D(colortex0, coord[0]);
    info.color[1]         = texture2D(colortex3, coord[0]);
    //info.color[2]         = texture2D(colortex7, coord[0]);

    info.depthtex.x       = texture2D(depthtex0, coord[0]).x;
    info.depthtex.y       = texture2D(depthtex1, coord[1]).x;

    info.forwardSolidMask = info.color[1].a >= 1.0;
    info.gbufferForward   = info.depthtex.y > info.depthtex.x;

    vec4  passthrough1    = texture2D(colortex1, coord[0]);
    vec4  passthrough2    = texture2D(colortex2, coord[0]);

    vec3  lightInfo1      = decode3x16(passthrough1.y);
    vec3  lightInfo2      = decode3x16(passthrough2.y);

    vec3  matInfo1        = decode3x16(passthrough1.z);
    vec3  matInfo2        = decode3x16(passthrough2.z);

    if (!info.gbufferForward) {
        passthrough2 = passthrough1;
        lightInfo2   = lightInfo1;
        matInfo2     = matInfo1;
    }

    if (info.forwardSolidMask) {
        info.depthtex.y = info.depthtex.x;
        passthrough1    = passthrough2;
        lightInfo1      = lightInfo2;
        matInfo1        = matInfo2;
    }

    info.normal[0]        = decodeNormal3x16(passthrough1.x);
    info.normal[1]        = decodeNormal3x16(passthrough2.x);
    
    info.specular[0]      = toLinear(matInfo1);
    info.specular[1]      = toLinear(matInfo2);

    info.lightmap[0]      = pow(pow2(lightInfo1.xy), vec2(1.0, 0.8));
    info.lightmap[1]      = pow(pow2(lightInfo2.xy), vec2(2.0, 0.8));

    info.shadowed         = passthrough1.a * 2.0 - 1.0;

    info.materialIDs.x    = decodeMaterialIDs(lightInfo1.z);
    info.materialIDs.y    = decodeMaterialIDs(lightInfo2.z);

    return info;
}

material calculateMaterialMasks(mat2x3 specular, vec2 depthtex, ivec2 materialIDs) {
    material mat;

    mat.land             = float(depthtex.y < 1.0);

    mat.water            = getMaterialID(materialIDs.y, 1);
    mat.translucent      = getMaterialID(materialIDs.x, 2);
    mat.emitter          = getMaterialID(materialIDs.x, 3);
    mat.nonSolid         = getMaterialID(materialIDs.x, 4);

    mat.roughness.x      = clamp(pow2(1.0 - specular[0].r), 0.001, 1.0);
    mat.roughness.y      = mat.water > 0.5 ? pow2(0.0001) : clamp(pow2(1.0 - specular[1].r), 0.00001, 1.0);
    mat.reflectiveness.x = specular[1].r;
    mat.reflectiveness.y = mat.water > 0.5 ? 0.80 : specular[1].r;
    mat.F0.x             = mix(0.02, 1.0, specular[0].g);
    mat.F0.y             = mix(0.02, 1.0, specular[1].g);
    mat.metalness.x      = specular[0].g;
    mat.metalness.y      = specular[1].g;
    mat.emissiveness.x   = specular[0].b;
    mat.emissiveness.y   = specular[1].b;

    return mat;
}

vec4 make_drawbuffer(in vec3 scenecol, in float alpha) {
    #ifdef MC_GL_RENDERER_GEFORCE
        vec3 temp   = clamp(scenecol, 1.0/65530.0, 65535.0);   //NaN fix on nvidia
    #else
        vec3 temp   = clamp(scenecol, 0.0, 65535.0);
    #endif

    return vec4(temp, alpha);
}
vec4 make_drawbuffer(in vec3 scenecol) {
    #ifdef MC_GL_RENDERER_GEFORCE
        vec3 temp   = clamp(scenecol, 1.0/65530.0, 65535.0);   //NaN fix on nvidia
    #else
        vec3 temp   = clamp(scenecol, 0.0, 65535.0);
    #endif

    return vec4(temp, 1.0);
}
vec4 make_drawbuffer(in vec4 scenecol) {
    #ifdef MC_GL_RENDERER_GEFORCE
        vec3 temp   = clamp(scenecol.rgb, 1.0/65530.0, 65535.0);
    #else
        vec3 temp   = clamp(scenecol.rgb, 0.0, 65535.0);
    #endif

    return vec4(temp, max(scenecol.a, 0.0));
}

//these are for non-scenecolor stuffs
vec4 clamp_drawbuffer(in vec3 scenecol) {
    vec3 temp   = clamp(scenecol, 0.0, 65535.0);

    return vec4(temp, 1.0);
}
vec4 clamp_drawbuffer(in vec4 scenecol) {
    vec3 temp   = clamp(scenecol.rgb, 0.0, 65535.0);

    return vec4(temp, max(scenecol.a, 0.0));
}