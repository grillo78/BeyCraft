const float atmosphereHeight     = 12228.0;
const float earthRadius          = 6371000.0;
const float atmosphereRadius     = earthRadius + atmosphereHeight;
const float atmosphereRadiusSq   = atmosphereRadius * atmosphereRadius;

const vec2  sky_scaleHeights        = vec2(8.0e3, 1.2e3);
const vec2  sky_inverseScaleHeights = 1.0 / sky_scaleHeights;
const vec2  sky_scaledPlanetRadius  = earthRadius * sky_inverseScaleHeights;

const float sky_mieg = 0.87;

// TODO: Calculate these coefficients myself so I can make sure they're consistent with what they should be. Until I do that I'll just use ones I've found that look good.
const vec3 sky_coefficientRayleigh = vec3(5.4000e-6, 1.1500e-5, 2.6100e-5);
const vec3 sky_coefficientOzone    = vec3(6.0550e-6, 5.9788e-6, 5.2136e-6);
const vec3 sky_coefficientMie      = vec3(2.6000e-6, 2.6000e-6, 2.6000e-6); // Should be >= 2e-6, depends heavily on conditions. Current value is just one that looks good.

const mat2x3 sky_coefficientsScattering  = mat2x3(sky_coefficientRayleigh, sky_coefficientMie);
const mat2x3 sky_coefficientsAttenuation = mat2x3(sky_coefficientRayleigh + sky_coefficientOzone, sky_coefficientMie * 1.11); // commonly called the extinction coefficient



struct param {
    vec3  earthPosition;
    bvec2 sphereIntersect;     // [0] = inner sphere || [1] = outer sphere
    mat2  sphereDepths;        // [0] = inner sphere || [1] = outer sphere
    vec2  sphereDepthsClipped; // .x  = entry depth  || .y  = exit depth
    vec3  sunlightColor;
    vec3  moonlightColor;
};

param calculateSkyParameters(vec3 viewVector, vec3 upVec) {
    param sky;
    sky.earthPosition       = upVec * (earthRadius + cameraPosition.y + horizonAltitude);
    sky.sphereIntersect.x   = raySphereIntersect(viewVector, sky.earthPosition, earthRadius, sky.sphereDepths[0]);
    sky.sphereIntersect.x   = sky.sphereIntersect.x && bool(greaterThan(sky.sphereDepths[0], vec2(0.0)));
    sky.sphereDepths[0]     = max0(sky.sphereDepths[0]);

    sky.sphereIntersect.y   = raySphereIntersect(viewVector, sky.earthPosition, atmosphereRadius, sky.sphereDepths[1]);
    sky.sphereIntersect.y   = sky.sphereIntersect.y && bool(greaterThan(sky.sphereDepths[1], vec2(0.0)));
    sky.sphereDepths[1]     = max0(sky.sphereDepths[1]);

    sky.sphereDepthsClipped = sky.sphereDepths[1];
    if (sky.sphereIntersect.x) sky.sphereDepthsClipped.y = sky.sphereDepths[0].x;

    return sky;
}


float rayleighPhase(float VoL) {
	return (3.0 / (16.0 * PI)) * (1.0 + pow2(VoL));
}

float hgPhase(float VoL, float g) {
	return (1.0 / (4.0 * PI)) * ((1.0 - pow2(g)) / pow(1.0 + pow2(g) - 2.0 * g * VoL, 1.5));
}

vec2 calculateAtmosphereOpticalDepth(float rayLength) {
    return exp(rayLength * -sky_inverseScaleHeights + (sky_scaledPlanetRadius + 0.5));
}