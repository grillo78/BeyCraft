
//Volumetric Clouds Originally by RRe36 (https://github.com/rre36)
#define vc_steps 65     //[10 30 65 130 200 300]
#define vc_altitude 512.0   //[-512.0 0.0 64.0 128.0 384.0 512.0 768.0 1024.0 2048.0]
#define vc_thickness 512.0  //[128.0 192.0 224.0 256.0 288.0 320.0 384.0 448.0 512.0 650.0 750.0 850.0 1024.0 1512.0]
#define vc_breakThreshold 0.1 //[0.2 0.1 0.05 0.025 0.01]   this should be rather small, <= 0.1 is usually good
//#define VCloud_Quality 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#define VC_Octaves 2 //[1 2 3]
#define VC_Density 0.3 //[0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
//#define VC_Poof 1.3 //[0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7]
#define VC_Scattering_Steps 10 //[3 5 10 15 20 40]
#define VC_Coverage 0.75 //[0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 3.0 4.0 5.0 10.0]
//#define VC_DetailNoise 3 //[1 2 3]
//#define VC_Fade 0.3 //high values may cause issues depending on cloud resolution[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
//#define NoiseType 3 //[1 2 3]
//#define Atmos_Fade 0.3 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8]
//#define LOWQ_Shape
#define Cloud_Speed 0.75 //[0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0]


#define RRe36 0 //https://github.com/rre36

const float atmosphere_planetRadius = 1731e3;
uniform float wetness;

const float vc_highedge     = vc_altitude+vc_thickness;
uniform float eyeAltitude;
//uniform sampler3D colortex7;
uniform float frameTime;

float stepsdynamic = vc_steps;
float vcCloudQDynamic = 1.0;

float vc_windTick   = frameTimeCounter * 0.05 * Cloud_Speed;
const float invLog2 = 1.0/log(2.0);

const float windDirectionRad  = radians(85.0);
const vec2  windDirection     = vec2(sin(windDirectionRad), cos(windDirectionRad));

vec2 rotateNoMat(vec2 coord, vec2 x) {
    float ns = x.y * coord.y + x.x * coord.x;
    float nc = x.x * coord.y - x.y * coord.x;
    return vec2(ns, nc);
}

vec3 planetCurvePosition(in vec3 x) {
    return vec3(x.x, length(x + vec3(0.0, atmosphere_planetRadius, 0.0)) -atmosphere_planetRadius, x.z) * 1.0;
}

vec3 noise_2d(vec2 pos) {
    return texture(noisetex, pos).xyz;
}

float getNoise3D(vec3 pos) {
    //pos.xz  = rotateNoMat(pos.xy + pos.yz, windDirection * 0.8);

    vec3 i          = floor(pos);
    vec3 f          = fract(pos);

    vec2 p1         = (i.xy + i.z * vec2(17.0) + f.xy);
    vec2 p2         = (i.xy + (i.z + 1.0) * vec2(17.0)) + f.xy;
    vec2 c1         = (p1 + 0.5) / noiseTextureResolution;
    vec2 c2         = (p2 + 0.5) / noiseTextureResolution;
    float r1        = texture(noisetex, c1).r;
    float r2        = texture(noisetex, c2).r;
    return mix(r1, r2, f.z);
}

vec3 noise_3d(vec3 pos) {   //x-large scale worley, y-small scale worley, z-perlin-worley
    return texture(depthtex2, fract(pos)).xyz;
}

float getSlicedWorley(in vec3 pos) {
    pos /= 54.0;

    return texture(depthtex2, fract(pos)).x;
}

float getSlicedWorleySmall(in vec3 pos) {
    pos /= 54.0;

    return texture(depthtex2, fract(pos)).y;
}

float getPerlin(in vec3 pos) {
    pos /= 54.0;

    return texture(depthtex2, fract(pos)).z;
}

float worley13(vec2 ge) {
    float dis = 1.0;
    for(int x = -1; x <= 1; x++) {
        for(int y = -1; y <= 1; y++) {
            vec2  p = floor(ge) + vec2(x, y);
            float d = length(hash22(p) + vec2(x, y) - fract(ge));
            if (dis>d) dis = d;
        }
    }
    return clamp01(1.0 - dis);
}

vec2 rotate_coord(vec2 pos, const float angle) {
    return vec2(cos(angle)*pos.x + sin(angle)*pos.y, 
                cos(angle)*pos.y - sin(angle)*pos.x);
}

float fbm(vec3 pos, vec3 offset, const float persistence, const float scale, const int octaves) {
    float n     = 1.0;
    float a     = 0.44;
    vec3 shift  = offset;
    float d     = a;

    for (int i = 0; i<(1 + 1); ++i) {

        n   += getNoise3D(pos + shift * ( 1.0 + (float (i) / (1 + 1)) * 0.25)) * a * (0.85 + rainStrength);
        //n   += getPerlin(pos + shift* 1.0 / VC_Octaves) * 0.021 * (0.95 + rainStrength) * pow2(VC_Coverage) * 0.8;

        //n   += getSlicedWorley(pos + shift* 1.0 / VC_Octaves) * 0.021 * (0.95 + rainStrength) * pow2(VC_Coverage) * 3.8;

        //n   += worley13(pos + shift* 1.0 / VC_Octaves) * (0.95 + rainStrength) * 0.25;
        pos *= scale * 0.95;
        a   *= persistence;
        d   += a;
    }
    return n/d;
}

float vcloud_depth = 6000.0;

#define sstep(x, low, high) smoothstep(low, high, x)    //because opengl's smoothstep input order is dumb

float vc_getCoverage(vec3 pos) {
    const float lowEdge     = vc_altitude;
    const float highEdge    = vc_altitude+vc_thickness;

    float lowErode  = 1.0-sstep(pos.y, vc_altitude, vc_altitude+vc_thickness*0.13);     //you were using the "wrong" smoothstep here
    float highErode = sstep(pos.y, vc_altitude+vc_thickness*0.2, highEdge);

    float lowFade   = sstep(pos.y, vc_altitude, vc_altitude+vc_thickness*0.075);
    float highFade  = 1.0-sstep(pos.y, vc_altitude+vc_thickness*0.6, highEdge);

    pos *= 0.0016;

    vec3 wind       = vec3(vc_windTick, 0.0, vc_windTick);

    float lcoverage = GetNoise(pos.xz * 0.05 + wind.xz * 0.04)  - (rainStrength);
        lcoverage   = smoothstep(0.2, 0.9, lcoverage) * (1.0 - VC_Coverage);


    //float shape     = fbm(pos, wind, 0.45, 0.3, 1);
    /* 2d noise is faster and more controllable here, also does less weird shape things and looks more authentic */
    float shape     = GetNoise(pos.xz + wind.xz);

        shape      += GetNoise(pos.xz * 3.0 + wind.xz)*0.5;

        //shape      += GetNoise(pos.zy * 0.1 + wind.xz)*0.1;
        //shape      += fbm(pos, wind, 0.45, 0.3, 1);
        shape      -= 0.455;

        shape      *= lowFade;  //pls no multiplier on the fades, makes stuff go weird
        shape      *= highFade;
        shape      -= lowErode * 0.2;
        shape      -= highErode * 1.3;

        shape      -= lcoverage * 1.2;  //this gives some nice varying cloud sizes now

    return max(shape, 0.0);
}

float vc_getShape(vec3 pos, float coverage, vec2 pattern) {
    pos             *= 0.0012;
    pos.xz  = rotate_coord(pos.xz, 3.14*0.33);

    #if (VC_Octaves <= 1) 
    pos *= 1.2;
    #endif
    
    vec3 wind       = vec3(vc_windTick, 0.0, vc_windTick);

    pos            += wind * 0.1;

    float shape     = coverage;
    float ditherOffset = fract((pattern.y * 128 + frameCounter * 7) / 128);
    float div       = 0.0;
    float noise     = 0.0;

    /* i guess the new shape is a lot more readable */
    /* i simply reuse the noise and div variables here with every octave by overwriting them */
    /* this method also allows you to make the most out of one 3d noise sample by using multiple channels of it */
    /* i leave the customization to you and just made a base to work off */
pos.xz  = rotate_coord(pos.xz, 3.14*0.33);
    vec3 octave1    = noise_3d(pos*0.8);
        //pos.xz  = rotate_coord(pos.xz, 3.14*0.33);
        //pos.xz  = rotateNoMat(pos.xz + pos.xy, windDirection * 1.8);
        noise       = octave1.x;        div  = 1.0;
        noise      += octave1.z * 0.4;  div += 0.3;

        noise      /= div;

        shape      -= (1.0 - noise) * 0.5;
        //shape      -= (0.8 - octave1.z) * 0.16;

    #if (VC_Octaves >= 2)
    vec3 octave2    = noise_3d(pos*3.9);
        //if (pos.x <= 15.0) octave2 = vec3(0.0);
        noise       = octave2.z;        div  = 1.0;
        noise      += octave2.z;        div += 0.53;

        noise      /= div;

        shape      -= (1.0 - noise) * 0.21;
        //shape      -= (0.8 - octave1.z) * 0.12;

    #endif
    #if (VC_Octaves >= 3)
    vec3 octave3    = noise_3d(pos*1.0);

        noise       = octave3.z * 1.4;        div  = 1.0;
        noise      += octave3.x * 0.1;        div += 0.1;


        noise      /= div;

        shape      -= (noise) * 0.1;
    #endif
    return max(shape, 0.0);
}

float vc_mie(float x, float g) {
    float temp  = 1.0 + pow2(g) - 2.0*g*x;
    return (1.0 - pow2(g)) / ((6.0*PI) * temp*(temp*0.5+0.5)) * 0.85;
}

//made phase gud
float vc_phase(float cos_theta, float g) {
    float mie1  = vc_mie(cos_theta, 0.12*g) + vc_mie(cos_theta, 0.45*g) * 0.8;
    float mie2  = vc_mie(cos_theta, -0.25*g) * 5.0;
    return mix(mie1, mie2 * 1, 0.18);
}

//i improved this one a little
float vc_getLD(vec3 rpos, const int steps, vec3 lvec, vec2 pattern) {
    vec3 dir    = normalize(mat3(gbufferModelViewInverse)*lvec);

    float basestep = mix(50.0, 6.0, clamp01(float(steps-1)/4.0));    //this fixes various issues related to exponential marching and high sample counts
    float exponent = mix(1.2, 1.1, clamp01(float(steps-8)/8.0));

    float stepsize  = basestep;

    float od    = 0.0;

    for (int i = 0; i < steps; ++i, rpos += dir * stepsize) {
        if (rpos.y < vc_altitude || rpos.y > vc_highedge) continue;
        stepsize *= exponent;

        float coverage = vc_getCoverage(rpos);
        if (coverage < 0.001) continue;

        float density  = vc_getShape(rpos, coverage, pattern);
              density *= VC_Density;

        if (density <= 0.001) continue;

        od += density * stepsize;
    }
    return od;
}

#define vcloud_clipdist 15000.0     //basically the far plane for the cloud rendering

void vc_render(inout vec4 data, vec3 viewvec, vec3 upvec, vec3 lightvec, vec3 camerapos, float vdotl, float dither, vec3 worldpos,  in vec2 coord, vec2 pattern) {
    vec3 wvec   = mat3(gbufferModelViewInverse) * viewvec;
    vec2 psphere = rsi((atmosphere_planetRadius + eyeAltitude) * upvec, viewvec, atmosphere_planetRadius);
    bool visible = !((eyeAltitude < vc_altitude && psphere.y > 0.0) || (eyeAltitude > (vc_altitude + vc_thickness) && wvec.y > 0.0));

    float moonFade = clamp(0.75 * (0.9 * (smoothstep(13000.0, 12000.0, float(worldTime)) + smoothstep(23000.0, 25000.0, float(worldTime)))),0.03, 1.0);
    if (visible) {
        const float lowEdge     = vc_altitude;
        const float highEdge    = vc_altitude+vc_thickness;

        vec2 bsphere    = rsi(vec3(0.0, 1.0, 0.0)*atmosphere_planetRadius+eyeAltitude, wvec, atmosphere_planetRadius + lowEdge);
        vec2 tsphere    = rsi(vec3(0.0, 1.0, 0.0)*atmosphere_planetRadius+eyeAltitude, wvec, atmosphere_planetRadius + highEdge);

        float startdist = eyeAltitude>highEdge ? tsphere.x : bsphere.y;
        float enddist   = eyeAltitude>highEdge ? bsphere.x : tsphere.y;

        vec3 startpos   = wvec * startdist;
        vec3 endpos     = wvec * enddist;

        float mrange    = (1.0 - clamp01 ((eyeAltitude - highEdge) * 0.2)) * (1.0 - clamp01((lowEdge - eyeAltitude) * 0.2));

        startpos        = mix(startpos, gbufferModelViewInverse[3].xyz, mrange);
        endpos          = mix(endpos, worldpos * (highEdge * 20.0 / far), mrange);

        startpos    = planetCurvePosition(startpos);
        endpos      = planetCurvePosition(endpos);

        vec3 bstep      = (endpos - startpos) / stepsdynamic;
        float blength = vc_thickness / stepsdynamic;
        float stepsCoeff = length(bstep) / blength;
            stepsCoeff  = 0.5 + clamp(stepsCoeff - 1.25, 0.0, 3.0) * 0.4 * vcCloudQDynamic;
            stepsCoeff  = mix(stepsCoeff, 30.0, pow3(mrange));      //this compensates the sample loss when being inside the cloud volume
        int steps       = int(stepsdynamic * stepsCoeff);

        vec3 rstep  = (endpos - startpos) / stepsdynamic;
        vec3 rpos   = rstep * dither + startpos + camerapos;

        float rlength = length(rstep);
        //steps += int(rlength);
        vec2 scatter    = vec2(0.0);
        float transmittance = 1.0;

        //vec3 lightColor = (lightColors[0] * sunTint * 0.9) + (lightColors[1] * moonTint * 3) * Sunlight_Brightness;
        //vec3 ambientColor = lightColors[2] * lightColor / PI * vec3(1.0, 0.9, 1.2);

        vec3 sunlight   = (lightColors[0]) * vec3(0.33, 0.45, 0.82) * 48.5;
            //sunlight    = vec3(1.0, 0.93, 0.9) * 2.0 * ((lightColors[0] * 4.8) + (MoonColor * 2)) * Sunlight_Brightness * 0.9;
        vec3 skylight   = lightColors[2] * 2.42 * moonFade;
        //skylight *= vec3(1.0, 0.7, 0.5);


        //this is new
        float fade      = 0.0;
        float fdist     = vcloud_clipdist + 1.0;    //we use this for the atmosfade later
        float pfade     = clamp01(vc_mie(vdotl, 0.4)); //this is used to fade the powder

       //this stuff is explained in my paper too, you can easily find it by it's name there
        const float sigma_a = 1.00;         //absorption coeff, not physical but helps making the cloud appear more dense
        const float sigma_s = 0.9;         //scattering coeff, can technically be assumed to be sigma_t since the albedo is close to 1.0
        const float sigma_t = 0.6;         //extinction coeff, 0.05-0.12 for cumulus, 0.04-0.06 for stratus


        //i pretty much revamped the raymarching loop
        for (int i = 0; i<stepsdynamic; ++i, rpos += rstep) {
            if (transmittance < vc_breakThreshold) break;
            if (rpos.y < lowEdge || rpos.y > highEdge) continue;

            float dist  = distance(rpos, camerapos);
            if (dist > vcloud_clipdist) continue;
            float dfade = clamp01(dist / vcloud_clipdist);
            
            float coverage = vc_getCoverage(rpos);
            if (coverage <= 0.005) continue;  //< 0.01 is decent enough here since the cloud shape is subtractive

            float density  = vc_getShape(rpos, coverage, pattern);
            density *= VC_Density;
            if (density <= 0.005) continue;

            if (fdist > vcloud_clipdist) fdist = dist;      //this part solves some problems with the fade distance
            else fdist  = mix(fdist, dist, transmittance);

            fade        = sstep(dfade, 0.15, 0.99);     //this is used later to hide the distance cutoff nicely

            float extinction    = density * sigma_t;
            float stept         = exp2(-extinction * rlength * invLog2);
            float integral      = (1.0 - stept) / sigma_t;  //this is a redundant scattering integral compared to previous approaches, see my paper for details

            //lighting is now done here because it is easier to read
            vec2 result_scatter = vec2(0.0);

            float direct_od     = vc_getLD(rpos, VC_Scattering_Steps, lightvec, pattern) * sigma_a;

            float skylight      = sqrt(clamp01((rpos.y - vc_altitude) / vc_thickness));     //the approximated skylight works pretty much fine, no need to change this

            float powder        = 1.0 - exp2(-density * 1.0 * sigma_a * invLog2);    //make powder for skylight and direct light
            float dpowder       = min(powder, 1.0 - exp2(-direct_od * 1.0 * invLog2));
                dpowder         = mix(dpowder, 5.0, pfade);

            for (int j = 0; j < VC_Scattering_Steps; ++j) {
                float n     = float(j);

                float s_d   = sigma_s * pow(0.55, n);    //scatter derivate
                float t_d   = sigma_t * pow(0.5, n);    //transmittance/attentuation derivate
                float phase = vc_phase(vdotl, pow(0.6, n));

                result_scatter.x += exp2(-direct_od * t_d * invLog2) * phase * dpowder * s_d;
            }
            result_scatter.y = skylight * powder;

            scatter        += result_scatter * integral * transmittance;

            transmittance *= stept;
        }

        transmittance   = clamp((transmittance - vc_breakThreshold) / (1.0 - vc_breakThreshold), 0.0, 1.0);
        fade            = clamp01(1.0 - fade);

        vec3 color      = sunlight * scatter.x + skylight * scatter.y;
            color      *= 1.5;


        float atmosfade = exp2(-fdist * invLog2 * 2e-4) * fade * 1.0;     //some gud fade

        transmittance   = mix(1.0, transmittance, atmosfade);

        //scenecolor     *= transmittance;
        //scenecolor     += color * fade;
        data    = vec4(color*fade, transmittance);
    if (worldTime >= 13000 && worldTime <= 22000) data    = vec4(0.0, 0.0, 0.0, 1.0);
    } else {
        data    = vec4(0.0, 0.0, 0.0, 1.0);
    }
}