mat3 calculateLightColors(vec3 sunVec) {
    // Calculates light colors, [0] sunlight, [1] moonlight
    const int steps = 10;
    const vec3 earthPosition = vec3(0.0, earthRadius + horizonAltitude, 0.0);

    vec3   lightIntersect = vec3(
        raySphereDepth( sunVec, -earthPosition, atmosphereRadius),
        raySphereDepth(-sunVec, -earthPosition, atmosphereRadius),
        atmosphereHeight
    );

    vec3 stepSize = lightIntersect / steps;

    mat3 rayDirections = mat3(
         sunVec * lightIntersect.x,
        -sunVec * lightIntersect.y,
        vec3(0.0, 1.0, 0.0) * lightIntersect.z
    );

    mat3 increments = mat3(
        rayDirections[0] / steps,
        rayDirections[1] / steps,
        rayDirections[2] / steps
    );

    mat3 rays = mat3(
        earthPosition,
        earthPosition,
        earthPosition
    );

    mat3 transmission = mat3(
        vec3(1.0),
        vec3(1.0),
        vec3(1.0)
    );
    
    vec3 scatter = vec3(0.0);

    for (int i = 0; i < steps; i++, rays[0] += increments[0], rays[1] += increments[1]) {
        mat3x2 opticalDepth = mat3x2(
            calculateAtmosphereOpticalDepth(length(rays[0])) * stepSize.x,
            calculateAtmosphereOpticalDepth(length(rays[1])) * stepSize.y,
            calculateAtmosphereOpticalDepth(length(rays[2])) * stepSize.z
        );

        scatter += sky_coefficientsAttenuation * opticalDepth[2] * transmission[2];
        transmission[0] *= exp(sky_coefficientsAttenuation * -opticalDepth[0]);
        transmission[1] *= exp(sky_coefficientsAttenuation * -opticalDepth[1]);
        transmission[2] *= exp(sky_coefficientsAttenuation * -opticalDepth[2]);
    }

    return mat3(transmission[0], transmission[1], scatter);
}
/*
void calculateAmbientDirections(out vec3[8] ambientDirections) {
    ambientDirections = vec3[8](
        vec3(-1.0,  1.0,  1.0), vec3( 1.0,  1.0,  1.0),
        vec3(-1.0,  1.0, -1.0), vec3( 1.0,  1.0, -1.0),
        vec3(-1.0, -1.0,  1.0), vec3( 1.0, -1.0,  1.0),
        vec3(-1.0, -1.0, -1.0), vec3( 1.0, -1.0, -1.0)
    );

    for (int i = 0; i < 8; i++) {
        ambientDirections[i] = normalize(ambientDirections[i]);
    }
}

void calculateDirectionalAmbient(in vec3[8] ambientDirections, in vec3 sunVector, out vec3[8] ambientScatter) {
    const ivec2 ambientQuality = ivec2(10, 2);
    const vec3  earthPosition  = vec3(0.0, earthRadius + horizonAltitude, 0.0);
    vec3[8] temp = vec3[8](
        vec3(0.0), vec3(0.0),
        vec3(0.0), vec3(0.0),
        vec3(0.0), vec3(0.0),
        vec3(0.0), vec3(0.0)
    );

    for (int i = 0; i < 8; i++) {
        vec3 transmission;
        mat3 scattering = sampleScattering(earthPosition, ambientDirections[i], sunVector, -sunVector, ambientQuality, transmission);

        temp[i] = mix(scattering[0] * sunTint + scattering[1] * moonTint + scattering[2] * lightColors[3], lightColors[3], rainStrength);
    }
    ambientScatter = temp;
}
*/