
float sky_rayleighPhase(float cosTheta) {
	const vec2 mul_add = vec2(0.2, 0.58) / PI;
	return cosTheta * mul_add.x + mul_add.y * 1.0;
}

float sky_miePhase(float cosTheta, const float g) {
	float gg = g * g;
	float p1 = (0.375 * (1.0 - gg)) / (PI * (2.0 + gg));
	float p2 = (cosTheta * cosTheta + 1.0) * pow(-2.0 * g * cosTheta + 1.0 + gg, -1.5);
	return (p1 * p2);
}

vec2 sky_phase(float cosTheta, const float g) {
	return vec2(sky_rayleighPhase(cosTheta), sky_miePhase(cosTheta, g));
}

vec2 sky_atmosphereThickness(vec3 position, vec3 direction, float rayLength, const float steps) {
	float stepSize  = rayLength / steps;
	vec3  increment = direction * stepSize;
	position += increment * 1.0;

	vec2 thickness = vec2(0.0);
	for (float i = 0.0; i < steps; i++, position += increment) {
        float rayLength = length(position);
		thickness      += calculateAtmosphereOpticalDepth(rayLength);
	}

	return thickness * stepSize;
}
vec2 sky_atmosphereThickness(vec3 position, vec3 direction, const float steps) {
	float rayLength = dot(position, direction);
	      rayLength = sqrt(rayLength * rayLength + atmosphereRadiusSq - dot(position, position)) - rayLength;

	return sky_atmosphereThickness(position, direction, rayLength, steps) * 1.0;
}

vec3 sky_atmosphereOpticalDepth(vec3 position, vec3 direction, float rayLength, const float steps) {
	return sky_coefficientsAttenuation * sky_atmosphereThickness(position, direction, rayLength, steps);
}
vec3 sky_atmosphereOpticalDepth(vec3 position, vec3 direction, const float steps) {
	return sky_coefficientsAttenuation * sky_atmosphereThickness(position, direction, steps);
}

vec3 sky_atmosphereTransmittance(vec3 position, vec3 direction, const float steps) {
	return exp(-sky_atmosphereOpticalDepth(position, direction, steps));
}


vec4 calculateSunSpot(vec3 viewVector, vec3 sunVector) {
	float cosTheta = dot(viewVector, sunVector);

	const vec3 a = vec3(0.397, 0.503, 0.652);
	const vec3 halfa = a * 0.5;
	const vec3 normalizationConst = vec3(0.896, 0.873, 0.844);

	float x = clamp(1.0 - ((sunAngularRadius * 1.3) - acos(cosTheta)) / (sunAngularRadius * 5.3), 0.0, 1.0);
	vec3 sunDisk = sunTint * exp2(log2(-x * x + 1.0) * halfa) / normalizationConst;

    return vec4(sunDisk * vec3(1.0, 0.8, 0.2), float(cosTheta > cos(sunAngularRadius * 5.3)));
}

vec4 calculateMoonSpot(vec3 viewVector, vec3 moonVector) {
	float cosTheta = dot(viewVector, moonVector);

	const vec3 a = vec3(0.397, 0.503, 0.652);
	const vec3 halfa = a * 0.5;
	const vec3 normalizationConst = vec3(0.896, 0.873, 0.844);

	float x = clamp(1.0 - ((sunAngularRadius * 2.2) - acos(cosTheta)) / (sunAngularRadius * 2.2), 0.0, 1.0);
	vec3 moonDisk = moonTint * exp2(log2(-x * x + 1.0) * halfa) * 250 / normalizationConst;

    return vec4(moonDisk, float(cosTheta > cos(sunAngularRadius)));
}


vec3 sky_atmosphere(
    vec3 background, 
    vec3 viewVector, 
    vec3 sunVector, vec3 moonVector, vec3 earthPosition, 
    const vec3 sunIlluminance, const vec3 moonIlluminance, 
    const ivec2 steps, 
    const vec2 skyDepths
) {
	const int iSteps = steps.x;
	const int jSteps = steps.y;

    float iStepSize  = (skyDepths.y - skyDepths.x) / iSteps;

	vec3  iIncrement = viewVector * iStepSize;
	vec3  iPosition  = earthPosition;

	vec2 phaseSun  = sky_phase(dot(viewVector, sunVector), sky_mieg);
	vec2 phaseMoon = sky_phase(dot(viewVector, moonVector), sky_mieg);

	vec3 scatteringSun  = vec3(0.0);
	vec3 scatteringMoon = vec3(0.0);
	vec3 transmittance  = vec3(1.0);

	for (int i = 0; i < iSteps; ++i, iPosition += iIncrement) {
        float rayLength = length(iPosition);
		vec2 density    = calculateAtmosphereOpticalDepth(rayLength);
		if (density.y > 1e15) break;
		vec2 stepAirmass = density * iStepSize;
		vec3 stepOpticalDepth = sky_coefficientsAttenuation * stepAirmass;

		vec3 stepTransmittance = exp(-stepOpticalDepth);
		vec3 stepTransmittedFraction = (stepTransmittance - 1.0) / -stepOpticalDepth;
		vec3 stepTransmittedScattering = (sky_coefficientsScattering * (stepAirmass * phaseSun)) * transmittance * stepTransmittedFraction;

		scatteringSun  += stepTransmittedScattering * sky_atmosphereTransmittance(iPosition, sunVector, jSteps);
		scatteringMoon += stepTransmittedScattering * sky_atmosphereTransmittance(iPosition, moonVector, jSteps);
		transmittance  *= stepTransmittance;
	}

	vec3 scattering = scatteringSun * sunIlluminance + scatteringMoon * moonIlluminance;
	float multiplier = 1.0;
	//if( worldTime > 12800 && worldTime < 23000) multiplier = 0.006;
	return (background * transmittance + scattering) * 12.3 * vec3(0.8, 0.9, 2.61) * multiplier * vec3(Skylight_Red, Skylight_Green, Skylight_Blue);
}

void applyAtmosphere(in param sky, inout vec3 color, in vec3 viewVector, in vec3 sunVector, in vec3 moonVector, in vec2 depths, in float skyMask) {
    if (skyMask > 0.5) return;

    // Calculate Backdrop
	float moonFade = smoothstep(0.0, 0.005, -sunVec[1].y);

    vec4 sunSpot = calculateSunSpot(viewVector, sunVector) * 21;
	vec4 moonSpot = calculateMoonSpot(viewVector, -sunVector) * 0.03;
	moonSpot.rgb *= vec3(0.8, 0.5, 0.1);
    vec3 stars   = vec3(0.0);
	ivec2 qualities = ivec2(10,3);
	if (worldTime >= 1000 && worldTime <= 11000) qualities = ivec2(3, 3);

    color = mix(stars, (sunSpot.rgb), sunSpot.a);
    color += (moonSpot.rgb);

    color = sky_atmosphere(color, viewVector, sunVector, -sunVector, sky.earthPosition, sunTint, moonTint * 0.001, qualities, depths);
}

void applyAtmosphere2(in param sky, inout vec3 color, in vec3 viewVector, in vec3 sunVector, in vec2 depths, in float skyMask) {
    if (skyMask > 0.5) return;

    // Calculate Backdrop
    float moonFade = clamp(0.75 * (0.9 * (smoothstep(13000.0, 12000.0, float(worldTime)) + smoothstep(23000.0, 24000.0, float(worldTime)))), 0.01, 1.0);

    vec4 sunSpot = vec4(0.0);
    vec3 stars   = vec3(0.0);

    color = mix(stars, (sunSpot.rgb), sunSpot.a);
    color = sky_atmosphere(color, viewVector, sunVector, -sunVector, sky.earthPosition, sunTint, vec3(0.1, 0.1, 0.1), ivec2(3, 3), depths) * moonFade;
	//color = clamp(color, 0.0, 1.0);
}