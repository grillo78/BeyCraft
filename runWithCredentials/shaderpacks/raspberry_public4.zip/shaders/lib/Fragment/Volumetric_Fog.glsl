float distortionfactor(vec2 shadowspace){
float dist = length(abs(shadowspace * 1.165));
float distortion = ((1.0 - shadowBias) + dist * shadowBias) * 0.97;
return distortion;
}


vec4 VL(vec2 pattern) {
    #ifndef Volumetric_Light
    return vec4(0.0);
    #endif
    vec4 endPos = gbufferProjectionInverse * (vec4(texcoord.st, texture2D(depthtex0, texcoord.st).r, 1.0) * 2.0 - 1.0);
    endPos /= endPos.w;
    endPos = shadowProjection * shadowModelView * gbufferModelViewInverse * endPos;
    vec4 startPos = shadowProjection * shadowModelView * gbufferModelViewInverse * vec4(0.0, 0.0, 0.0, 1.0);
    vec4 dir = normalize(endPos - startPos);
    if (VL_Quality >= 30) pattern = vec2(1.0);
    vec4 increment = dir * distance(endPos, startPos) / VL_Quality * pattern.y;
    startPos -= increment * bayer128(gl_FragCoord.xy);
    vec4 curPos = startPos;
    float indoors  = 1.0 + clamp01((eyeBrightnessSmooth.y + 230) / 100.0);
    mat4 matrix = shadowModelViewInverse * shadowProjectionInverse;

    float lengthOfIncrement = length(increment);

    vec4 result = vec4(0.0);
    for (int j = 0; j < VL_Quality; j++) {
        curPos += increment;
        vec3 shadowPos = (curPos.xyz / vec3(vec2(distortionfactor(curPos.xy)), shadowZstretch)) * 0.5 + 0.5;
        float shadowTransparent = float(texture2D(shadowtex1, shadowPos.st).r > shadowPos.p - 0.00008);
        vec3 shadow = vec3(shadowTransparent);

        result += vec4(shadow * lengthOfIncrement, 1.0) * vec4(1.0);
    }

    return result / (1.0+result) * 0.6 * (1.0 + (pow2(rainStrength))) * (indoors);
}

float remap(float value, const float originalMin, const float originalMax, const float newMin, const float newMax) {
	return (((value - originalMin) / (originalMax - originalMin)) * (newMax - newMin)) + newMin;
}


float volumetricFogFBM(vec3 position, vec2 pattern) {

    position = position * 1.0;

    float coverage = 0.0;

    float noise = 0.0;
    float a = 1.0;
    float weight = a;
    float time = frameTimeCounter;

    mat2  rotMat   = mat2(1.5, 1.1, -1.5, 1.5);
    vec3 movement = vec3(-time, 0.0, time);
    #ifndef Day_Fog
    if (worldTime >= 3000 && worldTime <= 9000) return 0.0;
    #endif

#ifdef Volumetric_Fog
        noise    += Get3DNoise(position * 0.5 + movement.z * 0.7) * a;
        //position.xz *= (rotMat * movement.x);
        #if (Volume_Fog_Octaves >= 2)
        //position.x *= 1.5;
        noise    += Get3DNoise(position * 0.1 + movement.z * 0.4) * a;
        #endif
        #if (Volume_Fog_Octaves >= 3)
        position.xz *= rotMat * 0.5;
        noise    += Get3DNoise(position * 1.8 + movement.z * 1.5) * a * pattern.y;
        #endif

        a        *= 5.32;
        weight   += a;
#endif
    if (cameraPosition.y <= 50) return 0.0;
    noise /= weight;
    noise  = pow(max0(((noise * 8.5)) - coverage) / (1.0 - coverage), 1.0);

    const float altitude = 45;
    const float scale = 1300 / altitude;
    const float thickness = 200 / scale;
    const float earthSize = 6371e3;


    //position.y -= dot(position.xz, position.xz) / earthSize;

    float height = position.y - altitude * 0.9;
    float scaleHeight = height / thickness;
    float heighAtten = remap(scaleHeight, 0.0, 0.2, 0.0, 1.0) * remap(scaleHeight, 0.8, 1.0, 1.0, 0.0);

    return max0(noise * heighAtten - (1 * heighAtten * scaleHeight * 0.5 + 0.5)) * exp2(-max0(height) * 0.35) * (1.0 * scale);
    //return noise;
}

vec2 calculateFogOpticalDensity(vec3 position, vec2 pattern) {
    const vec2 scaleHeight = vec2(8e3, 1.2e3);
    const vec2 rScaleHeigh = 1.0 / scaleHeight;
    vec2 densityGrad = exp2(-(position.y - 45) * rScaleHeigh) * 25;
    float dayFade = clamp(0.75 * (0.9 * (smoothstep(9000.0, 11000.0, float(worldTime)) + smoothstep(3000.0, 0000.0, float(worldTime)))), 0.0, 1.0);
    float moonFade = clamp(0.75 * (0.9 * (smoothstep(13000.0, 12000.0, float(worldTime)) + smoothstep(23000.0, 24000.0, float(worldTime)))), 0.2, 1.0);
    #ifdef Day_Fog
    dayFade = 1.0;
    #endif
    vec2 opticalDensity   = densityGrad;
         opticalDensity   += volumetricFogFBM(position, pattern) * vec2(125 * VFOG_Strength, 150 * VFOG_Strength);
         opticalDensity.y += exp2(-(position.y - 65) * 0.525) * 525;
         //opticalDensity.y *= 500.0;
    
    return opticalDensity * 1.4 * moonFade * dayFade;
}

vec4 calculateVolumetricLight(gbuffer info, material mat, scene spaces, vec2 pattern) {
    #ifndef Volumetric_Light
    return vec4(0.0);
    #endif
    if (isEyeInWater > 0) return vec4(0.0, 0.0, 0.0, 1.0);
    #ifndef Day_Fog
    if (worldTime >= 3000 && worldTime <= 9000) return vec4(0.0);
    #endif

    float dayFade = clamp(0.75 * (0.9 * (smoothstep(9000.0, 11000.0, float(worldTime)) + smoothstep(3000.0, 0000.0, float(worldTime)))), 0.00, 1.0);
    #ifdef Day_Fog
    dayFade = 1.0;
    #endif
    float heightFade = clamp(0.9 * (smoothstep(40.0, 60.0, float(cameraPosition.y))), 0.03, 1.0);

    // Offset dither pattern to prevent overlap with other dither related volumetrics
    float ditherOffset = fract((pattern.x * 128 + frameCounter * 7) / 128);
    vec3 mieCoefficientVL = mix(vec3(2.500e-6, 2.500e-6, 2.500e-6), vec3(4.500e-5, 4.500e-5, 4.500e-5), rainStrength);
    vec3 mieExtinction = mieCoefficientVL * 1.11;

    mat2x3 scatterCoeff    = isEyeInWater < 1 ?
        mat2x3(rayleighCoefficient, mieCoefficientVL) :
        mat2x3(vec3(0.0), waterScatterCoeff);
    mat2x3 extinctionCoeff = isEyeInWater < 1 ?
        mat2x3(rayleighCoefficient, mieExtinction) :
        mat2x3(waterAbsorbCoeff, waterScatterCoeff);

    // Setup scattering / extinction integral
	const mat2x3 a = mat2x3(-extinctionCoeff[0] * RCPLOG2, -extinctionCoeff[1] * RCPLOG2);
	const mat2x3 b = mat2x3(-1.0 / extinctionCoeff[0], -1.0 / extinctionCoeff[1]);
	const mat2x3 c = mat2x3( 1.0 / extinctionCoeff[0],  1.0 / extinctionCoeff[1]);

    float vlRenderDistance = far * 1.4;

    vec3  planeBottom = spaces.world[0] * (-cameraPosition.y) / spaces.world[0].y;
          planeBottom = spaces.world[2] * min(length(planeBottom), vlRenderDistance);
    vec3  planeTop    = spaces.world[0] * (vc_altitude - cameraPosition.y) / spaces.world[0].y;
          planeTop    = spaces.world[2] * min(length(planeTop), vlRenderDistance);

    vec3 rayStart  = vec3(0.0);
    vec3 rayEnd    = vec3(0.0);

    if (cameraPosition.y < -vc_altitude) {
        rayStart = planeBottom;
        rayEnd   = planeTop;
    } else if (cameraPosition.y > -vc_altitude && cameraPosition.y < vc_altitude) {
        rayStart = vec3(0.0);
        rayEnd   = spaces.world[2].y < 0.0 ? planeBottom : planeTop;
    } else if (cameraPosition.y > vc_altitude) {
        if (spaces.world[2].y > 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
        rayStart = planeTop;
        rayEnd   = planeBottom;
    }

    rayEnd = info.depthtex.x < 1.0 ? spaces.world[0] : rayEnd;

    vec3  rayIncrement = (rayEnd - rayStart) / VL_Quality;
    vec3  rayPosition  = rayIncrement * ditherOffset + rayStart;
    float stepSize     = length(rayIncrement);
    
    float VoL     = dot(spaces.world[2], lightVec[1]);
    vec2  phase   = sky_phase(VoL, 0.5);
    float indoors = pow2(eyeBrightnessSmooth.y / 240.0);

    vec4 volumetricLight = vec4(0.0, 0.0, 0.0, 1.0);
    vec3 transmission    = vec3(1.0);

    for (int i = 0; i < VL_Quality; i++, rayPosition += rayIncrement) {
        vec2  opticalDensity = calculateFogOpticalDensity(rayPosition + cameraPosition, pattern) * stepSize;
        //opticalDensity *= vec2(far * 0.006);
        //float cloudShadow    = calculateCloudShadows(rayPosition + cameraPosition);
        vec3  spos           = distortShadowSpace(calculateShadowSpace(rayPosition));
        float landShadow     = calculateShadow(shadowtex1, spos);
        float colorShadow    = calculateShadow(shadowtex1, spos);
        vec4 vlColor         = texture2D(shadowcolor0, spos.xy) * vec4(10.0, 10.0, 10.0, 1.0);

        vec3 lightingSun     = landShadow /*+ (vlColor.rgb * (1.0 - vlColor.a) * colorShadow)*/ * 1.0 * lightColors[0] * 3.5 * (1.0 - rainStrength + 0.1) * VFOG_Strength;
        vec3 lightingAmbient = indoors * RCPPI * lightColors[2] * vec3(0.0, 0.5, 1.0) * vec3(VFOG_Red, VFOG_Green, VFOG_Blue) * VFOG_Strength;

        mat2x3 scatteringScale = mat2x3(
            scatterCoeff[0] * (exp2(a[0] * opticalDensity.x) * b[0] + c[0]),
            scatterCoeff[1] * (exp2(a[1] * opticalDensity.y) * b[1] + c[1])
        );
        
        volumetricLight.rgb += (scatteringScale * phase) * lightingSun * transmission * vec3(pow2(VL_Red), pow2(VL_Green), pow2(VL_Blue))* VL_Strength;
        volumetricLight.rgb += (scatteringScale * vec2(0.25)) * lightingAmbient * transmission;
        transmission        *= exp(-extinctionCoeff * opticalDensity * RCPLOG2);
        volumetricLight.a   *= exp(-extinctionCoeff[0].x * opticalDensity.y * RCPLOG2);
    }

    volumetricLight.a = length(transmission);

    return volumetricLight * 0.8 * (1.0 + rainStrength) * dayFade * heightFade;
}