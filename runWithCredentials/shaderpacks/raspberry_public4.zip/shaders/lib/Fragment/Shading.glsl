uniform vec2 resolution;
uniform float screenBrightness;

vec4 cubic(float x) {
  float x2 = x * x;
  float x3 = x2 * x;
  vec4 w;
  w.x =   -x3 + 3*x2 - 3*x + 1;
  w.y =  3*x3 - 6*x2       + 4;
  w.z = -3*x3 + 3*x2 + 3*x + 1;
  w.w =  x3;
  return w / 6.f;
}

vec4 bicubicTexture(sampler2D tex, vec2 coord, float res, vec2 pattern) {
  vec2 resolutionScale = resolution * res;

  coord *= resolutionScale;

  float fx = fract(coord.x + pattern.x);
  float fy = fract(coord.y + pattern.x);
  coord.x -= fx;
  coord.y -= fy;

  vec4 xcubic = cubic(fx);
  vec4 ycubic = cubic(fy);

  vec4 c = vec4(coord.x - 0.5, coord.x + 1.5, coord.y - 0.5, coord.y + 1.5);
  vec4 s = vec4(xcubic.x + xcubic.y, xcubic.z + xcubic.w, ycubic.x + ycubic.y, ycubic.z + ycubic.w);
  vec4 offset = c + vec4(xcubic.y, xcubic.w, ycubic.y, ycubic.w) / s;

  vec4 sample0 = texture2DLod(tex, vec2(offset.x, offset.z) / resolutionScale, 0.0);
  vec4 sample1 = texture2DLod(tex, vec2(offset.y, offset.z) / resolutionScale, 0.0);
  vec4 sample2 = texture2DLod(tex, vec2(offset.x, offset.w) / resolutionScale, 0.0);
  vec4 sample3 = texture2DLod(tex, vec2(offset.y, offset.w) / resolutionScale, 0.0);

  float sx = s.x / (s.x + s.y);
  float sy = s.z / (s.z + s.w);

  return mix( mix(sample3, sample2, sx), mix(sample1, sample0, sx), sy);
}

const float gauss9w[9] = float[9] (
     0.0779, 0.12325, 0.0779,
    0.12325, 0.1954,  0.12225,
     0.0779, 0.12325, 0.0779
);

const vec2 gauss9o[9] = vec2[9] (
    vec2(1.0, 1.0), vec2(0.0, 1.0), vec2(-1.0, 1.0),
    vec2(1.0, 0.0), vec2(0.0, 0.0), vec2(-1.0, 0.0),
    vec2(1.0, -1.0), vec2(0.0, -1.0), vec2(-1.0, -1.0)
);

vec4 gauss9(sampler2D tex, vec2 coord, float sigma) {
    vec2 pixelRad = sigma*pixel;
    vec4 col = vec4(0.0);

    for (int i = 0; i<9; i++) {
        vec2 bcoord = coord + gauss9o[i]*pixelRad;
        col += texture(tex, bcoord)*gauss9w[i];
    }
    return col;
}

const float kernel_bias  = -0.234377;
const float kernel_scale = 1.241974;
const float kernel_size = 1024.000000;
const vec4 bits = vec4(1.0, 1.0/256.0, 1.0/(256.0*256.0), 1.0/(256.0*256.0*256.0));
//uniform sampler2D colortex4;

float
unpack_unit(vec4 rgba)
{
    // return rgba.r;  // uncomment this for r32f debugging
    return dot(rgba, bits);
}

float
unpack_ieee(vec4 rgba)
{
    // return rgba.r;  // uncomment this for r32f debugging
    rgba.rgba = rgba.abgr * 255.;
    float sign = 1.0 - step(128.0,rgba[0])*2.0;
    float exponent = 2.0 * mod(rgba[0],128.0) + step(128.0,rgba[1]) - 127.0;
    float mantissa = mod(rgba[1],128.0)*65536.0 + rgba[2]*256.0 + rgba[3] + float(0x800000);
    return sign * exp2(exponent) * (mantissa * exp2(-23.));
}

float
unpack_interpolate(sampler2D kernel, vec2 uv, vec2 pattern)
{
    // return texture2D(kernel, uv).r; //uncomment this for r32f debug without interpolation
    float kpixel = 1. / kernel_size;
    float u = uv.x / kpixel;
    float v = uv.y;
    float uf = fract(u);
    u = (u - uf) * kpixel;

    float d0 = unpack_unit(texture2D(kernel, vec2(u, v))) + pattern.x;
    float d1 = unpack_unit(texture2D(kernel, vec2(u + 1. * kpixel, v))) + pattern.x;
    return mix(d0 + pattern.x, d1 + pattern.x, uf);
}

vec4
filter1D_radius1( sampler2D kernel, float index, float x, vec4 c0, vec4 c1, vec2 pattern)
{
    float w, w_sum = 0.0;
    vec4 r = vec4(0.0,0.0,0.0,0.0);
    w = unpack_interpolate(kernel, vec2(0.000000+(x/1.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c0 * w;
    w = unpack_interpolate(kernel, vec2(1.000000-(x/1.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c1 * w;
    return r;
}

vec4
filter2D_radius1(sampler2D texture, sampler2D kernel, float index, vec2 uv, vec2 pixel, vec2 pattern)
{
    vec2 texel = uv/pixel - vec2(0.5, 0.5) ;
    vec2 f = fract(texel);
    texel = (texel-fract(texel) + vec2(0.001, 0.001)) * pixel;
    vec4 t0 = filter1D_radius1(kernel, index, f.x,
        texture2D( texture, texel + vec2(0, 0) * pixel),
        texture2D( texture, texel + vec2(1, 0) * pixel), pattern);
    vec4 t1 = filter1D_radius1(kernel, index, f.x,
        texture2D( texture, texel + vec2(0, 1) * pixel),
        texture2D( texture, texel + vec2(1, 1) * pixel), pattern);
    return filter1D_radius1(kernel, index, f.y, t0, t1, pattern);
}

vec4
filter1D_radius2( sampler2D kernel, float index, float x, vec4 c0, vec4 c1, vec4 c2, vec4 c3, vec2 pattern)
{
    float w, w_sum = 0.0;
    vec4 r = vec4(0.0,0.0,0.0,0.0);
    w = unpack_interpolate(kernel, vec2(0.500000+(x/2.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c0 * w;
    w = unpack_interpolate(kernel, vec2(0.500000-(x/2.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c2 * w;
    w = unpack_interpolate(kernel, vec2(0.000000+(x/2.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c1 * w;
    w = unpack_interpolate(kernel, vec2(1.000000-(x/2.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c3 * w;
    return r;
}

vec4
filter2D_radius2(sampler2D texture, sampler2D kernel, float index, vec2 uv, vec2 pixel, vec2 pattern)
{
    vec2 texel = uv/pixel - vec2(0.5, 0.5) ;
    vec2 f = fract(texel);
    texel = (texel-fract(texel) + vec2(0.001, 0.001)) * pixel;
    vec4 t0 = filter1D_radius2(kernel, index, f.x,
        texture2D( texture, texel + vec2(-1, -1) * pixel),
        texture2D( texture, texel + vec2(0, -1) * pixel),
        texture2D( texture, texel + vec2(1, -1) * pixel),
        texture2D( texture, texel + vec2(2, -1) * pixel), pattern);
    vec4 t1 = filter1D_radius2(kernel, index, f.x,
        texture2D( texture, texel + vec2(-1, 0) * pixel),
        texture2D( texture, texel + vec2(0, 0) * pixel),
        texture2D( texture, texel + vec2(1, 0) * pixel),
        texture2D( texture, texel + vec2(2, 0) * pixel), pattern);
    vec4 t2 = filter1D_radius2(kernel, index, f.x,
        texture2D( texture, texel + vec2(-1, 1) * pixel),
        texture2D( texture, texel + vec2(0, 1) * pixel),
        texture2D( texture, texel + vec2(1, 1) * pixel),
        texture2D( texture, texel + vec2(2, 1) * pixel), pattern);
    vec4 t3 = filter1D_radius2(kernel, index, f.x,
        texture2D( texture, texel + vec2(-1, 2) * pixel),
        texture2D( texture, texel + vec2(0, 2) * pixel),
        texture2D( texture, texel + vec2(1, 2) * pixel),
        texture2D( texture, texel + vec2(2, 2) * pixel), pattern);
    return filter1D_radius2(kernel, index, f.y, t0, t1, t2, t3, pattern);
}

vec4
filter1D_radius3( sampler2D kernel, float index, float x, vec4 c0, vec4 c1, vec4 c2, vec4 c3, vec4 c4, vec4 c5, vec2 pattern)
{
    float w, w_sum = 0.0;
    vec4 r = vec4(0.0,0.0,0.0,0.0);
    w = unpack_interpolate(kernel, vec2(0.666667+(x/3.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c0 * w;
    w = unpack_interpolate(kernel, vec2(0.333333-(x/3.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c3 * w;
    w = unpack_interpolate(kernel, vec2(0.333333+(x/3.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c1 * w;
    w = unpack_interpolate(kernel, vec2(0.666667-(x/3.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c4 * w;
    w = unpack_interpolate(kernel, vec2(0.000000+(x/3.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c2 * w;
    w = unpack_interpolate(kernel, vec2(1.000000-(x/3.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c5 * w;
    return r;
}

vec4
filter2D_radius3(sampler2D texture, sampler2D kernel, float index, vec2 uv, vec2 pixel, vec2 pattern)
{
    vec2 texel = uv/pixel - vec2(0.5, 0.5) ;
    vec2 f = fract(texel);
    texel = (texel-fract(texel) + vec2(0.001, 0.001)) * pixel;
    vec4 t0 = filter1D_radius3(kernel, index, f.x,
        texture2D( texture, texel + vec2(-2, -2) * pixel),
        texture2D( texture, texel + vec2(-1, -2) * pixel),
        texture2D( texture, texel + vec2(0, -2) * pixel),
        texture2D( texture, texel + vec2(1, -2) * pixel),
        texture2D( texture, texel + vec2(2, -2) * pixel),
        texture2D( texture, texel + vec2(3, -2) * pixel), pattern);
    vec4 t1 = filter1D_radius3(kernel, index, f.x,
        texture2D( texture, texel + vec2(-2, -1) * pixel),
        texture2D( texture, texel + vec2(-1, -1) * pixel),
        texture2D( texture, texel + vec2(0, -1) * pixel),
        texture2D( texture, texel + vec2(1, -1) * pixel),
        texture2D( texture, texel + vec2(2, -1) * pixel),
        texture2D( texture, texel + vec2(3, -1) * pixel), pattern);
    vec4 t2 = filter1D_radius3(kernel, index, f.x,
        texture2D( texture, texel + vec2(-2, 0) * pixel),
        texture2D( texture, texel + vec2(-1, 0) * pixel),
        texture2D( texture, texel + vec2(0, 0) * pixel),
        texture2D( texture, texel + vec2(1, 0) * pixel),
        texture2D( texture, texel + vec2(2, 0) * pixel),
        texture2D( texture, texel + vec2(3, 0) * pixel), pattern);
    vec4 t3 = filter1D_radius3(kernel, index, f.x,
        texture2D( texture, texel + vec2(-2, 1) * pixel),
        texture2D( texture, texel + vec2(-1, 1) * pixel),
        texture2D( texture, texel + vec2(0, 1) * pixel),
        texture2D( texture, texel + vec2(1, 1) * pixel),
        texture2D( texture, texel + vec2(2, 1) * pixel),
        texture2D( texture, texel + vec2(3, 1) * pixel), pattern);
    vec4 t4 = filter1D_radius3(kernel, index, f.x,
        texture2D( texture, texel + vec2(-2, 2) * pixel),
        texture2D( texture, texel + vec2(-1, 2) * pixel),
        texture2D( texture, texel + vec2(0, 2) * pixel),
        texture2D( texture, texel + vec2(1, 2) * pixel),
        texture2D( texture, texel + vec2(2, 2) * pixel),
        texture2D( texture, texel + vec2(3, 2) * pixel), pattern);
    vec4 t5 = filter1D_radius3(kernel, index, f.x,
        texture2D( texture, texel + vec2(-2, 3) * pixel),
        texture2D( texture, texel + vec2(-1, 3) * pixel),
        texture2D( texture, texel + vec2(0, 3) * pixel),
        texture2D( texture, texel + vec2(1, 3) * pixel),
        texture2D( texture, texel + vec2(2, 3) * pixel),
        texture2D( texture, texel + vec2(3, 3) * pixel), pattern);
    return filter1D_radius3(kernel, index, f.y, t0, t1, t2, t3, t4, t5, pattern);
}

vec4
filter1D_radius4( sampler2D kernel, float index, float x, vec4 c0, vec4 c1, vec4 c2, vec4 c3, vec4 c4, vec4 c5, vec4 c6, vec4 c7, vec2 pattern)
{
    float w, w_sum = 0.0;
    vec4 r = vec4(0.0,0.0,0.0,0.0);
    w = unpack_interpolate(kernel, vec2(0.750000+(x/4.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c0 * w;
    w = unpack_interpolate(kernel, vec2(0.250000-(x/4.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c4 * w;
    w = unpack_interpolate(kernel, vec2(0.500000+(x/4.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c1 * w;
    w = unpack_interpolate(kernel, vec2(0.500000-(x/4.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c5 * w;
    w = unpack_interpolate(kernel, vec2(0.250000+(x/4.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c2 * w;
    w = unpack_interpolate(kernel, vec2(0.750000-(x/4.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c6 * w;
    w = unpack_interpolate(kernel, vec2(0.000000+(x/4.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c3 * w;
    w = unpack_interpolate(kernel, vec2(1.000000-(x/4.0), index), pattern);
    w = w*kernel_scale + kernel_bias;
    r += c7 * w;
    return r;
}

vec4
filter2D_radius4(sampler2D texture, sampler2D kernel, float index, vec2 uv, vec2 pixel, vec2 pattern)
{
    vec2 texel = uv/pixel - vec2(0.5, 0.5) ;
    vec2 f = fract(texel);
    texel = (texel-fract(texel) + vec2(0.001, 0.001)) * pixel;
    vec4 t0 = filter1D_radius4(kernel, index, f.x,
        texture2D( texture, texel + vec2(-3, -3) * pixel),
        texture2D( texture, texel + vec2(-2, -3) * pixel),
        texture2D( texture, texel + vec2(-1, -3) * pixel),
        texture2D( texture, texel + vec2(0, -3) * pixel),
        texture2D( texture, texel + vec2(1, -3) * pixel),
        texture2D( texture, texel + vec2(2, -3) * pixel),
        texture2D( texture, texel + vec2(3, -3) * pixel),
        texture2D( texture, texel + vec2(4, -3) * pixel), pattern);
    vec4 t1 = filter1D_radius4(kernel, index, f.x,
        texture2D( texture, texel + vec2(-3, -2) * pixel),
        texture2D( texture, texel + vec2(-2, -2) * pixel),
        texture2D( texture, texel + vec2(-1, -2) * pixel),
        texture2D( texture, texel + vec2(0, -2) * pixel),
        texture2D( texture, texel + vec2(1, -2) * pixel),
        texture2D( texture, texel + vec2(2, -2) * pixel),
        texture2D( texture, texel + vec2(3, -2) * pixel),
        texture2D( texture, texel + vec2(4, -2) * pixel), pattern);
    vec4 t2 = filter1D_radius4(kernel, index, f.x,
        texture2D( texture, texel + vec2(-3, -1) * pixel),
        texture2D( texture, texel + vec2(-2, -1) * pixel),
        texture2D( texture, texel + vec2(-1, -1) * pixel),
        texture2D( texture, texel + vec2(0, -1) * pixel),
        texture2D( texture, texel + vec2(1, -1) * pixel),
        texture2D( texture, texel + vec2(2, -1) * pixel),
        texture2D( texture, texel + vec2(3, -1) * pixel),
        texture2D( texture, texel + vec2(4, -1) * pixel), pattern);
    vec4 t3 = filter1D_radius4(kernel, index, f.x,
        texture2D( texture, texel + vec2(-3, 0) * pixel),
        texture2D( texture, texel + vec2(-2, 0) * pixel),
        texture2D( texture, texel + vec2(-1, 0) * pixel),
        texture2D( texture, texel + vec2(0, 0) * pixel),
        texture2D( texture, texel + vec2(1, 0) * pixel),
        texture2D( texture, texel + vec2(2, 0) * pixel),
        texture2D( texture, texel + vec2(3, 0) * pixel),
        texture2D( texture, texel + vec2(4, 0) * pixel), pattern);
    vec4 t4 = filter1D_radius4(kernel, index, f.x,
        texture2D( texture, texel + vec2(-3, 1) * pixel),
        texture2D( texture, texel + vec2(-2, 1) * pixel),
        texture2D( texture, texel + vec2(-1, 1) * pixel),
        texture2D( texture, texel + vec2(0, 1) * pixel),
        texture2D( texture, texel + vec2(1, 1) * pixel),
        texture2D( texture, texel + vec2(2, 1) * pixel),
        texture2D( texture, texel + vec2(3, 1) * pixel),
        texture2D( texture, texel + vec2(4, 1) * pixel), pattern);
    vec4 t5 = filter1D_radius4(kernel, index, f.x,
        texture2D( texture, texel + vec2(-3, 2) * pixel),
        texture2D( texture, texel + vec2(-2, 2) * pixel),
        texture2D( texture, texel + vec2(-1, 2) * pixel),
        texture2D( texture, texel + vec2(0, 2) * pixel),
        texture2D( texture, texel + vec2(1, 2) * pixel),
        texture2D( texture, texel + vec2(2, 2) * pixel),
        texture2D( texture, texel + vec2(3, 2) * pixel),
        texture2D( texture, texel + vec2(4, 2) * pixel), pattern);
    vec4 t6 = filter1D_radius4(kernel, index, f.x,
        texture2D( texture, texel + vec2(-3, 3) * pixel),
        texture2D( texture, texel + vec2(-2, 3) * pixel),
        texture2D( texture, texel + vec2(-1, 3) * pixel),
        texture2D( texture, texel + vec2(0, 3) * pixel),
        texture2D( texture, texel + vec2(1, 3) * pixel),
        texture2D( texture, texel + vec2(2, 3) * pixel),
        texture2D( texture, texel + vec2(3, 3) * pixel),
        texture2D( texture, texel + vec2(4, 3) * pixel), pattern);
    vec4 t7 = filter1D_radius4(kernel, index, f.x,
        texture2D( texture, texel + vec2(-3, 4) * pixel),
        texture2D( texture, texel + vec2(-2, 4) * pixel),
        texture2D( texture, texel + vec2(-1, 4) * pixel),
        texture2D( texture, texel + vec2(0, 4) * pixel),
        texture2D( texture, texel + vec2(1, 4) * pixel),
        texture2D( texture, texel + vec2(2, 4) * pixel),
        texture2D( texture, texel + vec2(3, 4) * pixel),
        texture2D( texture, texel + vec2(4, 4) * pixel), pattern);
    return filter1D_radius4(kernel, index, f.y, t0, t1, t2, t3, t4, t5, t6, t7, pattern);
}

vec4 Nearest(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return texture2D(texture,uv); }

vec4 Bilinear(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius1(texture, texture, 0.031250, uv, 1.0/shape, pattern); }

vec4 Hanning(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius1(texture, colortex4, 0.093750, uv, 1.0/shape, pattern); }

vec4 Hamming(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius1(texture, colortex4, 0.156250, uv, 1.0/shape, pattern); }

vec4 Hermite(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius1(texture, colortex4, 0.218750, uv, 1.0/shape, pattern); }

vec4 Kaiser(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius1(texture, colortex4, 0.281250, uv, 1.0/shape, pattern); }

vec4 Quadric(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius2(texture, colortex4, 0.343750, uv, 1.0/shape, pattern); }

vec4 Bicubic(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius2(texture, colortex4, 0.406250, uv, 1.0/shape, pattern); }

vec4 CatRom(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius2(texture, colortex4, 0.468750, uv, 1.0/shape, pattern); }

vec4 Mitchell(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius2(texture, colortex4, 0.531250, uv, 1.0/shape, pattern); }

vec4 Spline16(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius2(texture, colortex4, 0.593750, uv, 1.0/shape, pattern); }

vec4 Spline36(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius3(texture, colortex4, 0.656250, uv, 1.0/shape, pattern); }

vec4 Gaussian(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius2(texture, colortex4, 0.718750, uv, 1.0/shape, pattern); }

vec4 Bessel(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius4(texture, colortex4, 0.781250, uv, 1.0/shape, pattern); }

vec4 Sinc(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius4(texture, colortex4, 0.843750, uv, 1.0/shape, pattern); }

vec4 Lanczos(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius4(texture, colortex4, 0.906250, uv, 1.0/shape, pattern); }

vec4 Blackman(sampler2D texture, vec2 shape, vec2 uv, vec2 pattern)
{ return filter2D_radius4(texture, colortex4, 0.968750, uv, 1.0/shape, pattern); }

vec4 denoise(sampler2D colortex, vec2 pattern) {
    const float scale  = 1.0;
    const vec2  offset = vec2(0.0, 0.0);
    //vec4 accumulated = texture2D(colortex, texcoord);
    //vec4 accumulated = bicubicTexture(colortex, texcoord, 0.8, pattern);
    #ifdef Spatial_Filter
    //accumulated =   Blackman(colortex, vec2(viewWidth, viewHeight), texcoord, pattern) * 0.01;
    #endif
    vec4 accumulated = texture2D(colortex, texcoord);

    return accumulated;
}

#define LOG2 log(2.0)
#define waterAbsorbCoeff     vec3(0.996078, 0.406863, 0.25098) * 0.125 / LOG2


void calculateWaterShading(inout gbuffer info, material mat, scene spaces) {
    if (mat.water < 0.5 || isEyeInWater > 0.5) return;

    vec3 totalCoeff   = waterAbsorbCoeff + waterScatterCoeff;

    float waterDepth  = distance(spaces.world[0], spaces.world[1]);

    vec3 sunLight     = pow4(info.lightmap[1].y) * lightColors[1] * 0.95;
    vec3 torchLight   = info.lightmap[0].x * torchColor * 0.1;
    vec3 skyLight     = info.lightmap[0].y * lightColors[2];

    vec3 finalShading = sunLight + torchLight + skyLight;

    vec3 absorption   = exp(-totalCoeff * waterDepth);
    vec3 scatter      = transmittedScatteringIntegral(waterDepth, totalCoeff) * 0.25 * finalShading * waterScatterCoeff;

    info.color[0].rgb = info.color[0].rgb * absorption + scatter * 1.0;
}

void calculateUnderwaterShading(inout gbuffer info, material mat, scene spaces) {
    if (isEyeInWater < 0.5) return;

    vec3 totalCoeff   = waterAbsorbCoeff + waterScatterCoeff;

    float waterDepth  = length(spaces.world[0]);

    vec3 finalShading = lightColors[2];

    vec3 absorption   = exp(-totalCoeff * waterDepth);
    vec3 scatter      = transmittedScatteringIntegral(waterDepth, totalCoeff) / PI * LOG2 * finalShading * waterScatterCoeff;

    info.color[0].rgb = info.color[0].rgb * absorption + scatter * 0.1;
    info.color[0].rgb = mix(info.color[0].rgb, scatter, 0.1);
    if (mat.land < 0.5 && mat.water > 0.5) info.color[0].rgb *= (lightColors[0] + (lightColors[1] * 0.05));
}

float phase_mie(float c, float g) {
	float gg = g * g;
  float cc = c * c;

	return (3.0 / (4.0 * PI) * (1.0 - gg) / (2.0 + gg)) * (1.0 * cc) / pow(1.0 + gg - 2.0 * g * c, 1.5);
}

float renderPhaseSSS(float VdotL, float diffuse){
  const float a = 0.45;

  float phase0 = phase_mie(VdotL, 0.25);
  float phase1 = phase_mie(VdotL, -0.10) * PI;

  return mix(max(phase0, phase1), a, a);
}

void drawTransparents(inout gbuffer info, material mat, scene spaces) {
    if (!info.gbufferForward) return;

    vec3  extinctionCoeff  = (0.1 / powf(info.color[1].rgb, 1.5)) * 0.5;
    float transparentDepth = min1(distance(spaces.world[0], spaces.world[1]));
    if (mat.water > 0.5) extinctionCoeff *= 0.5;

    info.color[0].rgb *= clamp01(exp(-transparentDepth * extinctionCoeff));
}

void calculateShading(inout gbuffer info, material mat, scene spaces, vec2 pattern, in vec3 viewSpace) {
    if (mat.land < 0.5) return;
    vec3 shadowSpace = calculateShadowSpace(spaces.world[1]);
    vec3 shadowLightmap = calculateSunlightVisibility(info, mat, spaces, shadowSpace, pattern);
    vec2 pattern2 = calculateJitteredSamplingDistributors();
    float moonFade = clamp(0.75 * (0.9 * (smoothstep(13000.0, 12000.0, float(worldTime)) + smoothstep(23000.0, 24000.0, float(worldTime)))), 0.003, 1.0);
    //vec3  V   = normalize(-spaces.world[2]);
    //vec3  R   = reflect(spaces.world[2], info.normal[1]);
    //vec3  H   = normalize(R + V);
    //float LoH = dot(R, H);

    //float F0  = mix(0.1 * mat.reflectiveness.y, 1.0, mat.metalness.y);
    float hand = float(texture2D(depthtex1,texcoord.xy).r < 0.56);
    float fresnel = f_dielectric(spaces.world[2], info.normal[1], mat.F0.y) * mat.reflectiveness.y;

    vec3 lightColor = (lightColors[0] * sunTint * 1.2) + (lightColors[1] * moonTint * 0.4) * Sunlight_Brightness;
    vec3 ambientColor = lightColors[2] * vec3(0.5, 0.6, 1.5) * 1 + vec3(0.1,0.1,0.1);
    //if (worldTime >= 13500) ambientColor = ambientColor * vec3(moonFade);
    vec3 fakeBounce = vec3(0.0);

    vec4 lighting      = denoise(colortex4, pattern);
    //vec4 lighting      = vec4(0.0);
    
    #ifdef Emissive_Mapping
    vec3 emissive = mat.emissiveness.x * info.color[0].rgb * 0.01;
    #else
    vec3 emissive = ((pow(length(info.color[0].rgb * 13), 2.6) * mat.emitter * torchColor) / 125000);// + ((mat.emissiveness.x * info.color[0].rgb) * 0.01);
    #endif

    //fakeBounce = (lightColors[0] * sunTint + lightColors[1] * moonTint) * (info.normal[0].y * 0.5 + 0.5) * 0.1;
    float indoors  = 1.0 + clamp01((eyeBrightnessSmooth.y + 230) / 100.0);

	vec3 fragpos = toNDC(vec3(gl_FragCoord.xy/vec2(viewWidth,viewHeight),gl_FragCoord.z));
    float Depth  = length(viewSpace);
    //float sss    = pow(clamp(dot(normalize(fragpos.xyz),vec3(lightVec)),0.02,0.0),1.0) * 10.5;
    float torchMap = clamp(info.lightmap[0].x, 0.0, 1.0);
    float torchMap2 = pow(torchMap, 0.5) * (5.0 + 0.5) + (torchMap * 1.5);
    vec3 blocklight = (torchMap2 * torchMap2) * torchColor * 0.1;
    vec3 torchCorrected = vec3(torchColor) * (vec3(1.0) - clamp01(vec3(mat.reflectiveness.x)));
    float noiser = noiseSmooth(gl_FragCoord.xy * noiseResInverse).rgb.b;
    vec3 totalShading  = vec3(0.0);

        //Sunlight
        /*if (mat.translucent <= 0.5)*/ totalShading += (diffuse(info.color[0].rgb, spaces, lightVec[1], lightColor, shadowLightmap, info, mat) * 3.6 * (1.0 - (rainStrength * 0.96)) * Sunlight_Brightness) * indoors;
        //if (mat.translucent >= 0.5) totalShading += diffuse(info.color[0].rgb, spaces, lightVec[1] * 1.1, lightColor, shadowLightmap, info, mat) * 5.5 * (1.0 - (rainStrength * 0.96)) * Sunlight_Brightness;
        //if (mat.translucent >= 0.5) totalShading += (lightColor * 0.6) * info.lightmap[0].y * shadowLightmap * Sunlight_Brightness;
        //GI + AO
        totalShading += lighting.rgb;

        //Emissive
        if (mat.emitter < 0.5 && hand <= 0.5) {
        totalShading += clamp(blocklight * 2, vec3(0.0), vec3(torchCorrected));
        //totalShading += (clamp(info.lightmap[0].x * 150, 0.0, 0.02)) * (vec3(1.0) - clamp01(vec3(mat.reflectiveness.x)));
        }
        totalShading += emissive * 4250.0;
        //if (mat.emitter > 0.5) totalShading += emissive + vec3(0.1);

        //Skylight
        #if Ambient_Occlusion != 1
        if (hand <= 0.5) totalShading += (diffuse(info.color[0].rgb, spaces, info.normal[0], ambientColor, vec3(info.lightmap[0].y + 0.0001), info, mat) * 2.0 * Skylight_Brightness * 1.0) * info.shadowed * vec3(Skylight_Red, Skylight_Green, Skylight_Blue) * vec3(moonFade);
        //if (mat.translucent > 0.5) totalShading += diffuse(info.color[0].rgb, spaces, info.normal[0], ambientColor, vec3(info.lightmap[0].y + 0.001), info, mat) * 2.0 * Skylight_Brightness * 0.5 * vec3(Skylight_Red, Skylight_Green * 0.85, Skylight_Blue) * (1.2 + (screenBrightness * 2));
        #endif
        //totalShading += lightColors[2];

        if (hand >= 0.5) { //If hand ->
            //Emissive
            totalShading += clamp(blocklight * 10, vec3(0.0), vec3(torchCorrected));
            //Skylight
            totalShading += (diffuse(info.color[0].rgb, spaces, info.normal[0], ambientColor, vec3(info.lightmap[0].y), info, mat) * 1.1 * Skylight_Brightness * 0.7) * vec3(Skylight_Red, Skylight_Green, Skylight_Blue)  * vec3(moonFade);
        }

        //Fresnel
        if (isEyeInWater < 0.5) totalShading *= 1.0 - fresnel;

        #ifdef SSS
        //SSS
        //if (mat.water < 0.5) totalShading += (sss * mat.translucent) * 0.142 * info.lightmap[0].y * ((lightColors[0] * sunTint) + (lightColors[1] * moonTint)) * (1.0 - (rainStrength * 0.96));
        //if (mat.water < 0.5) totalShading += (shadowLightmap * powf(info.color[0].rgb, 0.3)) * ((lightColors[0] * sunTint) + (lightColors[1] * moonTint)) / PI * 0.5 * mat.translucent * (1.0 - (rainStrength * 0.96));
        #endif

    
    info.color[0].rgb *= totalShading;
}

void calculateShading2(inout gbuffer info, material mat, scene spaces, vec2 pattern, in vec3 viewSpace) {
    if (mat.land < 0.5) return;
    vec3 shadowSpace = calculateShadowSpace(spaces.world[1]);
    vec3 shadowLightmap = calculateSunlightVisibility(info, mat, spaces, shadowSpace, pattern);
    //vec4 viewPos = GetViewPosition(texcoord.st, texture2D(depthtex1, texcoord.st).x);
    vec2 pattern2 = calculateJitteredSamplingDistributors();
    float moonFade = 0.75 * (0.9 * (smoothstep(13000.0, 12000.0, float(worldTime)) + smoothstep(23000.0, 24000.0, float(worldTime))));
    //vec3  V   = normalize(-spaces.world[2]);
    //vec3  R   = reflect(spaces.world[2], info.normal[1]);
    //vec3  H   = normalize(R + V);
    //float LoH = dot(R, H);

    //float F0  = mix(0.1 * mat.reflectiveness.y, 1.0, mat.metalness.y);
    float hand = float(texture2D(depthtex1,texcoord.xy).r < 0.56);
    float fresnel = f_dielectric(spaces.world[2], info.normal[1], mat.F0.y) * mat.reflectiveness.y;

    vec3 lightColor = (lightColors[0] * sunTint * 1.2) + (lightColors[1] * moonTint * 0.4) * Sunlight_Brightness;
    vec3 ambientColor = lightColors[2] * 1.0 * vec3(moonFade);
    //if (worldTime >= 13500) ambientColor = ambientColor * vec3(moonFade);
    vec3 fakeBounce = vec3(0.0);

    //vec4 lighting      = denoise(colortex4);
    vec4 lighting      = vec4(0.0);
    #if   Ambient_Occlusion == Off
         lighting.rgb += (lightColors[2] + fakeBounce * 0.05) * info.lightmap[0].y * 1.1 * Skylight_Brightness * 0.03;
    #elif Ambient_Occlusion == Molly
         lighting.rgb += (lightColors[2] + fakeBounce * 0.05) * info.lightmap[0].y * lighting.a * 1.1 * Skylight_Brightness * 0.03;
    #endif
    
    #ifdef Emissive_Mapping
    vec3 emissive = (mat.emissiveness.x * info.color[0].rgb) * 0.01;
    #else
    vec3 emissive = ((pow(length(info.color[0].rgb * 13), 2.6) * mat.emitter * torchColor) / 125000) + ((mat.emissiveness.x * info.color[0].rgb) * 0.01);
    #endif

    #ifndef Fake_Bounce
    fakeBounce = vec3(0.0);
    #endif
	vec3 fragpos = toNDC(vec3(gl_FragCoord.xy/vec2(viewWidth,viewHeight),gl_FragCoord.z));
    float Depth  = length(viewSpace);
    float sss    = pow(clamp(dot(normalize(fragpos.xyz),vec3(lightVec)),0.02,0.2),1.0) * 1.5;
    float torchMap = clamp(info.lightmap[0].x, 0.0, 1.0);
    float torchMap2 = pow(torchMap, 0.5) * (5.0 + 0.5) + (torchMap * 1.5);
    vec3 blocklight = (torchMap2 * torchMap2) * torchColor * 0.1;
    vec3 torchCorrected = vec3(torchColor) * (vec3(1.0) - clamp01(vec3(mat.reflectiveness.x)));

    vec3 totalShading  = vec3(0.0);

        //Sunlight
        //totalShading += diffuse(info.color[0].rgb, spaces, lightVec[1], lightColor, shadowLightmap, info, mat) * 1.0 * (1.0 - (rainStrength * 0.96));

        //GI + AO
        //if (mat.water < 0.5) totalShading += lighting.rgb;

        //Emissive
        if (mat.water < 0.5 && mat.emitter < 0.5 && hand <= 0.5) {
        totalShading += clamp(blocklight * 2, vec3(0.0), vec3(torchCorrected));
        //totalShading += (clamp(info.lightmap[0].x * 150, 0.0, 0.02) * pattern.y) * (vec3(1.0) - clamp01(vec3(mat.reflectiveness.x)));
        }
        if (mat.water < 0.5) totalShading += emissive * 250.0;
        if (mat.emitter > 0.5) totalShading += emissive + vec3(0.1);

        //Skylight
        if (hand <= 0.5) totalShading += vec3(0.1, 0.01, 0.01) * 0.1;
        //if (mat.translucent > 0.5) totalShading += diffuse(info.color[0].rgb, spaces, info.normal[0], ambientColor, vec3(info.lightmap[0].y), info, mat) * 1.0 * Skylight_Brightness * 0.5 * vec3(Skylight_Red, Skylight_Green * 0.85, Skylight_Blue);
        //totalShading += lightColors[2];

        if (hand >= 0.5) { //If hand ->
            //Emissive
            totalShading += clamp(blocklight * 10, vec3(0.0), vec3(torchCorrected));
            //Skylight
            //totalShading += (diffuse(info.color[0].rgb, spaces, info.normal[0], ambientColor, vec3(info.lightmap[0].y), info, mat) * 1.1 * Skylight_Brightness * 0.7) * vec3(Skylight_Red, Skylight_Green, Skylight_Blue);
        }

        //Fresnel
        if (isEyeInWater < 0.5) totalShading *= 1.0 - fresnel;

        #ifdef SSS
        //SSS
        //if (mat.water < 0.5) totalShading += (sss * mat.translucent) * 0.142 * info.lightmap[0].y * ((lightColors[0] * sunTint) + (lightColors[1] * moonTint)) * (1.0 - (rainStrength * 0.96));
        //if (mat.water < 0.5) totalShading += (shadowLightmap * powf(info.color[0].rgb, 0.3)) * ((lightColors[0] * sunTint) + (lightColors[1] * moonTint)) / PI * 0.5 * mat.translucent * (1.0 - (rainStrength * 0.96));
        #endif

    
    info.color[0].rgb *= totalShading;
}