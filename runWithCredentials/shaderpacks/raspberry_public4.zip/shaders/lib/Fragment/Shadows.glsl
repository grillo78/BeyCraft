float distortionFactor(vec2 shadowSpace) {
    float dist = length(abs(shadowSpace * 1.165));
    float distortion = ((1.0 - Shadow_Bias) + dist * Shadow_Bias) * 0.97;
    
    return distortion;
}

vec3 distortShadowSpace(vec3 shadowSpace) {
    shadowSpace = shadowSpace * 2.0 - 1.0;
    shadowSpace = shadowSpace / vec3(vec2(distortionFactor(shadowSpace.xy)), Shadow_Z_Stretch);
    shadowSpace = shadowSpace * 0.5 + 0.5;

    return shadowSpace;
}

vec3 calculateShadowSpace(vec3 worldSpace) {
    vec3 shadowSpace = projMAD(shadowProjection, transMAD(shadowViewMatrix, worldSpace + gbufferModelViewInverse[3].xyz));
    return shadowSpace * 0.5 + 0.5;
}

float calculateShadow(sampler2D shadow, vec3 shadowSpace) {
    return step(shadowSpace.z - 0.0001, texture2D(shadow, shadowSpace.xy).x);
}