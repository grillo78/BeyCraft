float schlick(float F0, float LoH) {
	return F0 + (1.0 - F0) * pow(1.0 - LoH, 5.0);
}

float GGX(float NoH, float alpha2) {
	float p = NoH == 1.0 ? alpha2 : (NoH * alpha2 - NoH) * NoH + 1.0;
	return alpha2 / (PI * p * p);
}

float G2_GGX(float NoL, float NoV, float alpha2) {
	float x = 2.0 * NoL * NoV;
    float y = (1.0 - alpha2);

    return x / (NoV * sqrt(alpha2 + y * pow2(NoL)) + NoL * sqrt(alpha2 + y * pow2(NoV)));
}

float BRDF_GGX(float NoH, float NoL, float NoV, float alpha2) {
	float d  = GGX(NoH, alpha2);
	float g2 = G2_GGX(NoL, NoV, alpha2);

	return max0(d * g2 / (TAU * 4.0 * NoL * NoV)) * NoL;
}

vec3 orenNayar(in vec3 albedo, in vec3 viewDir, in vec3 lightDir, in vec3 normal, in float roughness) {
    /*
        This is from:
        http://www1.cs.columbia.edu/CAVE/publications/pdfs/Oren_CVPR93.pdf
	*/
    float nDotL = clamp01(dot(normal, lightDir));
    float nDotV = clamp01(dot(normal, viewDir));

    vec2 angles = acos(vec2(nDotL, nDotV));

    if(angles.x < angles.y) {
        angles.xy = angles.yx;
    }
    float cosA = dot(viewDir - nDotV * normal, lightDir - nDotL * normal);

    float C1 = 1.0 + (roughness / (roughness + 0.4)) * (2.0 / PI - 1.0);
    float C2 = 0.4 * (roughness / (roughness + 0.2));
    if(cosA > 0.0) {
        C2 = C2 * pow(sin(angles.x), 1.56 + (0.20 / roughness));
    } else {
        C2 = C2 * (pow(sin(angles.x), 1.56 + (0.20 / roughness)) - pow(2.0*angles.y/PI, 2.0+(1.0/2.0*roughness)));
    }
    float C3 = 0.11 * (roughness / (roughness + 0.2)) * pow(4.0 * angles.x * angles.y / pow2(PI), 1.55 + (1.0 / 1.55 * roughness));

    vec3 Lr1 = (albedo / PI) * nDotL * (C1 + (cosA * C2 * tan(angles.y)) + ((1.0 - abs(cosA)) * C3 * tan((angles.x + angles.y) / 2.0)));
    vec3 Lr2 = (albedo * albedo) * nDotL * (0.045 * (roughness / (roughness + 0.2))) * (1.0 - cosA * pow(2.0 * angles.y / PI, 1.3 + (0.31 / roughness)));
    return clamp01(Lr1 + Lr2);
}

vec3 diffuse_burley(vec3 diffuseColor, vec3 V, vec3 L, vec3 N, float r) {
	vec3  H   = normalize(V + L);
	float NoH = abs(dot(N, H));
    float NoV = abs(dot(V, N));
    float NoL = clamp01(dot(L, N));
    float LoV = abs(dot(L, V));

    float facing  = LoV * 0.5 + 0.5;
    float rough   = facing * (0.9 - 0.4 * facing) * ((0.5 + NoH) / NoH);
    float smooths = 1.05 * (1.0 - pow(1.0 - NoL, 5.0)) * (1.0 - pow(1.0 - NoV, 5.0));
    float single  = mix(smooths, rough, r);
    float multi   = 0.1159 * r;
    
    return clamp(single + diffuseColor * multi, 0.1, 1.0) * NoL;
}

vec3 diffuse_hammon(vec3 albedo, vec3 view, vec3 light, vec3 normal, float roughness) {
	// Diffuse approximation for GGX + Smith microsurfaces.
	// http://gdcvault.com/play/1024478/PBR-Diffuse-Lighting-for-GGX

	float NoL = clamp01(dot(normal, light));
	float NoV = clamp01(dot(normal, view));
	float LoV = dot(light, view);
	float facing = 0.5 * LoV + 0.5;
	float NoH = (NoL + NoV) * inversesqrt(4.0 * facing);

	float single_rough  = facing * (-0.4 * facing + 0.9) * ((0.5 + NoH) / NoH);
	float single_smooth = 1.05 * (1.0 - pow5((1.0 - NoL))) * (1.0 - pow5((1.0 - NoV)));

	float single = clamp01(mix(single_smooth, single_rough, roughness) * RCPPI);
	float multi  = 0.1159 * roughness;

	return NoL * clamp((albedo * multi + single), 0.1, 1.0);
}

vec3 subsurface(vec3 albedo, inout vec3 diffuse, vec3 viewVector, vec3 lightVector, vec3 normal, float alpha) {
    const float g = 0.1;
    const float a = 0.0;

    float NoL = dot(lightVector, normalize(normal));
    float VoL = dot(viewVector, lightVector);

    float SSS_N = (1.0 / (4.0 * PI)) * ((1.0 - pow2(g)) / pow(1.0 + pow2(g) - 2.0 * g * -NoL, 1.5)) * alpha;
    float SSS_V = (1.0 / (4.0 * PI)) * ((1.0 - pow2(g)) / pow(1.0 + pow2(g) - 2.0 * g *  VoL, 1.5));
    vec3  coeff = 1.0 / powf(albedo, 0.25);

    diffuse *= 1.0 - SSS_N;

    return exp(-coeff * a) * SSS_N * SSS_V * PI * 10 * SSS_Brightness;
}

vec3 diffuse(vec3 albedo, scene spaces, vec3 lightDir, vec3 lightColor, vec3 lightAtt, gbuffer info, material mat) {
    vec3 diffuse     =    diffuse_burley(albedo, -spaces.world[2], lightDir, info.normal[0], mat.roughness.x);
    vec3 subsurface  =    subsurface(albedo, diffuse, normalize(spaces.view[2]), lightDir, normalize(info.normal[0]), mat.translucent);

    vec3 shade   = diffuse;
    #ifdef SSS
    shade += subsurface * 2.5;
    #endif
    return shade * lightAtt * lightColor;
}

/*
vec3 specular(material mat, vec3 viewVector, vec3 normal, vec3 reflection) {
    vec3  V   = normalize(-viewVector);
    vec3  R   = reflect(viewVector, normal);
    vec3  H   = normalize(R + V);
    float LoH = dot(R, H);

    float F0  = mix(0.21 * mat.reflectiveness.y, 1.0, mat.metalness.y);

    float fresnel = schlick(F0, LoH) * mat.reflectiveness.y;

    return reflection * fresnel;
}
*/

vec3 BSDF(vec3 albedo, scene spaces, vec3 lightDir, vec3 lightColor, vec3 lightAtt, gbuffer info, material mat) {
    vec3 diffuse = diffuse_burley(albedo, -spaces.world[2], lightDir, info.normal[0], mat.roughness.x);
    return diffuse * lightAtt * lightColor;
}


vec3 distributeMicrofacets(vec3 normal, vec4 noise, float alpha2, vec2 pattern) {
	noise.xyz = normalize(cross(normal, noise.xyz * 2.0 - 1.0));
	return normalize(noise.xyz * sqrt(alpha2 * noise.w / (1.0 - noise.w * 0.9)) + normal);
}

float calculateReflectionMipGGX(vec3 view, vec3 normal, vec3 light, float zDistance, float alpha2) {
	vec3 halfVector = normalize(view + light);

	float NoH = dot(normal, halfVector);

	float p = ((NoH * alpha2 - NoH) * NoH + Specular_Rays) * viewHeight;                                 //Reflection rays in place of 1.0
	return max0(0.25 * log2(4.0 * gbufferProjection[1].y * zDistance * dot(view, halfVector) * p * p / (1.0 * alpha2 * NoH)));
}

float f_dielectric(float NoH, float eta) { // H = N when no roughness
	// Assumes non-polarized
	float p = 1.0 - (eta * eta * (1.0 - NoH * NoH));
	if (p <= 0.0) return 1.0; p = sqrt(p);

	vec2 r = vec2(NoH, p);
	r = (eta * r - r.yx) / (eta * r + r.yx);
	return dot(r, r) * 0.5;
}

float f_dielectric(vec3 viewVector, vec3 normal, float F0) {
    vec3  V   = normalize(-viewVector);
    vec3  R   = reflect(viewVector, normal);
    vec3  H   = normalize(R + V);
    float LoH = dot(R, H);

    return schlick(F0, LoH);
}

float calculateGGXMipLevel(vec3 position, vec3 hitPosition, float roughness) {
	float rsScale = viewHeight * inversesqrt(Specular_Rays); // resolution and sample count
	float positionalScale = distance(position, hitPosition) / -hitPosition.z; // ray length and perspective divide

	return log2(roughness * rsScale * positionalScale);
}
