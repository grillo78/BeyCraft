float gernsterWaves(vec2 coord, float time, float waveSteepness, float waveAmplitude, float waveLength, vec2 waveDirection){
	const float g = 19.6;
    
	float k = TAU / waveLength;
	float w = sqrt(g * k);

	float x = w * time - k * dot(waveDirection, coord);
	float wave = sin(x) * 0.5 + 0.5;

	float h = waveAmplitude * pow(wave, waveSteepness);

	return h;
}

vec2 sincos2(float x){
    return vec2(sin(x),cos(x));
}

#define Water_Speed 1.0
const float windDirectionRad  = radians(45.0);
const vec2  windDirection     = vec2(sin(windDirectionRad), cos(windDirectionRad));

float getWaves(vec2 coord) {
    const int octaves   = 1;

    float movement      = frameTimeCounter * 0.14 * float(materialIDs != 4) * pow2(Water_Speed);

    float waveSteepness = 1.3 * exp2(1.0 / WaveOctaves);
	float waveAmplitude = 0.004 * WaveHeight;
	float waveLength    = 0.45;
    //float weight        = 0.0;
	vec2  waveDirection = -windDirection;
    vec2  noiseMovement = movement * waveDirection * 0.4 * WaveSpeed;
    vec2  noise;

    float waves = 0.0;

    {
        noise          = pow2(noiseSmooth(coord * 0.02 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 1.8;
        waveDirection  = sincos2(windDirectionRad + 0.9);

        #if (WaveOctaves > 1)
        noise          = pow2(noiseSmooth(coord * 0.03 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 0.7;
        waveDirection  = sincos2(windDirectionRad - 1.8);
        #endif

        #if (WaveOctaves > 2)
        noise          = pow2(noiseSmooth(coord * 0.01 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 2.6;
        waveLength    *= 0.8;
        waveDirection  = sincos2(windDirectionRad + 2.7);
        #endif

        #if (WaveOctaves > 3)
        noise          = pow2(noiseSmooth(coord * 0.01 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.3;
        waveAmplitude *= 0.3;
        waveLength    *= 0.4;
        waveDirection  = sincos2(windDirectionRad - 3.6);
        #endif

        #if (WaveOctaves > 4)
        noise          = pow2(noiseSmooth(coord * 0.01 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 1.6;
        waveDirection  = sincos2(windDirectionRad + 4.5);
        #endif

        #if (WaveOctaves > 5)
        noise          = pow2(noiseSmooth(coord * 0.01 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 0.5;
        waveDirection  = sincos2(windDirectionRad - 5.4);
        #endif
    
        #if (WaveOctaves >= 6)
        noise          = pow2(noiseSmooth(coord * 0.03 / sqrt(waveLength) - noiseMovement).xy);
        waves         += -gernsterWaves(coord + (noise) * sqrt(waveLength), movement, waveSteepness, waveAmplitude, waveLength, waveDirection) - noise.y * waveAmplitude;
        waveSteepness *= 1.0;
        waveAmplitude *= 0.6;
        waveLength    *= 0.5;
        waveDirection  = sincos2(windDirectionRad - 8.4);
        #endif
    }

    return waves;
}

float water_getNoise(vec2 coord) {
    vec2 floored = floor(coord);
    vec4 samples = textureGather(noisetex, noiseResInverse * floored);
    vec4 weights = (coord - floored).xxyy * vec4( 1,-1, 1,-1) + vec4(0, 1, 0, 1);
    weights *= weights * (-2.0 * weights + 3.0);
    return dot(samples, weights.yxxy * weights.zzww);
}

struct waveParams {
	vec2 inverseScale;
	vec2 scaledTranslation;
	vec2 skew;
	float height;
	bool sharpen;
	float sharpenThreshold;
	float sharpenMin;
};

float water_calculateWave(vec2 pos, const waveParams params) {
	pos = params.inverseScale * pos + params.scaledTranslation * frameTimeCounter;
	pos = pos.yx * params.skew + pos;
	float wave = water_getNoise(pos);
	if (params.sharpen)
		wave = 1.0 - almostIdentity(abs(wave * 2.0 - 1.0), params.sharpenThreshold, params.sharpenMin);
	return wave * params.height;
}

float water_calculateWaves(vec2 pos) {
	const waveParams[4] params = waveParams[4](
		waveParams(1.0 / vec2(2.50, 2.33), vec2(0.40, 3.43) / vec2(2.50, 3.33), vec2(0.2, 1.3), 0.250, false, 0.16, 0.08),
		waveParams(1.0 / vec2(2.71, 1.11), vec2(0.91,-0.71) / vec2(0.71, 1.11), vec2(0.0, 1.2), 0.120, false, 0.16, 0.08),
		waveParams(1.0 / vec2(0.26, 0.40), vec2(3.62, 0.26) / vec2(0.26, 0.40), vec2(0.0, 1.0), 0.020, false, 0.16, 0.08),
		waveParams(1.0 / vec2(0.09, 0.20), vec2(0.22, 0.16) / vec2(0.09, 0.20), vec2(0.0, 0.3), 0.028, false, 0.16, 0.08)
	);

	float waves = water_calculateWave(pos, params[0]) - params[0].height;
	for (int i = 1; i < params.length(); i++) {
		waves += water_calculateWave(pos, params[i]) - params[i].height;
	}

	return waves * 0.4;
}


vec2 waven(vec2 disp, vec2 pos, float wind, float frequency, float time) {
    float xeta    = frequency * dot(disp, pos) + time * wind;
    float wave = exp(sin(xeta) - 1.0);
    float dxeta   = wave * cos(xeta);
    
    return vec2(wave, -dxeta);
}
uniform float far;
float water_calculateWaves2(vec2 position) {
float timer = (frameTimeCounter * WaveSpeed);
    
    const float windPull    = 0.65 * Drag_Intensity + (rainStrength * 0.5);
    const float height      = 0.65 * WaveHeight;

    float ph                = 0.65 * (1.0 - Cell_Size);

    float iteration         = 0.0;
    float weight            = 1.0;
    float w                 = 0.0;
    float ws                = 0.0;

    float heightMult = ((0.8 - 0.2) * 0.5 + 0.5);

    float windFalse  = 1.5;

    for (int i = 0; i < WaveOctaves; i++) {
        vec2 p = vec2(cos(iteration),  sin(iteration));
        vec2 res = waven(p, p + position, windFalse, ph, timer);
            windFalse *= 1.09;

        position += p * res.y * weight * heightMult * windPull;
        w += weight * res.x;
        iteration += 2.0;
        ws += weight;
        weight = mix(weight, 0.0, 0.2);
        ph *= 1.18;
    }
    
    return (w / ws * heightMult - 1.0) * height;
}

vec3 calculateProceduralNormalsFlat(vec3 worldSpace) {
    vec3 worldSpaceCorrected = worldSpace;
#if MC_VERSION < 11400
    worldSpaceCorrected = -worldSpace;
#endif
    vec2 coord = worldSpaceCorrected.xz - worldSpaceCorrected.y;

	const float delta  = 0.01;
	const float iDelta = 1.0 / delta;
    float sampleC = getWaves(coord                   );
	float sampleX = getWaves(coord + vec2(delta, 0.0));
	float sampleY = getWaves(coord + vec2(0.0, delta));

    vec3 waveNormals = normalize(vec3(
	    (sampleC - sampleX) * iDelta,
        (sampleC - sampleY) * iDelta,
        1.0
    ));

    return waveNormals;
}

void calculateProceduralNormals(inout vec4 normal) {
    if (materialIDs != 1) return;

	vec3 tangentViewSpace = tbnMatrixView * viewSpace;

    vec3 parallaxDirection   = normalize(tangentViewSpace);
    vec3 worldSpaceCorrected = worldSpace + gbufferModelViewInverse[3].xyz;
         //worldSpaceCorrected = water_calculateParallax(worldSpaceCorrected, parallaxDirection);

    vec2 coord = worldSpaceCorrected.xz - worldSpaceCorrected.y;

	const float delta  = 0.01;
	const float iDelta = 1.0 / delta;

    float sampleC = getWaves(coord                   );
	float sampleX = getWaves(coord + vec2(delta, 0.0));
	float sampleY = getWaves(coord + vec2(0.0, delta));



    vec3 waveNormals = normalize(vec3(
	    (sampleC - sampleX) * iDelta,
        (sampleC - sampleY) * iDelta,
        1.0
    ));

    normal.xyz = waveNormals;
    normal.xyz = mix(vec3(0.0, 0.0, 1.0), normal.xyz, clamp(-tangentViewSpace.z, 0.0, 1.0));
}