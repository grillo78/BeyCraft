vec2 calculateRefraction(vec2 coord) {
    vec2 depthtex = vec2(
        texture2D(depthtex0, coord).x,
        texture2D(depthtex1, coord).y
    );
    if (depthtex.x >= depthtex.y || texture2D(colortex3, coord).a >= 1.0) return coord;

    mat2x3 viewSpace  = mat2x3(
        calculateViewSpace(vec3(coord, depthtex.x)),
        calculateViewSpace(vec3(coord, depthtex.y))
    );

    vec3 normalBump = decodeNormal3x16(texture2D(colortex2, coord).x);
    vec3 normalFlat = mat3(gbufferModelViewInverse) * normalize(cross(dFdx(viewSpace[0]), dFdy(viewSpace[0])));

    float refractionDepth = min(distance(viewSpace[0], viewSpace[1]), 0.28 * Refraction_Depth);

    vec2  refractedCoord = coord + (normalBump.xz - normalFlat.xz) * refractionDepth / viewSpace[0].z;
    float refractedDepth = texture2D(depthtex1, refractedCoord).x;
    return depthtex.x > refractedDepth ? coord : refractedCoord;
}


void calculateDispersion(inout gbuffer info, in vec2 coord, material mat) {
    if (info.depthtex.x > info.depthtex.y) return;
    vec2 refraction = coord - texcoord;
    if (isEyeInWater > 0.5 && mat.water > 0.5) return;
    
    mat3x2 dispersionCoord = mat3x2(
        texcoord + refraction * 1.5,
        texcoord + refraction * 1.25,
        texcoord + refraction * 1.0
    );

    info.color[0].r = texture2D(colortex0, dispersionCoord[0]).r;
    info.color[0].g = texture2D(colortex0, dispersionCoord[1]).g;
    info.color[0].b = texture2D(colortex0, dispersionCoord[2]).b;
    if (isEyeInWater > 0.5) info.color[0].r *= 0.8;
    info.color[0].rgb = clamp01(info.color[0].rgb);
}
