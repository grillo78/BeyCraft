void AerialPerspective(inout gbuffer info, scene spaces, in vec3 viewSpace, material mat) {
    
    vec3 lightColor = lightColors[0] * sunTint + lightColors[1] * moonTint;
    vec3 ambientColor = lightColors[2] * lightColor / PI;

    float dist     = length(viewSpace);
    float indoors  = 1.0 - clamp01((-eyeBrightnessSmooth.y + 230) / 100.0);
    float moonFade = smoothstep(0.0, 0.005, -sunVec[1].y);
    float factor   = pow(dist, 1.0) * 0.003 * 1.0;
    float waterDepth  = distance(spaces.world[0], spaces.world[1]);
    float underWaterDepth  = length(spaces.world[0]);
    //if (isEyeInWater > 0.5 && mat.land < 0.5) info.color[0].rgb = vec3(0.0);
    float multiplier = 1.0;
    if (worldTime >= 12500 && worldTime <= 23000) multiplier *= 0.1;

    if (mat.water > 0.5)                       info.lightmap[0].y += 0.1;
    if (mat.water > 0.5 && isEyeInWater < 0.5) info.color[0].rgb += min(ambientColor * 0.0008 * waterDepth * 1.5 * Water_thickness, 0.004) * vec3(0.0, 0.8, 1.0) * indoors * multiplier;
    if (isEyeInWater > 0.5)                    info.color[0].rgb += min(ambientColor * 0.0008 * underWaterDepth * 1.5 * Water_thickness, 0.004) * vec3(0.0, 0.8, 1.0);
    //if (isEyeInWater > 0.5 && mat.water > 0.5)  info.color[0].rgb += min(ambientColor * 0.0008 * underWaterDepth * 1.5 * Water_thickness, 0.004) * vec3(0.0, 0.8, 1.0);
    //if (isEyeInWater > 0.5 && mat.water > 0.5) info.color[0].rgb *= 0.1;
    if (isEyeInWater > 0.5 && mat.water < 0.5 && mat.land <= 0.5) info.color[0].rgb = min(ambientColor * 0.0008 * underWaterDepth * 1.5 * Water_thickness, 0.004) * vec3(0.0, 0.8, 1.0);
    if (mat.land < 0.5 && mat.water > 0.5 && isEyeInWater < 0.5)     info.color[0].rgb = min(ambientColor * 0.0008 * waterDepth * 1.5 * Water_thickness, 0.004) * vec3(0.0, 0.8, 1.0) * multiplier;
}

vec3 foggytime(inout gbuffer info, scene spaces, in vec3 viewSpace, material mat) {
    const float dist     = length(viewSpace);
    const float fog = exp(-dist * 0.02);

    float multiplier = 1.0;
        if (worldTime >= 12500 && worldTime <= 23000) multiplier *= 0.1;

    const vec3 lightColor = lightColors[0] * sunTint + lightColors[1] * moonTint;
    const vec3 ambientColor = lightColors[2] * lightColor / PI;

    const vec3 fogColor = ambientColor * vec3(0.6, 0.7, 0.9);

    float indoors  = 1.0 - clamp01((-eyeBrightnessSmooth.y + 230) / 100.0);


    return mix(info.color[0].rgb, fogColor, 1.0 - fog) * (rainStrength) * indoors * multiplier * rainFog_Strength;
}