#ifdef fsh
  #define varying in
#endif

#ifdef vsh
  #define varying out
  #define attribute in
#endif