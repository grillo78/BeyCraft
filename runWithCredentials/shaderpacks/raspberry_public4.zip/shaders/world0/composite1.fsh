#version 460 compatibility
#define COMPOSITE 1
#define fsh
#include "/lib/Header.glsl"


#include "/program/composite/shading_0.fsh"