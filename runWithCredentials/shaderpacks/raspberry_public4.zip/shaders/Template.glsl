#version 460 compatibility
#define [File Name]
#define [File Extension]
#include "/lib/Syntax.glsl"
#include "/lib/Settings.glsl"
#include "/lib/Utility.glsl"


/* Include program if applicable, stop here if done so */


/* DRAWBUFFERS:01234567 */

layout (location = 0) out vec4 solidColor; // albedo in gbuffers
layout (location = 1) out vec4 solidGbuffer;
layout (location = 2) out vec4 forwardGbuffer;
layout (location = 3) out vec4 forwardColor;
layout (location = 4) out vec4 passthrough1;
layout (location = 5) out vec4 passthrough2;
layout (location = 6) out vec4 skipClear;
layout (location = 7) out vec4 texture; // normally will not be written to, reserved for custom textures


/* I/O */

/* in, data type descending, flats last, example:
   mat4, all ins of each datatype organized alphabetically
    V
    V
    V
   int
   flat mat4
    V
    V
    V
   flat int
*/

/* out, data type descending, example:
   mat4, all outs of each datatype organized alphabetically
    V
    V
    V
   int
*/

/* uniform, data type descending, example:
   sampler2D, all uniforms of each datatype organized alphabetically
   sampler2DShadow
   mat4
    V
    V
    V
   int
*/


/* Libraries */
   
// Utility, organized alphabetically

// Fragment / Vertex (depending on file extension), organized alphabetically

// Texturing, organized alphabetically


/* Functions */


void main() {
    // Calculate gbuffer information
    // Calculate spaces
    
    // Calculate sample patterns (dither / noise)

    // Calculate file wide function inputs (structs to replace globals)


    // Call function voids


    // Write colors to outs
}
   


