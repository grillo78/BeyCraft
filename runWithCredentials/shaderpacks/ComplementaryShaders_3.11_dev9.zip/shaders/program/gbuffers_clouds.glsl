/* 
BSL Shaders v7.1.05 by Capt Tatsu, Complementary Shaders by EminGT
*/ 

//Settings//
#include "/lib/settings.glsl"

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

//Varyings//
#ifndef CLOUDS
varying vec2 texCoord;

varying vec3 normal;
varying vec3 sunVec, upVec;

varying vec4 color;
#endif

#ifdef WEATHER_PERBIOME
uniform float isDry, isRainy, isSnowy;
#endif

//Uniforms//
#ifndef CLOUDS
uniform int isEyeInWater;
uniform int worldTime;

uniform float rainStrength;
uniform float screenBrightness; 
uniform float timeAngle, timeBrightness;
uniform float viewWidth, viewHeight;
uniform float far;
uniform float sunAngle;

uniform ivec2 eyeBrightnessSmooth;

uniform vec3 skyColor;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;

uniform sampler2D texture;

#if AA > 1
uniform int frameCounter;
#endif
#endif

//Common Variables//
#ifndef CLOUDS
float eBS = eyeBrightnessSmooth.y / 240.0;
float sunVisibility  = clamp(dot( sunVec,upVec) + 0.0625, 0.0, 0.125) * 8.0;
float vsBrightness = clamp(screenBrightness, 0.0, 1.0);
#endif

//Includes//
#ifndef CLOUDS
#include "/lib/util/spaceConversion.glsl"
#include "/lib/color/lightColor.glsl"
#include "/lib/color/skyColor.glsl"

#if AA == 2 || AA == 3
#include "/lib/util/jitter.glsl"
#endif
#if AA == 4
#include "/lib/util/jitter2.glsl"
#endif
#endif

//Program//
void main(){
    #ifndef CLOUDS
		vec4 albedo = vec4(1.0, 1.0, 1.0, texture2D(texture, texCoord.xy).a);
		albedo.rgb = pow(albedo.rgb,vec3(2.2));
		
		float quarterNdotU = clamp(0.25 * dot(normal, upVec) + 0.75,0.5,1.0);
		float timeBrightnessS = 1.0 - timeBrightness;
		timeBrightnessS = 1.0 - timeBrightnessS * timeBrightnessS;
		if (rainStrength < 1.0) albedo.rgb = lightCol * sky_ColorSqrt * (0.5 + 0.15 * timeBrightnessS);
		//albedo.rgb *= (1.0 - rainStrength * 0.75);
		if (rainStrength > 0.0) {
			vec3 rainColor = weatherCol*weatherCol * (0.002 + 0.03 * timeBrightnessS + 0.02 * sunVisibility*sunVisibility);
			albedo.rgb = mix(albedo.rgb, rainColor, rainStrength);
		}
		albedo.rgb *= quarterNdotU;
		albedo.a *= CLOUD_OPACITY;

		vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
		#if AA > 1
			vec3 viewPos = ToNDC(vec3(TAAJitter(screenPos.xy, -0.5), screenPos.z));
		#else
			vec3 viewPos = ToNDC(screenPos);
		#endif

		vec3 nViewPos = normalize(viewPos.xyz);

		float NdotU = dot(nViewPos, upVec);
		float cosS = dot(nViewPos, sunVec);

		float scattering = 0.5 * pow(cosS * 0.5 * (2.0 * sunVisibility - 1.0) + 0.5, 6.0);
		//scattering *= scattering;
		albedo.rgb *= 1.0 + scattering * (1.0 - rainStrength);

		float meFactorP = 0.075;
		if (sunAngle > 0.5) {
			if (sunAngle >  0.75) meFactorP = sunAngle - 0.925;
			if (sunAngle <= 0.75) meFactorP = 0.575 - sunAngle;
		}
		meFactorP = max(meFactorP, 0.0);
		vec3 meSkyColor = vec3(0.0);
		if (cosS > 0.0) {
			float meNdotU = 1.0 - abs(NdotU);
			float meFactor = meFactorP * meNdotU * cosS * meNdotU * 12.0 * (1.0 - rainStrength);
			meSkyColor = mix(lightMorning, lightEvening, mefade);
			meSkyColor *= meSkyColor * meSkyColor;
			meSkyColor *= meFactor * meFactor;
		}
		albedo.rgb += meSkyColor * 0.25;
		
		vec3 worldPos = ToWorld(viewPos);
		float lWorldPos = length(worldPos.xz);
		float cloudDistance = 300.0;
		cloudDistance = clamp((cloudDistance - lWorldPos) / cloudDistance, 0.0, 1.0);
		//cloudDistance = sqrt(cloudDistance);
		albedo.a *= cloudDistance;

		vec3 vlAlbedo = mix(vec3(1.0), albedo.rgb, sqrt(albedo.a)) * (1.0 - pow(albedo.a, 64.0));
	#else
		discard;
		vec4 albedo = vec4(1.0);
		vec3 vlAlbedo = vec3(1.0);
	#endif
	
	#ifdef GBUFFER_CODING
		albedo.rgb = vec3(255.0, 255.0, 255.0) / 255.0;
		albedo.rgb = pow(albedo.rgb, vec3(2.2)) * 2.0;
	#endif

    /* DRAWBUFFERS:01 */
    gl_FragData[0] = albedo;
	gl_FragData[1] = vec4(vlAlbedo, 1.0);

	#ifdef ADVANCED_MATERIALS
	/* DRAWBUFFERS:01367 */
	gl_FragData[2] = vec4(0.0, 0.0, 0.0, 1.0);
	gl_FragData[3] = vec4(0.0, 0.0, 0.0, 1.0);
	gl_FragData[4] = vec4(0.0, 0.0, 0.0, 1.0);
	#endif
}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

//Varyings//
#ifndef CLOUDS
varying vec2 texCoord;

varying vec3 normal;
varying vec3 sunVec, upVec;

varying vec4 color;
#endif

//Uniforms//
#ifndef CLOUDS
#if AA == 2 || AA == 3
uniform int frameCounter;

uniform float viewWidth;
uniform float viewHeight;
#endif
#if AA == 4
uniform int frameCounter;

uniform float viewWidth;
uniform float viewHeight;
#endif

uniform float timeAngle;

uniform mat4 gbufferModelView;
#endif

//Includes//
#ifndef CLOUDS
#if AA == 2 || AA == 3
#include "/lib/util/jitter.glsl"
#endif
#if AA == 4
#include "/lib/util/jitter2.glsl"
#endif
#endif

//Program//
void main(){
	#ifndef CLOUDS
		texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

		color = gl_Color;

		normal = normalize(gl_NormalMatrix * gl_Normal);
		
		const vec2 sunRotationData = vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
		float ang = fract(timeAngle - 0.25);
		ang = (ang + (cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
		sunVec = normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) * 2000.0, 1.0)).xyz);

		upVec = normalize(gbufferModelView[1].xyz);
		gl_Position = ftransform();

		#if AA > 1
			gl_Position.xy = TAAJitter(gl_Position.xy, gl_Position.w);
		#endif
	#else
		gl_Position = vec4(0.0);
		return;
	#endif
	
}

#endif