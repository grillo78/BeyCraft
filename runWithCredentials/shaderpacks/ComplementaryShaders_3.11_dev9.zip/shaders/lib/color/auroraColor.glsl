vec3 auroraUColSqrt = vec3(AURORA_UR, AURORA_UG, AURORA_UB) * AURORA_UI / 255.0;
vec3 auroraUCol = auroraUColSqrt * auroraUColSqrt;

vec3 auroraDColSqrt = vec3(AURORA_DR, AURORA_DG, AURORA_DB) * AURORA_DI / 255.0;
vec3 auroraDCol = auroraDColSqrt * auroraDColSqrt;