/* 
BSL Shaders v7.1.05 by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 120 

#extension GL_ARB_shader_texture_lod : enable

#define DEFERRED
#define NETHER
#define FSH

#include "/program/deferred1.glsl"
